<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('AKEEBA_PRO', '1');
define('AKEEBA_VERSION', '3.7.7');
define('AKEEBA_DATE', '2013-05-11');