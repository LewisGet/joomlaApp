<?php
/**
 * @package AkeebaBackup
 * @copyright Copyright (c)2009-2012 Nicholas K. Dionysopoulos
 * @license GNU General Public License version 3, or later
 *
 * @since 1.3
 */

defined('_JEXEC') or die();

JHtml::_('behavior.framework');

$disabled = AKEEBA_PRO ? '' : 'disabled = "disabled"';

$confirmText = JText::_('AKEEBA_POSTSETUP_MSG_MINSTABILITY');
$script = <<<ENDSCRIPT
window.addEvent('domready', function(){
	(function($) {
		$('#akeeba-postsetup-apply').click(function(e){
			var minstability = $('#minstability').val();
			if(minstability != 'stable') {
				var reply=confirm("$confirmText");
				if(!reply) return false;
			}
			$('#adminForm').submit();
		});
	})(akeeba.jQuery);
});

ENDSCRIPT;
JFactory::getDocument()->addScriptDeclaration($script);

?>
<?php if(!version_compare(PHP_VERSION, '5.3.0', 'ge')): ?>
<div style="margin: 1em; padding: 1em; background: #ffff00; border: thick solid red; color: black; font-size: 14pt;" id="notfixedperms">
	<h1 style="margin: 1em 0; color: red; font-size: 22pt;">OUTDATED PHP VERSION</h1>
	<p>You are using an outdated version of PHP which is not properly supported by Akeeba Backup. Please upgrade to PHP 5.3 or later as soon as possible. Future versions of Akeeba Backup will not work at all on PHP 5.2.</p>
</div>
<?php endif; ?>

<div class="akeeba-bootstrap" style="width:100%">
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<input type="hidden" name="option" value="com_akeeba" />
	<input type="hidden" name="view" value="postsetup" />
	<input type="hidden" name="task" id="task" value="save" />
	<input type="hidden" name="<?php echo JFactory::getSession()->getToken()?>" value="1" />
	
	<p><?php echo JText::_('AKEEBA_POSTSETUP_LBL_WHATTHIS'); ?></p>

	<?php if($this->showsrp): ?>
	<label for="srp" class="postsetup-main">
		<input type="checkbox" id="srp" name="srp" <?php if($this->enablesrp): ?>checked="checked"<?php endif; ?> <?php echo $disabled?> />
		<?php echo JText::_('AKEEBA_POSTSETUP_LBL_SRP')?>
	</label>
	</br>
	<?php if(AKEEBA_PRO): ?>
	<div class="postsetup-desc"><?php echo JText::_('AKEEBA_POSTSETUP_DESC_SRP');?></div>
	<?php else: ?>
	<div class="postsetup-desc"><?php echo JText::_('AKEEBA_POSTSETUP_NOTAVAILABLEINCORE');?></div>
	<?php endif; ?>
	<br/>
	<?php else: ?>
	<input type="hidden" id="srp" name="srp" value="0" />
	<?php endif; ?>

	<label for="autoupdate" class="postsetup-main">
		<input type="checkbox" id="autoupdate" name="autoupdate" <?php if($this->enableautoupdate): ?>checked="checked"<?php endif; ?> <?php echo $disabled?> />
		<?php echo JText::_('AKEEBA_POSTSETUP_LBL_AUTOUPDATE')?>
	</label>
	</br>
	<?php if(AKEEBA_PRO): ?>
	<div class="postsetup-desc"><?php echo JText::_('AKEEBA_POSTSETUP_DESC_autoupdate');?></div>
	<?php else: ?>
	<div class="postsetup-desc"><?php echo JText::_('AKEEBA_POSTSETUP_NOTAVAILABLEINCORE');?></div>
	<?php endif; ?>
	<br/>
	
	<label for="confwiz" class="postsetup-main">
		<input type="checkbox" id="confwiz" name="confwiz" <?php if($this->enableconfwiz): ?>checked="checked"<?php endif; ?> />
		<?php echo JText::_('AKEEBA_POSTSETUP_LBL_confwiz')?>
	</label>
	</br>
	<div class="postsetup-desc"><?php echo JText::_('AKEEBA_POSTSETUP_DESC_confwiz');?></div>
	<br/>
	
	<?php if(AKEEBA_PRO): ?>
	<label for="minstability" class="postsetup-main"><?php echo JText::_('AKEEBA_POSTSETUP_LBL_MINSTABILITY')?></label>
	<select id="minstability" name="minstability">
		<option value="alpha" <?php if($this->minstability=='alpha'): ?>selected="selected"<?php endif; ?>><?php echo JText::_('AKEEBA_STABILITY_ALPHA') ?></option>
		<option value="beta" <?php if($this->minstability=='beta'): ?>selected="selected"<?php endif; ?>><?php echo JText::_('AKEEBA_STABILITY_BETA') ?></option>
		<option value="rc" <?php if($this->minstability=='rc'): ?>selected="selected"<?php endif; ?>><?php echo JText::_('AKEEBA_STABILITY_RC') ?></option>
		<option value="stable" <?php if($this->minstability=='stable'): ?>selected="selected"<?php endif; ?>><?php echo JText::_('AKEEBA_STABILITY_STABLE') ?></option>
	</select>
	</br>
	<div class="postsetup-desc"><?php echo JText::_('AKEEBA_POSTSETUP_DESC_MINSTABILITY');?></div>
	<br/>
	<?php else: ?>
	<input type="hidden" id="minstability" name="minstability" value="stable" />
	<?php endif; ?>
	
	<br/>
	<button id="akeeba-postsetup-apply" class="btn-primary btn-large" onclick="return false;"><?php echo JText::_('AKEEBA_POSTSETUP_LBL_APPLY');?></button>

</form>
</div>