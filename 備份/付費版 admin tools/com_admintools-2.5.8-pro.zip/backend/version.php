<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('ADMINTOOLS_VERSION', '2.5.8');
define('ADMINTOOLS_DATE', '2013-09-10');
define('ADMINTOOLS_PRO','1');