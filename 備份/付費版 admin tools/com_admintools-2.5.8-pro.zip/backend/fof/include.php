<?php
defined('_JEXEC') or die();

if(!defined('FOF_INCLUDED')) {
	include_once JPATH_LIBRARIES.'/fof/include.php';

	// Do not remove this line - for some reason, PHP 5.4.1 didn't load this file if I removed this line.
}