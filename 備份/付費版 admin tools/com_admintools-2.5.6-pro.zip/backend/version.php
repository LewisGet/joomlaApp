<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('ADMINTOOLS_VERSION', '2.5.6');
define('ADMINTOOLS_DATE', '2013-06-28');
define('ADMINTOOLS_PRO','1');