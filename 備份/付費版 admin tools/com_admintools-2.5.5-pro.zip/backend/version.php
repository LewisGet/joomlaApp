<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('ADMINTOOLS_VERSION', '2.5.5');
define('ADMINTOOLS_DATE', '2013-05-11');
define('ADMINTOOLS_PRO','1');