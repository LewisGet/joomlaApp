<?php
/**
 * @version		1.0.0
 * @package		Joomla
 * @subpackage	Doc Indexer
 * @author  Tuan Pham Ngoc
 * @copyright	Copyright (C) 2010 Ossolution Team
 * @license		GNU/GPL, see LICENSE.php
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
$mainframe->registerEvent( 'onSearch', 'plgSearchEB' );
$mainframe->registerEvent( 'onSearchAreas', 'plgSearchEBAreas' );
require_once JPATH_ROOT.DS.'components'.DS.'com_eventbooking'.DS.'helper'.DS.'helper.php';
/**
 * @return array An array of search areas
 */
function &plgSearchEBAreas() {
	static $areas = array(
		'eb_search' => 'Events'
	);
	return $areas;
}

/**
* Event Booking Search method
*
* The sql must return the following fields that are used in a common display
* routine: href, title, section, created, text, browsernav
* @param string Target search string
* @param string mathcing option, exact|any|all
* @param string ordering option, newest|oldest|popular|alpha|category
 * @param mixed An array if the search it to be restricted to areas, null if search all
 */
function plgSearchEB( $text, $phrase='', $ordering='', $areas=null )
{	
	$db		=& JFactory::getDBO();	
	if (is_array( $areas )) {
		if (!array_intersect( $areas, array_keys( plgSearchEBAreas()) )) {
			return array();
		}
	}
	// load plugin params info
 	$plugin =& JPluginHelper::getPlugin('search', 'eb_search');
 	$pluginParams = new JParameter( $plugin->params );
	$limit = $pluginParams->def( 'search_limit', 50 );
	$text = trim( $text );
	if ($text == '') {
		return array();
	}
	$section 	= JText::_( 'Events' );
	$wheres 	= array();
	switch ($phrase)
	{
		case 'exact':
			$text		= $db->Quote( '%'.$db->getEscaped( $text, true ).'%', false );
			$wheres2 	= array();
			$wheres2[] 	= 'a.title LIKE '.$text;
			$wheres2[] 	= 'a.short_description LIKE '.$text;
			$wheres2[] 	= 'a.description LIKE '.$text;						
			$where 		= '(' . implode( ') OR (', $wheres2 ) . ')';
			break;

		case 'all':
		case 'any':
		default:
			$words 	= explode( ' ', $text );
			$wheres = array();
			foreach ($words as $word)
			{
				$word		= $db->Quote( '%'.$db->getEscaped( $word, true ).'%', false );
				$wheres2 	= array();
				$wheres2[] 	= 'a.title LIKE '.$word;
				$wheres2[] 	= 'a.short_description LIKE '.$word;
				$wheres2[] 	= 'a.description LIKE '.$word;				
				$wheres[] 	= implode( ' OR ', $wheres2 );
			}
			$where 	= '(' . implode( ($phrase == 'all' ? ') AND (' : ') OR ('), $wheres ) . ')';
			break;
	}

	switch ( $ordering )
	{
		case 'oldest':
			$order = 'a.event_date ASC';
			break;		
		case 'alpha':
			$order = 'a.title ASC';
			break;
		case 'newest':
			$order = 'a.event_date ASC';
		default:
			$order = 'a.ordering ';
	}	
	$user = & JFactory::getUser() ;
	$gid = $user->get('aid');	
	$query = 'SELECT a.id, a.category_id AS cat_id, a.title AS title, a.description AS text, event_date AS `created`, '	
	.$db->Quote($section) .' AS section,'
	. ' "1" AS browsernav'
	. ' FROM #__eb_events AS a'	
	. ' WHERE ('. $where .') AND a.access<='.$gid
	. ' AND a.published = 1'	
	. ' ORDER BY '. $order
	;
	$db->setQuery( $query, 0, $limit );	
	$rows = $db->loadObjectList();
	if (count($rows)) {
		foreach($rows as $key => $row) {		
			$rows[$key]->href = JRoute::_('index.php?option=com_eventbooking&task=view_event&event_id='.$row->id);		
		}	
	}	
	return $rows ;
}
