<?php
// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.plugin.plugin');
class plgContentEBEvent extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	function plgContentEBEvent( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}
	/**	 	 
	 * Method is called by the view
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 */
	function onPrepareContent( &$article, &$params, $limitstart )
	{			
		error_reporting(0) ;
		global $mainframe;
		if ($mainframe->isAdmin())
			return true;
		if ( strpos( $article->text, 'ebevent' ) === false ) {
			return true;
		}
		$regex = "#{ebevent (\d+)}#s";
		$article->text = preg_replace_callback( $regex, array( &$this, '_replaceEBEvent') , $article->text );
		return true;
	}	
	/**
	 * Replace the text with the event detail
	 * 
	 * @param array $matches
	 */
	function _replaceEBEvent(&$matches) {		
		global $mainframe, $Itemid ;	
		require_once JPATH_ROOT.DS.'components'.DS.'com_eventbooking'.DS.'helper'.DS.'fields.php';
		require_once (JPATH_ROOT.DS.'components'.DS.'com_eventbooking'.DS.'helper'.DS.'helper.php');
		require_once (JPATH_ROOT.DS.'components'.DS.'com_eventbooking'.DS.'payments'.DS.'os_payment.php');
		require_once (JPATH_ROOT.DS.'components'.DS.'com_eventbooking'.DS.'payments'.DS.'os_payments.php');
		EventBookingHelper::loadLanguage();		
		$viewConfig['name'] = 'form' ;
		$viewConfig['base_path'] = JPATH_ROOT.DS.'plugins'.DS.'content'.DS.'ebevent' ;
		$viewConfig['template_path'] = JPATH_ROOT.DS.'plugins'.DS.'content'.DS.'ebevent' ;
		$viewConfig['layout'] = 'default' ;
		$view =  new JView($viewConfig) ;	
		$document = & JFactory::getDocument() ;
		$document->addStyleSheet(JURI::base(true).'/components/com_eventbooking/assets/css/style.css') ;
		$db = & JFactory::getDBO();			
		$id = $matches[1] ;			
		if ($id) {
			EventBookingHelper::checkEventAccess($id);
		}
		$sql = 'SELECT COUNT(*) FROM #__eb_events WHERE id='.$id.' AND published= 1' ;
		$db->setQuery($sql) ;
		$totalEvent = $db->loadResult();
		if (!$totalEvent) {
			$mainframe->redirect('index.php?option=com_eventbooking&Itemid='.$Itemid, JText::_('EB_INVALID_EVENT'));			
		} 			
		$config = EventBookingHelper::getConfig();						 	
		$sql = 'SELECT * FROM #__eb_events WHERE id='.$id;
		$db->setQuery($sql) ;									
		$item = $db->loadObject() ;		
		$sql = 'SELECT SUM(number_registrants) FROM #__eb_registrants WHERE event_id='.$id.' AND group_id=0 AND (published = 1 OR (payment_method LIKE "os_offline%" AND published != 2))';		
		$db->setQuery($sql) ;
		$item->total_registrants = (int) $db->loadResult();													
		$tmpl = JRequest::getVar('tmpl', '') ;
		$config->process_plugin = 1 ;		
		if ($config->process_plugin) {
			$dispatcher = & JDispatcher::getInstance();
			JPluginHelper::importPlugin('content');
			$params = new JParameter('');
			$limitstart = 0 ;			
			$article = new stdClass ;
			$article->catid = 0 ; 
			$article->sectionid = 0;
			$article->text = $item->description ;
			$dispatcher->trigger('onPrepareContent', array (& $article, & $params, $limitstart));
			$item->description = $article->text ; 							
		}		
		if ($tmpl == 'component')
			$showTaskBar = false ;
		else 
			$showTaskBar = true ;							
		$user = & JFactory::getUser() ;
		$userId = $user->get('id', 0);
		if ($item->location_id) {
			$sql = 'SELECT * FROM #__eb_locations WHERE id='.$item->location_id ;
			$db->setQuery($sql) ;
			$location = $db->loadObject();
			$view->assignRef('location', $location) ;	
		} 					
		$nullDate = $db->getNullDate();	
		$sql = 'SELECT * FROM #__eb_event_group_prices WHERE event_id='.$item->id.' ORDER BY id';
		$db->setQuery($sql) ;
		$rowGroupRates = $db->loadObjectList();	
		if ($config->event_custom_field) {
			$params = new JParameter($item->custom_fields, JPATH_COMPONENT.DS.'fields.xml') ;
			$params = $params->getParams();			
			$paramData = array() ;
			foreach ($params as $param) {
				$paramData[$param[5]]['title'] = $param[3] ;
				$paramData[$param[5]]['value'] = $param[4] ;
			}						
			$view->assignRef('params', $params) ;
			$view->assignRef('paramData', $paramData) ;			
		}				
		$view->assignRef('item', $item) ;															
		$view->assignRef('Itemid', $Itemid) ;
		$view->assignRef('config', $config) ;
		$view->assignRef('showTaskBar', $showTaskBar) ;					
		$view->assignRef('userId', $userId) ;
		$view->assignRef('nullDate', $nullDate) ;
		$view->assignRef('rowGroupRates', $rowGroupRates) ;													
		ob_start();		
		$view->display() ;	
		$text = ob_get_contents() ;
		ob_end_clean();
		return $text ;					
	}	
}