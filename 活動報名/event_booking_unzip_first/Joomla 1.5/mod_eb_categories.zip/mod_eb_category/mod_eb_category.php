<?php	
	defined('_JEXEC') or die ;	
	$user = & JFactory::getUser();
	require_once JPATH_ROOT.DS.'components'.DS.'com_eventbooking'.DS.'helper'.DS.'helper.php';
	EventBookingHelper::loadLanguage();	
	$db = & JFactory::getDBO();		
	$numberCategories = $params->get('number_categories', 0);
	if (version_compare(JVERSION, '1.6.0', 'ge')) {
	    $sql = 	 'SELECT a.id, a.name, COUNT(b.id) AS total_categories  FROM #__eb_categories AS a LEFT JOIN #__eb_categories AS b ON (a.id = b.parent AND b.published =1) WHERE '
			.' a.parent = 0 AND a.published=1 AND a.access IN ('.implode(',', $user->getAuthorisedViewLevels()).')'
			.' GROUP BY a.id '
			.' ORDER BY a.ordering '
			.( $numberCategories ? ' LIMIT '.$numberCategories : '')
	    ;   
	} else {
	    $sql = 	 'SELECT a.id, a.name, COUNT(b.id) AS total_categories  FROM #__eb_categories AS a LEFT JOIN #__eb_categories AS b ON (a.id = b.parent AND b.published =1) WHERE '
			.' a.parent = 0 AND a.published=1 AND a.access <= '.$user->get('aid')
			.' GROUP BY a.id '
			.' ORDER BY a.ordering '
			.( $numberCategories ? ' LIMIT '.$numberCategories : '')
	    ;
	}	
	$db->setQuery($sql) ;	
	$rows = $db->loadObjectList() ;
	$itemId = (int) $params->get('item_id');
	if (!$itemId)		
	    $itemId = EventBookingHelper::getItemid() ;			 
	require(JModuleHelper::getLayoutPath('mod_eb_category', 'default'));
?>