<?php	
	defined('_JEXEC') or die ('');
	$document = & JFactory::getDocument() ;		
	$styleUrl = JURI::base(true).'/components/com_eventbooking/assets/css/style.css';		
	$document->addStylesheet( $styleUrl, 'text/css', null, null );	
	$user = & JFactory::getUser();
	require_once JPATH_ROOT.DS.'components'.DS.'com_eventbooking'.DS.'helper'.DS.'helper.php';
	EventBookingHelper::loadLanguage();	
	$db =  JFactory::getDBO();		
	$showCategory = $params->get('show_category', 1);
	$showLocation = $params->get('show_location', 0);
	
	$categoryId = JRequest::getInt('category_id', 0);	
	$locationId = JRequest::getInt('location_id', 0);
	
	$text = JRequest::getVar('search') ? JRequest::getVar('search') : JText::_('EB_SEARCH_WORD');
    
	//Build Category Drodown
	if ($showCategory) {
	    if (version_compare(JVERSION, '1.6.0', 'ge')) {
	        $sql = "SELECT id, parent, parent AS parent_id, name, name AS title FROM #__eb_categories WHERE published = 1 AND (`access` = 0 OR `access` IN (".implode(',', $user->getAuthorisedViewLevels())."))";
	    } else {
	        $sql = "SELECT id, parent, name FROM #__eb_categories WHERE published = 1 AND `access` <= ".$user->get('aid');   
	    }	    		
    	$db->setQuery($sql);
    	$rows = $db->loadObjectList();		
    	$children = array();
    	if ($rows)
    	{
    		// first pass - collect children
    		foreach ( $rows as $v )
    		{
    			$pt 	= $v->parent;
    			$list 	= @$children[$pt] ? $children[$pt] : array();
    			array_push( $list, $v );
    			$children[$pt] = $list;
    		}
    	}					
    	$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 0 );				
    	$options 	= array();		
    	$options[] = JHTML::_('select.option', 0, JText::_('EB_SELECT_CATEGORY'));
    	foreach ( $list as $listItem ) {
    		$options[] = JHTML::_('select.option',  $listItem->id, '&nbsp;&nbsp;&nbsp;'. $listItem->treename );
    	}
    	if (version_compare(JVERSION, '1.6.0', 'ge')) {
    	    $lists['category_id'] =  JHTML::_('select.genericlist', $options, 'category_id', ' class="inputbox category_box" ', 'value', 'text', $categoryId);
    	    $lists['category_id'] = JHtml::_('select.genericlist', $options, 'category_id', array(
		        'option.text.toHtml' => false ,
		        'list.attr' => 'class="inputbox category_box" ',
				'option.text' => 'text' ,    
				'option.key' => 'value',
				'list.select' => $categoryId, 		    		    		    		    
		        ));
    	} else {    	    
    	    $lists['category_id'] =  JHTML::_('select.genericlist', $options, 'category_id', ' class="inputbox category_box" ', 'value', 'text', $categoryId);
    	}		    	  
	}    
	
	//Build location dropdown
	if ($showLocation) {
	     $options = array() ;
    	$sql = 'SELECT id, name FROM #__eb_locations  WHERE published=1 ORDER BY name';
    	$db->setQuery($sql) ;
    	$options[] = JHTML::_('select.option', 0, JText::_('EB_SELECT_LOCATION'), 'id', 'name') ;
    	$options = array_merge($options, $db->loadObjectList()) ;    	
    	$lists['location_id'] = JHTML::_('select.genericlist', $options, 'location_id', ' class="inputbox location_box" ', 'id', 'name', $locationId) ;   
	}	
	$itemId = (int)$params->get('item_id');
	if (!$itemId)	
	    $itemId = EventBookingHelper::getItemid() ;			 
			
	require(JModuleHelper::getLayoutPath('mod_eb_search', 'default'));
?>