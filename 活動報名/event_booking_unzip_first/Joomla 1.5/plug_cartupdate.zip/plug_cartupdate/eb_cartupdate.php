<?php
/**
 * @version		1.0
 * @package		Joomla
 * @subpackage	Event Booking
 * @author  Tuan Pham Ngoc
 * @copyright	Copyright (C) 2010 Ossolution Team
 * @license		GNU/GPL, see LICENSE.php
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
$mainframe->registerEvent( 'onAfterPaymentSuccess', 'plgEBCartUpdate' );
/**
* Plugin which subscribe registrants to ACYMailing Newsletters
*/
function plgEBCartUpdate($row) {
	$db = & JFactory::getDBO() ;
	$sql = 'UPDATE #__eb_registrants SET published=1, payment_date=NOW() WHERE cart_id='.$row->id;
	$db->setQuery($sql) ;
	$db->query();	
}	