<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$mainframe->registerEvent( 'onAfterStoreRegistrant', 'plgCCNewsletter' );
/**
* Plugin which subscriber users to CCNewsleters
*/
function plgCCNewsletter($row) {
	$db = & JFactory::getDBO() ;
	$sql = "SELECT COUNT(*) FROM #__ccnewsletter_subscribers WHERE email='$row->email'";
	$db->setQuery($sql) ;
	$total = $db->loadResult();
	if (!$total) {
		$name = $row->first_name . ' ' . $row->last_name ;
		$sql = "INSERT INTO #__ccnewsletter_subscribers(name, email, sdate)
				VALUES('$name', '$row->email', NOW())	
				";
		$db->setQuery($sql) ;			
		$db->query();			
	}
}	