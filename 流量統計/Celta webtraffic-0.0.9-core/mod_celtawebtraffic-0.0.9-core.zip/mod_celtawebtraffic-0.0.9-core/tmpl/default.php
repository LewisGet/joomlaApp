<?php defined('_JEXEC') or die('Restricted access');
/**
 * @package             Joomla
 * @subpackage          CeltaWeb Traffic Module
 * @author              Steven Palmer
 * @author url          http://coalaweb.com
 * @author email        support@coalaweb.com
 * @license             GNU/GPL, see /files/en-GB.license.txt
 * @copyright           Copyright (c) 2012 Steven Palmer All rights reserved.
 * @version             Version 0.0.9 November 2012
 *
 * The CeltaWeb traffic module was inspired by VCNT Thanks to Viktor Vogel {@link http://joomla-extensions.kubik-rubik.de/}
 *
 * CeltaWeb Traffic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

$document = JFactory::getDocument();
$document->addStyleSheet(JURI :: base().'media/mod_celtawebtraffic/css/cw-base.css');
$document->addStyleSheet(JURI :: base().'media/mod_celtawebtraffic/css/themes/'.$select_theme.'/cw-visitors.css');
?>

<div>

	<?php if ($s_today) : ?>
                <?php echo $cssleft_t.''.$today.''.$cssclose ?><?php echo $cssright.''.$today_visitors.''.$cssclose ?><br />
	<?php endif; ?>
	<?php if ($s_yesterday) : ?>
		<?php echo $cssleft_y.''.$yesterday.''.$cssclose ?><?php echo $cssright.''.$yesterday_visitors.''.$cssclose ?><br />
	<?php endif; ?>	
	<?php if ($s_week) : ?>
		<?php echo $cssleft_w.''.$x_week.''.$cssclose ?><?php echo $cssright.''.$week_visitors.''.$cssclose ?><br />
	<?php endif; ?>
	<?php if ($s_month) : ?>
		<?php echo $cssleft_m.''.$x_month.''.$cssclose ?><?php echo $cssright.''.$month_visitors.''.$cssclose ?><br />
	<?php endif; ?>
	<?php if ($s_all) : ?>
		<?php echo $cssleft_a.''.$all.''.$cssclose ?><?php echo $cssright.''.$all_visitors.''.$cssclose ?><br />
	<?php endif; ?>
                
                
<?php if ($hline) : ?>
	<hr/>
<?php endif; ?>

<?php if ($s_guestip) : ?>
	<span class="cw_guestInfo"><?php echo $guestip.' '.$ip?></span>
<?php endif; ?>

 <?php if ($s_guestinfo) : ?>
        <span class="cw_guestInfo"><?php echo $guestinfo.' '.$yourbrowser;?></span>
 <?php endif; ?>

 <?php if ($s_dateTime) : ?>
        <span class="cw_guestInfo"><?php echo $date?></span>
 <?php endif; ?>

<?php if ($copy) : ?>
	<span class="cw_copyrht"><?php echo $powered ?> <a target="_blank" title="CoalaWeb" href="http://coalaweb.com">CoalaWeb</a></span>
<?php endif; ?>
</div>
