DROP TABLE IF EXISTS `#__cwtraffic`;
DROP TABLE IF EXISTS `#__cwtraffic_whoiswho`;
DROP TABLE IF EXISTS `#__cwtraffic_total`;
