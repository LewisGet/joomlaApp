<?php
defined('_JEXEC') or die('Restricted access');

/**
 * @package             Joomla
 * @subpackage          CeltaWeb Traffic Component
 * @author              Steven Palmer
 * @author url          http://coalaweb.com
 * @author email        support@coalaweb.com
 * @license             GNU/GPL, see /files/en-GB.license.txt
 * @copyright           Copyright (c) 2012 Steven Palmer All rights reserved.
 * @version             Version 0.0.9 November 2012
 *
 * CeltaWeb Traffic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_celtawebtraffic'))
{
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}
 
// require helper file
JLoader::register('CeltawebtrafficHelper', dirname(__FILE__) . DS . 'helpers' . DS . 'celtawebtraffic.php');
 
// import joomla controller library
jimport('joomla.application.component.controller');
 
// Get an instance of the controller prefixed by Celtawebtraffic
$controller = JController::getInstance('Celtawebtraffic');
 
// Perform the Request task
$controller->execute(JRequest::getCmd('task'));
 
// Redirect if set by the controller
$controller->redirect();

?>
<div id="cw_poweredbycw">
    <p class="cw_poweredbycw"><?php echo JTEXT::_('COM_CELTAWEBTRAFFIC_POWEREDBY_MSG'); ?> <a href="http://coalaweb.com" target="_blank" title="CoalaWeb">CoalaWeb</a> <?php echo JTEXT::_('COM_CELTAWEBTRAFFIC_POWEREDBY_VERSION'); ?></p>
</div>
