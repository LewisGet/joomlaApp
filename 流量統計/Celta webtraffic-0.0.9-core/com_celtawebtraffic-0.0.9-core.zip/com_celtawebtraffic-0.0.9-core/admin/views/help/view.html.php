<?php
defined('_JEXEC') or die( 'Restricted access' );

/**
 * @package             Joomla
 * @subpackage          CeltaWeb Traffic Component
 * @author              Steven Palmer
 * @author url          http://coalaweb.com
 * @author email        support@coalaweb.com
 * @license             GNU/GPL, see /files/en-GB.license.txt
 * @copyright           Copyright (c) 2012 Steven Palmer All rights reserved.
 * @version             Version 0.0.9 November 2012
 *
 * CeltaWeb Traffic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

jimport('joomla.application.component.view');

class CeltawebtrafficViewHelp extends JView {
    
	function display($tpl = null) 
        {
            $canDo = CeltawebtrafficHelper::getActions();
            JToolBarHelper::title(JText::_('COM_CELTAWEBTRAFFIC_TITLE_MAIN'). ' [ ' . JText::_( 'COM_CELTAWEBTRAFFIC_TITLE_HELP' ) . ' ]' , 'celtawebtraffic.png' );
            JToolBarHelper::back( 'COM_CELTAWEBTRAFFIC_TITLE_CPANEL', 'index.php?option=com_celtawebtraffic' );
            if ($canDo->get('core.admin')) 
		{
			JToolBarHelper::divider();
			JToolBarHelper::preferences('com_celtawebtraffic');
		}

            parent::display($tpl);
	}
}
?>