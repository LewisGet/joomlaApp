<?php
defined('_JEXEC') or die('Restricted access');

/**
 * @package             Joomla
 * @subpackage          CeltaWeb Traffic Component
 * @author              Steven Palmer
 * @author url          http://coalaweb.com
 * @author email        support@coalaweb.com
 * @license             GNU/GPL, see /files/en-GB.license.txt
 * @copyright           Copyright (c) 2012 Steven Palmer All rights reserved.
 * @version             Version 0.0.9 November 2012
 *
 * CeltaWeb Traffic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

JHTML::_('behavior.tooltip');
JHTML::stylesheet('com-celtawebtraffic-base.css', JURI::root().'/media/com_celtawebtraffic/css/');
JHTML::stylesheet('com-celtawebtraffic-help.css', JURI::root().'/media/com_celtawebtraffic/css/');
?>
<head lang="en">
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<title>Getting started with CeltaWeb Traffic</title>
	<!-- Framework CSS -->
	<style type="text/css" media="screen">
		p, table, hr, .box { margin-bottom:25px; }
		.box p { margin-bottom:10px; }
	</style>
</head>


<body>
	<div class="help_container">

		<h3 class="center alt">CeltaWeb Traffic, a Joomla component and module. Documentation by Steven Palmer - Version 0.0.9</h3>

		<hr>

		<h1 class="center">Getting started with CeltaWeb Traffic</h1>

		<div class="borderTop">
			<div class="span-6 colborder info prepend-1">
				<p class="prepend-top">
					<strong>
					Created: February 2012<br>
                                        Last Updated: November 2012<br>
					By: Steven Palmer<br>
					Email: <a href="mailto:coalaweb@gmail.com">support@coalaweb.com</a>
					</strong>
				</p>
			</div><!-- end div .span-6 -->

			<div class="span-12 last">
				<p class="prepend-top append-0" style="text-align: justify;" >Thanks for trying out this CoalaWeb extension, we hope you like it. If you have any questions that are beyond the scope of this help file the best place to get answers would be the CoalaWeb Forum. For more information click <a href="#forum">HERE</a>.</p>
			</div>
		</div><!-- end div .borderTop -->

		<hr>

		<h2 id="toc" class="alt">Table of Contents</h2>
		<ol class="alpha">
			<li><a href="#Component">Component Quick Start</a></li>
                        <li><a href="#Module">Module Quick Start</a></li>
                        <li><a href="#online">Online Documentation</a></li>
                        <li><a href="#forum">Support Forum</a></li>
                        <li><a href="#credits">Sources and Credits</a></li>
		</ol>
		
		<hr>
                <h2 id="Component"><strong>A) Component Quick Start</strong> - <a href="#toc">top</a></h2>
                <p><span class="success">The CeltaWeb Traffic component is broken up into 3 main sections which are explained in detail below.</span></p>
                <h2>Control Panel</h2>
                <p>The first is the <b>Control Panel </b><em>[see figure below]</em>, designed to be an easy starting point. Think of it as the components headquarters. While carrying out tasks you can easily jump from the Control Panel to different sections and then return before moving onto the next one.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_465.png" alt="Figure 1" width="700" height="499" /></p>
                <br clear="LEFT" />
                <h2>Visitors</h2>
                <p>The next section is the <b>Visitors</b> section, where all the visitors to your site are listed. The visitors are displayed with the following information <em>[see figure below]</em>.</p>
                <ul>
                    <li>Their IP address.</li>
                    <li>The date they visited.</li>
                    <li>The time they visited.</li>
                    <li>Name assigned (optional).</li>
                </ul>
                <p>You also have filter and search options. To filter the visitor information you have the following options.</p>
                <ul>
                        <li>IP - Click this title to display the visitor info in numerical order descending click again for ascending.</li>
                        <li>Date of Visit - Click this title to display the visitor info in numerical order descending click again for ascending.</li>
                        <li>IP Owner- Click this title to display the visitor info in alphabetical order descending click again for ascending.</li>
                </ul>
                <p>You also have a search box in the top left here you can choose to enter an IP, Date or IP Owner to search for specific visitor information..</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_464.png" alt="Figure 2" width="700" height="358" /></p>
                <br clear="LEFT" />
                <h2>Known IPs</h2>
                <p>The third section is the <b>KnownIPs</b> section. Here you can give any IP that you recognize, such as your own or any that you are suspicious of, a name and a description <em>[see figures below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_461.png" alt="Figure 3" width="700" height="250" /></p>
                <br clear="LEFT" />
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_463.png" alt="Figure 4" width="700" height="316" /></p>
                <br clear="LEFT" />
                <p>Once you have given a particular IP a name it will automatically display in the <b>IP Owner</b> column of the <b>Visitors</b> section. This will make it easy to look down the list and see occurrences of that IP.</p>
                <h4> Well that's it for the component! We wanted to keep it nice and simple but we have plans to expand, so stay tuned.</h4>
                <hr>
                <h2 id="Module"><strong>B) Module Quick Start</strong> - <a href="#toc">top</a></h2>
                <p><span class="success">The CeltaWeb Traffic module has a huge list of options so we have broken them up into 8 sections which are explained in detail below.</span></p>
                <p><span class="notice">Note: Text boxes for assigning item labels should be left blank for multilingual sites. You will need to use the language files instead.</span></p>
                <h2>General Display Options</h2>
                <p style="text-align: justify;">In this section you have the ability to turn on or off the display for today, yesterday, week, month and total. It's up to you which ones you display. Under each of these options is a text box where you can assign a word to be displayed next to the item but if your site is multilingual leave these blank and use the language files to control what's displayed. The last option in this section is to choose a theme, which will affect which icons are displayed along side the counter items, or you can choose to have no icons <em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_355.png" alt="Figure 5" width="513" height="470" /></p>
                <br clear="LEFT" />
                <h2>Visitor Display Options</h2>
                <p style="text-align: justify;">This section controls what information about the visitor is displayed at the bottom of the module. The first option turns on or off a horizontal line that acts as a separator between the counter items and the visitor information. The next option allows you to decide whether the visitors IP will be displayed or not. As per the <b>General Display Options</b> you also have a text box to assign a word to display next to the IP. The last option is to turn on or off extended visitor information such as the browser and operating system they are using you also have a text box to assign a word to display next to the info. <em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_356.png" alt="Figure 6" width="500" height="262" /></p>
                <br clear="LEFT" />
                <h2>Date and Time Options</h2>
                <p style="text-align: justify;">This section gives you the option to show the date and time at the bottom of the module and in what format to display it. The date and time will be displayed in the current Joomla language making it even easier to integrate into your multi language website.<em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_357.png" alt="Figure 7" width="522" height="162" /></p>
                <br clear="LEFT" />
                <h2>System Options</h2>
                <p style="text-align: justify;">In this section you have three options the first is how many minutes to lock an IP for. This means how much time do you want to pass before an IP is counted again. The second is used to preset the counter if for example you reinstalled your site you could preset the total here. The last is to turn on automatic clean up of the database tables used by system, it will keep the current data but delete out the old entries adding them to a running total. It is recommended to turn this feature on. <em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_359.png" alt="Figure 8" width="511" height="198" /></p>
                <br clear="LEFT" />
                <h2>Module Layout Options</h2>
                <p style="text-align: justify;">In this section you have several options that affect the layout of the module. First is the module spacing which controls the distance the counter items are displayed from the left and right sides of the module. A setting of 1 will push them out to the sides of the module and as the number increases they move towards the center of the module. The next option is the module layout - you have three options to choose from:</p>
                <ul>
                    <li>Default - The vertical layout allows both the counter and visitor info to be displayed.</li>
                    <li>Horizontal - The horizontal layout only displays the counter info.</li>
                    <li>Compact - The compact layout only displays the horizontal text you choose and the <b>Total</b> counter.</li>
                </ul>
                <p style="text-align: justify;">The next option is the horizontal text, which will display to the left of both the horizontal and compact layouts. The last option is the separator, which will be displayed between items in both the horizontal and compact layouts <em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_360.png" alt="Figure 9" width="593" height="224" /></p>
                <br clear="LEFT" />
                <h2>Block Bots</h2>
                <p style="text-align: justify;">In the <b>Block Bots</b> section you can choose to exclude bots from being counted and list the particular bots you want excluded in the text box remembering to separate each bot with a comma <em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_361.png" alt="Figure 10" width="645" height="160" /></p>
                <br clear="LEFT" />
                <h2>Block IPs</h2>
                <p style="text-align: justify;">In the <b>Block IPs</b> section you can choose to exclude IPs from being counted and list the particular IPs you want excluded in the text box remembering to separate each IP with a comma <em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_362.png" alt="Figure 11" width="628" height="157" /></p>
                <br clear="LEFT" />
                <h2>Advanced Options</h2>
                <p style="text-align: justify;">The last section contains the <b>Advanced Options</b>. Here you can turn on or off the caching of the module and set the time to cache for. You also have the option to assign a <b>Module Class Suffix</b>, which allows your template to style the module. The last option is to show support for CeltaWeb, but you can turn this on or off and assign a word to be published next to the link <em>[see figure below]</em>.</p>
                <p><img style="float: left; margin: 5px;" src="http://coalaweb.com/images/Docs/Joomla/Extensions/Traffic/selection_363.png" alt="Figure 12" width="573" height="276" /></p>
                <br clear="LEFT" />
                <hr>
                <h2 id="online"><strong>C) Online Documentation</strong> - <a href="#toc">top</a></h2>
                <p>This guide gives you a good overview of the CeltaWeb Traffic extension. If you want to see our online options click one of the links below.</p>
                <p><span class="notice">Note: This section is being expanded all the time so with each update of this extension drop by and see what's new.</span></p>
                <h3>Online Guides</h3>
                <ul>
                    <li>Online quick start guide. <a href="http://coalaweb.com/en/services/joomla-services-such-a-great-cms/joomla-docs/item/celtaweb-traffic-guide" TARGET="_blank">Click Here</a></li>
                   
                </ul>
                <hr>
                <h2 id="forum"><strong>D) CoalaWeb's Support Forum</strong> - <a href="#toc">top</a></h2>
                <p>Below are the steps to get access to the <strong>Support Forum</strong>, the best place to search for answers to all your questions. Each extension has a forum category assigned to it plus there are general FAQ areas as well.</p>
                <ul>
                    <li>If you are reading this then I'm assuming you have downloaded and installed one of CoalaWeb's extensions, so onto the next step.</li>
                    <li>Next you need to register, so click <a href="http://coalaweb.com/component/users/?view=registration" TARGET="_blank">HERE</a> and then select the link at the top of the forum titled <b>Create an account</b>.</li>
                    <li>Then drop by our forum <a href="http://coalaweb.com/forum/index" TARGET="_blank">HERE</a> and go to the category with the same name as the extension you installed.</li>
                    <li>Check to see if you question has already been answered and, if not, ask away!</li>
                </ul>
                <hr>
		<h2 id="credits"><strong>E) Sources and Credits</strong> - <a href="#toc">top</a></h2>
		<ul>
			<li> The CeltaWeb Traffic module was inspired by VCNT. Thanks to <a href="http://joomla-extensions.kubik-rubik.de" TARGET="_blank">Viktor Vogel.</a></li>
		</ul>
		<hr>

		<p>Once again, thank you for trying this extension. As I mentioned in the <a href="#forum">Support Forum</a> section above, I'll be glad to help you if you have any questions relating to this extension. No guarantees, but I'll do my best to assist.</p>

		<p class="append-bottom alt large"><strong>Steven Palmer (CoalaWeb)</strong></p>
		<p><a href="#toc">Go To Table of Contents</a></p>

		<hr class="space">
	</div><!-- end div .container -->
</body>
</html>
