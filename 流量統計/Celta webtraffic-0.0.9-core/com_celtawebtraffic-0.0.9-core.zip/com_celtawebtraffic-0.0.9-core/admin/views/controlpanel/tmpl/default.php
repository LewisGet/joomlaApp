<?php
defined('_JEXEC') or die('Restricted access');

/**
 * @package             Joomla
 * @subpackage          CeltaWeb Traffic Component
 * @author              Steven Palmer
 * @author url          http://coalaweb.com
 * @author email        support@coalaweb.com
 * @license             GNU/GPL, see /files/en-GB.license.txt
 * @copyright           Copyright (c) 2012 Steven Palmer All rights reserved.
 * @version             Version 0.0.9 November 2012
 *
 * CeltaWeb Traffic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

$user= &JFactory::getUser();
JHTML::stylesheet('com-celtawebtraffic-base.css', JURI::root().'/media/com_celtawebtraffic/css/');
?>

<div id="cpanel" style="float:left;width:40%;">
 
	<div style="float:left;">
    	<div class="icon">
	    	<a href="index.php?option=com_celtawebtraffic&view=visitors">
                    <img alt="<?php echo JText::_('COM_CELTAWEBTRAFFIC_TITLE_VISITORS'); ?>" src="<?php echo JURI::root()?>/media/com_celtawebtraffic/images/icons/icon-48-celtawebtraffic.png" />
                    <span><?php echo JText::_('COM_CELTAWEBTRAFFIC_TITLE_VISITORS'); ?></span>
	    	</a>
    	</div>
  	</div>

        <div style="float:left;">
    	<div class="icon">
	    	<a href="index.php?option=com_celtawebtraffic&view=knownips">
                    <img alt="<?php echo JText::_('COM_CELTAWEBTRAFFIC_TITLE_TRANSLATION'); ?>" src="<?php echo JURI::root()?>/media/com_celtawebtraffic/images/icons/icon-48-celtawebtraffic.png" />
                    <span><?php echo JText::_('COM_CELTAWEBTRAFFIC_TITLE_KNOWNIPS'); ?></span>
	    	</a>
    	</div>
  	</div>

      	<div style="float:left;">
    	<div class="icon">
	    	<a href="index.php?option=com_celtawebtraffic&amp;view=help">
                    <img alt="<?php echo JText::_('COM_CELTAWEBTRAFFIC_TITLE_HELP'); ?>" src="<?php echo JURI::root()?>/media/com_celtawebtraffic/images/icons/icon-48-celtawebtraffic.png" />
                    <span><?php echo JText::_('COM_CELTAWEBTRAFFIC_TITLE_HELP'); ?></span>
	    	</a>
    	</div>
  	</div>

	<div class="clr"></div>
</div>
<div id="tabs" style="float:right; width:40%;">

 	<?php
	jimport('joomla.html.pane');

	$pane =& JPane::getInstance('Tabs');

	echo $pane->startPane('cwtrafficPane');

		echo $pane->startPanel(JText::_('COM_CELTAWEBTRAFFIC_TAB_ABOUT'), 'abouttab');
                ?>
                <div style="text-align:center">
                    <div class="icon">
                        <a href="http://coalaweb.com">
                            <img src="<?php echo JURI::root()?>/media/com_celtawebtraffic/images/icons/coalaweb.png" height="128" alt="CeltaWeb" />
                        </a>
                    </div>
                    <div style="margin: 10px 0px 0px 0px">
                        <h1><?php echo JText::_('COM_CELTAWEBTRAFFIC_TITLE_MAIN');?></h1>
                    </div>
                    <div>
                        <p><?php echo JText::_('COM_CELTAWEBTRAFFIC_DESCRIPTION');?></p>
                        <h2><?php echo JText::_('COM_CELTAWEBTRAFFIC_DOCS_ONLINE');?></h2>
                        <p><a href="http://coalaweb.com/en/services/joomla-services-such-a-great-cms/joomla-docs/item/celtaweb-traffic-guide" TARGET="_blank">English</a></p>
                        <h2><?php echo JText::_('COM_CELTAWEBTRAFFIC_SUPPORT_US');?></h2>
                        <p><?php echo JText::_('COM_CELTAWEBTRAFFIC_SUPPORT_US_DESC');?></p>
                        <p><a href="http://extensions.joomla.org/extensions/site-management/analytics/visitors/20077" target="_blank" title="Review CeltaWeb Traffic">Review CeltaWeb Traffic</a></p>
                        <h2><?php echo JText::_('COM_CELTAWEBTRAFFIC_COPYRIGHT');?></h2>
                        <p><?php echo JText::_('COM_CELTAWEBTRAFFIC_COPYRIGHT_DESC');?></p>
                    </div>
                </div>
		<?php
		echo $pane->endPanel();
            echo $pane->endPane();
	?>
</div>
<div class="clr"></div>






