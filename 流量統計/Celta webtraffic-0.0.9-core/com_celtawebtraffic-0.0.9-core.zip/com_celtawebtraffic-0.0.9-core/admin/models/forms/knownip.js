
window.addEvent('domready', function() {
	document.formvalidator.setHandler('visitors',
		function (value) {
			regex=/^[^0-9]+$/;
			return regex.test(value);
	});
});
window.addEvent('domready', function() {
	document.formvalidator.setHandler('ip',
		function (value) {
			regex=/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
			return regex.test(value);
	});
});
