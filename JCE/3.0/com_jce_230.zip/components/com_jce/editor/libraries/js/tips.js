/*  
 * JCE Editor                 2.3.0
 * @package                 JCE
 * @url                     http://www.joomlacontenteditor.net
 * @copyright               Copyright (C) 2006 - 2012 Ryan Demmer. All rights reserved
 * @license                 GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 * @date                    06 December 2012
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * NOTE : Javascript files have been compressed for speed and can be uncompressed using http://jsbeautifier.org/
 */
(function($){$.support.canvas=false;var isMobile={Android:function(){return navigator.userAgent.match(/Android/i);},BlackBerry:function(){return navigator.userAgent.match(/BlackBerry/i);},iOS:function(){return navigator.userAgent.match(/iPhone|iPad|iPod/i);},Opera:function(){return navigator.userAgent.match(/Opera Mini/i);},Windows:function(){return navigator.userAgent.match(/IEMobile/i);},any:function(){return(isMobile.Android()||isMobile.BlackBerry()||isMobile.iOS()||isMobile.Opera()||isMobile.Windows());}};$.widget("ui.tips",{options:{speed:150,position:'top center',opacity:0.9,className:'',offsets:{'x':16,'y':16},width:200,fixed:true,parent:'body',trigger:'hover',show:$.noop,hide:$.noop,disabled:':disabled, .disabled'},_init:function(options){var self=this;$.extend(this.options,options);if($(this.element).hasClass('wf-tooltip-cancel-ondrag')){this._cancelOnDrag();}
$(this.element).click(function(e){if(self.options.trigger=='click'&&$(this).is(self.options.disabled)){return;}
if(this.nodeName=='A'||$('a',this).length||$(this).hasClass('wf-tooltip-cancel-ondrag')){return;}
if(self.options.trigger=='click'){if($('#jce-tooltip').is(':visible')){return self._end();}
self._start(e);}
if($('#jce-tooltip').hasClass('sticky')){self._unpin();}else{self._pin();}});if(this.options.trigger=='hover'){$(this.element).hover(function(e){if($('#jce-tooltip').hasClass('sticky')||$(this).hasClass('nohover')){return;}
return self._start(e);},function(e){if($('#jce-tooltip').hasClass('sticky')||$(this).hasClass('nohover')){return;}
return self._end();});}},_createTips:function(){var self=this,$tips=$('#jce-tooltip');if(!$tips.get(0)){$tips=$('<div id="jce-tooltip" role="tooltip" aria-hidden="true">'+'<span class="ui-icon ui-icon-close" title="Close"></span>'+'<div class="jce-tooltip-content"></div>'+'</div>').appendTo(this.options.parent);$('#jce-tooltip').append('<div class="jce-tooltip-pointer"></div>');if($.support.leadingWhitespace===false){$('#jce-tooltip div.jce-tooltip-pointer').append('<div class="jce-tooltip-pointer-inner"></div>');}
$('span.ui-icon-close',$tips).click(function(){self._end();}).hide();if($.support.cssFloat){$tips.css('opacity',0);}}
$tips.removeAttr('class').addClass('jce-tooltip').addClass(this.options.className);},_start:function(e){var self=this;this._createTips();var $tips=$('#jce-tooltip');$tips.data('source',this.element);if(this.options.content){var h=this.options.content;}else{var text=$(this.element).attr('title')||'',title='';if(/::/.test(text)){var parts=text.split('::');title=$.trim(parts[0]);text=$.trim(parts[1]);}
$(this.element).data('title',$(this.element).attr('title')).attr('title','');$(this.element).attr('aria-describedby','jce-tooltip');var h='';if(title){h+='<h4>'+title+'</h4>';}
if(text){h+='<p>'+text+'</p>';}}
$('div.jce-tooltip-content',$tips).html(h);$tips.show().attr('aria-hidden','false');if($.support.cssFloat){$tips.animate({'opacity':this.options.opacity},this.options.speed);}else{if(!window.XMLHttpRequest){$tips.css('width',200);}}
this._trigger('show');window.setTimeout(function(){self._position();$tips.css('visibility','visible');},1);},close:function(){return this._end();},_end:function(){var $tips=$('#jce-tooltip'),element=$tips.data('source')||this.element;if($(element).data('title')){$(element).attr('title',$(element).data('title'));}
$(element).removeAttr('aria-describedby');$tips.css('visibility','hidden').attr('aria-hidden','true').hide();if($.support.cssFloat){$tips.css('opacity',0);}
this._trigger('hide');this._unpin();},_cancelOnDrag:function(){var self=this;$(this.element).bind('mousedown',function(){$(this).addClass('nohover');self._end();$(this).data('title',$(this).attr('title')).attr('title','');}).bind('mouseup',function(){$(this).removeClass('nohover');$(this).attr('title',$(this).data('title'));});},_pin:function(){var self=this;$('#jce-tooltip').addClass('sticky');$('span.ui-icon-close','#jce-tooltip').show();$(window).on('click.tooltip-blur',function(e){var el=$(self.element).get(0),n=e.target;if(n==el||(el.nodeName=='LABEL'&&$(el).attr('for')&&n==$('#'+$(el).attr('for')).get(0))||n==$('#jce-tooltip').get(0)){return;}
if($(n).parents('#jce-tooltip').length===0){self._end();}});},_unpin:function(){$('#jce-tooltip').removeClass('sticky');$('span.ui-icon-close','#jce-tooltip').hide();$(window).off('click.tooltip-blur');},_position:function(){var $tips=$('#jce-tooltip');var $pointer=$('.jce-tooltip-pointer',$tips);var o=this.options.offsets;var tip={'width':$tips.outerWidth(),'height':$tips.outerHeight()};$($pointer).attr('style','');var position=this.options.position;var at=position.replace(/\s*center\s*/,'');var my=at.replace(/(left|right|top|bottom)/,function(s){switch(s){case'left':return'right-'+o.x;break;case'right':return'left+'+o.x;break;case'top':return'bottom-'+o.y;break;case'bottom':return'top+'+o.y;break;}});var pos={},ww=Math.round($(window).width()),wh=Math.round($(window).height()),pw=10,ph=10;$tips.position({my:my,at:at,of:$(this.element),collision:'flipfit flipfit',using:function(props,fb){if(Math.round(props.top)==0){props.top+=10;}
if(Math.round(props.left)==0){props.left+=10;}
if(Math.round(props.top+tip.height)==wh){props.top-=10;}
if(Math.round(props.left+tip.width)==ww){props.left-=10;}
if(/left|right/.test(position)){$pointer.css('top',Math.round(fb.target.top-props.top)+(ph/2-1));}
if(/top|bottom/.test(position)&&Math.round(fb.element.left)==0){$pointer.css('left',fb.target.left+Math.round(fb.target.width/2)-pw);}
if(fb.element.left<fb.target.left){position=position.replace('right','left');}else{position=position.replace('left','right');}
if(fb.element.top<fb.target.top){position=position.replace('bottom','top');}else{position=position.replace('top','bottom');}
$tips.css(props);}});$pointer.removeClass('top right bottom left center').addClass(position);},_createPointer:function(position){var $tips=$('#jce-tooltip'),canvas=$('canvas',$tips).get(0),context=canvas.getContext('2d');var w=canvas.width,h=canvas.height;context.clearRect(0,0,canvas.width,canvas.height);context.fillStyle=$tips.css('background-color');context.strokeStyle=$tips.css('border-top-color');context.lineWidth=1.8;context.beginPath();var pos=/(top|bottom|left|right)/.exec(position)||['','top'];switch(pos[1]){case'top':context.moveTo(0,0);context.lineTo(w/2,h);context.lineTo(w,0);break;case'bottom':context.moveTo(0,h);context.lineTo(w/2,0);context.lineTo(w,h);break;case'left':context.moveTo(0,0);context.lineTo(w,h/2);context.lineTo(0,h);break;case'right':context.moveTo(w,0);context.lineTo(0,h/2);context.lineTo(w,h);break;}
context.fill();context.stroke();context.closePath();},_locate:function(e){this._createTips();var $tips=$('#jce-tooltip');var o=this.options.offsets;var page={'x':e.pageX,'y':e.pageY};var tip={'x':$tips.outerWidth(),'y':$tips.outerHeight()};var offset=$(e.target).offset();var pos={'x':page.x+o.x,'y':page.y+o.y};var position=this.options.position;var scrollTop=$(document).scrollTop();if((pos.y-tip.y)<0||offset.top<(scrollTop+tip.y)){$tips.removeClass('jce-'+this.options.className+'-top');position=position.replace('top','bottom');$tips.addClass('jce-'+this.options.className+'-bottom');}else{$tips.removeClass('jce-'+this.options.className+'-bottom');position=position.replace('bottom','top');$tips.addClass('jce-'+this.options.className+'-top');}
switch(position){case'top center':pos.x=(page.x-Math.round((tip.x/2)))+o.x;pos.y=(page.y-tip.y)-o.y;break;case'bottom center':pos.x=(page.x-(tip.x/2))+o.x;pos.y=page.y+o.y;break;}
if(pos.x<0){pos.x=5;}
if(pos.x>parseFloat($(window).width())){pos.x=parseFloat($(window).width())-(tip.x/2+5);}
$tips.css({top:pos.y,left:pos.x});},destroy:function(){$.Widget.prototype.destroy.apply(this,arguments);}});$.extend($.ui.tips,{version:"2.3.0"});})(jQuery);