<?php

class PpinstallerHelperMigrate {
	
	static public function isRequired()
	{
		// I'm not considering  build version
		$old_version = self::oldVersion();
		$new_version = self::requiredVersion();
		
		return version_compare($old_version, $new_version,'<') ? true : false; 
	}
	

	static public function oldVersion($level = '')
	{
		return PpinstallerHelperUtils::version_level(self::payplans_version(),$level);		
	}
	
	/**
	 *  Return Exist PayPlans Version
	 * */
	static public function payplans_version($table_prefix = '#__') 
	{
		$table_name = $table_prefix.'payplans_support';
		
		$db 	= JFactory::getDbo();
		$query  = " SELECT GROUP_CONCAT(`value` ORDER BY `value` SEPARATOR '.') 
					FROM `$table_name`
					WHERE `key`IN ('global_version', 'build_version')
					";
		$db->setQuery($query);
		return $db->loadResult();
	}
	
	static public function requiredVersion($folder_path = null , $level= 'default')
	{
		static $version_level =Array();
		
		// Ticket number #1564
		if(!empty($version_level)){
			return $version_level[$level];
		}
		
		$full_version = PPINSTALLER_PAYPLANS_VERSION.'.'.PPINSTALLER_PAYPLANS_REVISION;

		$explode_version  = explode('.', $full_version );
		
		$version_level['major']		  = $explode_version[0];
		$version_level['minor']		  = $explode_version[1];
		$version_level['build']		  = $explode_version[2];
		$version_level['development'] = $explode_version[3];
		$version_level['default']     = PPINSTALLER_PAYPLANS_VERSION ;		
		
		return $version_level[$level];;	
	}
	
	static function isTableExist($tableName, $prefix='#__')
	{
		$db		 	= JFactory::getDBO();
		$tables		= $db->getTableList();
		
		//if table name consist #__ replace it.
		$tableName = str_replace($prefix, $db->getPrefix(), $tableName);

		//check if table exist
		return in_array($tableName, $tables ) ? true : false;
	}
	
	static public function fileName($version){
		$version = explode('.', $version);
		return "$version[0].$version[1].php"; 
	}
	
	static public function className($version){
		$version = explode('.', $version);
		return "Migrate$version[0]$version[1]"; 
	}	
	
	//XiTODO :: use utilts function
	static public function sessionValue($fun = 'get', $var ='payplans_version' ,$value= '20',$name_space = 'payplans_installer')
	{
		//get new version 
		return JFactory::getSession()->$fun($var, $value, $name_space );
	}
	
	static public function clear_session($variables =Array('payplans_version'))
	{ 
		if(!is_array($variables)){	$variables = Array($variables);	}
		
		foreach($variables as $var){
			PpinstallerHelperUtils::clear_session_value($var);
		}
	}
	
	static public function getFolderPath() 
	{
		$extractdir		 = constant('PPINSTALLER_TMP_PAYPLANS'.PPINSTALLER_PAYPLANS_KIT_SUFFIX);
	
		return $extractdir;
		
	}
	
	static function importSql($fileName)
	{
		$is_success = true;
		$db	= JFactory::getDBO();
		//read file
		if(!($sql = JFile::read($fileName))){
			return false;
		}

		//clean comments from files
		$sql = self::_filterComments($sql);

		//break into queries
		$queries	= $db->splitSql($sql);

		//run queries
		foreach($queries as $query)
		{
			//filter whitespace
			$query = self::_filterWhitespace($query);

			//if query is blank
			if(empty($query)){ continue; }

			//run our query now
			$db->setQuery($query);
			$is_success &= $db->query();

			//if error add it
			PpinstallerHelperLogger::log(JText::_('COM_PPINSTALLER_EXECUTE_QUERY'),$db->getErrorMsg());
		}
		return $is_success;
	}
	
	static function _filterComments($sql)
	{
		return preg_replace("!/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/!s","",$sql);
	}
	
	/*
	 * Filter Unneccessary characters from a query to identify empty query
	 */
	static function _filterWhitespace($sql)
	{
		//query need trimming
		$sql	=  trim($sql,"\n\r\t");

		//remove leading, trailing and "more than one" space in between words
		$pat[0] = "/^\s+/";
		$pat[1] = "/\s+\$/";
		$rep[0] = "";
		$rep[1] = "";
		$sql = preg_replace($pat,$rep,$sql);

		return $sql;
	}
	/**
	 * 
	 * Enter description here ...
	 */
	static public function getKeyValue($key = 'migration_status') 
	{
		$db		=  JFactory::getDbo();
		$query  = " SELECT `value` FROM `#__payplans_support` WHERE `key` = '$key' ";
		$db->setQuery($query);
		$key_value = $db->loadResult();
		return ($key_value) ? $key_value : false;
	}
	
	static public function setKeyValue($key='migration_status',$value='') 
	{	
		if(empty($value)){
			//XITODO:: Handle it
			return false;
		}
		
		$current_status = self::getKeyValue($key);
		if(!$current_status){
			$query = " INSERT INTO `#__payplans_support` 
						   (`key`,`value`)VALUES
						   ('$key','$value')
					  ";
		}else {
			$query = " UPDATE `#__payplans_support`
							SET `value` = '$value'
							WHERE `key` = '$key'
					  ";
		}
		$db		=  JFactory::getDbo();
		$db->setQuery($query);
		$db->query();
		
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_UPDATE_MIGRATION_STATUS',$value),$db->errorMsg());
	}
}