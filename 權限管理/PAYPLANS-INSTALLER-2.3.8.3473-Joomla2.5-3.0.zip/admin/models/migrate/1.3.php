<?php

/**
 *  We don't need any extra migration script. Because everything is alreay done in patches file. 
 */
include_once dirname(__FILE__).DS.'1.4.php';

class Migrate13 extends Migrate14 {}