CREATE TABLE IF NOT EXISTS `#__payplans_invoice`(
	`invoice_id` int(11) NOT NULL AUTO_INCREMENT,
	`object_id` int(11) NOT NULL DEFAULT '0',
	`object_type` varchar(255) DEFAULT NULL,
	`user_id` int(11) NOT NULL,
	`subtotal` decimal(15,5) DEFAULT '0.00000',
	`total` decimal(15,5) NOT NULL DEFAULT '0.00000',
	`currency` char(3) DEFAULT NULL,
	`counter` int(11) DEFAULT '0',
	`status` int(11) NOT NULL DEFAULT '0',
	`params` text,
	`created_date` datetime NOT NULL,
	`modified_date` datetime NOT NULL,
	`checked_out` int(11) DEFAULT '0',
	`checked_out_time` datetime DEFAULT NULL,
  	PRIMARY KEY (`invoice_id`),
  	INDEX `idx_user_id` (`user_id` ASC),
  	INDEX `idx_order_id` (`object_id` ASC)
)
ENGINE=MyISAM 
DEFAULT CHARSET=utf8 ;


CREATE TABLE IF NOT EXISTS `#__payplans_modifier` (
  `modifier_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `amount` decimal(15,5) DEFAULT '0.00000',
  `type` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `message` text,
  `percentage` tinyint(1) NOT NULL DEFAULT '1',
  `serial` int(11) NOT NULL DEFAULT '0',
  `frequency` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`modifier_id`),
  KEY `idx_user_id` (`invoice_id`)
)
ENGINE=MyISAM 
DEFAULT CHARSET=utf8 ;


CREATE TABLE IF NOT EXISTS `#__payplans_transaction`(
	`transaction_id` INT NOT NULL AUTO_INCREMENT,
	`user_id` INT DEFAULT 0,
	`invoice_id` INT DEFAULT 0,
	`current_invoice_id` INT DEFAULT 0,
	`payment_id` INT DEFAULT 0,
	`gateway_txn_id` varchar(255) DEFAULT NULL,
	`gateway_parent_txn` varchar(255) DEFAULT NULL,
	`gateway_subscr_id` varchar(255) DEFAULT NULL,
	`amount` DECIMAL(15,5) DEFAULT '0.00000',
	`reference` varchar(255) NULL,
	`message` varchar(255) NULL,
	`created_date` datetime NOT NULL,
	`params` TEXT NULL,
  	PRIMARY KEY (`transaction_id`),	
  	INDEX `idx_user_id` (`user_id` ASC)
)
ENGINE=MyISAM 
DEFAULT CHARSET=utf8 ;


CREATE TABLE IF NOT EXISTS `#__payplans_wallet`(
	`wallet_id` INT NOT NULL AUTO_INCREMENT,
	`user_id` INT NOT NULL,
	`transaction_id` INT DEFAULT 0,
	`amount` DECIMAL(15,5) DEFAULT '0.00000',
	`message` varchar(255) NULL,
	`invoice_id` INT DEFAULT 0,
	`created_date` datetime NOT NULL,
  	PRIMARY KEY (`wallet_id`),
  	INDEX `idx_user_id` (`user_id` ASC)
)
ENGINE=MyISAM 
DEFAULT CHARSET=utf8 ;
