<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Google Analytics E-Commerce Tracking
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppPap extends PayplansApp
{
	protected $_location	= __FILE__;
	
	public function isApplicable($refObject = null, $eventName='')
	{
		// if not with reference to payment then return
		if($refObject instanceof PayplanssiteViewOrder && $eventName === 'onPayplansViewAfterRender'){
			$order_key = JRequest::getVar('order_key', '');
			$order_id = XiFactory::getEncryptor()->decrypt($order_key);
			$order = PayplansOrder::getInstance($order_id);
			
			return parent::isApplicable($order, $eventName);
		}
	
		return false;
	}
	
	public function onPayplansViewAfterRender(XiView $view, $task, $output)
	{
		XiFactory::getDocument()
					->addScriptDeclaration($this->getAppParam('papScript', ''));
					
		$action = JRequest::getVar('action');
		if($task != 'complete' && $action != 'success'){
			return true;
		}
		
		$user 		   = PayplansUser::getInstance(XiFactory::getUser()->id);
		$order 		   = PayplansOrder::getInstance($view->getModel()->getId());
		$subscription  = array_pop($order->getSubscriptions());

		$papUrl        = $this->getAppParam('papUrl', '');
		$accountId     = $this->getAppParam('accountId','default1');
		$papUsername   = $this->getAppParam('papUsername');
		$papPassword   = $this->getAppParam('papPassword');
		
		require_once('PapApi.class.php');
		
	    $visitorId = @$_COOKIE['PAPVisitorId'];
		
		$saleTracker = new Pap_Api_SaleTracker($papUrl.'/scripts/sale.php',true);
	    $saleTracker->setAccountId($accountId);
	    $saleTracker->setVisitorId($visitorId);
	    
	    $sale1 = $saleTracker->createSale();
        $sale1->setTotalCost($order->getTotal());
		$sale1->setOrderID($order->getKey());
		$sale1->setProductID($subscription->getKey());
		
		$sale1->setData1($user->getEmail());
		$sale1->setData2($user->getRealname());
		$saleTracker->register();
		
		return true;
	}
}