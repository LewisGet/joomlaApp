<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Google Analytics E-Commerce Tracking
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppGanalytics extends PayplansApp
{
	protected $_location	= __FILE__;
	
	public function isApplicable($refObject = null, $eventName='')
	{
		// if not with reference to payment then return
		if($refObject === null || !($refObject instanceof PayplanssiteViewInvoice) 
				|| $eventName != 'onPayplansViewAfterRender'){
			return false;
		}
	
		$newRefObject = PayplansInvoice::getInstance($refObject->getModel()->getId());
		return parent::isApplicable($newRefObject, $eventName);
	}
	
	
	public function onPayplansViewAfterRender(XiView $view, $task, $output)
	{
		$action = JRequest::getVar('action');
		if($task !== 'thanks' && $action != 'success'){
			return true;
		}

		$this->assign('ga_id', $this->getAppParam('ga_id'));
		
		$invoice = PayplansInvoice::getInstance($view->getModel()->getId());
		$order = $invoice->getReferenceObject(PAYPLANS_INSTANCE_REQUIRE);
		
		if(!($order instanceof PayplansOrder)){
			return '';
		}
		
		$this->assign('invoice', $invoice);
		$this->assign('order', $order);
		
		$script = $this->_render('script');
		
		// add javascript to document object
		XiFactory::getDocument()->addScriptDeclaration($script);
		$msg = XiText::_('COM_PAYPLANS_LOGGER_GANALYTICS_ORDER_SALES_TRACKING');
		PayplansHelperLogger::log(XiLogger::LEVEL_INFO, $msg, $this, $script);
		return true;
	}
}