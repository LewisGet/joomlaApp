<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage		Premium Themes
* @contact		payplans@readybytes.in
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Payplans Premium Themes, App, Logs-Feature and Remove-Backlinking Plugin
 *
 * @author Puneet
 */
class plgPayplansPayplansPremium extends XiPlugin
{
	public function onPayplansSystemStart()
	{
		define('PAYPLANS_PREMIUM_BUILD', true);
		
		$themes = dirname(__FILE__).DS.'payplanspremium'.DS.'themes';
		PayplansHelperTheme::addThemePath($themes);
		
		$apps = dirname(__FILE__).DS.'payplanspremium'.DS.'apps';
		PayplansHelperApp::addAppsPath($apps);
		
		return true;
	}
	
}
