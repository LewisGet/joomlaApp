<?php
/**
* @package		M2C
*/

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
* @package		M2C
*/
class M2cViewM2c extends JView
{
	function display( $tpl = null )
	{
		$mainframe	= &JFactory::getApplication();
		$document	= &JFactory::getDocument();


		// Get the page/component configuration
		$params = &$mainframe->getParams();

		$menus	= &JSite::getMenu();
		$menu	= $menus->getActive();
		
		// because the application sets a default page title, we need to get it
		// right from the menu item itself
		$document->setTitle( $params->get( 'page_title' ) );
		$this->assignRef('params',		$params);

		parent::display($tpl);
	}
}
