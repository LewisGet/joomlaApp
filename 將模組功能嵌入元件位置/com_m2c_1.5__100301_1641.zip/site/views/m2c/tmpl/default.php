<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<div class="contentpane<?php echo $this->params->get( 'pageclass_sfx' ); ?>" id="m2c">
<?php if ( $this->params->get( 'show_page_title', 1 ) ) : ?>
	<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
	<?php echo $this->params->get( 'page_title' ); ?>
	</div>
<?php endif; ?>
<?php 
	if(trim($this->params->get('mdescription'))){
		echo '<div id="m2c-description"><p>'.$this->params->get('mdescription')."</p></div>";
	}
	
	jimport('joomla.application.module.helper');
	
	$document	= &JFactory::getDocument();
	$renderer	= $document->loadRenderer('module');
	$params		= array('style'=>'-2');

	$contents = '';
	foreach (JModuleHelper::getModules($this->params->get('position','left')) as $mod)  {
		$contents .= $renderer->render($mod, $params);
	}
	echo $contents;
 ?>
 
</div>
