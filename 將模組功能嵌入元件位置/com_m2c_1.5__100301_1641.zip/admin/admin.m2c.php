<?php
/**
 * @version		$Id: admin.categories.php 10571 2008-07-21 01:27:35Z pasamio $
 * @package		Joomla
 * @subpackage	Categories
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// get parameters from the URL or submitted form

switch (JRequest::getCmd('task')){
	default:
		config($option );
		break;
}

/**
* Compiles a list of categories for a section
* @param string The name of the category section
*/
function config( $option )
{
	global $mainframe;

	$db					=& JFactory::getDBO();
	
	$query = "SELECT id "
	. "\nFROM #__menu "
	. "\n WHERE link = 'index.php?option=".$option."'";
	$db->setQuery($query);
	if(!$result = $db->query()) {
	    echo $db->stderr();
	    return false;
	}
	$menuItem	= $db->loadResult();	
    
    if($menuItem)
    	$mainframe->redirect('index.php?option=com_menus&menutype=mainmenu&task=edit&cid[]='.$menuItem,'Edit Component configuration');
    else
    	$mainframe->redirect('index.php?option=com_menus&task=edit&type=component&url[option]='.$option.'&menutype=mainmenu','You have to create a menu item in order to use this component and change its configuration');
}
?>