<?php
defined('_JEXEC') or die('Restricted access');
/**
* Attachments component
* @package Attachments
* @Copyright (C) 2007, 2008 Jonathan M. Cameron, All Rights Reserved
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @link http://joomlacode.org/gf/project/attachments/frs/
* @author Jonathan M. Cameron
**/

function com_install()
{
    // First make sure that this version of Joomla is 1.5 or greater
    $version = new JVersion();
    if ( (real)$version->RELEASE < 1.5 ) {
        echo "<h1 style=\"color: red;\">This version of M2C will only work on Joomla version 1.5 or later!</h1> For an earlier version please visit: <a href=\"http://joomla.focalizaisso.com.br\">Joomla.Focalizaisso.com.br</a>";
        return false;
        }

    return true;
}
?>