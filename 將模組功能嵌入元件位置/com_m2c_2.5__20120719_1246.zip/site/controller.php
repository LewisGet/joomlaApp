<?php
/**
 * @version SVN: $Id: header.php 18 2010-11-08 01:10:19Z elkuku $
 * @package    M2C
 * @subpackage Base
 * @author     Douglas Machado {@link http://idealextensions.com}
 * @author     Created on 14-Apr-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

// import Joomla controller library
jimport('joomla.application.component.controller');


/**
 * Inherit the JController class.
 *
 * @package M2C
 */
class M2CController extends JController
{
}//class
