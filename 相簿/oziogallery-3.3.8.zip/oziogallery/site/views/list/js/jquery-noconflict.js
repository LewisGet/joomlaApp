// http://api.jquery.com/jQuery.noConflict/
jQuery.noConflict();

