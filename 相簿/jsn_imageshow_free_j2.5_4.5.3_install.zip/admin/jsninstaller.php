<?php
/**
 * @version    $Id: jsninstaller.php 17303 2012-10-23 07:52:09Z cuongnm $
 * @package    JSN_Framework
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Class for finalizing JSN extension installation.
 *
 * @package  JSN_Framework
 * @since    1.0.0
 */
abstract class JSNInstallerScript
{
	/**
	 * XML manifest.
	 *
	 * @var  SimpleXMLElement
	 */
	protected $manifest;

	/**
	 * Implement preflight hook.
	 *
	 * This step will be verify permission for install/update process.
	 *
	 * @param   string  $mode    Install or update?
	 * @param   object  $parent  JInstaller object.
	 *
	 * @return  boolean
	 */
	public function preflight($mode, $parent)
	{
		// Initialize variables
		$installer = $parent->getParent();

		$this->app		= JFactory::getApplication();
		$this->manifest	= $installer->getManifest();

		// Check if installed Joomla version is compatible
		$joomlaVersion	= new JVersion;
		$canInstall		= $joomlaVersion->RELEASE == (string) $this->manifest['version'] ? true : false;

		if ( ! $canInstall)
		{
			$this->app->enqueueMessage(sprintf('Cannot install "%s" because the installation package is not compatible with your installed Joomla version', (string) $this->manifest->name), 'error');
		}

		// Parse dependency
		$this->parseDependency($installer);

		// Check environment
		$canInstallExtension		= true;
		$canInstallSiteLanguage		= is_writable(JPATH_SITE . '/language');
		$canInstallAdminLanguage	= is_writable(JPATH_ADMINISTRATOR . '/language');

		if ( ! $canInstallSiteLanguage)
		{
			$this->app->enqueueMessage(sprintf('Cannot install language file at "%s"', JPATH_SITE . '/language'), 'error');
		}
		else
		{
			foreach (glob(JPATH_SITE . '/language/*', GLOB_ONLYDIR) AS $dir)
			{
				if ( ! is_writable($dir))
				{
					$canInstallSiteLanguage = false;
					$this->app->enqueueMessage(sprintf('Cannot install language file at "%s"', $dir), 'error');
				}
			}
		}

		if ( ! $canInstallAdminLanguage)
		{
			$this->app->enqueueMessage(sprintf('Cannot install language file at "%s"', JPATH_ADMINISTRATOR . '/language'), 'error');
		}
		else
		{
			foreach (glob(JPATH_ADMINISTRATOR . '/language/*', GLOB_ONLYDIR) AS $dir)
			{
				if ( ! is_writable($dir))
				{
					$canInstallAdminLanguage = false;
					$this->app->enqueueMessage(sprintf('Cannot install language file at "%s"', $dir), 'error');
				}
			}
		}

		// Checking directory permissions for dependency installation
		foreach ($this->dependencies AS $extension)
		{
			// Simply continue if extension is set to be removed
			if (isset($extension->remove) AND (int) $extension->remove > 0)
			{
				continue;
			}

			// Check if dependency can be installed
			switch ($extension->type = strtolower($extension->type))
			{
				case 'component':
					$sitePath	= JPATH_SITE . '/components';
					$adminPath	= JPATH_ADMINISTRATOR . '/components';

					if ( ! is_dir($sitePath) OR ! is_writable($sitePath))
					{
						$canInstallExtension = false;
						$this->app->enqueueMessage(sprintf('Cannot install "%s" %s because "%s" is not writable', $extension->name, $extension->type, $sitePath), 'error');
					}

					if ( ! is_dir($adminPath) OR ! is_writable($adminPath))
					{
						$canInstallExtension = false;
						$this->app->enqueueMessage(sprintf('Cannot install "%s" %s because "%s" is not writable', $extension->name, $extension->type, $adminPath), 'error');
					}
				break;

				case 'plugin':
					$path = JPATH_ROOT . '/plugins/' . $extension->folder;

					if ((is_dir($path) AND ! is_writable($path)) OR ( ! is_dir($path) AND ! is_writable(dirname($path))))
					{
						$canInstallExtension = false;
						$this->app->enqueueMessage(sprintf('Cannot install "%s" %s because "%s" is not writable', $extension->name, $extension->type, $path), 'error');
					}
				break;

				case 'module':
				case 'template':
					$path = ($extension->client == 'site' ? JPATH_SITE : JPATH_ADMINISTRATOR) . "/{$extension->type}s";

					if ( ! is_dir($path) OR ! is_writable($path))
					{
						$canInstallExtension = false;
						$this->app->enqueueMessage(sprintf('Cannot install "%s" %s because "%s" is not writable', $extension->name, $extension->type, $path), 'error');
					}
				break;
			}
		}
		
		/******************************* JSN IMAGESHOW ***************************************/
		if ($canInstall && $canInstallExtension && $canInstallSiteLanguage && $canInstallAdminLanguage)
		{
			$extInfo 	= $this->getExtInfo();
		
			if (!is_null($extInfo))
			{
				$info = json_decode($extInfo->manifest_cache);
				
				if (version_compare($info->version, '4.0.0') == -1)
				{
					$this->app->enqueueMessage('JSN ImageShow no longer supports all versions that are older than 4.0.0. Please make a backup file and uninstall current version, then install the latest version and restore data', 'error');
					return false;
				}
								
				if (version_compare($this->manifest->version, $info->version) == -1)
				{
					$this->app->enqueueMessage(sprintf('You cannot install an older version %s on top of the newer version %s', $this->manifest->version, $info->version), 'error');
					return false;
				}	
				
				$session 	= JFactory::getSession();
				$session->set('preversion', $info->version, 'jsnimageshow');
				
				/*The code portion only to maintain for version 4.5.0. Dreprecated*/
				if ($this->manifest->version == '4.5.0')
				{
					$fileISData = $installer->getPath('source') . DS . 'admin' . DS . 'classes' . DS . 'jsn_is_data.php';
					if (is_file($fileISData))
					{
						$dest     = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow' . DS . 'classes' . DS . 'jsn_is_data.php';
						@copy($fileISData, $dest);
					}
				}
				/*The code portion only to maintain for version 4.5.0. Dreprecated*/
				
				/*include_once JPATH_ROOT . DS . 'administrator' . DS . 'components' . DS . 'com_imageshow'. DS . 'classes' . DS . 'jsn_is_factory.php';
					
				$objJSNBackUp = JSNISFactory::getObj('classes.jsn_is_backup');
				$objJSNBackUp->createBackUpFileForMigrate();*/
				
				$fileUpgradeHelper = $installer->getPath('source') . DS . 'admin' . DS . 'subinstall' . DS . 'upgrade.helper.php';

				if (is_file($fileUpgradeHelper))
				{	
					$httpRequestFile 	= JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow' . DS . 'classes' . DS .'jsn_is_httprequest.php';
					$readxmlDetailsFile = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow' . DS . 'classes' . DS . 'jsn_is_readxmldetails.php';
					$comparefilesFile   = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow' . DS . 'classes' . DS . 'jsn_is_comparefiles.php';
					if (is_file($httpRequestFile) && is_file($readxmlDetailsFile) && is_file($comparefilesFile))	
					{	
						include_once $fileUpgradeHelper;
						$objUpgradeHelper	= new JSNUpgradeHelper($this->manifest);
						$objUpgradeHelper->executeUpgrade();
					}
				}
				
				$this->updateSchema($info->version);
								
			}
			else 
			{	
				$session = JFactory::getSession();
				$session->set('preversion', null, 'jsnimageshow');				
			}
		}
		/******************************* JSN IMAGESHOW ***************************************/
		return $canInstall AND $canInstallExtension AND $canInstallSiteLanguage AND $canInstallAdminLanguage;
	}

	/**
	 * Implement postflight hook.
	 *
	 * @param   string  $type    Extension type.
	 * @param   object  $parent  JInstaller object.
	 *
	 * @return  void
	 */
	public function postflight($type, $parent)
	{
		/******************************* JSN IMAGESHOW ***************************************/
		
		$factoryFile 				= JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow'. DS . 'classes' . DS . 'jsn_is_factory.php';
		$upgradeDBUtilFile 			= JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow'. DS . 'classes' . DS . 'jsn_is_upgradedbutil.php';
		$installerMessageFile 		= JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow'. DS . 'classes' . DS . 'jsn_is_installermessage.php';
		
		$imageShowPostFlightFlag 	= false;
		if (is_file($factoryFile) && is_file($upgradeDBUtilFile) && is_file($installerMessageFile))
		{	
			include_once $factoryFile;
			include_once $upgradeDBUtilFile;
			include_once $installerMessageFile;
			$imageShowPostFlightFlag = true;
		}
		/******************************* JSN IMAGESHOW ***************************************/
		// Get original installer
		$installer = $parent->getParent();

		// Process dependency installation
		foreach ($this->dependencies AS $extension)
		{
			// Remove installed extension if requested
			if (isset($extension->remove) AND (int) $extension->remove > 0)
			{
				$this->removeExtension($extension);
				continue;
			}

			// Install only dependency that has local installation package
			if (isset($extension->source))
			{
				// Install and update dependency status
				$this->installExtension($extension);
			}
			elseif ( ! isset($this->missingDependency))
			{
				$this->missingDependency = true;
			}

			// Build query to get dependency installation status
			$db	= JFactory::getDbo();
			$q	= $db->getQuery(true);

			$q->select('custom_data, manifest_cache, params');
			$q->from('#__extensions');
			$q->where("element = '{$extension->name}'");
			$q->where("type = '{$extension->type}'", 'AND');
			$extension->type != 'plugin' OR $q->where("folder = '{$extension->folder}'", 'AND');

			$db->setQuery($q);

			if ($status = $db->loadObject())
			{
				$ext = strtolower($this->manifest->name);
				$dep = array($ext);

				// Backward compatible: move all dependency data from params to custom_data column
				if (is_array($params = (isset($status->params) AND $status->params != '{}') ? (array) json_decode($status->params) : null))
				{
					foreach (array('imageshow', 'poweradmin', 'sample') AS $com)
					{
						if ($com != $ext AND isset($params[$com]))
						{
							$dep[] = $com;
						}
					}
				}

				// Preset dependency object
				$status->custom_data = ! empty($status->custom_data) ? (array) json_decode($status->custom_data) : array();
				$status->custom_data = array_unique(array_merge($status->custom_data, $dep));

				// Build query to update dependency data
				$q = $db->getQuery(true);

				$q->update('#__extensions');
				$q->set("custom_data = '" . json_encode($status->custom_data) . "'");

				// Backward compatible: keep data in this column for older product to recognize
				$manifestCache = json_decode($status->manifest_cache);
				$manifestCache->dependency = $status->custom_data;

				$q->set("manifest_cache = '" . json_encode($manifestCache) . "'");

				// Backward compatible: keep data in this column also for another old product to recognize
				$q->set("params = '" . json_encode((object) array_combine($status->custom_data, $status->custom_data)) . "'");

				$q->where("element = '{$extension->name}'");
				$q->where("type = '{$extension->type}'", 'AND');
				$extension->type != 'plugin' OR $q->where("folder = '{$extension->folder}'", 'AND');

				$db->setQuery($q);
				$db->query();
			}
		}
		
		// Get installed extension directory and name
		$path = $installer->getPath('extension_administrator');
		$name = substr(basename($path), 4);

		if ( ! defined('JSN_' . strtoupper($name) . '_DEPENDENCY'))
		{
			foreach ($this->dependencies AS & $dependency)
			{
				unset($dependency->source);
				unset($dependency->upToDate);
			}
			$this->dependencies = json_encode($this->dependencies);
			
			// Store dependency declaration
			file_exists($defines = $path . '/defines.php') OR file_exists($defines = $path . "/{$name}.defines.php") OR $defines = $path . "/{$name}.php";

			if (is_writable($defines))
			{
				$buffer = preg_replace(
					'/(defined\s*\(\s*._JEXEC.\s*\)[^\n]+\n)/',
					'\1' . "\ndefine('JSN_" . strtoupper($name) . "_DEPENDENCY', '" . $this->dependencies . "');\n",
					file_get_contents($defines)
				);

				JFile::write($defines, $buffer);
			}
		}
		
		/******************************* JSN IMAGESHOW ***************************************/
		$extInfo = $this->getExtInfo();
		
		if (!is_null($extInfo))
		{	
			if ($imageShowPostFlightFlag)
			{	
				$objUpgradeDBUtil	= new JSNISUpgradeDBUtil($installer->getManifest());
				$objUpgradeDBUtil->executeUpgradeDB();
			}
		}
		
		$this->duplicateManifestFile();
		if ($imageShowPostFlightFlag)
		{	
			$objJSNInstMessage 	= new JSNISInstallerMessage();
			$objJSNInstMessage->installMessage();
		}		
		/******************************* JSN IMAGESHOW ***************************************/
		$redirect = $this->app->input->getBool('tool_redirect', true);
				
		if ($redirect)
		{	
			// Do we have any missing dependency
			if ($this->missingDependency)
			{
				if (strpos($_SERVER['HTTP_REFERER'], '/administrator/index.php?option=com_installer') !== false)
				{
					// Set redirect to finalize dependency installation
					$installer->setRedirectURL('index.php?option=com_' . $name . '&view=installer');
				}
				else
				{
					// Let Ajax client redirect
					echo '
						<script type="text/javascript">
							if (window.parent)
								window.parent.location.href ="' . JUri::root() . 'administrator/index.php?option=com_' . $name . '&view=installer";
							else
								location.href ="' . JUri::root() . 'administrator/index.php?option=com_' . $name . '&view=installer";
						</script>';
					exit;
				}
			}
		}
	}

	/**
	 * Implement uninstall hook.
	 *
	 * @param   object  $parent  JInstaller object.
	 *
	 * @return  void
	 */
	public function uninstall($parent)
	{
		// Initialize variables
		$installer = $parent->getParent();

		$this->app			= JFactory::getApplication();
		$this->manifest		= $installer->getManifest();

		// Parse dependency
		$this->parseDependency($installer);

		// Remove all dependency
		foreach ($this->dependencies AS $extension)
		{
			$this->removeExtension($extension);
		}
		
		$this->removeAllThemes();
		$this->removeAllImageSources();
	}

	/**
	 * Retrieve dependency from manifest file.
	 *
	 * @param   object  $installer  JInstaller object.
	 *
	 * @return  object  Return itself for method chaining.
	 */
	protected function parseDependency($installer)
	{
		// Continue only if dependency not checked before
		if ( ! isset($this->dependencies) OR ! is_array($this->dependencies))
		{
			// Preset dependency list
			$this->dependencies = array();

			if (isset($this->manifest->subinstall) AND $this->manifest->subinstall instanceOf SimpleXMLElement)
			{
				// Loop on each node to retrieve dependency information
				foreach ($this->manifest->subinstall->children() AS $node)
				{
					// Verify tag name
					if (strcasecmp($node->getName(), 'extension') != 0)
					{
						continue;
					}

					// Re-create serializable dependency object
					$extension = (array) $node;
					$extension = (object) $extension['@attributes'];

					$extension->title = trim((string) $node != '' ? (string) $node : ($node['title'] ? (string) $node['title'] : (string) $node['name']));

					// Validate dependency
					if ( ! isset($extension->name) OR ! isset($extension->type)
						OR ! in_array($extension->type, array('template', 'plugin', 'module', 'component'))
						OR ($extension->type == 'plugin' AND ! isset($extension->folder)))
					{
						continue;
					}

					// Check if dependency has local installation package
					if (isset($extension->dir) AND is_dir($source = $installer->getPath('source') . '/' . $extension->dir))
					{
						$extension->source	= $source;
					}

					$this->dependencies[] = $extension;
				}
			}
		}

		return $this;
	}

	/**
	 * Install a dependency.
	 *
	 * @param   object   $extension  Object containing extension details.
	 *
	 * @return  void
	 */
	public function installExtension($extension)
	{
		// Get application object
		isset($this->app) OR $this->app = JFactory::getApplication();

		// Get database object
		$db	= JFactory::getDbo();
		$q	= $db->getQuery(true);

		// Build query to get dependency installation status
		$q->select('manifest_cache, custom_data');
		$q->from('#__extensions');
		$q->where("element = '{$extension->name}'");
		$q->where("type = '{$extension->type}'", 'AND');
		$extension->type != 'plugin' OR $q->where("folder = '{$extension->folder}'", 'AND');

		// Execute query
		$db->setQuery($q);

		if ($status = $db->loadObject())
		{
			// Initialize variables
			$jVersion = new JVersion;
			$manifest = json_decode($status->manifest_cache);

			// Get information about the dependency to be installed
			$xml = JPATH::clean($extension->source . '/' . $extension->name . '.xml');

			if (is_file($xml) AND ($xml = simplexml_load_file($xml)))
			{
				if ($jVersion->RELEASE == (string) $xml['version'] AND version_compare($manifest->version, (string) $xml->version, '<'))
				{
					// The dependency to be installed is newer than the existing one, mark for update
					$doInstall = true;
				}

				if ($jVersion->RELEASE != (string) $xml['version'] AND version_compare($manifest->version, (string) $xml->version, '<='))
				{
					// The dependency to be installed might not newer than the existing one but Joomla version is difference, mark for update
					$doInstall = true;
				}
			}
		}
		elseif (isset($extension->source))
		{
			// The dependency to be installed not exist, mark for install
			$doInstall = true;
		}

		if (isset($doInstall) AND $doInstall)
		{
			// Install dependency
			$installer = new JInstaller;

			if ( ! $installer->install($extension->source))
			{
				$this->app->enqueueMessage(sprintf('Error installing "%s" %s', $extension->name, $extension->type), 'error');
			}
			else
			{
				$this->app->enqueueMessage(sprintf('Install "%s" %s was successfull', $extension->name, $extension->type));

				// Update dependency status
				$this->updateExtension($extension);

				// Build query to get dependency installation status
				$q	= $db->getQuery(true);

				$q->select('manifest_cache, custom_data');
				$q->from('#__extensions');
				$q->where("element = '{$extension->name}'");
				$q->where("type = '{$extension->type}'", 'AND');
				$extension->type != 'plugin' OR $q->where("folder = '{$extension->folder}'", 'AND');

				$db->setQuery($q);

				// Load dependency installation status
				$status = $db->loadObject();
			}
		}

		// Update dependency tracking
		if (isset($status))
		{
			$ext = strtolower(isset($this->manifest) ? $this->manifest->name : substr($this->app->input->getCmd('option'), 4));
			$dep = ! empty($status->custom_data) ? (array) json_decode($status->custom_data) : array();

			// Update dependency list
			in_array($ext, $dep) OR $dep[] = $ext;
			$status->custom_data = array_unique($dep);

			// Build query to update dependency data
			$q = $db->getQuery(true);

			$q->update('#__extensions');
			$q->set("custom_data = '" . json_encode($status->custom_data) . "'");

			// Backward compatible: keep data in this column for older product to recognize
			$manifestCache = json_decode($status->manifest_cache);
			$manifestCache->dependency = $status->custom_data;

			$q->set("manifest_cache = '" . json_encode($manifestCache) . "'");

			// Backward compatible: keep data in this column also for another old product to recognize
			$q->set("params = '" . json_encode((object) array_combine($status->custom_data, $status->custom_data)) . "'");

			$q->where("element = '{$extension->name}'");
			$q->where("type = '{$extension->type}'", 'AND');
			$extension->type != 'plugin' OR $q->where("folder = '{$extension->folder}'", 'AND');

			$db->setQuery($q);
			$db->query();
		}
	}

	/**
	 * Update dependency status.
	 *
	 * @param   object  $extension  Extension to update.
	 *
	 * @return  object  Return itself for method chaining.
	 */
	protected function updateExtension($extension)
	{
		// Get object to working with extensions table
		$table = JTable::getInstance('Extension');

		// Load extension record
		$table->load(array('element' => $extension->name));

		// Update extension record
		$table->enabled		= (isset($extension->publish)	AND (int) $extension->publish > 0)	? 1 : 0;
		$table->protected	= (isset($extension->lock)		AND (int) $extension->lock > 0)		? 1 : 0;
		$table->client_id	= (isset($extension->client)	AND $extension->client == 'site')	? 0 : 1;

		// Store updated extension record
		$table->store();

		// Update module instance
		if ($extension->type == 'module')
		{
			// Get object to working with modules table
			$module = JTable::getInstance('module');

			// Load module instance
			$module->load(array('module' => $extension->name));

			// Update module instance
			$module->title		= $extension->title;
			$module->ordering	= isset($extension->ordering) ? $extension->ordering : 0;
			$module->published	= (isset($extension->publish) AND (int) $extension->publish > 0) ? 1 : 0;
			
			if ($hasPosition = (isset($extension->position) AND (string) $extension->position != ''))
			{
				$module->position = (string) $extension->position;
			}
			
			// Store updated module instance
			$module->store();

			// Set module instance to show in all page
			if ($hasPosition AND (int) $module->id > 0)
			{
				// Get database object
				$db	= JFactory::getDbo();
				$q	= $db->getQuery(true);

				try
				{
					// Remove all menu assignment records associated with this module instance
					$q->delete('#__modules_menu');
					$q->where("moduleid = {$module->id}");

					// Execute query
					$db->setQuery($q);
					$db->query();

					// Build query to show this module instance in all page
					$q->insert('#__modules_menu');
					$q->columns('moduleid, menuid');
					$q->values("{$module->id}, 0");

					// Execute query
					$db->setQuery($q);
					$db->query();
				}
				catch (Exception $e)
				{
					throw $e;
				}
			}
		}

		return $this;
	}

	/**
	 * Disable a dependency.
	 *
	 * @param   object  $extension  Extension to update.
	 *
	 * @return  object  Return itself for method chaining.
	 */
	protected function disableExtension($extension)
	{
		// Get database object
		$db	= JFactory::getDbo();
		$q	= $db->getQuery(true);

		// Build query
		$q->update('#__extensions');
		$q->set('enabled = 0');
		$q->where("element = '{$extension->name}'");

		// Execute query
		$db->setQuery($q);
		$db->query();

		return $this;
	}

	/**
	 * Unlock a dependency.
	 *
	 * @param   object  $extension  Extension to update.
	 *
	 * @return  object  Return itself for method chaining.
	 */
	protected function unlockExtension($extension)
	{
		// Get database object
		$db	= JFactory::getDbo();
		$q	= $db->getQuery(true);

		// Build query
		$q->update('#__extensions');
		$q->set('protected = 0');
		$q->where("element = '{$extension->name}'");

		// Execute query
		$db->setQuery($q);
		$db->query();

		return $this;
	}

	/**
	 * Remove a dependency.
	 *
	 * @param   object  $extension  Extension to update.
	 *
	 * @return  object  Return itself for method chaining.
	 */
	protected function removeExtension($extension)
	{
		// Get application object
		isset($this->app) OR $this->app = JFactory::getApplication();

		// Preset dependency status
		$extension->removable = true;

		// Get database object
		$db	= JFactory::getDbo();
		$q	= $db->getQuery(true);

		// Build query to get dependency installation status
		$q->select('extension_id, manifest_cache, custom_data');
		$q->from('#__extensions');
		$q->where("element = '{$extension->name}'");
		$q->where("type = '{$extension->type}'", 'AND');
		$extension->type != 'plugin' OR $q->where("folder = '{$extension->folder}'", 'AND');

		// Execute query
		$db->setQuery($q);

		if ($status = $db->loadObject())
		{
			// Initialize variables
			$id		= $status->extension_id;
			$ext	= strtolower(isset($this->manifest) ? $this->manifest->name : substr($this->app->input->getCmd('option'), 4));
			$deps	= ! empty($status->custom_data) ? (array) json_decode($status->custom_data) : array();

			// Update dependency tracking
			$status->custom_data = array();

			foreach ($deps AS $dep)
			{
				// Backward compatible: ensure that product is not removed
				// if ($dep != $ext)
				if ($dep != $ext AND is_dir(JPATH_BASE . '/components/com_' . $dep))
				{
					$status->custom_data[] = $dep;
				}
			}

			if (count($status->custom_data))
			{
				// Build query to update dependency data
				$q = $db->getQuery(true);

				$q->update('#__extensions');
				$q->set("custom_data = '" . json_encode($status->custom_data) . "'");

				// Backward compatible: keep data in this column for older product to recognize
				$manifestCache = json_decode($status->manifest_cache);
				$manifestCache->dependency = $status->custom_data;

				$q->set("manifest_cache = '" . json_encode($manifestCache) . "'");

				// Backward compatible: keep data in this column also for another old product to recognize
				$q->set("params = '" . json_encode((object) array_combine($status->custom_data, $status->custom_data)) . "'");

				$q->where("element = '{$extension->name}'");
				$q->where("type = '{$extension->type}'", 'AND');
				$extension->type != 'plugin' OR $q->where("folder = '{$extension->folder}'", 'AND');

				$db->setQuery($q);
				$db->query();

				// Indicate that extension is not removable
				$extension->removable = false;
			}
		}
		else
		{
			// Extension was already removed
			$extension->removable = false;
		}

		if ($extension->removable)
		{
			// Disable and unlock dependency
			$this->disableExtension($extension);
			$this->unlockExtension($extension);

			// Remove dependency
			$installer = new JInstaller;

			if ($installer->uninstall($extension->type, $id))
			{
				$this->app->enqueueMessage(sprintf('"%s" %s has been uninstalled', $extension->name, $extension->type));
			}
			else
			{
				$this->app->enqueueMessage(sprintf('Cannot uninstall "%s" %s', $extension->name, $extension->type));
			}
		}

		return $this;
	}
	
	protected function getExtInfo()
	{
		$db 	= JFactory::getDBO();
		$query 	= $db->getQuery(true);
		$query->select('*');
		$query->from('#__extensions');
		$query->where('element=\'com_imageshow\' AND type=\'component\'');
		$db->setQuery($query);
		$result = $db->loadObject();
		return $result;
	}
	
	protected function updateSchema($preVersion)
	{
		$row = JTable::getInstance('extension');
		$eid = $row->find(array('element' => 'com_imageshow', 'type' => 'component'));
		if ($eid)
		{
			$db = JFactory::getDBO();
			$query = $db->getQuery(true);
			$query->select('version_id')
			->from('#__schemas')
			->where('extension_id = ' . $eid);
			$db->setQuery($query);
			$version = $db->loadResult();
			if (is_null($version))
			{
				$query = $db->getQuery(true);
				$query->delete()
				->from('#__schemas')
				->where('extension_id = ' . $eid);
				$db->setQuery($query);
				if ($db->Query())
				{
					$query->clear();
					$query->insert($db->quoteName('#__schemas'));
					$query->columns(array($db->quoteName('extension_id'), $db->quoteName('version_id')));
					$query->values($eid . ', ' . $db->quote($preVersion));
					$db->setQuery($query);
					$db->Query();
				}
			}
		}
	}	
	
	protected function duplicateManifestFile()
	{
		$src	  = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow' . DS . 'imageshow.xml';
		$dest     = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_imageshow' . DS . 'com_imageshow.xml';
		@copy($src, $dest);
	}

	protected function removeAllThemes()
	{
		jimport('joomla.installer.installer');
		require_once dirname(__FILE__) . DS . 'classes' . DS . 'jsn_is_showcasetheme.php';
		$objJSNTheme 	= new JSNISShowcaseTheme();
		$listThemes	 	= $objJSNTheme->listThemes(false);
		$installer 		= new JInstaller();
		$extentsion 	= JTable::getInstance('extension');
		JPluginHelper::importPlugin('jsnimageshow');
		$dispatcher 	= JDispatcher::getInstance();
		if (count($listThemes))
		{
			foreach ($listThemes as $theme)
			{
				$id = trim($theme['id']);
				$extentsion->load($id);
				$extentsion->protected = 0;
				$extentsion->store();
				$dispatcher->trigger('onExtensionBeforeUninstall', array('eid' => $id));
				$result = $installer->uninstall('plugin', $id);
			}
			$this->app->enqueueMessage('Successfully removed all JSN ImageShow Theme plugins');
		}
	}
	
	protected function removeAllImageSources()
	{
		jimport('joomla.installer.installer');
		require_once dirname(__FILE__) . DS . 'classes' . DS . 'jsn_is_factory.php';
		require_once dirname(__FILE__) . DS . 'classes' . DS . 'jsn_is_source.php';
		$objJSNSource 	= new JSNISSource();
		$listImageSources = $objJSNSource->getListSources();
		$installer 		= new JInstaller();
		$extentsion 	= JTable::getInstance('extension');

		if (count($listImageSources))
		{
			foreach ($listImageSources as $imageSource)
			{
				if(isset($imageSource->pluginInfo->extension_id))
				{
					$extentsion->load($imageSource->pluginInfo->extension_id);
					$extentsion->protected = 0;
					$extentsion->store();
					$result = $installer->uninstall('plugin', $imageSource->pluginInfo->extension_id);
				}
			}
			$this->app->enqueueMessage('Successfully removed all JSN ImageShow Sources plugins');
		}
	}	
}
