<?php
/**
 * Abivia Super Table Plugin.
 *
 * @package AbiviaSuperTable
 * @copyright (C) 2011-2012 by Abivia Inc. All rights reserved.
 * @license GNU/GPL
 * @link http://www.abivia.net/
 */
// Check to ensure this file is included in Joomla!
defined('_JEXEC')or die('Restricted access');require_once 'AstArticleBase.php';class AstArticle extends AstArticleBase{protected
function _generateRows($ref){return '<span>Row Highlight is a feature of SuperTable Plus.</span>';}}
