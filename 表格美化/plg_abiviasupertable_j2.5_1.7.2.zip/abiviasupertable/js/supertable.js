/**
 * Abivia Super Table Plugin.
 *
 * @package AbiviaSuperTable
 * @copyright (C) 2011-2012 by Abivia Inc. All rights reserved.
 * @license GNU/GPL
 * @link http://www.abivia.net/
 */

window.addEvent('domready', function() {
	var tablesCol = $$('.supertable-colmode');
	var highlightCol = new Array();
	tablesCol.each(function(table, tableInd) {
        if (table.hasClass('supertable-inactive')) {
            return;
        }
		var columns = table.getElements('.supertable-col');
		columns.each(function(col, colInd) {
			if (col.hasClass('supertable-active')) {
				highlightCol[tableInd] = colInd;
			}
            if (!col.hasClass('supertable-col-rowhead')) {
                col.addEvents({
                    'mouseenter': function() {
                        columns.removeClass('supertable-active');
                        this.addClass('supertable-active');
                    }
                });
            }
		});
		var headcolumns = table.getElements('.supertable-col-rowhead');
		headcolumns.each(function(col, colInd) {
			col.addEvents({
				'mouseleaave': function() {
					columns.removeClass('supertable-active');
					table.getElements('.supertable-col')[highlightCol[tableInd]]
                        .addClass('supertable-active');
				}
			});
		});
		if ($chk(highlightCol[tableInd])) {
			table.addEvent('mouseleave', function() {
				table.getElements('.supertable-col').removeClass('supertable-active');
				table.getElements('.supertable-col')[highlightCol[tableInd]]
                    .addClass('supertable-active');
			});
		}
	});
});
