<?php
/**
 * Abivia Super Table Plugin.
 *
 * @package AbiviaSuperTable
 * @copyright (C) 2011-2012 by Abivia Inc. All rights reserved.
 * @license GNU/GPL
 * @link http://www.abivia.net/
 */
// Check to ensure this file is included in Joomla!
defined('_JEXEC')or die('Restricted access');class AstCompat{static function inject($params){if($params->get('loadMoo',1)
){JHtml::_('behavior.framework',true);}}static function setup($params){}}
