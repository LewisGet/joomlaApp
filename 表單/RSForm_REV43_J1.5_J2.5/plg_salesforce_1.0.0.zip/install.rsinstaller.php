<?php
/**
* @version 1.4.0
* @package RSform!Pro 1.4.0
* @copyright (C) 2007-2011 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/
defined( '_JEXEC' ) or die( 'Restricted access' );

// Get a new installer
$plg_installer = new JInstaller();

$plg_installer->install($this->parent->getPath('source').DS.'rsfpsalesforce');

require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'.DS.'helpers'.DS.'rsform.php');
if (RSFormProHelper::isJ16())
{
	$db->setQuery("UPDATE #__extensions SET `enabled`='1' WHERE `type`='plugin' AND `element`='rsfpsalesforce' AND `folder`='system'");
	$db->query();
}
else
{
	$db->setQuery("UPDATE #__plugins SET published=1 WHERE `element`='rsfpsalesforce' AND `folder`='system'");
	$db->query();
}

$path = array(
	'type' => 'folder',
	'src' => $this->parent->getPath('source').DS.'admin',
	'dest' => JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'
);

$plg_installer->copyFiles(array($path));

$db->setQuery("SHOW COLUMNS FROM `#__rsform_salesforce` WHERE `Field`='slsf_custom_fields'");
if (!$db->loadResult())
{
	$db->setQuery("ALTER TABLE `#__rsform_salesforce` ADD `slsf_industry` VARCHAR( 255 ) NOT NULL AFTER `slsf_debugEmail` ,".
				  "ADD `slsf_description` TEXT NOT NULL AFTER `slsf_industry` ,".
				  "ADD `slsf_mobile` VARCHAR( 255 ) NOT NULL AFTER `slsf_description` ,".
				  "ADD `slsf_fax` VARCHAR( 255 ) NOT NULL AFTER `slsf_mobile` ,".
				  "ADD `slsf_website` VARCHAR( 255 ) NOT NULL AFTER `slsf_fax` ,".
				  "ADD `slsf_salutation` VARCHAR( 255 ) NOT NULL AFTER `slsf_website` ,".
				  "ADD `slsf_revenue` VARCHAR( 255 ) NOT NULL AFTER `slsf_salutation` ,".
				  "ADD `slsf_employees` VARCHAR( 255 ) NOT NULL AFTER `slsf_revenue` ,".
				  "ADD `slsf_custom_fields` TEXT NOT NULL AFTER `slsf_employees`");
	$db->query();
}

$db->setQuery("SHOW COLUMNS FROM `#__rsform_salesforce` WHERE `Field`='slsf_campaign_id'");
if (!$db->loadResult())
{
	$db->setQuery("ALTER TABLE `#__rsform_salesforce` ADD `slsf_campaign_id` VARCHAR( 255 ) NOT NULL AFTER `slsf_custom_fields`");
	$db->query();
}

$db->setQuery("SHOW COLUMNS FROM `#__rsform_salesforce` WHERE `Field`='slsf_donotcall'");
if (!$db->loadResult())
{
	$db->setQuery("ALTER TABLE `#__rsform_salesforce` ADD `slsf_donotcall` VARCHAR( 255 ) NOT NULL AFTER `slsf_campaign_id`, ADD `slsf_emailoptout` VARCHAR( 255 ) NOT NULL AFTER `slsf_donotcall`,
ADD `slsf_faxoptout` VARCHAR( 255 ) NOT NULL AFTER `slsf_emailoptout`");
	$db->query();
}

if (RSFormProHelper::isJ16())
	$this->parent->parseSQLFiles($this->manifest->install->sql);