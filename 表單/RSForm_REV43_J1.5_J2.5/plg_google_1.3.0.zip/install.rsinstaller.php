<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/
defined( '_JEXEC' ) or die( 'Restricted access' );

$db =& JFactory::getDBO();
$db->setQuery("INSERT IGNORE INTO `#__rsform_config` (`ConfigId`, `SettingName`, `SettingValue`) VALUES ('', 'google.code', '')");
$db->query();


// Get a new installer
$plg_installer = new JInstaller();

$plg_installer->install($this->parent->getPath('source').DS.'rsfpgoogle');