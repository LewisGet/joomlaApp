function rsform_hex_to_rgb(h)
{
	h = h.charAt(0)=="#" ? h.substring(1,7) : h;
	r = parseInt(h.substring(0,2),16);
	g = parseInt(h.substring(2,4),16);
	b = parseInt(h.substring(4,6),16);
	
	return [r, g, b];
}