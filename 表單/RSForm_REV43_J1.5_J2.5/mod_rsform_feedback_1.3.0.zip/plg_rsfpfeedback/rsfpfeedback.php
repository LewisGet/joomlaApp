<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * RSForm! Pro system plugin
 */
class plgSystemRSFPFeedback extends JPlugin
{
	var $_products = array();
	
	/**
	 * Constructor
	 *
	 * For php4 compatibility we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	function plgSystemRSFPFeedback( &$subject, $config )
	{
		parent::__construct( $subject, $config );
	}
	
	function _getParams($id)
	{
		//$this->loadLanguage( 'plg_system_rsfpfeedback' );
		
		$db =& JFactory::getDBO();
		
		if (JRequest::getVar('lang'))
		{
			$db->setQuery("SELECT `id` FROM #__languages WHERE `shortcode`='".$db->getEscaped(JRequest::getVar('lang'))."'");
			$lang_id = $db->loadResult();
			if ($lang_id)
			{
				$db->setQuery("SELECT `value` FROM #__jf_content WHERE `language_id`='".(int) $lang_id."' AND `reference_id`='".(int) $id."' AND `reference_table`='modules' AND `reference_field`='params' AND `published`='1'");
				$jf_params = $db->loadResult();
				if ($jf_params)
					return $jf_params;
			}
		}
		
		$db->setQuery("SELECT `params` FROM #__modules WHERE `id`='".(int) $id."' AND `module`='mod_rsform_feedback' AND `published`='1'");
		return $db->loadResult();
	}
	
	function rsfp_f_onSwitchTasks()
	{
		if (JRequest::getVar('plugin_task') == 'feedback.image' && JRequest::getInt('id'))
		{
			$id = JRequest::getInt('id');
			jimport('joomla.html.parameter');
			$params = new JParameter($this->_getParams($id));
			
			switch ($params->get('position', 'right'))
			{
				case 'left':
					$angle = 270;
				break;
				
				default:
				case 'right':
					$angle = 90;
				break;
				
				case 'top':
					$angle = 0;
				break;
				
				case 'bottom':
					$angle = 0;
				break;
			}
			
			
			$options = array(
				'string' 	 => $params->get('string', 'Contact Us!'),
				'size' 		 => $params->get('font-size', 14),
				'angle' 	 => $angle,
				'text-color' => $params->get('text-color', '#000000'),
				'bg-color' 	 => $params->get('bg-color', '#FFFFFF'),
				'font' 		 => $params->get('font', 'ariblk').'.ttf',
				'type' 		 => $params->get('type', 'png'),
				'transparent'=> 0
			);
			
			require_once(JPATH_SITE.DS.'modules'.DS.'mod_rsform_feedback'.DS.'helper.php');
			$img = new RSFormProImageText($options);
			$img->showImage();
		}
	}
	
	function _getHTML($id)
	{
		jimport('joomla.html.parameter');
		$params = new JParameter($this->_getParams($id));
		$sfx = $params->get('moduleclass_sfx');
		$position = $params->get('position', 'left');
		
		$html = '';
		$html .= '<style type="text/css">';
		
		// #rsform_feedback
		$html .= "\n".'#rsform_feedback { ';
		$html .= 'z-index: 999;';
		if ($position == 'left')
			$html .= 'position: fixed; top: 45%; left: 0;';
		elseif ($position == 'right')
			$html .= 'position: fixed; top: 45%; right: 0;';
		elseif ($position == 'top')
		{
			$size = $params->get('font-size', 14) * strlen($params->get('string'));
			$size = (int) ($size / 1.7);
			$html .= 'width: '.$size.'px; margin: 0 auto;';
		}
		elseif ($position == 'bottom')
		{
			$size = $params->get('font-size', 14) * strlen($params->get('string'));
			$size = (int) ($size / 1.7);
			$html .= 'width: '.$size.'px; margin: 0 auto;';
		}
		$html .= '}';
		
		// #rsform_feedback img
		$html .= "\n".'#rsform_feedback img { ';
		$html .= 'background-color: '.$params->get('bg-color', '#FFFFFF').';';
		$html .= 'border: solid 2px '.$params->get('border-color', '#000000').';';
		$html .= 'padding: 5px;';
		$html .= '}';

		// #rsform_feedback_container
		$html .= "\n".'#rsform_feedback_container { ';
		if ($position == 'top')
			$html .= 'width: 100%; position: fixed; top: 0; z-index: 1000;';
		elseif ($position == 'bottom')
			$html .= 'width: 100%; position: fixed; bottom: 0; z-index: 1000;';
		
		$html .= "\n".'</style>';
		
		$html .= '<div id="rsform_feedback_container'.$sfx.'">';
		$html .= '<div id="rsform_feedback'.$sfx.'">';
		
		$a_attr = '';
		if ($params->get('open-in', 'same') == 'new')
			$a_attr .= ' target="_blank"'; 
		elseif ($params->get('open-in', 'same') == 'modal')
			$a_attr .= ' class="modal" rel="{handler: \'iframe\', size: {x: '.(int) $params->get('modal_x', 660).', y: '.(int) $params->get('modal_y', 475).'}}"';
			
		$a_href = '';
		if ((int) $params->get('itemid'))
			$a_href .= '&Itemid='.(int)$params->get('itemid');
		if ($params->get('open-in', 'same') == 'modal')
			$a_href .= '&tmpl=component';
		
		$html .= '<a href="'.JRoute::_('index.php?option=com_rsform&formId='.$params->get('formId').$a_href).'"'.$a_attr.'><img src="'.JRoute::_('index.php?option=com_rsform&task=plugin&plugin_task=feedback.image&id='.$id.'&rand='.@microtime()).'" alt="" /></a>';
		$html .= '</div>';
		$html .= '</div>';
		
		return $html;
	}
	
	function onAfterRender()
	{		
		$mainframe =& JFactory::getApplication();
		
		if ($mainframe->isAdmin()) return;
		if (!defined('RSFORM_FEEDBACK_MODULE')) return;
		
		$content =& JResponse::getBody();
		$html = $this->_getHTML(RSFORM_FEEDBACK_MODULE);
		$content = str_replace('</body>', $html.'</body>', $content);
		JResponse::setBody($content);
	}
}