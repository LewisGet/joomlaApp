<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

$db = &JFactory::getDBO();

if (!JFile::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'.DS.'helpers'.DS.'rsform.php'))
{
	JError::raiseWarning(500, 'You need RSForm! Pro installed first before using this plugin. You can get RSForm! Pro from <a href="http://www.rsjoomla.com/">www.rsjoomla.com</a>');
	return;
}

if (version_compare(phpversion(), '4.3.0') < 0)
{
	JError::raiseWarning(500, 'You need at least PHP 4.3.0 to use this module. Please update your PHP version.');
	return;
}

require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'.DS.'helpers'.DS.'rsform.php');

// Get a new installer
$plg_installer = new JInstaller();

$plg_installer->install($this->parent->getPath('source').DS.'plg_rsfpfeedback');
if (RSFormProHelper::isJ16())
{
	$db->setQuery("UPDATE #__extensions SET `enabled`='1' WHERE `type`='plugin' AND `element`='rsfpfeedback' AND `folder`='system'");
	$db->query();
}
else
{
	$db->setQuery("UPDATE #__plugins SET published=1 WHERE `element`='rsfpfeedback' AND `folder`='system'");
	$db->query();
}

$plg_installer->install($this->parent->getPath('source').DS.'mod_rsform_feedback');

$path = array(
	'type' => 'folder',
	'src' => $this->parent->getPath('source').DS.'admin',
	'dest' => JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'
);
$plg_installer->copyFiles(array($path), true);

$path = array(
	'type' => 'folder',
	'src' => $this->parent->getPath('source').DS.'site',
	'dest' => JPATH_SITE.DS.'components'.DS.'com_rsform'
);
$plg_installer->copyFiles(array($path), true);