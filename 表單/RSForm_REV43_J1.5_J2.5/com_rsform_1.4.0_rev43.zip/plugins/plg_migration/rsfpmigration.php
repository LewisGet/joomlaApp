<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2011 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * RSForm! Pro system plugin
 */
class plgSystemRSFPMigration extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatibility we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	function plgSystemRSFPMigration( &$subject, $config )
	{
		parent::__construct( $subject, $config );
		$this->loadLanguage( 'plg_system_rsfpmigration' );
	}
	
	function canRun()
	{
		if (class_exists('RSFormProHelper')) return true;
		
		$helper = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'.DS.'helpers'.DS.'rsform.php';
		if (file_exists($helper))
		{
			require_once($helper);
			RSFormProHelper::readConfig();
			return true;
		}
		
		return false;
	}
	
	function rsfp_bk_onSwitchTasks()
	{
		global $mainframe;
		$migrationTask = JRequest::getVar('migration_task');
		switch($migrationTask)
		{
			case 'migration.process':
				$this->migrationProcess();
			break;
			
			default:
			break;
		}
	}
	
	function rsfp_bk_onAfterShowConfigurationTabs()
	{
		if (!$this->canRun()) return;
		
		jimport('joomla.html.pane');
		$tabs =& JPane::getInstance('Tabs', array(), true);
		
		echo $tabs->startPanel(JText::_('RSFP_MIGRATION_LABEL'), 'form-migration');
			$this->migrationScreen();
		echo $tabs->endPanel();
	}
	
	
		
	function migrationScreen()
	{		
		$db = JFactory::getDBO();
		$db->setQuery("SHOW TABLES LIKE '%_forme_forms'");
		$exist = $db->loadResult();
		
		if($exist)
		{
			$db->setQuery("SELECT COUNT(id) FROM #__forme_forms");
			$exist = $db->loadResult();
		}
		?>
		<table class="adminform">
		<tr>
			<th><?php echo $exist ? JText::_('RSFP_MIGRATION_TITLE_HEAD') : JText::_('RSFP_MIGRATION_TITLE_NOFORM_HEAD'); ?></th>
		</tr>
		<tr>
			<td align="left">
			<?php if ($exist) { ?>
				<input class="button" type="button" value="<?php printf(JText::_('RSFP_MIGRATION_BTN'),$exist);?>" onclick="document.location='index.php?option=com_rsform&task=plugin&migration_task=migration.process';"/>
			<?php } else { ?>
				<?php echo JText::_('RSFP_MIGRATION_INSTRUCTIONS');?>
			<?php } ?>
			</td>
		</tr>
		<tr>
			<td align="left">
				<?php echo JText::_('RSFP_MIGRATION_INSTRUCTIONS');?>
			</td>
		</tr>
		</table>
		<?php
	}
		
	function migrationProcess()
	{
		global $mainframe;
		
		$db = JFactory::getDBO();
		
		$db->setQuery("SELECT * FROM #__forme_forms");
		$forms = $db->loadObjectList();
		foreach ($forms as $form)
		{			
			$db->setQuery("INSERT INTO #__rsform_forms SET `FormName`='".$db->getEscaped($form->name)."', `FormLayout`='', `FormLayoutName`='inline', `FormLayoutAutogenerate`=0, `FormTitle`='".$db->getEscaped($form->title)."', `Published`='".(int) $form->published."', `Lang`='', `ReturnUrl`='".$db->getEscaped($db->getEscaped($form->return_url))."', `Thankyou`='".$db->getEscaped($form->thankyou)."', `UserEmailText`='".$db->getEscaped($form->email)."', `UserEmailTo`='".$db->getEscaped($form->emailto)."', `UserEmailFrom`='".$db->getEscaped($form->emailfrom)."', `UserEmailFromName`='".$db->getEscaped($form->emailfromname)."', `UserEmailSubject`='".$db->getEscaped($form->emailsubject)."', `UserEmailMode`='".$db->getEscaped($form->emailmode)."'");
			$db->query();
			$formId = $db->insertid();
			
			$newform 	= $form;
			$formLayout = '';
			
			$db->setQuery("SELECT * FROM #__forme_fields WHERE form_id = '".(int) $form->id."' ORDER BY ordering");
			$fields = $db->loadObjectList();
			foreach ($fields as $field)
			{				
				if ($field->fieldstyle == '')
					$field->fieldstyle = $form->fieldstyle;
				
				$inputtype = $this->getComponentTypeId($field->inputtype);
				
				$db->setQuery("INSERT INTO #__rsform_components SET `FormId`='".$formId."', `ComponentTypeId`='".$inputtype."', `Order`='".$field->ordering."', `Published`='".$field->published."'");
				$db->query();
				$componentId = $db->insertid();
				
				$db->setQuery("INSERT INTO #__rsform_properties (`PropertyId`, `ComponentId`, `PropertyName`, `PropertyValue`) VALUES ".$this->parseComponent($inputtype, $field, $componentId)."");
				$db->query();
				
				$field->fieldstyle = str_replace('{fieldtitle}','{'.$field->name.':caption}',$field->fieldstyle);
				$field->fieldstyle = str_replace('{field}','{'.$field->name.':body}'.'<br/>{'.$field->name.':validation}',$field->fieldstyle);
				$field->fieldstyle = str_replace('{fielddesc}','{'.$field->name.':description}',$field->fieldstyle);
				$field->fieldstyle = str_replace('{validationsign}',($field->validation_rule == '' ? '':' (*) '),$field->fieldstyle);
				
				if ($field->published)
					$formLayout .= $field->fieldstyle;
			
				$newform = $this->changePlaceholdersValues($field->name, $newform);
			}
			
			$thankyou_enabled = 0;
			if (!empty($newform->thankyou))
				$thankyou_enabled = 1;
			
			$db->setQuery("UPDATE #__rsform_forms SET `ReturnUrl` = '".$db->getEscaped($newform->return_url)."', `Thankyou` = '".$db->getEscaped($newform->thankyou)."', `UserEmailText` = '".$db->getEscaped($newform->email)."', `UserEmailTo` = '".$db->getEscaped($newform->emailto)."', `UserEmailFrom` = '".$db->getEscaped($newform->emailfrom)."', `UserEmailFromName` = '".$db->getEscaped($newform->emailfromname)."', `UserEmailSubject` = '".$db->getEscaped($newform->emailsubject)."' WHERE FormId = '".$formId."'");
			$db->query();
			
			$db->setQuery("UPDATE #__rsform_forms SET ShowThankyou='".$thankyou_enabled."' WHERE FormId='".$formId."'");
			$db->query();
			
			//update form layout
			
			$explodes = explode('<form', $form->formstyle);
			
			$afterForm = $explodes[1];
			$afterForm = explode('>',$afterForm);
			array_shift($afterForm);
			$afterForm = implode('>',$afterForm);
			$form->formstyle = $explodes[0].$afterForm;
			
			$form->formstyle = str_replace('</form>','',$form->formstyle);
			$form->formstyle = str_replace('{formtitle}','{global:formtitle}',$form->formstyle);
			$form->formstyle = str_replace('{formfields}',$formLayout,$form->formstyle);
			
			$db->setQuery("UPDATE #__rsform_forms SET FormLayout = '".$db->getEscaped($form->formstyle)."' WHERE FormId = '".$formId."'");
			$db->query();
			
			//submissions
			$db->setQuery("SELECT * FROM #__forme_data WHERE form_id = '".$form->id."'");
			$submissions = $db->loadObjectList();
			
			foreach ($submissions as $submission)
			{
				$db->setQuery("INSERT INTO #__rsform_submissions SET `FormId`='".$formId."', `DateSubmitted`='".$db->getEscaped($submission->date_added)."', `UserIp`='".$db->getEscaped($submission->uip)."', `Username`='', `UserId`='".(int) $submission->uid."'");
				$db->query();
				
				$SubmissionId = $db->insertid();
				
				$result_explode = explode("||\n",$submission->params);
				$result = array();
				foreach($result_explode as $param_row)
				{
					$param_row = explode('=',$param_row,2);
					if(isset($param_row[1])){
						$result[$param_row[0]] = $param_row[1];
					}else{
						$result[$param_row[0]] = '';
					}
				}
				
				if(!empty($result))
					foreach($result as $key=>$value)
					{
						$db->setQuery("INSERT INTO #__rsform_submission_values SET `SubmissionId`='".$SubmissionId."',`FormId`='".$formId."',`FieldName`='".$db->getEscaped($key)."',`FieldValue`='".$db->getEscaped($value)."'");
						$db->query();
					}
			}
		}
		
		$msg = count($forms) . JText::_('RSFP_MIGRATION_MSG');
		$mainframe->redirect('index.php?option=com_rsform&task=forms.manage',$msg);
	}
	
	function parseItems($def_value)
	{
		$db = JFactory::getDBO();
		
		$rows = explode(",",$def_value);
		if(!empty($rows))
			foreach($rows as $i=>$row)
			{
				$checked = '';
				if(stristr($row,'{checked}'))
					$checked = '[c]';
				
				$rows[$i] = str_replace('{checked}','', $row) . $checked;
			}
		
		$def_value = $db->getEscaped(implode("\n",$rows));
		return $def_value;	
	}
	
		
	function parseComponent($inputtype, $field, $componentId)
	{
		$db = JFactory::getDBO();
		$query = "('', '".$componentId."', 'NAME', '".$db->getEscaped($field->name)."'),";
		
		switch($inputtype)
		{
			case 1:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'SIZE', '20'),";
				$query .= "('', '$componentId', 'MAXSIZE', ''),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', '".$db->getEscaped($field->default_value)."'),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 2:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'COLS', '50'),";
				$query .= "('', '$componentId', 'ROWS', '5'),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', '".$db->getEscaped($field->default_value)."'),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 3:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'SIZE', ''),";
				$query .= "('', '$componentId', 'MULTIPLE', 'NO'),";
				$query .= "('', '$componentId', 'ITEMS', '".$this->parseItems($field->default_value)."'),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', ''),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 4:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'FLOW', 'HORIZONTAL'),";
				$query .= "('', '$componentId', 'ITEMS', '".$this->parseItems($field->default_value)."'),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', ''),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 5:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'FLOW', 'HORIZONTAL'),";
				$query .= "('', '$componentId', 'ITEMS', '".$this->parseItems($field->default_value)."'),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', ''),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 6:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'DATEFORMAT', 'dd.mm.yyyy'),";
				$query .= "('', '$componentId', 'CALENDARLAYOUT', 'FLAT'),";
				$query .= "('', '$componentId', 'READONLY', 'YES'),";
				$query .= "('', '$componentId', 'POPUPLABEL', '...'),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', ''),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 7:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'LABEL', '".$db->getEscaped($field->default_value)."'),";
				$query .= "('', '$componentId', 'RESET', 'NO'),";
				$query .= "('', '$componentId', 'RESETLABEL', 'Reset'),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', ''),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
			break;
			case 8:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'LENGTH', '4'),";
				$query .= "('', '$componentId', 'BACKGROUNDCOLOR', '#FFFFFF'),";
				$query .= "('', '$componentId', 'TEXTCOLOR', '#000000'),";
				$query .= "('', '$componentId', 'TYPE', 'ALPHA'),";
				$query .= "('', '$componentId', 'FLOW', 'VERTICAL'),";
				$query .= "('', '$componentId', 'SHOWREFRESH', 'NO'),";
				$query .= "('', '$componentId', 'REFRESHTEXT', 'Refresh'),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', 'style=\"text-align:center;width:75px;\"'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 9:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'FILESIZE', ''),";
				$query .= "('', '$componentId', 'ACCEPTEDFILES', ''),";
				$query .= "('', '$componentId', 'DESTINATION', ''),";
				$query .= "('', '$componentId', 'ATTACHUSEREMAIL', 'NO'),";
				$query .= "('', '$componentId', 'ATTACHADMINEMAIL', 'NO'),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 10:
				$query .= "('', '$componentId', 'TEXT', '".$db->getEscaped($field->default_value)."'),";
			break;
			case 11:
				$query .= "('', '$componentId', 'DEFAULTVALUE', '".$db->getEscaped($field->default_value)."'),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
			break;
			case 12:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'RESET', 'NO'),";
				$query .= "('', '$componentId', 'RESETLABEL', 'Reset'),";
				$query .= "('', '$componentId', 'IMAGERESET', ''),";
				$query .= "('', '$componentId', 'IMAGEBUTTON', '".$db->getEscaped($field->default_value)."'),";
				$query .= "('', '$componentId', 'LABEL', 'Button'),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
			break;
			case 13:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'LABEL', '".$db->getEscaped($field->default_value)."'),";
				$query .= "('', '$componentId', 'RESET', 'NO'),";
				$query .= "('', '$componentId', 'RESETLABEL', 'Reset'),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', ''),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
			break;
			case 14:
				$query .= "('', '$componentId', 'CAPTION', '".$db->getEscaped($field->title)."'),";
				$query .= "('', '$componentId', 'DESCRIPTION', '".$db->getEscaped($field->description)."'),";
				$query .= "('', '$componentId', 'SIZE', '20'),";
				$query .= "('', '$componentId', 'MAXSIZE', ''),";
				$query .= "('', '$componentId', 'DEFAULTVALUE', ''),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
			case 15:
				$query .= "('', '$componentId', 'LENGTH', '".$db->getEscaped($field->default_value)."'),";
				$query .= "('', '$componentId', 'CHARACTERS', 'ALPHANUMERIC'),";
				$query .= "('', '$componentId', 'ADDITIONALATTRIBUTES', '".$db->getEscaped($field->params)."'),";
				$query .= $this->parseValidation($field, $componentId);
			break;
				
		}
		
		$query .= "('', '$componentId', 'COMPONENTTYPE', '".$inputtype."')";
		
		return $query;
	}
	
		
	function parseValidation($field, $componentId)
	{
		$db = JFactory::getDBO();
		
		switch($field->validation_rule)
		{
			case '':
				$query = "('', '$componentId', 'VALIDATIONRULE', ''),".
						 "('', '$componentId', 'VALIDATIONMESSAGE', '".$db->getEscaped($field->validation_message)."'),".
						 "('', '$componentId', 'REQUIRED', 'NO'),";
			break;
			case 'mandatory':
				$query = "('', '$componentId', 'VALIDATIONRULE', ''),".
						 "('', '$componentId', 'VALIDATIONMESSAGE', '".$db->getEscaped($field->validation_message)."'),".
						 "('', '$componentId', 'REQUIRED', 'YES'),";
			break;
			case 'email':
				$query = "('', '$componentId', 'VALIDATIONRULE', 'email'),".
						 "('', '$componentId', 'VALIDATIONMESSAGE', '".$db->getEscaped($field->validation_message)."'),".
						 "('', '$componentId', 'REQUIRED', 'YES'),";
			break;
			case 'number':
				$query = "('', '$componentId', 'VALIDATIONRULE', 'numeric'),".
						 "('', '$componentId', 'VALIDATIONMESSAGE', '".$db->getEscaped($field->validation_message)."'),".
						 "('', '$componentId', 'REQUIRED', 'YES'),";
			break;
			case 'alphanum':
				$query = "('', '$componentId', 'VALIDATIONRULE', 'alphanumeric'),".
						 "('', '$componentId', 'VALIDATIONMESSAGE', '".$db->getEscaped($field->validation_message)."'),".
						 "('', '$componentId', 'REQUIRED', 'YES'),";
			break;
			case 'alpha':
				$query = "('', '$componentId', 'VALIDATIONRULE', 'alpha'),".
						 "('', '$componentId', 'VALIDATIONMESSAGE', '".$db->getEscaped($field->validation_message)."'),".
						 "('', '$componentId', 'REQUIRED', 'YES'),";
			break;
		}	
		return $query;
	}

	function changePlaceholdersValues($fieldname, $formArray)
	{
		foreach($formArray as $key => $value)
		{
			$formArray->$key = str_replace('{'.$fieldname.'}','{'.$fieldname.':value}',$formArray->$key);
		}
		return $formArray;
	}
		
	function getComponentTypeId($type)
	{
		switch($type)
		{
			case 'text': 			return 1;
			case 'password': 		return 14;
			case 'radio': 			return 5;
			case 'checkbox':		return 4;
			case 'calendar':		return 6;
			case 'textarea':		return 2;
			case 'select':			return 3;
			case 'button':			return 7;
			case 'image button':	return 12;
			case 'submit button':	return 13;
			case 'reset button':	return 7;
			case 'file upload':		return 9;
			case 'hidden':			return 11;
			case 'free text':		return 10;
			case 'ticket number':	return 15;
			case 'captcha':			return 8;
		}
	}

}