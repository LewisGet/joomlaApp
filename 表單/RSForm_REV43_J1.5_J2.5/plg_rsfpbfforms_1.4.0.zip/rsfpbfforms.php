<?php
/**
* @version 1.4.0
* @package RSform!Pro 1.4.0
* @copyright (C) 2007-2011 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * RSForm! Pro system plugin
 */
class plgSystemRSFPBFForms extends JPlugin
{
	var $_message = array();
	
	/**
	 * Constructor
	 *
	 * For php4 compatibility we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	function plgSystemRSFPBFForms( &$subject, $config )
	{
		parent::__construct( $subject, $config );
		$this->loadLanguage('plg_system_rsfpbfforms');
	}
	
	function canRun()
	{
		if (class_exists('RSFormProHelper')) return true;
		
		$helper = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'.DS.'helpers'.DS.'rsform.php';
		if (file_exists($helper))
		{
			require_once($helper);
			RSFormProHelper::readConfig();
			return true;
		}
		
		return false;
	}
	
	function escape($string)
	{
		return RSFormProHelper::htmlEscape($string);
	}
	
	function rsfp_bk_onSwitchTasks()
	{
		$task = JRequest::getVar('plugin_task');
		switch($task)
		{
			case 'bfimport.form':
				$this->importForms();
			break;
		}
	}
	
	function rsfp_bk_onAfterShowConfigurationTabs()
	{
		if (!$this->canRun()) return;
		
		jimport('joomla.html.pane');
		$tabs =& JPane::getInstance('Tabs', array(), true);
		
		echo $tabs->startPanel(JText::_('RSFP_BFF_MIGRATION'), 'form-bffmigration');
			$this->migrationScreen();
		echo $tabs->endPanel();
	}
	
	function getbfForms()
	{
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id`, `form_name` FROM #__form_forms");
		return $db->loadObjectList();
	}
	
	function hasAkismet()
	{
		jimport('joomla.plugin.helper');
		
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id` FROM #__form_forms WHERE `spam_akismet_key` != '' LIMIT 1");
		return $db->loadResult() && !JPluginHelper::isEnabled('system', 'rsfpakismet');
	}
	
	function hasMailChimp()
	{
		jimport('joomla.plugin.helper');
		
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id` FROM #__form_actions WHERE `plugin` = 'mailchimp' LIMIT 1");
		return $db->loadResult() && !JPluginHelper::isEnabled('system', 'rsfpmailchimp');
	}
	
	function hasSalesforce()
	{
		jimport('joomla.plugin.helper');
		
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id` FROM #__form_actions WHERE `plugin` = 'salesforcew2l' LIMIT 1");
		return $db->loadResult() && !JPluginHelper::isEnabled('system', 'rsfpsalesforce');
	}
	
	function migrationScreen()
	{
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id` FROM #__components WHERE `option`='com_form' LIMIT 1");
		$exists = $db->loadResult();
		if ($exists)
			$forms = $this->getbfForms();
		?>
		<script type="text/javascript">
		function bfImport()
		{
			var bfforms = document.getElementsByName('bfforms[]');
			for (var i=0; i<bfforms.length; i++)
				bfforms[i].disabled = true;
			document.getElementById('bfsubmissions0').disabled = true;
			document.getElementById('bfsubmissions1').disabled = true;
			document.getElementById('bfcaptcha0').disabled = true;
			document.getElementById('bfcaptcha1').disabled = true;
			document.getElementById('bfmovefiles0').disabled = true;
			document.getElementById('bfmovefiles1').disabled = true;
			document.getElementById('bfimport').style.display = 'none';
			document.getElementById('rsloading').style.display = '';
			
			for (var i=0; i<bfforms.length; i++)
			{
				if (bfforms[i].checked == false)
					continue;
				
				document.getElementById('rsstatus').innerHTML = '<?php echo JText::_('RSFP_BFF_IMPORTING_FORM', true); ?>'.replace('\%d', bfforms[i].value);
				
				var todo = 'repeat';
				while(todo == 'repeat')
					todo = bfImportForms(bfforms[i].value);
				
				document.getElementById('formId').value = '0';
				document.getElementById('limitstart').value = '0';
			}
			
			for (var i=0; i<bfforms.length; i++)
				bfforms[i].disabled = false;
			document.getElementById('bfsubmissions0').disabled = false;
			document.getElementById('bfsubmissions1').disabled = false;
			document.getElementById('bfcaptcha0').disabled = false;
			document.getElementById('bfcaptcha1').disabled = false;
			document.getElementById('bfmovefiles0').disabled = false;
			document.getElementById('bfmovefiles1').disabled = false;
			document.getElementById('bfimport').style.display = '';
			document.getElementById('rsloading').style.display = 'none';
			
			document.getElementById('rsstatus').innerHTML = '<img src="components/com_rsform/assets/images/icons/ok.png" alt="" /> <?php echo JText::_('RSFP_BFF_DONE', true); ?>';
		}
		
		function bfImportForms(bfid)
		{
			var xml = buildXmlHttp();
			var url = 'index.php?option=com_rsform&task=plugin&plugin_task=bfimport.form&randomTime=' + Math.random();
			xml.open("POST", url, false);
			
			params = new Array();
			params.push('id=' + bfid);
			if (document.getElementById('bfsubmissions1').checked == true)
				params.push('bfsubmissions=1');
			if (document.getElementById('bfcaptcha1').checked == true)
				params.push('bfcaptcha=1');
			if (document.getElementById('bfmovefiles1').checked == true)
				params.push('bfmovefiles=1');
			params.push('formId=' + document.getElementById('formId').value);
			params.push('limitstart=' + document.getElementById('limitstart').value);
			params = params.join('&');
			
			//Send the proper header information along with the request
			xml.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			xml.setRequestHeader("Content-length", params.length);
			xml.setRequestHeader("Connection", "close");
			xml.send(params);
			
			if (xml.responseXML)
			{
				try {
					var action = xml.responseXML.getElementsByTagName('action')[0].firstChild.nodeValue;
					var formId = xml.responseXML.getElementsByTagName('formId')[0].firstChild.nodeValue;
					var limitstart = xml.responseXML.getElementsByTagName('limitstart')[0].firstChild.nodeValue;
				}
				catch (err) {
					var action = xml.responseText.indexOf('repeat') > -1 ? 'repeat' : 'stop';
					var matches = xml.responseText.match(/<formId>([0-9]+)<\/formId>/);
					var formId = matches[1];
					var matches = xml.responseText.match(/<limitstart>([0-9]+)<\/limitstart>/);
					var limitstart = matches[1];
				}
			}
			else // fail-safe method
			{
				try {
					var action = xml.responseText.indexOf('repeat') > -1 ? 'repeat' : 'stop';
					var matches = xml.responseText.match(/<formId>([0-9]+)<\/formId>/);
					var formId = matches[1];
					var matches = xml.responseText.match(/<limitstart>([0-9]+)<\/limitstart>/);
					var limitstart = matches[1];
				}
				catch (err) {
					// default to stop...
					action = 'stop';
				}
			}
			
			document.getElementById('formId').value = formId;
			document.getElementById('limitstart').value = limitstart;
			
			return action;
		}
		</script>
		<style type="text/css">
		#rsstatus { font-size: 14px; font-weight: bold; }
		</style>
		
		<table class="admintable">
		<?php if (!$exists) { ?>
		<tr>
			<td colspan="2"><?php echo JText::_('RSFP_BFF_NOT_INSTALLED'); ?></td>
		</tr>
		<?php } else { ?>
		<?php if ($this->hasAkismet()) { ?>
		<tr>
			<td colspan="2" style="color: red; font-weight: bold;"><?php echo JText::_('RSFP_AKISMET_WARNING'); ?></td>
		</tr>
		<?php } ?>
		<?php if ($this->hasMailChimp()) { ?>
		<tr>
			<td colspan="2" style="color: red; font-weight: bold;"><?php echo JText::_('RSFP_MAILCHIMP_WARNING'); ?></td>
		</tr>
		<?php } ?>
		<?php if ($this->hasSalesforce()) { ?>
		<tr>
			<td colspan="2" style="color: red; font-weight: bold;"><?php echo JText::_('RSFP_SALESFORCE_WARNING'); ?></td>
		</tr>
		<?php } ?>
		<tr>
			<td width="200" align="right" class="key" style="width: 200px;"><label><span class="hasTip" title="<?php echo JText::_('RSFP_BFF_MIGRATE_FORMS_DESC'); ?>"><?php echo JText::_('RSFP_BFF_MIGRATE_FORMS'); ?></span></label></td>
			<td>
			<?php if ($forms) foreach ($forms as $form) { ?>
				<p><input type="checkbox" name="bfforms[]" id="bfforms<?php echo $form->id; ?>"checked="checked" value="<?php echo $form->id; ?>" /> <label for="bfforms<?php echo $form->id; ?>"><?php echo $this->escape($form->form_name); ?></label></p>
			<?php } else { ?>
				<?php echo JText::_('RSFP_BFF_MIGRATE_NO_FORMS'); ?>
			<?php } ?>
			</td>
		</tr>
		<?php if ($forms) { ?>
		<tr>
			<td width="200" align="right" class="key" style="width: 200px;"><label><?php echo JText::_('RSFP_BFF_MIGRATE_SUBMISSIONS'); ?></label></td>
			<td><?php echo JHTML::_('select.booleanlist', 'bfsubmissions', null, 1); ?></td>
		</tr>
		<tr>
			<td width="200" align="right" class="key" style="width: 200px;"><label><?php echo JText::_('RSFP_BFF_SPAM_WHAT'); ?></label></td>
			<td><?php echo JHTML::_('select.booleanlist', 'bfcaptcha', null, 1, JText::_('RSFP_BFF_CONVERT_CAPTCHA'), JText::_('RSFP_BFF_KEEP_HIDDEN_FIELDS')); ?></td>
		</tr>
		<tr>
			<td width="200" align="right" class="key" style="width: 200px;"><label><?php echo JText::_('RSFP_BFF_MOVE_FILES'); ?></label></td>
			<td><?php echo JHTML::_('select.booleanlist', 'bfmovefiles', null, 1); ?></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><button id="bfimport" onclick="bfImport();" type="button"><?php echo JText::_('RSFP_BFF_IMPORT'); ?></button><img id="rsloading" style="display: none;" src="<?php echo JURI::root(true); ?>/administrator/components/com_rsform/assets/images/loading.gif" alt="Loading" /> <span id="rsstatus"></span></td>
		</tr>
		<?php } ?>
		<?php } ?>
		</table>
		<input type="hidden" name="formId" value="0" id="formId" />
		<input type="hidden" name="limitstart" value="0" id="limitstart" />
		<?php
	}
	
	function _getFormId()
	{
		static $id;
		if (empty($id))
			$id = JRequest::getInt('id');
		
		return $id;
	}
	
	function _getReplaceCaptcha()
	{
		static $replace;
		if (is_null($replace))
			$replace = JRequest::getInt('bfcaptcha');
			
		return $replace;
	}
	
	function _getMoveFiles()
	{
		static $move;
		if (is_null($move))
			$move = JRequest::getInt('bfmovefiles');
		
		return $move;
	}
	
	function _getMoveSubmissions()
	{
		static $submissions;
		if (is_null($submissions))
			$submissions = JRequest::getInt('bfsubmissions');
		
		return $submissions;
	}
	
	function _getLimit()
	{
		static $limit;
		if (is_null($limit))
			$limit = JRequest::getInt('limit', 30);
		
		return $limit;
	}
	
	function _getLimitStart()
	{
		static $limitstart;
		if (is_null($limitstart))
			$limitstart = JRequest::getInt('limitstart');
		
		return $limitstart;
	}
	
	function _getRSFormId()
	{
		static $id;
		if (empty($id))
			$id = JRequest::getInt('formId');
		
		return $id;
	}
	
	function importForms()
	{
		if (!$this->canRun())
			return;
		
		$db =& JFactory::getDBO();
		$id 			  = $this->_getFormId();
		$replace_captcha  = $this->_getReplaceCaptcha();
		$move_files 	  = $this->_getMoveFiles();
		$move_submissions = $this->_getMoveSubmissions();
		$limitstart		  = $this->_getLimitStart();
		$limit			  = $this->_getLimit();
		$formId			  = $this->_getRSFormId();
		
		$db->setQuery("SELECT * FROM #__form_forms WHERE `id`='".$id."'");
		$bfform = $db->loadObject();
		
		if ($limitstart == 0)
		{
			$scripts['display']  = array();
			$scripts['process']  = array();
			$scripts['process2'] = array();
			$scripts['useremail']  = array();
			$scripts['adminemail'] = array();
			$scripts['addemail'] = array();
			
			$form =& JTable::getInstance('RSForm_Forms', 'Table');
			$form->Published = $bfform->published;
			$form->FormName  = $bfform->form_name;
			$form->FormTitle = $bfform->page_title;
			$form->MetaTitle = $bfform->showtitle;
			
			// these are added as actions in bfForms
			$form->Keepdata  	 = 0;
			$form->ShowThankyou  = 0;
			$form->store();
			
			$scripts['display'][] = '$user =& JFactory::getUser();';
			$scripts['display'][] = '$mainframe =& JFactory::getApplication();';
			$scripts['display'][] = '$db =& JFactory::getDBO();';
			
			$scripts['process'][] = '$db =& JFactory::getDBO();';
			
			// 1.6 ?
			if ($bfform->access)
			{
				$scripts['display'][] = 'if ($user->get(\'aid\') < '.$bfform->access.') { $mainframe->enqueueMessage(\'Access denied to this form.\', \'error\'); $formLayout = \'\'; }';
				$scripts['process'][] = 'if ($user->get(\'aid\') < '.$bfform->access.') { $mainframe->enqueueMessage(\'Access denied to this form.\', \'error\'); $mainframe->redirect(JURI::root()); }';
			}
			
			if ($bfform->target)
				$form->CSSAdditionalAttributes = 'target="'.$bfform->target.'" accept-charset="'.$bfform->{'accept-charset'}.'"';
			
			if ($bfform->processorurl)
				$form->CSSAction = $bfform->processorurl;
			
			if ($bfform->custom_js)
				$form->JS = '<script type="text/javascript">'.
							"\n".$bfform->custom_js.
							"\n".'</script>';
							
			if ($bfform->custom_css)
				$form->CSS = '<style type="text/css">'.
							 "\n".'<!--'.
							 "\n".$bfform->custom_css.
							 "\n".'-->'.
							 "\n".'</style>';
			
			if ($bfform->maxsubmissions)
			{
				$scripts['display'][] = '$db->setQuery("SELECT COUNT(SubmissionId) FROM #__rsform_submissions WHERE FormId=\''.$form->FormId.'\'");';
				$scripts['display'][] = 'if ($db->loadResult() >= '.$bfform->maxsubmissions.') { $mainframe->enqueueMessage(\'Unfortunately, this form has reached its submissions limit.\', \'error\'); $formLayout = \'\'; }';
			}
			
			if ($bfform->maxsubmissionsperuser)
			{
				$scripts['display'][] = 'if ($user->get(\'guest\')) { ';
				$scripts['display'][] = '$db->setQuery("SELECT COUNT(SubmissionId) FROM #__rsform_submissions WHERE FormId=\''.$form->FormId.'\' AND UserId=\'".$user->get(\'id\')."\'");';
				$scripts['display'][] = '} else {';
				$scripts['display'][] = '$db->setQuery("SELECT COUNT(SubmissionId) FROM #__rsform_submissions WHERE FormId=\''.$form->FormId.'\' AND UserIp=\'".$db->getEscaped($_SERVER[\'REMOTE_ADDR\'])."\'");';
				$scripts['display'][] = '}';
				$scripts['display'][] = 'if ($db->loadResult() >= '.$bfform->maxsubmissionsperuser.') { $mainframe->enqueueMessage(\'Unfortunately, you have reached the number of submissions available for this form.\', \'error\'); $formLayout = \'\'; }';
			}
			
			if ($bfform->spam_ipblacklist)
			{
				$bfform->spam_ipblacklist = explode("\n", str_replace(array("\r\n", "\r"), "\n", $bfform->spam_ipblacklist));
				array_walk($bfform->spam_ipblacklist, array('plgSystemRSFPBFForms', '_addSlashes'));
				
				$banned_line = '$banned_ips = array(\''.implode("','", $bfform->spam_ipblacklist).'\');';
				
				$scripts['display'][] = $banned_line;
				$scripts['display'][] = 'if (in_array($_SERVER[\'REMOTE_ADDR\'], $banned_ips)) { $mainframe->enqueueMessage(\'Unfortunately, you cannot submit this form.\', \'error\'); $formLayout = \'\'; }';
				
				$scripts['process'][] = $banned_line;
				$scripts['process'][] = 'if (in_array($_SERVER[\'REMOTE_ADDR\'], $banned_ips)) { $mainframe->enqueueMessage(\'Unfortunately, you cannot submit this form.\', \'error\'); $formLayout = \'\'; }';
			}
			
			if ($bfform->spam_wordblacklist)
			{
				$bfform->spam_wordblacklist = explode('|', $bfform->spam_wordblacklist);
				array_walk($bfform->spam_wordblacklist, array('plgSystemRSFPBFForms', '_addSlashes'));
				$scripts['process'][] = '$banned_words = array(\''.implode("','", $bfform->spam_wordblacklist).'\');';
				$scripts['process'][] = 'foreach ($banned_words as $word) {';
				$scripts['process'][] = 'foreach ($_POST[\'form\'] as $val) {';
				$scripts['process'][] = 'if (is_array($val)) $val = implode(\',\', $val);';
				$scripts['process'][] = 'if (strstr(strtolower($val), strtolower($word))) {';
				$scripts['process'][] = '$mainframe->enqueueMessage(\'Your submission contains banned words.\', \'error\');';
				$scripts['process'][] = '$invalid = 99999;';
				$scripts['process'][] = 'break 2;';
				$scripts['process'][] = '}';
				$scripts['process'][] = '}';
				$scripts['process'][] = '}';
			}
			
			$db->setQuery("SELECT * FROM #__form_fields WHERE form_id='".$bfform->id."'");
			$bffields = $db->loadObjectList();
			$upload_fields = array();
			foreach ($bffields as $bffield)
			{
				$component   = $this->_convertField($bffield, $scripts);
				$componentId = $this->_addComponent($component, $form->FormId);
				
				// upload field
				if ($component->ComponentTypeId == 9)
					$upload_fields[] = $componentId;
			}
			
			$newOrder = isset($component->Order) ? $component->Order+1 : 1;
			
			if ($bfform->spam_hiddenfield)
			{
				if ($replace_captcha)
				{
					$component = new stdClass();
					$component->Order = $newOrder;
					$component->ComponentTypeId = 8;
					$component->Published = 1;
					$component->properties['NAME'] = $bfform->spam_hiddenfield;
					$component->properties['CAPTION'] = 'SPAM Protection';
					$component->properties['LENGTH'] = 4;
					$component->properties['BACKGROUNDCOLOR'] = '#FFFFFF';
					$component->properties['TEXTCOLOR'] = '#000000';
					$component->properties['TYPE'] = 'ALPHANUMERIC';
					$component->properties['ADDITIONALATTRIBUTES'] = 'style="text-align:center;width:75px;"';
					$component->properties['DESCRIPTION'] = '';
					$component->properties['COMPONENTTYPE'] = 8;
					$component->properties['VALIDATIONMESSAGE'] = 'Please type the 4 character code you see in the image above.';
					$component->properties['FLOW'] = 'HORIZONTAL';
					$component->properties['SHOWREFRESH'] = 'YES';
					$component->properties['REFRESHTEXT'] = JText::_('RSFP_COMP_FVALUE_REFRESH');
					$component->properties['SIZE'] = '15';
					$component->properties['IMAGETYPE'] = 'FREETYPE';
					
					$componentId = $this->_addComponent($component, $form->FormId);
				}
				else
				{
					$component = new stdClass();
					$component->Order = $newOrder;
					$component->ComponentTypeId = 1;
					$component->Published = 1;
					$component->properties['NAME'] = $bfform->spam_hiddenfield;
					$component->properties['CAPTION'] = '';
					$component->properties['REQUIRED'] = 'NO';
					$component->properties['SIZE'] = 20;
					$component->properties['MAXSIZE'] = '';
					$component->properties['VALIDATIONRULE'] = 'none';
					$component->properties['VALIDATIONMESSAGE'] = '';
					$component->properties['ADDITIONALATTRIBUTES'] = 'style="display: none;"';
					$component->properties['DEFAULTVALUE'] = '';
					$component->properties['DESCRIPTION'] = '';
					$component->properties['COMPONENTTYPE'] = 1;
					$component->properties['VALIDATIONEXTRA'] = '';
					
					$componentId = $this->_addComponent($component, $form->FormId);
					
					$scripts['process'][] = '// start: SPAM hidden field protection';
					$scripts['process'][] = 'if (!empty($_POST[\'form\'][\''.$this->_addSlashes($bfform->spam_hiddenfield).'\'])) $invalid[] = \''.$componentId.'\';';
					$scripts['process'][] = '// end: SPAM hidden field protection';
				}
				
				$newOrder++;
			}
			
			if (!$bfform->usecustomtemplate)
			{
				jimport('joomla.application.component.model');
				
				$form->FormLayoutAutogenerate = 1;
				$form->FormLayoutName = 'inline-xhtml';
				$form->store();
				
				$component = new stdClass();
				$component->Order = $newOrder;
				$component->ComponentTypeId = 13;
				$component->Published = 1;
				$component->properties['NAME'] = 'submit';
				$component->properties['CAPTION'] = '';
				$component->properties['LABEL'] = $bfform->submitbuttontext;
				$component->properties['RESET'] = $bfform->showresetbutton ? 'YES' : 'NO';
				$component->properties['RESETLABEL'] = $bfform->resetbuttontext;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				$component->properties['COMPONENTTYPE'] = 13;
				$component->properties['PREVBUTTON'] = JText::_('PREV');
				
				$componentId = $this->_addComponent($component, $form->FormId);
				
				// create layout xhtml
				JRequest::setVar('formId', $form->FormId);
				
				$model = JModel::getInstance('Forms', 'RSFormModel', array('base_path' => JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'));
				$model->getForm();
				
				$model->autoGenerateLayout();
				$form->FormLayout = $model->_form->FormLayout;
				$form->store();
			}
			else
			{
				$form->FormLayoutAutogenerate = 0;
				
				// parse smarty template
				$replace = array('{$FORM_OPEN_TAG}', '{$FORM_CLOSE_TAG}');
				$with  	 = array('', '');
				
				$slugs = $this->_getSlugs($id);
				foreach ($slugs as $slug)
				{
					array_push($replace, '{$'.strtoupper($slug).'_TITLE}', '{$'.strtoupper($slug).'_DESC}', '{$'.strtoupper($slug).'_ELEMENT}');
					array_push($with, '{'.$slug.':caption}', '{'.$slug.':description}', '{'.$slug.':body}<br />'.'{'.$slug.':validation}<br />');
				}
				
				$form->FormLayout = str_replace($replace, $with, $bfform->custom_smarty);
			}
			
			$db->setQuery("SELECT * FROM #__form_actions WHERE published='1' ORDER BY `ordering`");
			$bfactions = $db->loadObjectList();
			foreach ($bfactions as $bfaction)
				$this->_convertAction($bfaction, $scripts, $form, $upload_fields, $id);
			
			jimport('joomla.plugin.helper');
			
			if ($bfform->spam_akismet_key && JPluginHelper::isEnabled('system', 'rsfpakismet'))
			{
				$row = JTable::getInstance('RSForm_Akismet', 'Table');
				$row->form_id 		 = $form->FormId;
				$row->aki_published  = 1;
				$row->aki_merge_vars = serialize(array(
					'author' => $bfform->spam_akismet_author,
					'email'	 => $bfform->spam_akismet_email,
					'body' 	 => $bfform->spam_akismet_body
				));
				$row->store();
				
				$db->setQuery("UPDATE #__rsform_config SET `SettingValue`='".$db->getEscaped($bfform->spam_akismet_key)."' WHERE `SettingName`='aki.key'");
				$db->query();
			}
			
			/*
			$bfform->nextbuttontext;
			$bfform->prevbuttontext;
			
			$bfform->spam_mollom_privatekey;
			$bfform->spam_mollom_publickey;
			
			$bfform->enableixedit;
			$bfform->enablejankomultipage;
			*/
			$form->ScriptDisplay  = implode("\n", $scripts['display']);
			$form->ScriptProcess  = implode("\n", $scripts['process']);
			$form->ScriptProcess2 = implode("\n", $scripts['process2']);
			$form->UserEmailScript = implode("\n", $scripts['useremail']);
			$form->AdminEmailScript = implode("\n", $scripts['adminemail']);
			$form->AdditionalEmailsScript = implode("\n", $scripts['addemail']);
			
			$form->store();
			
			$formId = $form->FormId;
		}
		
		// convert submissions
		// ?
		if ($bfform->hasusertable)
		{
			$db->setQuery("SELECT * FROM `".$db->getEscaped($bfform->hasusertable)."` ORDER BY `id` ASC", $limitstart, $limit);
			$submissions = $db->loadObjectList();
			
			if (!count($submissions) || !$move_submissions)
			{
				$this->_setMessage('action', 'stop');
				$this->_setMessage('formId', $formId);
				$this->_setMessage('limitstart', ($limitstart+$limit));
				$this->_exit();
			}
			
			foreach ($submissions as $submission)
			{
				$db->setQuery("INSERT INTO #__rsform_submissions SET `FormId`='".$formId."', `DateSubmitted`=NOW(), `UserIp`='127.0.0.1', `Username`='', `UserId`='".$submission->bf_user_id."', `Lang`='en-GB', `confirmed`='1'");
				$db->query();
				$submissionId = $db->insertid();
				
				$values = get_object_vars($submission);
				unset($values['id'], $values['bf_status'], $values['bf_user_id']);
				
				$fields  = $this->_getSubmissionFields($values, $id);
				$uploads = $this->_getUploadFields($values, $id);
				
				foreach ($values as $key => $val)
				{
					if (!isset($fields[$key]))
						continue;
						
					if (isset($uploads[$key]))
					{						
						switch ($uploads[$key]['setting'])
						{
							// abs path
							case 1:
								$val = $val;
							break;
							
							// url
							default:
							case 2:
								$val = end(explode('/', $val));
								$val = $uploads[$key]['destination'].DS.$val;
							break;
							
							// filename
							case 3:
								$val = $uploads[$key]['destination'].DS.$val;
							break;
						}
						
						if (!JFile::exists($val) || !is_file($val))
							$val = '';
						
						if ($move_files && $val && JFile::copy($val, JPATH_SITE.DS.'components'.DS.'com_rsform'.DS.'uploads'.DS.basename($val)))
							$val = JPATH_SITE.DS.'components'.DS.'com_rsform'.DS.'uploads'.DS.basename($val);
					}
						
					$db->setQuery("INSERT INTO #__rsform_submission_values SET `FormId`='".$formId."', `SubmissionId`='".$submissionId."', `FieldName`='".$db->getEscaped($fields[$key])."', `FieldValue`='".$db->getEscaped($val)."'");
					$db->query();
				}
			}
			
			$this->_setMessage('action', 'repeat');
			$this->_setMessage('formId', $formId);
			$this->_setMessage('limitstart', ($limitstart+$limit));
			$this->_exit();
		}
	}
	
	function _exit()
	{
		header('Content-type: text/xml');
		
		echo "<?xml version='1.0' encoding='utf-8'?>";
		echo '<response>';
		foreach ($this->_message as $tag => $value)
			echo '<'.$tag.'>'.$value.'</'.$tag.'>';
		echo '</response>';
		jexit();
	}
	
	function _setMessage($tag, $value)
	{
		$this->_message[$tag] = $value;
	}
	
	function _getSubmissionFields($values, $id)
	{
		static $cache;
		
		if (!is_array($cache))
		{
			$cache  = array();
			
			$db	=& JFactory::getDBO();
			$db->setQuery("SELECT id, slug FROM #__form_fields WHERE form_id='".(int) $id."'");
			$fields = $db->loadObjectList();
			foreach ($fields as $field)
				$cache['FIELD_'.$field->id] = $field->slug;
		}
		
		return $cache;
	}
	
	function _getUploadFields($values, $id)
	{
		static $cache;
		
		if (!is_array($cache))
		{
			jimport('joomla.filesystem.file');
			
			$cache  = array();
			
			$db	=& JFactory::getDBO();
			$db->setQuery("SELECT id, slug, fileupload_setvalueto, fileupload_destdir FROM #__form_fields WHERE form_id='".(int) $id."' AND `plugin`='fileupload'");
			$fields = $db->loadObjectList();
			foreach ($fields as $field)
				$cache['FIELD_'.$field->id] = array('slug' => $field->slug, 'setting' => $field->fileupload_setvalueto, 'destination' => $field->fileupload_destdir);
		}
		
		return $cache;
	}
	
	function _convertAction($action, &$scripts, &$form, $upload_fields, $id)
	{
		static $mailcount;
		static $mailids;
		if (is_null($mailcount))
			$mailcount = 0;
		if (!is_array($mailids))
			$mailids = array();
		
		switch ($action->plugin)
		{
			case 'executephp':
				$slugs = $this->_getSlugs($id);
				$bftypes = array();
				$rstypes = array();
				foreach ($slugs as $slug)
				{
					$bftypes[] = '$'.strtoupper($slug);
					$rstypes[] = '$_POST[\'form\'][\''.$this->_addSlashes($slug).'\']';
				}
				
				$scripts['process2'][] = '// start: '.$action->title;
				$scripts['process2'][] = str_replace($bftypes, $rstypes, $action->desc);
				$scripts['process2'][] = '// end: '.$action->title;
			break;
			
			case 'httppost':
				$scripts['process2'][] = '// start: '.$action->title;
				$scripts['process2'][] = "\$url = '".$this->_addSlashes($action->desc)."';";
				$scripts['process2'][] = '$ch = curl_init();';
				$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_USERAGENT, \'YahooSeeker-Testing/v3.9 (compatible; Mozilla 4.0; MSIE 5.5; http://search.yahoo.com/)\');';
				$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_POST, 1);';
				$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_URL, $url);';
				
				if ($action->custom6) // Send submitted details in the post
				{
					$scripts['process2'][] = '$data = array();';
					$scripts['process2'][] = 'foreach ($_POST[\'form\'] as $post => $value)';
					$scripts['process2'][] = '{';
					$scripts['process2'][] = 'if (is_array($value)) foreach ($value as $post2 => $value2) $data[] = $post.\'[]=\'.urlencode($value2);';
					$scripts['process2'][] = 'else $data[] = $post.\'=\'.urlencode($value);';
					$scripts['process2'][] = '}';
					$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_POSTFIELDS, implode(\'&\', $data));';
				}
				
				if ($action->custom9) // Enable Debug Mode
					$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);';
					
				$scripts['process2'][] = '$result = curl_exec($ch);';
				$scripts['process2'][] = 'curl_close($ch);';
				
				if ($action->custom9) // Enable Debug Mode
					$scripts['process2'][] = 'exit();';
				
				$scripts['process2'][] = '// end: '.$action->title;
			break;
			
			case 'mail':
				$db =& JFactory::getDBO();
				$slugs = $this->_getSlugs($id);
				$bftypes = array();
				$rstypes = array();
				foreach ($slugs as $slug)
				{
					$bftypes[] = '#'.strtoupper($slug).'#';
					$rstypes[] = '{'.$slug.':value}';
				}
				
				$action->emailto = str_replace(array("\r\n", "\r", "\n"), ',', $action->emailto);
				$action->emailcc = str_replace(array("\r\n", "\r", "\n"), ',', $action->emailcc);
				$action->emailbcc = str_replace(array("\r\n", "\r", "\n"), ',', $action->emailbcc);
				
				if ($mailcount == 0)
				{
					$form->UserEmailSubject = str_replace($bftypes, $rstypes, $action->emailsubject);
					$form->UserEmailFromName = str_replace($bftypes, $rstypes, $action->emailfromname);
					$form->UserEmailFrom = str_replace($bftypes, $rstypes, $action->emailfrom);
					$form->UserEmailReplyTo = str_replace($bftypes, $rstypes, $action->emailfrom);
					$form->UserEmailTo = str_replace($bftypes, $rstypes, $action->emailto);
					$form->UserEmailCC = str_replace($bftypes, $rstypes, $action->emailcc);
					$form->UserEmailBCC = str_replace($bftypes, $rstypes, $action->emailbcc);
					$form->UserEmailText = $action->emailhtml ? str_replace($bftypes, $rstypes, $action->emailhtml) : str_replace($bftypes, $rstypes, $action->emailplain);
					$form->UserEmailMode = $action->emailhtml ? 1 : 0;
					
					$form->UserEmailAttach = 0;
					$form->UserEmailAttachFile = '';
					if ($action->attachments)
					{
						$tmp = explode("\n", str_replace(array("\r\n", "\r"), "\n", $action->attachments));
						if (count($tmp))
						{
							$form->UserEmailAttach = 1;
							$form->UserEmailAttachFile = $tmp[0];
							
							unset($tmp[0]);
							foreach ($tmp as $file)
								$scripts['useremail'][] = "\$userEmail['files'][] = '".$this->_addSlashes($file)."';";
						}
					}
				}
				elseif ($mailcount == 1)
				{
					$form->AdminEmailSubject = '';
					$form->AdminEmailFromName = '';
					$form->AdminEmailFrom = '';
					$form->AdminEmailReplyTo = '';
					$form->AdminEmailTo = '';
					$form->AdminEmailCC = '';
					$form->AdminEmailBCC = '';
					$form->AdminEmailText = '';
					$form->AdminEmailMode = '';
					
					$form->AdminEmailAttach = 0;
					$form->AdminEmailAttachFile = '';
					if ($action->attachments)
					{
						$tmp = explode("\n", str_replace(array("\r\n", "\r"), "\n", $action->attachments));
						if (count($tmp))
						{
							$form->AdminEmailAttach = 1;
							$form->AdminEmailAttachFile = $tmp[0];
							
							unset($tmp[0]);
							foreach ($tmp as $file)
								$scripts['adminemail'][] = "\$adminEmail['files'][] = '".$this->_addSlashes($file)."';";
						}
					}
				}
				else
				{
					$email =& JTable::getInstance('RSForm_Emails', 'Table');
					$email->formId = $form->FormId;
					$email->from = str_replace($bftypes, $rstypes, $action->emailfrom);
					$email->fromname = str_replace($bftypes, $rstypes, $action->emailfromname);
					$email->replyto = str_replace($bftypes, $rstypes, $action->emailfrom);
					$email->to = str_replace($bftypes, $rstypes, $action->emailto);
					$email->cc = str_replace($bftypes, $rstypes, $action->emailcc);
					$email->bcc = str_replace($bftypes, $rstypes, $action->emailbcc);
					$email->subject = str_replace($bftypes, $rstypes, $action->emailsubject);
					$email->mode = $action->emailhtml ? 1 : 0;
					$email->message = $action->emailhtml ? str_replace($bftypes, $rstypes, $action->emailhtml) : str_replace($bftypes, $rstypes, $action->emailplain);
					
					if ($email->store())
					{
						$mailids[] = $email->id;
						
						if ($action->attachments)
						{
							$tmp = explode("\n", str_replace(array("\r\n", "\r"), "\n", $action->attachments));
							if (count($tmp))
								foreach ($tmp as $file)
									$scripts['addemail'][] = "if (\$email->id == '".$email->id."') \$additionalEmail['files'][] = '".$this->_addSlashes($file)."';";
						}
					}
				}
				
				if ($action->senduploadedfiles && count($upload_fields))
				{
					$value = '';
					if ($mailcount == 0)
						$value = 'useremail';
					elseif ($mailcount == 1)
						$value = 'useremail,adminemail';
					else
						$value = 'useremail,adminemail,'.implode(',',$mailids);
					
					$db->setQuery("UPDATE #__rsform_properties SET `PropertyValue`='' WHERE ComponentId IN (".implode(',', $upload_fields).") AND `PropertyName`='EMAILATTACH'");
					$db->query();
				}
				
				$mailcount++;
			break;
			
			case 'redirect':
				$form->ReturnUrl = $action->desc;
				
				$db =& JFactory::getDBO();
				$db->setQuery("SELECT `slug` FROM #__form_fields WHERE form_id='".$id."'");
				$slugs   = $db->loadResultArray();
				$rstypes = array();
				foreach ($slugs as $slug)
					$rstypes[] = $slug.'='.'{'.$slug.':value}';
				if ($action->custom4 == 'GET' && $action->custom6)
					$form->ReturnUrl .= (strpos($form->ReturnUrl, '?') === false ? '?' : '&').implode('&', $rstypes);
				// $action->title  = title
				// $action->access = access level ?
				// $action->desc   = url
				// $action->custom6 = Send submitted details in the post
				// $action->custom4 = Redirect Method POST GET
			break;
			
			case 'listmessenger':
				$scripts['process2'][] = '// start: '.$action->title;
				$scripts['process2'][] = "\$url = JURI::root().'index.php';";
				$scripts['process2'][] = '$ch = curl_init();';
				$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_USERAGENT, \'YahooSeeker-Testing/v3.9 (compatible; Mozilla 4.0; MSIE 5.5; http://search.yahoo.com/)\');';
				$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_POST, 1);';
				$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_URL, $url);';
				
				$scripts['process2'][] = '$data = array();';
				$scripts['process2'][] = 'foreach ($_POST[\'form\'] as $post => $value)';
				$scripts['process2'][] = '{';
				$scripts['process2'][] = 'if (is_array($value)) foreach ($value as $post2 => $value2) $data[] = $post.\'[]=\'.urlencode($value2);';
				$scripts['process2'][] = 'else $data[] = $post.\'=\'.urlencode($value);';
				$scripts['process2'][] = '}';
				
				$scripts['process2'][] = "\$data['firstname'] = @\$_POST['form']['".$this->_addSlashes($action->emailfrom)."'];";
				$scripts['process2'][] = "\$data['lastname'] = @\$_POST['form']['".$this->_addSlashes($action->emailfromname)."'];";
				$scripts['process2'][] = "\$data['email_address'] = @\$_POST['form']['".$this->_addSlashes($action->emailto)."'];";
				$scripts['process2'][] = "\$data['option'] = 'com_mailinglist';";
				$scripts['process2'][] = "\$data['tmpl'] = 'component';";
				$scripts['process2'][] = "\$data['group_ids'] = '".$this->_addSlashes($action->custom5)."';";
				$scripts['process2'][] = "\$data['action'] = '".($action->custom6 ? 'subscribe' : 'unsubscribe')."';";
				
				$scripts['process2'][] = 'curl_setopt($ch, CURLOPT_POSTFIELDS, implode(\'&\', $data));';
					
				$scripts['process2'][] = '$result = curl_exec($ch);';
				$scripts['process2'][] = 'curl_close($ch);';
				
				$scripts['process2'][] = '// end: '.$action->title;
			break;
			
			case 'save':
				$form->Keepdata = 1;
			break;
			
			case 'thankyou':
				$db =& JFactory::getDBO();
				$db->setQuery("SELECT `slug` FROM #__form_fields WHERE form_id='".$id."'");
				$slugs   = $db->loadResultArray();
				$bftypes = array();
				$rstypes = array();
				foreach ($slugs as $slug)
				{
					$bftypes[] = '$'.strtoupper($slug);
					$rstypes[] = '{'.$slug.':value}';
				}
				
				$form->ShowThankyou = 1;
				$form->Thankyou 	= str_replace($bftypes, $rstypes, $action->desc);
			break;
			
			case 'mailchimp':
				$db =& JFactory::getDBO();
				$db->setQuery("UPDATE #__rsform_config SET `SettingValue`='".$db->getEscaped($action->custom4)."' WHERE `SettingName`='mailchimp.key'");
				$db->query();
				
				$row = JTable::getInstance('RSForm_MailChimp', 'Table');
				$row->form_id 		= $form->FormId;
				$row->mc_list_id 	= $action->custom5;
				$row->mc_action 	= $action->custom6;
				$row->mc_merge_vars = serialize(array(
					'EMAIL' => $action->emailto,
					'FNAME' => $action->emailfrom,
					'LNAME' => $action->emailfromname,
				));
				$row->mc_published 	= 1;
				$row->store();
			break;
			
			case 'salesforcew2l':
				$row = JTable::getInstance('RSForm_Salesforce', 'Table');
				$row->form_id 		 = $form->FormId;
				$row->slsf_published = 1;
				
				if (preg_match('#name="oid" value="(.*?)"#is', $action->custom5, $match))
					$row->slsf_oid = $match[1];
				
				if ($action->custom6 == 1)
				{
					$row->slsf_debug = 1;
					if (preg_match('#name="debugEmail" value="(.*?)"#is', $action->custom5, $match))
						$row->slsf_debugEmail = $match[1];
				}
				
				$custom = array();
				$pairs  = explode("\n", $action->custom4);
				foreach ($pairs as $pair)
				{
					$pair = trim($pair);
					list($salesforce, $field) = explode(':', $pair, 2);
					
					$check = 'slsf_'.$salesforce;
					
					if (isset($row->$check))
						$row->$check = '{'.$field.':value}';
					else
					{
						$tmp = new stdClass();
						$tmp->api_name = $salesforce;
						$tmp->value    = '{'.$field.':value}';
						
						$custom[] = $tmp;
					}
				}
				$row->slsf_custom_fields = serialize($custom);
				
				$row->store();
			break;
		}
	}
	
	function _convertField($field, &$scripts)
	{
		$lang =& JFactory::getLanguage();
		$component = new stdClass();
		$component->properties = array();
		$component->properties['NAME'] = $field->slug;
		$component->Published = $field->published;
		$component->Order = $field->ordering;
		
		switch ($field->plugin)
		{
			case 'radio':
			case 'checkbox':
				$component->ComponentTypeId = ($field->plugin == 'radio') ? 5 : 4;
				
				if ($field->multiple)
					$field->value = RSFormProHelper::checkValue($field->multiple, $field->value);
				
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['ITEMS'] = $field->value;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['FLOW'] = $field->layoutoption ? 'HORIZONTAL' : 'VERTICAL';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				
				if ($field->allowsetbyget)
				{
					$field->value = explode("\n", str_replace(array("\r\n", "\r"), "\n", $field->value));
					array_walk($field->value, array('plgSystemRSFPBFForms', '_addSlashes'));
					$field->value = implode("','", $field->value);
					
					$component->properties['ITEMS'] = "//<code>\n \$items = array('".$field->value."');\n return RSFormProHelper::checkValue(JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->multiple)."'), \$items);\n//</code>";
				}
				
				$this->_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'hidden':
			case 'ipaddresshidden':
			case 'useremailaddresshidden':
			case 'userfullnamehidden':
			case 'useridhidden':
			case 'usernamehidden':
			case 'randomnumber':
			case 'timestamp':
			case 'referer':
			case 'embeddedpagetitle':
				$component->ComponentTypeId = 11;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
					
				switch ($field->plugin)
				{
					default:
					case 'hidden':
						$component->properties['DEFAULTVALUE'] = $field->value;
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->value)."');\n//</code>";
					break;
					case 'ipaddresshidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return \$_SERVER['REMOTE_ADDR'];\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$_SERVER['REMOTE_ADDR']);\n//</code>";
					break;
					case 'useremailaddresshidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('email', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('email', '');\n//</code>";
					break;
					case 'userfullnamehidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('name', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('name', '');\n//</code>";
					break;
					case 'useridhidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('id', 0);\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('id', 0);\n//</code>";
					break;
					case 'usernamehidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('username', 'NOT LOGGED IN');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('username', 'NOT LOGGED IN');\n//</code>";
					break;
					case 'randomnumber':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return rand(".str_replace(':', ',', $field->value).");\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', rand(".str_replace(':', ',', $field->value)."));\n//</code>";
					break;
					case 'timestamp':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return date('".$this->_addSlashes($field->value)."');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', date('".$this->_addSlashes($field->value)."'));\n//</code>";
					break;
					case 'referer':
						$component->properties['DEFAULTVALUE'] = "#HTTP_REFERER#";
						$scripts['display'][] = '$session =& JFactory::getSession()';
						$scripts['display'][] = 'if ((!isset($_POST) || !isset($_POST[\'form\'])) && isset($_SERVER[\'HTTP_REFERER\'])) $session->set(\'com_rsform.referer\', $_SERVER[\'HTTP_REFERER\']);';
						$scripts['display'][] = '$formLayout = str_replace(\'"#HTTP_REFERER#"\', $session->get(\'com_rsform.referer\', \'\'), $formLayout);';
						
						if ($field->allowsetbyget)
							$scripts['display'][] = '$formLayout = str_replace(\'"#HTTP_REFERER#"\', JRequest::getVar(\''.$this->_addSlashes($component->properties['NAME']).'\', $session->get(\'com_rsform.referer\', \'\')), $formLayout);';
						else
							$scripts['display'][] = '$formLayout = str_replace(\'"#HTTP_REFERER#"\', $session->get(\'com_rsform.referer\', \'\'), $formLayout);';
					break;
					case 'embeddedpagetitle':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$doc =& JFactory::getDocument();\n return \$doc->getTitle();\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$doc =& JFactory::getDocument();\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$doc->getTitle());\n//</code>";
					break;
				}
				
				$this->_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'useremailaddress':
			case 'userfullname':
			case 'userid':
			case 'username':
			case 'ipaddress':
			case 'textbox':
				$component->ComponentTypeId = 1;
				
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				
				$component->properties['SIZE'] = $field->size;
				$component->properties['MAXSIZE'] = $field->maxlength;
				$component->properties['VALIDATIONRULE'] = 'none';
				$this->_convertValidationRule($field, $component, $scripts);
				
				switch ($field->plugin)
				{
					default:
					case 'textbox':
						$component->properties['DEFAULTVALUE'] = $field->value;
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->value)."');\n//</code>";
					break;
					
					case 'useremailaddress':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('email', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('email', '');\n//</code>";
					break;

					case 'userfullname':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('name', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('name', '');\n//</code>";
					break;
					
					case 'userid':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('id', 0);\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('id', 0);\n//</code>";
					break;
					
					case 'username':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return \$user->get('username', 'NOT LOGGED IN');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user =& JFactory::getUser(); \n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$user->get('username', 'NOT LOGGED IN');\n//</code>";
					break;
					
					case 'ipaddress':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return \$_SERVER['REMOTE_ADDR'];\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', \$_SERVER['REMOTE_ADDR']);\n//</code>";
					break;
				}
				
				$this->_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'textarea':
				$component->ComponentTypeId = 2;
				
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['COLS'] = $field->cols;
				$component->properties['ROWS'] = $field->rows;
				$component->properties['VALIDATIONRULE'] = 'none';
				$this->_convertValidationRule($field, $component, $scripts);
				
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				$component->properties['DEFAULTVALUE'] = $field->value;
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->value)."');\n//</code>";
			break;
			
			case 'html':
				$component->ComponentTypeId = 10;
				
				$component->properties['DEFAULTVALUE'] = $field->value;
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->value)."');\n//</code>";
			break;
			
			case 'submit':
				$component->ComponentTypeId = 13;
				
				$component->properties['LABEL'] = $field->value;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
			break;
			
			case 'select':
			case 'selectaustralianstates':
			case 'selectcanadianprovince':
			case 'selectcountries':
			case 'selectcurrency':
			case 'selectonetohundred':
			case 'selectrating':
			case 'selecttruefalse':
			case 'selectusastates':
			case 'selectyear':
				$component->ComponentTypeId = 3;
				
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['MULTIPLE'] = $field->multiple ? 'YES' : 'NO';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
				
				if ($field->value)
					$field->params = RSFormProHelper::checkValue($field->value, $field->params);
				
				$component->properties['ITEMS'] = $field->params;
				
				// sql values
				if ($field->option2)
				{
					$component->properties['ITEMS'] = "//<code>\n \$db =& JFactory::getDBO();\n \$db->setQuery(\"".$field->populatebysql."\"); return RSFormProHelper::createList(\$db->loadObjectList()); \n //</code>";
					
					if ($field->allowsetbyget)
						$component->properties['ITEMS'] = "//<code>\n \$db =& JFactory::getDBO();\n \$db->setQuery(\"".$field->populatebysql."\"); return RSFormProHelper::checkValue(JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->value)."'), RSFormProHelper::createList(\$db->loadObjectList())); \n //</code>";
				}
				if ($field->allowsetbyget)
				{
					$field->params = explode("\n", str_replace(array("\r\n", "\r"), "\n", $field->params));
					array_walk($field->params, array('plgSystemRSFPBFForms', '_addSlashes'));
					$field->params = implode("','", $field->params);
					
					$component->properties['ITEMS'] = "//<code>\n \$items = array('".$field->params."');\n return RSFormProHelper::checkValue(JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->multiple)."'), \$items);\n//</code>";
				}
				
				$this->_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'password':
				$component->ComponentTypeId = 14;
				
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['SIZE'] = $field->size;
				$component->properties['MAXSIZE'] = $field->maxlength;
				$component->properties['VALIDATIONRULE'] = 'none';
				$this->_convertValidationRule($field, $component, $scripts);
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				
				$component->properties['DEFAULTVALUE'] = $field->value;
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '".$this->_addSlashes($field->value)."');\n//</code>";
			break;
			
			case 'datepicker':
				$component->ComponentTypeId = 6;
				
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['CALENDARLAYOUT'] = 'POPUP';
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				$component->properties['DATEFORMAT'] = $this->_getCalendarFormat($field->value);
				
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".$this->_addSlashes($component->properties['NAME'])."', '');\n//</code>";
			break;
			
			case 'fileupload':
				$component->ComponentTypeId = 9;
				
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['DESTINATION'] = $field->fileupload_destdir;
				if ($this->_getMoveFiles())
					$component->properties['DESTINATION'] = JPATH_SITE.DS.'components'.DS.'com_rsform'.DS.'uploads';
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
				
				$component->properties['ACCEPTEDFILES'] = str_replace(',', "\n", $field->verify_fileupload_extensions);
				$component->properties['FILESIZE'] = $field->verify_fileupload_maxsize*1024;
			break;
			
			case 'pause':
				$component->ComponentTypeId = 7;
				
				$component->properties['LABEL'] = $field->value;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
			break;
		}
		
		static $cache;
		if (!is_array($cache))
			$cache = array();
		
		if (!isset($cache[$component->ComponentTypeId]))
		{
			$db =& JFactory::getDBO();
			$db->setQuery("SELECT `FieldName`, `FieldValues` FROM #__rsform_component_type_fields WHERE `ComponentTypeId`='".$component->ComponentTypeId."' ORDER BY `Ordering` ASC");
			$cache[$component->ComponentTypeId] = $db->loadObjectList();
		}
		foreach ($cache[$component->ComponentTypeId] as $item)
			if (!isset($component->properties[$item->FieldName]))
			{
				$item->FieldValues = RSFormProHelper::isCode($item->FieldValues);
				if (strpos($item->FieldValues, "\n") !== false)
					$item->FieldValues = reset(explode("\n", str_replace(array("\r\n", "\r"), "\n", $item->FieldValues)));
				
				$component->properties[$item->FieldName] = $lang->hasKey('RSFP_COMP_FVALUE_'.$item->FieldValues) ? JText::_('RSFP_COMP_FVALUE_'.$item->FieldValues) : $item->FieldValues;
			}
		
		return $component;
	}
	
	function _convertValidationRule($field, &$component, &$scripts)
	{
		/*
		verify_isvalidukninumber
		verify_isvalidssn
		verify_isvalidukpostcode
		verify_isvalidvatnumber
		verify_brazil_cpf
		verify_brazil_cnpj
		verify_iban
		- not supported
		*/
		
		if ($field->verify_isexistingusername)
		{
			$scripts['process'][] = '$db->setQuery("SELECT id FROM #__users WHERE `username` LIKE \'".$db->getEscaped($_POST[\'form\'][\''.$this->_addSlashes($field->slug).'\'])."\'");';
			$scripts['process'][] = "if (!\$db->loadResult()) \$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
		}
		
		if ($field->verify_isnotexistingusername)
		{
			$scripts['process'][] = '$db->setQuery("SELECT id FROM #__users WHERE `username` LIKE \'".$db->getEscaped($_POST[\'form\'][\''.$this->_addSlashes($field->slug).'\'])."\'");';
			$scripts['process'][] = "if (\$db->loadResult()) \$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
		}
		
		if ($field->verify_isemailaddress)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'email';
			
		if ($field->verify_isipaddress)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'ipaddress';
			
		if ($field->verify_isvaliduszip)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'uszipcode';
			
		if ($field->verify_isvalidcreditcardnumber)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'creditcard';
			
		if ($field->verify_isvalidurl)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'validurl';
		
		if ($field->verify_isalloweddomain)
		{
			$field->verify_isalloweddomain = explode(',', $field->verify_isalloweddomain);
			array_walk($field->verify_isalloweddomain, array('plgSystemRSFPBFForms', '_addSlashesAndTrim'));
			
			$scripts['process'][] = "\$domains = array('".implode("','", $field->verify_isalloweddomain)."');";
			$scripts['process'][] = "list(\$emailuser, \$domain) = explode('@', \$_POST['form']['".$this->_addSlashes($field->slug)."'], 2)";
			$scripts['process'][] = 'if (!in_array(strtolower($domain), $domains))';
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'email';
		}
		
		if ($field->verify_isdenieddomain)
		{
			$field->verify_isdenieddomain = explode(',', $field->verify_isdenieddomain);
			array_walk($field->verify_isdenieddomain, array('plgSystemRSFPBFForms', '_addSlashesAndTrim'));
			
			$scripts['process'][] = "\$domains = array('".implode("','", $field->verify_isdenieddomain)."');";
			$scripts['process'][] = "list(\$emailuser, \$domain) = explode('@', \$_POST['form']['".$this->_addSlashes($field->slug)."'], 2)";
			$scripts['process'][] = 'if (in_array(strtolower($domain), $domains))';
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'email';
		}
		
		if ($field->verify_isinteger)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		
		if ($field->verify_stringlengthgreaterthan)
		{
			$scripts['process'][] = "if (strlen(\$_POST['form']['".$this->_addSlashes($field->slug)."']) < ".(int) $field->verify_stringlengthgreaterthan.")";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
		}
		
		if ($field->verify_stringlengthlessthan)
		{
			$scripts['process'][] = "if (strlen(\$_POST['form']['".$this->_addSlashes($field->slug)."']) > ".(int) $field->verify_stringlengthlessthan.")";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
		}
		
		if ($field->verify_stringlengthequals)
		{
			$scripts['process'][] = "if (strlen(\$_POST['form']['".$this->_addSlashes($field->slug)."']) == ".(int) $field->verify_stringlengthequals.")";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
		}
		
		if ($field->verify_numbergreaterthan)
		{
			$scripts['process'][] = "if (\$_POST['form']['".$this->_addSlashes($field->slug)."'] <= '".$field->verify_numbergreaterthan."')";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_numberlessthan)
		{
			$scripts['process'][] = "if (\$_POST['form']['".$this->_addSlashes($field->slug)."'] >= '".$field->verify_numberlessthan."')";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_numberequals)
		{
			$scripts['process'][] = "if (\$_POST['form']['".$this->_addSlashes($field->slug)."'] == '".$field->verify_numberequals."')";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_regex)
		{
			if (isset($component->properties['VALIDATIONEXTRA']))
				$component->properties['VALIDATIONEXTRA'] = $field->verify_regex;
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'regex';
		}
		
		if ($field->verify_equalto)
		{
			if (isset($component->properties['VALIDATIONEXTRA']))
				$component->properties['VALIDATIONEXTRA'] = $field->verify_equalto;
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_isinarray)
		{
			$field->verify_isinarray = explode(',', $field->verify_isinarray);
			array_walk($field->verify_isinarray, array('plgSystemRSFPBFForms', '_addSlashesAndTrim'));
			
			$scripts['process'][] = "\$values = array('".implode("','", $field->verify_isinarray)."');";
			$scripts['process'][] = 'if (!in_array($_POST[\'form\'][\''.$this->_addSlashes($field->slug).'\'], $values))';
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".$this->_addSlashes($field->slug)."');";
		}
	}
	
	function _addSlashes(&$item, $key=0)
	{
		$item = addcslashes($item, "'");
		return $item;
	}
	
	function _addSlashesAndTrim(&$item, $key=0)
	{
		$item = addcslashes(trim($item), "'");
		return $item;
	}
	
	function _getCalendarFormat($format)
	{
		$js  = array('%m', '%d', '%Y');
		$php = array('mm', 'dd', 'yyyy');
		
		return str_replace($js, $php, $format);
	}
	
	function _addComponent($component, $formId)
	{
		$db =& JFactory::getDBO();
		$db->setQuery("INSERT INTO #__rsform_components SET FormId='".$formId."', `ComponentTypeId`='".$component->ComponentTypeId."', `Order`='".$component->Order."', `Published`='".$component->Published."'");
		$db->query();
		
		$componentId = $db->insertid();
		if (is_array($component->properties))
			foreach ($component->properties as $property => $value)
			{
				$db->setQuery("INSERT INTO #__rsform_properties SET PropertyValue='".$db->getEscaped($value)."', PropertyName='".$db->getEscaped($property)."', ComponentId='".$componentId."'");
				$db->query();
			}
		
		return $componentId;
	}
	
	function _getSlugs($id)
	{
		static $cache;
		
		if (!is_array($cache))
			$cache = array();
		
		if (!isset($cache[$id]))
		{
			$db =& JFactory::getDBO();
			$db->setQuery("SELECT `slug` FROM #__form_fields WHERE form_id='".$id."'");
			$cache[$id] = $db->loadResultArray();
		}
		
		return $cache[$id];
	}
}