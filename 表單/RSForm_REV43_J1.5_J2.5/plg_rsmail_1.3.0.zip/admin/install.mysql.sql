DELETE FROM `#__rsform_component_type_fields` WHERE `ComponentTypeId` = 25;
DELETE FROM `#__rsform_component_types` WHERE `ComponentTypeId` = 25;


INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`) VALUES(25, 'checkboxGroup');
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'NAME', 'hiddenparam', 'RSMail_component', 1);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'CAPTION', 'textbox', '', 2);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'ITEMS', 'hiddenparam', '//<code>\r\nif(class_exists(''plgSystemRsmail_RSFormPro_Subscription''))return plgSystemRsmail_RSFormPro_Subscription::createSubscribeOption();\r\n//</code> ', 3);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'FLOW', 'hiddenparam', 'HORIZONTAL', 4);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'REQUIRED', 'select', 'YES\r\nNO', 5);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'ADDITIONALATTRIBUTES', 'textarea', '', 6);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'DESCRIPTION', 'textarea', '', 7);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'VALIDATIONMESSAGE', 'textarea', 'INVALIDINPUT', 8);
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeFieldId`, `ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES('', 25, 'COMPONENTTYPE', 'hidden', '25', 9);