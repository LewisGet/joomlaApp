<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * RSForm! Pro system plugin
 */
 
if(file_exists(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'helpers'.DS.'rsevents.php') && file_exists(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'models'.DS.'events.php') && file_exists(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'tables'.DS.'rsevents_events.php') && file_exists(JPATH_SITE.DS.'components'.DS.'com_rsform'.DS.'rsform.php'))
{
	class plgSystemRSFPRSEvents extends JPlugin
	{
		/**
		 * Constructor
		 *
		 * For php4 compatibility we must not use the __constructor as a constructor for plugins
		 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
		 * This causes problems with cross-referencing necessary for the observer design pattern.
		 *
		 * @access	protected
		 * @param	object	$subject The object to observe
		 * @param 	array   $config  An array that holds the plugin configuration
		 * @since	1.0
		 */
		function plgSystemRSFPRSEvents( &$subject, $config )
		{
			parent::__construct( $subject, $config );
			$this->newComponents = array(16,17,18,19,20,26,40);
		}
		
		function canRun()
		{
			if (class_exists('RSFormProHelper')) return true;
			
			$helper = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'.DS.'helpers'.DS.'rsform.php';
			if (file_exists($helper))
			{
				require_once($helper);
				return true;
			}
			
			return false;
		}
		
		/*
			Event Triggered Functions
		*/
		function rsfp_bk_onAfterShowComponents()
		{
			if (!$this->canRun()) return;
			
			$lang =& JFactory::getLanguage();
			$lang->load( 'plg_system_rsfprsevents' );
			$lang->load( 'com_rsevents',JPATH_SITE );
			?>
			
			<li class="rsform_navtitle"><?php echo JText::_('RSFP_RSEVENTS_LABEL'); ?></li>
			<li><a href="javascript: void(0);" onclick="displayTemplate('16');return false;" id="rsfpc16"><span id="textbox"><?php echo JText::_('RSFP_RSEVENTS_FNAME'); ?></span></a></li>
			<li><a href="javascript: void(0);" onclick="displayTemplate('17');return false;" id="rsfpc17"><span id="textbox"><?php echo JText::_('RSFP_RSEVENTS_LNAME'); ?></span></a></li>
			<li><a href="javascript: void(0);" onclick="displayTemplate('18');return false;" id="rsfpc18"><span id="textbox"><?php echo JText::_('RSFP_RSEVENTS_EMAIL'); ?></span></a></li>
			<li><a href="javascript: void(0);" onclick="displayTemplate('19');return false;" id="rsfpc19"><span id="dropdown"><?php echo JText::_('RSFP_RSEVENTS_TICKETS'); ?></span></a></li>
			<li><a href="javascript: void(0);" onclick="displayTemplate('26');return false;" id="rsfpc26"><span id="dropdown"><?php echo JText::_('RSFP_RSEVENTS_NUMTICKETS'); ?></span></a></li>
			<li><a href="javascript: void(0);" onclick="displayTemplate('20');return false;" id="rsfpc20"><span id="radiogroup"><?php echo JText::_('RSFP_RSEVENTS_PAYMENT'); ?></span></a></li>
			<li><a href="javascript: void(0);" onclick="displayTemplate('40');return false;" id="rsfpc40"><span id="textbox"><?php echo JText::_('RSFP_RSEVENTS_CUPON'); ?></span></a></li>
			<?php
		}
		
		function rse_f_onAfterLoadRegistrationForm($args)
		{
			$db = &JFactory::getDBO();
			
			//do we have payment on this event?
			$db->setQuery("SELECT SUM(TicketPrice) AS Price, COUNT(IdTicket) AS Cnt FROM `#__rsevents_tickets` WHERE `IdEvent` = '".(int) $args['event']->IdEvent."'");
			$ticketProperties = $db->loadObject();
		
			$pieces = array(16=>16, 17=>17, 18=>18, 19=>19, 20=>20, 26=>26);
			if(!$ticketProperties->Price) 
			{
				unset($pieces[20]);
				unset($pieces[26]);
				if($ticketProperties->Cnt == 1) unset($pieces[19]);
			}
			
			$db->setQuery("SELECT DISTINCT f.FormId FROM #__rsform_forms f LEFT JOIN #__rsform_components c ON c.FormId=f.FormId WHERE c.ComponentTypeId IN ( ".implode(',',$pieces).") AND f.Published =1 AND c.Published=1 GROUP BY c.FormId HAVING COUNT(c.ComponentTypeId ) = '".count($pieces)."'");
			$args['formids'] = $db->loadResultArray();
		}
		
		function rsfp_f_onBeforeFormDisplay($args)
		{
			if (!$this->canRun()) return;
			
			$option = JRequest::getCmd('option');
			$view = JRequest::getCmd('view');
			$layout = JRequest::getCmd('layout');
			$cid = JRequest::getInt('cid');
			
			$exists = RSFormProHelper::componentExists($args['formId'], $this->newComponents);
			if (!empty($exists))
			{
				if ($option == 'com_rsevents' && $view == 'events' && $layout == 'subscribe')
				{
					$args['formLayout'] .= '<script type="text/javascript">';
					$args['formLayout'] .= "rse_hidePayment(document.getElementById('RSEventsTickets').value,1,'".$cid."');";
					$args['formLayout'] .= '</script>';
				}
			}
		}
		
		function rsfp_f_onBeforeFormValidation($args)
		{
			if (!$this->canRun()) return;
			
			$form   = JRequest::getVar('form');
			$formId = (int) $form['formId'];
			
			$exists = RSFormProHelper::componentExists($formId, $this->newComponents);
			if (!empty($exists))
			{
				require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'helpers'.DS.'events.php');
				require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'helpers'.DS.'rsevents.php');
				
				$db 	=& JFactory::getDBO();
				$cid 	= JRequest::getInt('cid',0,'request');
				$option = JRequest::getVar('option',0,'request');
				
				if ($cid && $option == 'com_rsevents' && $this->_getHasForm($cid, $formId))
				{
					$db->setQuery("SELECT COUNT(IdSubscription) FROM #__rsevents_subscriptions WHERE IdEvent='".(int) $cid."' AND Email='".$db->getEscaped($form['RSEventsEmail'])."'");
					$registered = $db->loadResult();
					
					$db->setQuery("SELECT ConfigValue FROM #__rsevents_config WHERE ConfigName = 'event.multiple.reg' ");
					$multiplereg = $db->loadResult();
					if ($registered && $multiplereg == 0)
					{
						JError::raiseWarning(500, JText::_('RSE_SUBSCRIBER_ALLREADY_REGISTERED'));
						$args['invalid'][] = $this->_getComponentId('RSEventsEmail', $formId);
					}
				}
			}
		}
		
		function rsfp_f_onAfterFormProcess($args)
		{
			if (!$this->canRun()) return;
			
			$exists = RSFormProHelper::componentExists($args['formId'], $this->newComponents);
			if (!empty($exists))
			{
				require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'helpers'.DS.'events.php');
				require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'helpers'.DS.'rsevents.php');
				
				$db 	=& JFactory::getDBO();
				$cid 	= JRequest::getInt('cid',0,'request');
				$option = JRequest::getVar('option',0,'request');
				if ($cid && $option == 'com_rsevents' && $this->_getHasForm($cid, $args['formId']))
				{
					eventsHelper::saveRegistration($args['SubmissionId']);
					
					$form = JRequest::getVar('form');
					if ($form['RSEventsFirstName'])
					{
						$tickets = JRequest::getVar('tickets');
						
						if (empty($tickets))
							$tickets = $form['RSEventsTickets'];
						
						$hasPrice = 0;
						
						if (!empty($tickets))
							foreach ($tickets as $ticket)
							{
								$db->setQuery("SELECT TicketPrice FROM #__rsevents_tickets WHERE IdTicket = ".(int) $ticket." ");
								if ($db->loadResult() > 0) $hasPrice = 1;
							}
						
						if ($hasPrice)
							exit();
					}
				}
			}
		}
		
		function rsfp_f_onBeforeStoreSubmissions($args)
		{
			$db =& JFactory::getDBO();
			$post =& $args['post'];
			
			$db->setQuery("SELECT ConfigValue FROM #__rsevents_config WHERE ConfigName = 'event.multiple.tickets' ");
			$multipleTickets = $db->loadResult();
			
			$thestring = '';
			
			if ($multipleTickets)
			{
				$tickets = JRequest::getVar('tickets');
				$quantity = JRequest::getVar('notickets');
				
				if (!empty($tickets))
				{
					$tmp = array();
					foreach ($tickets as $ticket)
					{
						$db->setQuery("SELECT TicketName FROM #__rsevents_tickets WHERE IdTicket = ".(int) $ticket." ");
						$ticketName = $db->loadResult();
						$ticketno = isset($quantity[$ticket]) ? $quantity[$ticket] : 1;
						
						$tmp[] = $ticketno.' x '.$ticketName;
					}
					
					$thestring .= !empty($tmp) ? implode(' , ',$tmp) : '';
					
				} else 
				{
					$ticket = $post['RSEventsTickets'];
					$ticket = is_array($post['RSEventsTickets']) ? $post['RSEventsTickets'][0] : $post['RSEventsTickets'];
					
					$db->setQuery("SELECT TicketName FROM #__rsevents_tickets WHERE IdTicket = ".(int) $ticket." ");
					$ticketName = $db->loadResult();
					
					$quantity = $post['RSEventsNumTickets'];
					$quantity = is_array($post['RSEventsNumTickets']) ? $post['RSEventsNumTickets'][0] : $post['RSEventsNumTickets'];
					$quantity = !empty($quantity) ? (int) $quantity : 1;
					
					$thestring .= $quantity.' x '.$ticketName;
				}
			} else 
			{
				$ticket = $post['RSEventsTickets'];
				$ticket = is_array($post['RSEventsTickets']) ? $post['RSEventsTickets'][0] : $post['RSEventsTickets'];
				
				$db->setQuery("SELECT TicketName FROM #__rsevents_tickets WHERE IdTicket = ".(int) $ticket." ");
				$ticketName = $db->loadResult();
				
				$quantity = $post['RSEventsNumTickets'];
				$quantity = is_array($post['RSEventsNumTickets']) ? $post['RSEventsNumTickets'][0] : $post['RSEventsNumTickets'];
				$quantity = !empty($quantity) ? (int) $quantity : 1;
				
				$thestring .= $quantity.' x '.$ticketName;
			}
			
			$post['RSEventsTickets'] = $thestring;
			
			$payment = $post['RSEventsPayment'];
			
			$db->setQuery("SELECT name FROM #__rsevents_payments WHERE id = ".(int) $payment." ");
			$pname = $db->loadResult();
			
			$post['RSEventsPayment'] = !empty($pname) ? $pname : ucfirst($payment);
		}
		
		function _getHasForm($IdEvent, $formId)
		{
			static $cache;
			if (!isset($cache[$formId]))
			{
				$db =& JFactory::getDBO();
				$db->setQuery("SELECT count(IdEvent) cnt FROM #__rsevents_events WHERE EventRegistrationForm = '".(int) $formId."' AND IdEvent = '".(int) $IdEvent."'");
				
				$cache[$formId] = $db->loadResult();
			}
			
			return $cache[$formId];
		}
		
		function _getComponentId($name, $formId)
		{
			if (method_exists('RSFormProHelper', 'getComponentId'))
				return RSFormProHelper::getComponentId($name, $formId);
			
			static $cache;
			if (!is_array($cache))
				$cache = array();
				
			if (empty($formId))
			{
				$formId = JRequest::getInt('formId');
				if (empty($formId))
				{
					$post   = JRequest::getVar('form');
					$formId = (int) @$post['formId'];
				}
			}
			
			if (!isset($cache[$formId][$name]))
				$cache[$formId][$name] = RSFormProHelper::componentNameExists($name, $formId);
			
			return $cache[$formId][$name];
		}
		
		/*
			Additional Functions
		*/
		function RSEventsGetSettings()
		{
			$db =& JFactory::getDBO();
			$db->setQuery("SELECT * FROM `#__rsevents_config`");
			$rseventsConfigDb = $db->loadObjectList();
			$rseventsConfig = array();
			foreach ($rseventsConfigDb as $rowConfig)
				$rseventsConfig[$rowConfig->ConfigName] = $rowConfig->ConfigValue;
			
			return $rseventsConfig;
		}
		
		
		function RSEventsGetEvent($cid)
		{
			require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'helpers'.DS.'rsevents.php');
			require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'models'.DS.'events.php');
			require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'tables'.DS.'rsevents_events.php');
			return rseventsModelEvents::getEvent($cid);
		}
		
		
		function RSEventsTickets()
		{
			$lang =& JFactory::getLanguage();
			$lang->load( 'plg_system_rsfprsevents' );
			$lang->load( 'com_rsevents',JPATH_SITE );
			
			$info  = plgSystemRSFPRSEvents::RSEventsGetSettings();
			$db = &JFactory::getDBO();
			$cid = JRequest::getVar('cid',0,'request');
			$event = plgSystemRSFPRSEvents::RSEventsGetEvent($cid);
		
			$db->setQuery("SELECT IdTicket,  TicketName, TicketPrice, TicketMaxAudience, TicketDescription FROM #__rsevents_tickets WHERE IdEvent='".(int) $cid."' ORDER BY ordering");
		
			$tickets = $db->loadObjectList();
			$ticket_list = array();
			$ticket_descriptions = '';
			foreach($tickets as $i => $objTicketDetails)
			{
				$db->setQuery("SELECT SUM(st.TicketsSubscribed) FROM #__rsevents_subscription_tickets st LEFT JOIN #__rsevents_subscriptions s ON s.IdSubscription=st.IdSubscription WHERE st.IdTicket='".(int) $objTicketDetails->IdTicket."' AND s.SubscriptionState IN (1,0)");
				$result = $db->loadResult();
				
				if($event->EventOverbooking == 0)
				{
					if($tickets[$i]->TicketMaxAudience > $result || $tickets[$i]->TicketMaxAudience == 0)
					{
						$objTicketDetails->value = (($objTicketDetails->TicketPrice == '0') ? $objTicketDetails->IdTicket.'|'.$objTicketDetails->TicketName . ' (' . JText::_('RSE_TICKETS_FREE').')' : $objTicketDetails->IdTicket.'|'.$objTicketDetails->TicketName . ' (' . number_format($objTicketDetails->TicketPrice,$info['payment.nrdecimals'], $info['payment.decimal'], $info['payment.thousands']).' '.$info['payment.currency'].')');
						$ticket_list[] = $objTicketDetails->value;
						$ticket_descriptions .= '<p id="rsevents_ticket_'.$objTicketDetails->IdTicket.'" style="display:'.($i==0 ? 'inline':'none').';">'.$objTicketDetails->TicketDescription.'</p>';
					}
				}
				else 
				{
					$objTicketDetails->value = (($objTicketDetails->TicketPrice == '0') ? $objTicketDetails->IdTicket.'|'.$objTicketDetails->TicketName . ' (' . JText::_('RSE_TICKETS_FREE').')' : $objTicketDetails->IdTicket.'|'.$objTicketDetails->TicketName . ' (' . number_format($objTicketDetails->TicketPrice,$info['payment.nrdecimals'], $info['payment.decimal'], $info['payment.thousands']).' '.$info['payment.currency'].')');
					$ticket_list[] = $objTicketDetails->value;
					$ticket_descriptions .= '<p id="rsevents_ticket_'.$objTicketDetails->IdTicket.'" style="display:'.($i==0 ? 'inline':'none').';">'.$objTicketDetails->TicketDescription.'</p>';
				}
			}
		
			$ticket_list = implode("\n",$ticket_list);
		
			return $ticket_list;
		}
		
		function RSEventsGetEmail()
		{
			$db = &JFactory::getDBO();
			$user = &JFactory::getUser();
			
			$db->setQuery("SELECT email FROM #__users WHERE id=".(int) $user->id);
			return $db->loadResult();
		}
		
		function RSEventsGetInfo($what=0)
		{
			$user = &JFactory::getUser();
			$name=explode(' ',$user->name); 
			$fName=@$name[0];
			$lName ='';
			if (count($name) > 1)
			{
				unset($name[0]);
				$lName = implode(' ',$name);
			}
			if($what == 0)
			return $fName;
			else
			return $lName;
		}
		
		function RSEventsGetPayment()
		{
			$db		=& JFactory::getDBO();
			$lang	=& JFactory::getLanguage();
			
			$lang->load( 'plg_system_rsfprsevents' );
			$lang->load( 'plg_system_rseventsauthorize' );
			$lang->load( 'com_rsevents',JPATH_SITE );
			
			$payments = array();
			$info  = plgSystemRSFPRSEvents::RSEventsGetSettings();
			
			$id = JRequest::getInt('cid');
			
			$db->setQuery("SELECT payments FROM #__rsevents_events WHERE IdEvent = ".$id." ");
			$eventPayments = $db->loadResult();
			
			require_once(JPATH_SITE.DS.'components'.DS.'com_rsevents'.DS.'helpers'.DS.'rsevents.php');
			$payment_items = rseventsHelper::getPayments(false,$eventPayments);
			
			if (!empty($payment_items))
			{
				foreach ($payment_items as $payment)
				{
					$default = $info['payment.default'] == $payment->value ? '[c]' : '';
					$payments[] = $payment->value.'|'.$payment->text.$default;
				}
			}
			
			if (!empty($payments))
				return implode("\n",$payments);
			
			return '';
		}
	}
}