<?php
/**
* @version 1.4.0
* @package RSform!Pro 1.4.0
* @copyright (C) 2007-2012 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * RSForm! Pro Payment Plugin
 */
class plgSystemRSFPPayment extends JPlugin
{
	protected $_products = array();
	
	/**
	 * Constructor
	 *
	 * For php4 compatibility we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	function plgSystemRSFPPayment( &$subject, $config )
	{
		parent::__construct( $subject, $config );
		$this->newComponents = array(21, 22, 23, 27, 28);
		
		$this->loadLanguage();
	}
	
	function canRun()
	{
		if (class_exists('RSFormProHelper')) return true;
		
		$helper = JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsform.php';
		if (file_exists($helper))
		{
			require_once($helper);
			RSFormProHelper::readConfig();
			return true;
		}
		
		return false;
	}
	
	function rsfp_bk_onAfterShowComponents()
	{
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfppayment');
		
		$mainframe 	= JFactory::getApplication();
		$db 		= JFactory::getDBO();
		$formId 	=  JRequest::getInt('formId');
		
		$link1 = "displayTemplate('21')";
		$link2 = "displayTemplate('23')";
		$link3 = "displayTemplate('27')";
		$link4 = "displayTemplate('28')";
		if ($components = RSFormProHelper::componentExists($formId, 21))
			$link1 = "displayTemplate('21', '".$components[0]."')";
		if ($components = RSFormProHelper::componentExists($formId, 23))
			$link2 = "displayTemplate('23', '".$components[0]."')";
		if ($components = RSFormProHelper::componentExists($formId, 27))
			$link3 = "displayTemplate('27', '".$components[0]."')";
		if ($components = RSFormProHelper::componentExists($formId, 28))
			$link4 = "displayTemplate('28', '".$components[0]."')";
		
		$doc = JFactory::getDocument();
		$doc->addStyleDeclaration('ul.rsform_leftnav li a span#payment, ul.rsform_leftnav li a#payment span { background: url(components/com_rsform/assets/images/icons/payment.png) no-repeat 10px center; }');
		$doc->addStyleDeclaration('ul.rsform_leftnav li a span#donation { background: url(components/com_rsform/assets/images/icons/donation.png) no-repeat 10px center; }');
		$doc->addStyleDeclaration('ul.rsform_leftnav li a span#total { background: url(components/com_rsform/assets/images/icons/total.png) no-repeat 10px center; }');
		$doc->addStyleDeclaration('ul.rsform_leftnav li a span#choosepayment { background: url(components/com_rsform/assets/images/icons/choosepayment.png) no-repeat 10px center; }');
		
		?>
		<li class="rsform_navtitle"><?php echo JText::_('RSFP_PAYMENT'); ?></li>
		<li><a href="javascript: void(0);" onclick="<?php echo $link1;?>;return false;" id="rsfpc21"><span id="payment"><?php echo JText::_('RSFP_SPRODUCT'); ?></span></a></li>
		<li><a href="javascript: void(0);" onclick="displayTemplate('22');return false;" id="rsfpc22"><span id="payment"><?php echo JText::_('RSFP_MPRODUCT'); ?></span></a></li>
		<li><a href="javascript: void(0);" onclick="<?php echo $link4;?>;return false;" id="rsfpc27"><span id="donation"><?php echo JText::_('RSFP_DONATION'); ?></span></a></li>
		<li><a href="javascript: void(0);" onclick="<?php echo $link2;?>;return false;" id="rsfpc23"><span id="total"><?php echo JText::_('RSFP_TOTAL'); ?></span></a></li>
		<li><a href="javascript: void(0);" onclick="<?php echo $link3;?>;return false;" id="rsfpc27"><span id="choosepayment"><?php echo JText::_('RSFP_CHOOSE_PAYMENT'); ?></span></a></li>
		<?php
	}
	
	function rsfp_bk_onAfterShowFormEditTabs()
	{
		$formId = JRequest::getInt('formId');
		
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfppayment');
		
		$row = JTable::getInstance('RSForm_Payment', 'Table');
		if (!$row)
			return;
		$row->load($formId);
		$row->params = !empty($row->params) ? unserialize($row->params) : new stdClass();
		
		$def_params = array('UserEmail', 'AdminEmail', 'AdditionalEmails');
		foreach ($def_params as $def_param)
			if (!isset($row->params->{$def_param}))
				$row->params->{$def_param} = 0;
		
		$lists['UserEmail'] 		= RSFormProHelper::renderHTML('select.booleanlist','payment[UserEmail]','class="inputbox"',$row->params->UserEmail);
		$lists['AdminEmail'] 		= RSFormProHelper::renderHTML('select.booleanlist','payment[AdminEmail]','class="inputbox"',$row->params->AdminEmail);
		$lists['AdditionalEmails'] 	= RSFormProHelper::renderHTML('select.booleanlist','payment[AdditionalEmails]','class="inputbox"',$row->params->AdditionalEmails);
		
		echo '<div id="paymentdiv">';
			include JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/payment.php';
		echo '</div>';
	}
	
	function rsfp_bk_onAfterShowFormEditTabsTab()
	{
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfppayment');
		
		echo '<li><a href="javascript: void(0);" id="payment"><span>'.JText::_('RSFP_PAYMENT_EMAIL_SETTINGS').'</span></a></li>';
	}
	
	function rsfp_onFormSave($form)
	{
		$post = JRequest::get('post', JREQUEST_ALLOWRAW);
		
		$row = JTable::getInstance('RSForm_Payment', 'Table');
		if (!$row)
			return;
		$row->form_id = $post['formId'];
		$params = new stdClass();
		if (isset($post['payment']) && is_array($post['payment']))
			foreach ($post['payment'] as $key => $value)
				$params->{$key} = $value;
		$row->params = serialize($params);
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT form_id FROM #__rsform_payment WHERE form_id='".(int) $post['formId']."'");
		if (!$db->loadResult())
		{
			$db->setQuery("INSERT INTO #__rsform_payment SET form_id='".(int) $post['formId']."'");
			$db->execute();
		}
		
		if ($row->store())
		{
			return true;
		}
		else
		{
			JError::raiseWarning(500, $row->getError());
			return false;
		}
	}
	
	function rsfp_bk_onAfterCreateComponentPreview($args = array())
	{		
		$nodecimals = RSFormProHelper::getConfig('payment.nodecimals');
		$decimal    = RSFormProHelper::getConfig('payment.decimal');
		$thousands  = RSFormProHelper::getConfig('payment.thousands');
		$currency   = RSFormProHelper::getConfig('payment.currency');
		
		switch ($args['ComponentTypeName'])
		{
			case 'singleProduct':
				if (!$args['data']['PRICE']) {
					$args['data']['PRICE'] = 0;
				}
				$args['out'] = '<td>'.$args['data']['CAPTION'].'</td>';
				$args['out'].= '<td><img src="'.JURI::root(true).'/administrator/components/com_rsform/assets/images/icons/payment.png" /> '.$args['data']['CAPTION'].' - '.number_format($args['data']['PRICE'], $nodecimals, $decimal, $thousands).' '.$currency.'</td>';	
			break;
			
			case 'multipleProducts':
				$out 	=& $args['out'];
				$data 	=& $args['data'];
				
				$out  = '<td>'.$data['CAPTION'].'</td>';
				$out .= '<td><img src="'.JURI::root(true).'/administrator/components/com_rsform/assets/images/icons/payment.png" />';
				
				$items = RSFormProHelper::explode(RSFormProHelper::isCode($data['ITEMS']));
				
				if ($data['VIEW_TYPE'] == 'DROPDOWN') {
					$out .= '<select '.($data['MULTIPLE']=='YES' ? 'multiple="multiple"' : '').'>';

					$special = array('[c]', '[g]', '[d]');
					
					foreach ($items as $item) {
						@list($val, $txt) = @explode('|', str_replace($special, '', $item), 2);
						if (is_null($txt))
							$txt = $val;
						if (!$val) {
							$val = 0;
						}
						$txt_price = $txt.' - '.number_format($val, $nodecimals, $decimal, $thousands).' '.$currency;
						
						// <optgroup>
						if (strpos($item, '[g]') !== false) {
							$out .= '<optgroup label="'.$this->_escape($val).'">';
							continue;
						}
						// </optgroup>
						if(strpos($item, '[/g]') !== false) {
							$out .= '</optgroup>';
							continue;
						}
						
						$additional = '';
						// selected
						if (strpos($item, '[c]') !== false)
							$additional .= 'selected="selected"';
						// disabled
						if (strpos($item, '[d]') !== false)
							$additional .= 'disabled="disabled"';
						
						$out .= '<option '.$additional.' value="'.$this->_escape($txt).'">'.$this->_escape($txt_price).'</option>';
					}
					$out .= '</select>';
				} elseif ($data['VIEW_TYPE'] == 'CHECKBOX') {
					$i = 0;
					
					$special = array('[c]', '[d]');
					
					foreach ($items as $item) {
						@list($val, $txt) = @explode('|', str_replace($special, '', $item), 2);
						if (is_null($txt))
							$txt = $val;
						if (!$val) {
							$val = 0;
						}
						$txt_price = $txt.' - '.number_format($val, $nodecimals, $decimal, $thousands).' '.$currency;
						
						$additional = '';
						// checked
						if (strpos($item, '[c]') !== false)
							$additional .= 'checked="checked"';
						// disabled
						if (strpos($item, '[d]') !== false)
							$additional .= 'disabled="disabled"';
							
						$out .= '<input '.$additional.' type="checkbox" value="'.$this->_escape($txt).'" /><label>'.$txt_price.'</label>';
						if ($data['FLOW']=='VERTICAL') {
							$out .= '<br />';
						}
						
						$i++;
					}
				}
				
				$out .= '</td>';
			break;
			
			case 'total':
				$args['out'] = '<td>'.$args['data']['CAPTION'].'</td>';
				$args['out'].= '<td><img src="'.JURI::root(true).'/administrator/components/com_rsform/assets/images/icons/total.png" /> '.number_format(0, $nodecimals, $decimal, $thousands).' '.$currency.'</td>';	
			break;
			
			case 'choosePayment':
				$out 	=& $args['out'];
				$data 	=& $args['data'];
				$out =  '<td>'.$data['CAPTION'].'</td>';
				$out .= '<td><img src="'.JURI::root(true).'/administrator/components/com_rsform/assets/images/icons/choosepayment.png" /> ';	
				
				$items = $this->_getPayments($args['formId']);
				
				if ($data['VIEW_TYPE'] == 'DROPDOWN') {
					$out .= '<select>';
					foreach ($items as $item) {
						$out .= '<option>'.$this->_escape($item->text).'</option>';
					}
					$out .= '</select>';
				} elseif ($data['VIEW_TYPE'] == 'RADIOGROUP') {
					$i = 0;
					foreach ($items as $item) {
						$checked = $i == 0 ? 'checked="checked"' : '';
						$out .= '<input '.$checked.' type="radio" value="'.$this->_escape($item->value).'" id="'.$data['NAME'].$i.'" /><label for="'.$data['NAME'].$i.'">'.$this->_escape($item->text).'</label>';
						if ($data['FLOW']=='VERTICAL') {
							$out .= '<br />';
						}
						$i++;
					}
				}
				$out .= '</td>';
			break;
			
			case 'donationProduct':
				$defaultValue = RSFormProHelper::isCode($args['data']['DEFAULTVALUE']);
				
				$args['out']  = '<td>'.$args['data']['CAPTION'].'</td>';
				$args['out'] .= '<td><img src="'.JURI::root(true).'/administrator/components/com_rsform/assets/images/icons/payment.png" /> <input type="text" value="'.$this->_escape($defaultValue).'" size="'.$args['data']['SIZE'].'" /></td>';
			break;
		}
	}
	
	function rsfp_bk_onAfterShowConfigurationTabs($tabs)
	{
		$lang = JFactory::getLanguage();
		$lang->load( 'plg_system_rsfppayment' );
		
		$tabs->addTitle(JText::_('RSFP_PAYMENT'), 'form-payment');
		$tabs->addContent($this->paymentConfigurationScreen());
	}
	
	function rsfp_bk_onAfterCreateFrontComponentBody($args)
	{
		$nodecimals = RSFormProHelper::getConfig('payment.nodecimals');
		$decimal    = RSFormProHelper::getConfig('payment.decimal');
		$thousands  = RSFormProHelper::getConfig('payment.thousands');
		$currency   = RSFormProHelper::getConfig('payment.currency');
		
		$value = $args['value'];
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT FormLayoutName FROM #__rsform_forms WHERE FormId='".(int) $args['formId']."'");
		$layoutName = $db->loadResult();
		
		$out 		=& $args['out'];
		$data 		=& $args['data'];
		$invalid 	=& $args['invalid'];
		
		switch($args['r']['ComponentTypeId'])
		{
			case 21:
			{
				if(isset($args['data']['SHOW']) && $args['data']['SHOW']=='NO')
				{
					//Hidden
					$args['out'] = '<input type="hidden" name="rsfp_payment_item[]" value="'.$this->_escape($args['data']['PRICE']).'"/>
					<input type="hidden" name="form['.$args['data']['NAME'].']" id="'.$args['data']['NAME'].'" value="'.$this->_escape($args['data']['CAPTION']).'"/>';
				}
				else
				{
					$args['out'] = '<input type="hidden" name="rsfp_payment_item[]" id="'.$args['data']['NAME'].'" value="'.$this->_escape($args['data']['PRICE']).'"/>
					<input type="hidden" name="form['.$args['data']['NAME'].']" id="'.$args['data']['NAME'].'" value="'.$this->_escape($args['data']['CAPTION']).'"/>';
				}
			}
			break;
			
			case 22:
			{
				switch($args['data']['VIEW_TYPE'])
				{
					case 'DROPDOWN':
					{
						$className = 'rsform-select-box';
						if ($invalid)
							$className .= ' rsform-error';
						RSFormProHelper::addClass($data['ADDITIONALATTRIBUTES'], $className);
						
						$out .= '<select '.($data['MULTIPLE']=='YES' ? 'multiple="multiple"' : '').' name="form['.$data['NAME'].'][]" '.((int) $data['SIZE'] > 0 ? 'size="'.(int) $data['SIZE'].'"' : '').' id="payment-'.$args['componentId'].'" '.$data['ADDITIONALATTRIBUTES'].' onchange="getPrice_'.$args['formId'].'();">';
						
						$items = RSFormProHelper::explode(RSFormProHelper::isCode($data['ITEMS']));
						
						$special = array('[c]', '[g]', '[d]');
						
						foreach ($items as $item)
						{
							@list($val, $txt) = @explode('|', str_replace($special, '', $item), 2);
							if (is_null($txt))
								$txt = $val;
							if (!$val) {
								$val = 0;
							}
							$txt_price = $txt.' - '.number_format($val, $nodecimals, $decimal, $thousands).' '.$currency;
							
							// <optgroup>
							if (strpos($item, '[g]') !== false) {
								$out .= '<optgroup label="'.$this->_escape($val).'">';
								continue;
							}
							// </optgroup>
							if(strpos($item, '[/g]') !== false) {
								$out .= '</optgroup>';
								continue;
							}
							
							$additional = '';
							// selected
							if ((strpos($item, '[c]') !== false && empty($value)) || (isset($value[$data['NAME']]) && in_array($val, $value[$data['NAME']])))
								$additional .= 'selected="selected"';
							// disabled
							if (strpos($item, '[d]') !== false)
								$additional .= 'disabled="disabled"';
							
							$out .= '<option '.$additional.' value="'.$this->_escape($txt).'">'.$this->_escape($txt_price).'</option>';
							
							$product = array(
								$data['NAME'].'|_|'.$txt => $val
							);
							$this->_products = $this->merge($this->_products, $product);
						}
						$out .= '</select>';
					}
					break;
					
					case 'CHECKBOX':
					{
						$i = 0;
				
						$items = RSFormProHelper::explode(RSFormProHelper::isCode($data['ITEMS']));
						
						$special = array('[c]', '[d]');
						
						foreach ($items as $item)
						{
							@list($val, $txt) = @explode('|', str_replace($special, '', $item), 2);
							if (is_null($txt))
								$txt = $val;
							if (!$val) {
								$val = 0;
							}
							$txt_price = $txt.' - '.number_format($val, $nodecimals, $decimal, $thousands).' '.$currency;
							
							$additional = '';
							// checked
							if ((strpos($item, '[c]') !== false && empty($value)) || (isset($value[$data['NAME']]) && in_array($val, $value[$data['NAME']])))
								$additional .= 'checked="checked"';
							// disabled
							if (strpos($item, '[d]') !== false)
								$additional .= 'disabled="disabled"';
							
							if ($data['FLOW']=='VERTICAL' && $layoutName == 'responsive')
								$out .= '<p class="rsformVerticalClear">';
							$out .= '<input '.$additional.' name="form['.$data['NAME'].'][]" type="checkbox" value="'.$this->_escape($txt).'" id="payment-'.$args['componentId'].'-'.$i.'" '.$data['ADDITIONALATTRIBUTES'].' onclick="getPrice_'.$args['formId'].'();" /><label for="payment-'.$args['componentId'].'-'.$i.'">'.$txt_price.'</label>';
							if ($data['FLOW']=='VERTICAL')
							{
								if ($layoutName == 'responsive')
									$out .= '</p>';
								else
									$out .= '<br />';
							}
							
							$product = array(
								$data['NAME'].'|_|'.$txt => $val
							);
							$this->_products = $this->merge($this->_products, $product);
							
							$i++;
						}
					}
					break;
				}
			}
			break;
		
			case 23:
			{
				$args['out'] = '<span id="payment_total_'.$args['formId'].'" class="rsform_payment_total">'.number_format(0,$nodecimals, $decimal, $thousands).'</span> '.$currency.' <input type="hidden" id="'.$args['data']['NAME'].'" value="" name="form['.$args['data']['NAME'].']" />';
			}
			break;
			
			case 28:
			{
				$defaultValue = RSFormProHelper::isCode($data['DEFAULTVALUE']);
				
				$className = 'rsform-input-box';
				if ($invalid)
					$className .= ' rsform-error';
				RSFormProHelper::addClass($data['ADDITIONALATTRIBUTES'], $className);
				
				$out .= '<input type="text" value="'.(isset($value[$data['NAME']]) ? $this->_escape($value[$data['NAME']]) : $this->_escape($defaultValue)).'" size="'.$data['SIZE'].'" '.((int) $data['MAXSIZE'] > 0 ? 'maxlength="'.(int) $data['MAXSIZE'].'"' : '').' name="form['.$data['NAME'].']" id="'.$data['NAME'].'" '.$data['ADDITIONALATTRIBUTES'].'/>';
			}
			break;
			
			case 27:
			{
				$data 	= $args['data'];
				$out  	=& $args['out'];
				$value 	= $args['value'];
				
				if (isset($data['SHOW']) && $data['SHOW'] == 'NO') {
					$doc = JFactory::getDocument();
					$doc->addStyleDeclaration('.rsform-block-'.JFilterOutput::stringURLSafe($data['NAME']).' { display: none !important; }');
				}
				
				if ($data['VIEW_TYPE'] == 'DROPDOWN')
				{
					$className = 'rsform-select-box';
					RSFormProHelper::addClass($data['ADDITIONALATTRIBUTES'], $className);
					
					$out .= '<select name="form['.$data['NAME'].'][]" id="'.$data['NAME'].'" '.$data['ADDITIONALATTRIBUTES'].' >';
					$items = $this->_getPayments($args['formId']);
					foreach ($items as $item)
					{
						$selected = '';
						if (isset($value[$data['NAME']]) && in_array($item->value, $value[$data['NAME']]))
							$selected = 'selected="selected"';
						
						$out .= '<option '.$selected.' value="'.$this->_escape($item->value).'">'.$this->_escape($item->text).'</option>';
					}
					
					$out .= '</select>';
				}
				elseif ($data['VIEW_TYPE'] == 'RADIOGROUP')
				{
					$i 		= 0;
					$items  = $this->_getPayments($args['formId']);
					foreach ($items as $item)
					{
						$checked = '';
						if (isset($value[$data['NAME']]) && $item->value == $value[$data['NAME']])
							$checked = 'checked="checked"';
						elseif (!isset($value[$data['NAME']]) && $i == 0)
							$checked = 'checked="checked"';
						
						if ($data['FLOW']=='VERTICAL' && $layoutName == 'responsive')
							$out .= '<p class="rsformVerticalClear">';
						$out .= '<input name="form['.$data['NAME'].']" type="radio" '.$checked.' value="'.$this->_escape($item->value).'" id="'.$data['NAME'].$i.'" '.$data['ADDITIONALATTRIBUTES'].' /><label for="'.$data['NAME'].$i.'">'.$this->_escape($item->text).'</label>';
						if ($data['FLOW']=='VERTICAL')
						{
							if ($layoutName == 'responsive')
								$out .= '</p>';
							else
								$out .= '<br />';
						}
						$i++;
					}
				}
			}
			break;
		}
	}
	
	protected function _escape($string) {
		return RSFormProHelper::htmlEscape($string);
	}
	
	function _getPayments($formId)
	{
		$items 		= array();
		$mainframe 	= JFactory::getApplication();
		$mainframe->triggerEvent('rsfp_getPayment', array(&$items, $formId));
		
		return $items;
	}
	
	function rsfp_afterConfirmPayment($SubmissionId)
	{
		RSFormProHelper::sendSubmissionEmails($SubmissionId);
	}
	
	function rsfp_f_onBeforeFormDisplay($args)
	{
		RSFormProHelper::readConfig(true);
		$nodecimals = RSFormProHelper::getConfig('payment.nodecimals');
		$decimal    = RSFormProHelper::getConfig('payment.decimal');
		$thousands  = RSFormProHelper::getConfig('payment.thousands');
		$currency   = RSFormProHelper::getConfig('payment.currency');
		
		$payments 		= RSFormProHelper::componentExists($args['formId'], 22);
		$total 			= RSFormProHelper::componentExists($args['formId'], 23);
		$totaldetails 	= RSFormProHelper::getComponentProperties(@$total[0]);
		
		$properties = RSFormProHelper::getComponentProperties($payments);
		
		if (!empty($payments))
		{
			$args['formLayout'] .='<script type="text/javascript">';
			$args['formLayout'] .='
				function getPrice_'.$args['formId'].'()
				{
					price = 0;
					
					products = new Array();
					';
					foreach ($this->_products as $product => $price)
					{
						$product = addslashes($product);
						$product = str_replace('[c]','',$product);
						$args['formLayout'] .= "products['".$product."'] = '".$price."';\n";
					}
					
					foreach ($payments as $componentId)
					{	
						$details = $properties[$componentId];
						
						if($details['MULTIPLE'] == 'YES' && $details['VIEW_TYPE']== 'DROPDOWN')
						{
							$args['formLayout'] .= "var elemd = document.getElementById('payment-".$componentId."');
	
	for(i=0;i<elemd.options.length;i++)
	{
		if(elemd.options[i].selected == true ) price += parseFloat(products['".$details['NAME']."|_|' + elemd.options[i].value]); 
	}";
							
						}
						elseif ($details['VIEW_TYPE']== 'DROPDOWN')
							$args['formLayout'] .= "price += parseFloat(products['".$details['NAME']."|_|' + document.getElementById('payment-".$componentId."').value]);\n";
						
						if ($details['VIEW_TYPE'] == 'CHECKBOX')
						{
							$args['formLayout'] .= "\n var elemc = document.getElementsByName('form[".$details['NAME']."][]');
	for(i=0;i<elemc.length;i++)
	{
		if(elemc[i].checked == true ) price += parseFloat(products['".$details['NAME']."|_|' + elemc[i].value]);
	}";
							
						}
					}
					
					if (!empty($total))
						$args['formLayout'] .= '
					document.getElementById(\'payment_total_'.$args['formId'].'\').innerHTML = number_format( price, '.$nodecimals.', \''.$decimal.'\', \''.$thousands.'\');
					//document.getElementById(\'payment_total_'.$args['formId'].'\').value = price;';
					
					if (!empty($totaldetails['NAME']))
						$args['formLayout'] .= "\n".'document.getElementById(\''.$totaldetails['NAME'].'\').value = number_format(price, 2, \'.\', \'\');';
			
		$args['formLayout'] .='}</script>';
		$args['formLayout'] .='<script type="text/javascript">getPrice_'.$args['formId'].'();</script>';
		
		}
		
		if (RSFormProHelper::componentExists($args['formId'], 21))
		{
			$args['formLayout'].='<script type="text/javascript">';
			$args['formLayout'].="rsfp_payment_items = document.getElementsByName('rsfp_payment_item[]');
			total = 0;
			for(i=0;i<rsfp_payment_items.length;i++)
			{
				total += parseFloat(rsfp_payment_items[i].value);
			}
			total = number_format( total, ".$nodecimals.", '".$decimal."', '".$thousands."' );
			";
			if (!empty($total))
				$args['formLayout'].= "document.getElementById('payment_total_".$args['formId']."').innerHTML = total;";
			if (!empty($totaldetails['NAME']))
				$args['formLayout'].= "document.getElementById('".@$totaldetails['NAME']."').value = total;";
			$args['formLayout'].= "</script>\n\n";
		}
	}
	
	function rsfp_f_onBeforeStoreSubmissions($args)
	{
		if (RSFormProHelper::componentExists($args['formId'], $this->newComponents))
			$args['post']['_STATUS'] = '0';
	}
	
	function rsfp_f_onAfterFormProcess($args)
	{		
		if (RSFormProHelper::componentExists($args['formId'], $this->newComponents))
		{
			$db 				= JFactory::getDBO();
			
			$products 			= array();
			$price 				= 0; 
			$total 				= RSFormProHelper::componentExists($args['formId'], 23);
			$totaldetails 		= RSFormProHelper::getComponentProperties(@$total[0]);
			$multipleProducts 	= RSFormProHelper::componentExists($args['formId'], 22);
			$donationProduct 	= RSFormProHelper::componentExists($args['formId'], 28);
			$choosePayment		= RSFormProHelper::componentExists($args['formId'], 27);
			// PayPal, for legacy reasons
			$hasPayPal			= RSFormProHelper::componentExists($args['formId'], 500);
			
			if (!empty($multipleProducts)) { // multiple products
				foreach ($multipleProducts as $product)
				{
					$pdetail 	= RSFormProHelper::getComponentProperties($product);
					$detail 	= $this->_getSubmissionValue($args['SubmissionId'], $product);
					if ($detail == '') continue;
					
					$items = str_replace("\r\n", "\n", $pdetail['ITEMS']);
					$items = explode("\n", $items);
					foreach ($items as $item)
					{
						if (strpos($item, '|') === false && $item == $detail)
							continue 2;
					}
					
					$products[] = strip_tags($pdetail['CAPTION']).' - '.strip_tags($detail);
				}
				$price = $this->_getSubmissionValue($args['SubmissionId'], $totaldetails['componentId']);
			} elseif (!empty($donationProduct)) { // donation
				$price = $this->_getSubmissionValue($args['SubmissionId'], $donationProduct[0]);
				$details = RSFormProHelper::getComponentProperties($donationProduct[0]);
				$products[] = strip_tags($details['CAPTION']);
			} else { // single product
				//Get Component properties
				$data 		= RSFormProHelper::getComponentProperties($this->getComponentId('rsfp_Product', $args['formId']));
				$products[] = strip_tags($data['CAPTION']);
				$price 		= $data['PRICE'];
			}
			
			if (($choosePayment && ($payValue = $this->_getSubmissionValue($args['SubmissionId'], $choosePayment[0]))) || ($hasPayPal && !$choosePayment && $payValue = 'paypal'))
			{
				//build verification code
				$db->setQuery("SELECT DateSubmitted FROM #__rsform_submissions WHERE SubmissionId = '".$args['SubmissionId']."'");
				$code = md5($args['SubmissionId'].$db->loadResult());
				
				$mainframe = JFactory::getApplication();
				$mainframe->triggerEvent('rsfp_doPayment', array($payValue, $args['formId'], $args['SubmissionId'], $price, $products, $code));
			}
		}
	}
	
	/*
		Additional Functions
	*/
	
	function getComponentName($componentId)
	{
		$componentId = (int) $componentId;
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT PropertyValue FROM #__rsform_properties WHERE ComponentId='".$componentId."' AND PropertyName='NAME'");
		return $db->loadResult();
	}
	
	function getComponentId($name, $formId)
	{
		$formId = (int) $formId;
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT p.ComponentId FROM #__rsform_properties p LEFT JOIN #__rsform_components c ON (p.ComponentId=c.ComponentId) WHERE p.PropertyValue='".$db->escape($name)."' AND p.PropertyName='NAME' AND c.FormId='".$formId."'");
		
		return $db->loadResult();
	}
	
	function _getSubmissionValue($submissionId, $componentId)
	{
		$name = $this->getComponentName($componentId);
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT FieldValue FROM #__rsform_submission_values WHERE SubmissionId='".(int) $submissionId."' AND FieldName='".$db->escape($name)."'");
		return $db->loadResult();
	}
	
	function paymentConfigurationScreen()
	{
		ob_start();
		
		?>
		<div id="page-payments">
			<table class="admintable">
				<tr>
					<td width="200" style="width: 200px;" align="right" class="key"><label for="currency"><?php echo JText::_( 'RSFP_PAYMENT_CURRENCY' ); ?></label></td>
					<td><input type="text" name="rsformConfig[payment.currency]" value="<?php echo $this->_escape(RSFormProHelper::getConfig('payment.currency'));  ?>" size="4" maxlength="50"></td>
				</tr>
				<tr>
					<td width="200" style="width: 200px;" align="right" class="key"><label for="thousands"><?php echo JText::_( 'RSFP_PAYMENT_THOUSANDS' ); ?></label></td>
					<td><input type="text" name="rsformConfig[payment.thousands]" value="<?php echo $this->_escape(RSFormProHelper::getConfig('payment.thousands'));  ?>" size="4" maxlength="50"></td>
				</tr>
				<tr>
					<td width="200" style="width: 200px;" align="right" class="key"><label for="decimal"><?php echo JText::_( 'RSFP_PAYMENT_DECIMAL_SEPARATOR' ); ?></label></td>
					<td><input type="text" name="rsformConfig[payment.decimal]" value="<?php echo $this->_escape(RSFormProHelper::getConfig('payment.decimal'));  ?>" size="4" maxlength="50"></td>
				</tr>
				<tr>
					<td width="200" style="width: 200px;" align="right" class="key"><label for="nr.decimal"><?php echo JText::_( 'RSFP_PAYMENT_NR_DECIMALS' ); ?></label></td>
					<td><input type="text" name="rsformConfig[payment.nodecimals]" value="<?php echo $this->_escape(RSFormProHelper::getConfig('payment.nodecimals'));  ?>" size="4" maxlength="50"></td>
				</tr>
			</table>
		</div>
		<?php
		
		$contents = ob_get_contents();
		ob_end_clean();
		return $contents;
	}
	
	function merge($a,$b)
	{	
		foreach($b as $key => $value)
			$a[$key] = $value; 
		return $a;
	}
	
	function rsfp_beforeUserEmail($args)
	{
		$form =& $args['form'];
		$db = JFactory::getDBO();
		$db->setQuery("SELECT `params` FROM #__rsform_payment WHERE form_id='".(int) $form->FormId."'");
		if ($params = $db->loadResult())
		{
			$params = @unserialize($params);
			if (is_object($params) && isset($params->UserEmail))
			{
				$db->setQuery("SELECT FieldValue,FieldName FROM #__rsform_submission_values WHERE FieldName='_STATUS' AND SubmissionId='".(int) $args['submissionId']."'");
				if ($status = $db->loadObject())
				{
					// defer sending if
					// - user email is defered && the payment is not confirmed (send email only when payment is confirmed)
					if ($params->UserEmail == 1 && $status->FieldValue == 0)
						$args['userEmail']['to'] = '';
					if ($params->UserEmail == 0 && $status->FieldValue == 1)
					// - user email is not defered && the payment is confirmed (don't send the email once again, it has already been sent)
						$args['userEmail']['to'] = '';
				}
			}
		}
	}
	
	function rsfp_beforeAdminEmail($args)
	{
		$form =& $args['form'];
		$db = JFactory::getDBO();
		$db->setQuery("SELECT `params` FROM #__rsform_payment WHERE form_id='".(int) $form->FormId."'");
		if ($params = $db->loadResult())
		{
			$params = @unserialize($params);
			if (is_object($params) && isset($params->AdminEmail))
			{
				$db->setQuery("SELECT FieldValue,FieldName FROM #__rsform_submission_values WHERE FieldName='_STATUS' AND SubmissionId='".(int) $args['submissionId']."'");
				if ($status = $db->loadObject())
				{
					// defer sending if
					// - admin email is defered && the payment is not confirmed (send email only when payment is confirmed)
					if ($params->AdminEmail == 1 && $status->FieldValue == 0)
						$args['adminEmail']['to'] = '';
					if ($params->AdminEmail == 0 && $status->FieldValue == 1)
					// - admin email is not defered && the payment is confirmed (don't send the email once again, it has already been sent)
						$args['adminEmail']['to'] = '';
				}
			}
		}
	}
	
	function rsfp_beforeAdditionalEmail($args)
	{
		$form =& $args['form'];
		$db = JFactory::getDBO();
		$db->setQuery("SELECT `params` FROM #__rsform_payment WHERE form_id='".(int) $form->FormId."'");
		if ($params = $db->loadResult())
		{
			$params = @unserialize($params);
			if (is_object($params) && isset($params->AdditionalEmails))
			{
				$db->setQuery("SELECT FieldValue,FieldName FROM #__rsform_submission_values WHERE FieldName='_STATUS' AND SubmissionId='".(int) $args['submissionId']."'");
				if ($status = $db->loadObject())
				{
					// defer sending if
					// - admin email is defered && the payment is not confirmed (send email only when payment is confirmed)
					if ($params->AdditionalEmails == 1 && $status->FieldValue == 0)
						$args['additionalEmail']['to'] = '';
					if ($params->AdditionalEmails == 0 && $status->FieldValue == 1)
					// - admin email is not defered && the payment is confirmed (don't send the email once again, it has already been sent)
						$args['additionalEmail']['to'] = '';
				}
			}
		}
	}
}