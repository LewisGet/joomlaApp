<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
function rsfp_changeRsmList(what)
{
	var value = what.value;
	
	document.getElementById('state').innerHTML='Status: loading...';
	document.getElementById('state').style.color='rgb(255,0,0)';
	
	var params = new Array();
	params.push('list_id=' + escape(value));
	
	xml = buildXmlHttp();
	var url = 'index.php?option=com_rsform&task=plugin&plugin_task=rsm_get_merge_vars';
	xml.open("POST", url, true);
	
	params = params.join('&');
	
	//Send the proper header information along with the request
	xml.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xml.setRequestHeader("Content-length", params.length);
	xml.setRequestHeader("Connection", "close");
	
	xml.send(params);
	xml.onreadystatechange=function()
	{
		if (xml.readyState==4)
		{
			var table = document.getElementById('merge_vars_rsm');
			while (table.rows.length >= 1)
				table.deleteRow(table.rows.length - 1);
		
			if (xml.responseText != '')
			{
				var result = xml.responseText.split("\n");
				for (var i=0; i<result.length; i++)
				{
					field = result[i];
					property = result[i];
					
					if (field.indexOf('rsm_email_') != -1)
					{
						field = field.replace('rsm_email_','');
						property = 'rsm_email';
					}
					
					var x = table.insertRow(table.rows.length);
					var y = x.insertCell(0);
					y.innerHTML = field;
					y.nowrap = true;
					y.align = 'right';
					var y = x.insertCell(1);
					
					var select = document.createElement('select');
					select.name = 'rsm_merge_vars[' + property + ']';
					<?php foreach ($fields as $field) { ?>
					var option = document.createElement('option');
					option.text = '<?php echo $field->text; ?>';
					option.value = '<?php echo $field->value; ?>';
					select.options.add(option);
					<?php } ?>
					y.appendChild(select);
				}
			}
				
			document.getElementById('state').innerHTML='Status: ok';
			document.getElementById('state').style.color='';
		}
	}
}

function rsfp_changeRsmAction(what)
{	
	if (what.value == 2)
		document.getElementById('rsm_action_field').disabled = false;
	else
		document.getElementById('rsm_action_field').disabled = true;
}
</script>

<table class="admintable">
<tr>
	<td valign="top" align="left" width="30%">
		<table>
			<tr>
				<td colspan="2" align="center"><?php echo JHTML::image('administrator/components/com_rsform/assets/images/rsmail_logo.png', 'RSMail!'); ?></td>
			</tr>
			<tr>
				<td colspan="2"><div class="rsform_error"><?php echo JText::_('RSFP_RSMAIL_DESC'); ?></div></td>
			</tr>
			<tr>
				<td width="80" align="right" nowrap="nowrap" class="key"><?php echo JText::_('RSFP_RSM_USE_INTEGRATION'); ?></td>
				<td><?php echo $lists['published']; ?></td>
			</tr>
			<tr>
				<td width="80" align="right" nowrap="nowrap" class="key">
					<span class="hasTip" title="<?php echo JText::_('RSFP_RSM_ACTION_DESC'); ?>"><?php echo JText::_('RSFP_RSM_ACTION'); ?></span>
				</td>
				<td nowrap="nowrap"><?php echo $lists['rsm_action']; ?> <?php echo $lists['rsm_action_field']; ?></td>
			</tr>
			<tr>
				<td colspan="2"><?php echo JText::_('RSFP_RSM_ACTION_WARNING'); ?></td>
			</tr>
			<tr>
				<td width="80" align="right" nowrap="nowrap" class="key"><?php echo JText::_('RSFP_RSM_LIST_ID'); ?></td>
				<td nowrap="nowrap"><?php echo $lists['rsm_list_id']; ?></td>
			</tr>
			<tr>
				<td colspan="2" class="key" align="center"><p align="center"><?php echo JText::_('RSFP_RSM_MERGE_VARS'); ?></p></td>
			</tr>
			<tr>
				<td colspan="2"><?php echo JText::_('RSFP_RSM_MERGE_VARS_DESC'); ?></td>
			</tr>
			<tbody id="merge_vars_rsm">
			<?php if (is_array($merge_vars)) { ?>
				<?php foreach ($merge_vars as $merge_var => $title) { ?>
				<tr>
					<td nowrap="nowrap" align="right"><?php echo $title; ?></td>
					<td><?php echo $lists['fields'][$merge_var]; ?></td>
				</tr>
				<?php } ?>
			<?php } ?>
			</tbody>
		</table>
	</td>
	<td valign="top">
		&nbsp;
	</td>
</tr>
</table>