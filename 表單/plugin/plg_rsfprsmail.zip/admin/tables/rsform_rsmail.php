<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

class TableRSForm_Rsmail extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $form_id = null;
	
	var $rsm_list_id = '';
	var $rsm_action = 1; // 0 - unsubscribe; 1 - subscribe, 2 - let the user decide
	var $rsm_action_field = '';
	var $rsm_merge_vars = '';
	var $rsm_published = 0;
		
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableRSForm_Rsmail(& $db)
	{
		parent::__construct('#__rsform_rsmail', 'form_id', $db);
	}
}