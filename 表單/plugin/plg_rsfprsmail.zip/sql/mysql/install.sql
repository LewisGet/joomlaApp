CREATE TABLE IF NOT EXISTS `#__rsform_rsmail` (
  `form_id` int(11) NOT NULL,
  `rsm_list_id` varchar(255) NOT NULL,
  `rsm_action` tinyint(1) NOT NULL,
  `rsm_action_field` varchar(255) NOT NULL,
  `rsm_merge_vars` text NOT NULL,
  `rsm_published` tinyint(1) NOT NULL,
  PRIMARY KEY (`form_id`)
);