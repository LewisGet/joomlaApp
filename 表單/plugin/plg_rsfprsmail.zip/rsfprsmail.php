<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * RSForm! Pro system plugin
 */
class plgSystemRSFPRsmail extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatibility we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	function plgSystemRSFPRsmail(&$subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	function canRun()
	{
		if (class_exists('RSFormProHelper')) return true;
		
		$helper = JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsform.php';
		if (file_exists($helper))
		{
			require_once($helper);
			RSFormProHelper::readConfig();
			return true;
		}
		
		return false;
	}
	
	function rsfp_onFormSave($form)
	{
		$post = JRequest::get('post', JREQUEST_ALLOWRAW);
		$post['form_id'] = $post['formId'];
		
		$row = JTable::getInstance('RSForm_Rsmail', 'Table');
		if (!$row)
			return;
		if (!$row->bind($post))
		{
			JError::raiseWarning(500, $row->getError());
			return false;
		}
		
		$row->rsm_merge_vars = serialize($post['rsm_merge_vars']);
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT form_id FROM #__rsform_rsmail WHERE form_id='".(int) $post['form_id']."'");
		if (!$db->loadResult())
		{
			$db->setQuery("INSERT INTO #__rsform_rsmail SET form_id='".(int) $post['form_id']."'");
			$db->execute();
		}
		
		if ($row->store())
		{
			return true;
		}
		else
		{
			JError::raiseWarning(500, $row->getError());
			return false;
		}
	}
	
	function rsfp_bk_onAfterShowFormEditTabs()
	{
		$formId = JRequest::getInt('formId');
		
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfprsmail');
		
		if (file_exists(JPATH_SITE.'/components/com_rsmail/helpers/helper.php'))
			require_once JPATH_SITE.'/components/com_rsmail/helpers/helper.php';
		else
			return true;
		
		$row = JTable::getInstance('RSForm_Rsmail', 'Table');
		if (!$row) return;
		$row->load($formId);
		$row->rsm_merge_vars = @unserialize($row->rsm_merge_vars);
		if ($row->rsm_merge_vars === false)
			$row->rsm_merge_vars = array();
		
		// Get a new instance of the RSMail! helper
		$rsmail = new rsmHelper(); 
		
		// Fields
		$fields_array = $this->_getFields($formId);
		$fields = array();
		$fields[] = JHTML::_('select.option', '', JText::_('RSFP_RSM_IGNORE'));
		foreach ($fields_array as $field)
			$fields[] = JHTML::_('select.option', $field, $field);
		
		// Action
		$rsm_action = array(
			JHTML::_('select.option', 1, JText::_('RSFP_RSM_ACTION_SUBSCRIBE')),
			JHTML::_('select.option', 0, JText::_('RSFP_RSM_ACTION_UNSUBSCRIBE')),
			JHTML::_('select.option', 2, JText::_('RSFP_RSM_LET_USER_DECIDE'))
		);
		$lists['rsm_action'] = JHTML::_('select.genericlist', $rsm_action, 'rsm_action', 'onchange="rsfp_changeRsmAction(this);"', 'value', 'text', $row->rsm_action);
		
		// Action Field
		$lists['rsm_action_field'] = JHTML::_('select.genericlist', $fields, 'rsm_action_field', $row->rsm_action != 2 ? 'disabled="disabled"' : '', 'value', 'text', $row->rsm_action_field);
		
		// RSMail! Lists
		$results = $rsmail->getLists();
		$rsm_lists = array(
			JHTML::_('select.option', '0', JText::_('RSFP_PLEASE_SELECT_LIST'))
		);
		if (!empty($results))
			foreach ($results as $result)
				$rsm_lists[] = JHTML::_('select.option', $result->IdList, $result->ListName);
		
		$lists['rsm_list_id'] = JHTML::_('select.genericlist', $rsm_lists, 'rsm_list_id', 'onchange="rsfp_changeRsmList(this)"', 'value', 'text', $row->rsm_list_id);
		
		// Merge Vars
		$merge_vars = array();
		if ($row->rsm_list_id)
		{
			$rsm_fields = $rsmail->getFields($row->rsm_list_id);
			if (!empty($rsm_fields))
			{
				$merge_vars['rsm_email'] = JText::_('RSFP_RSM_EMAIL');
				foreach ($rsm_fields as $field)
					$merge_vars[$field] = $field;
			}
		}
		
		$lists['fields'] = array();
		if (is_array($merge_vars))
			foreach ($merge_vars as $merge_var => $title)
			{
				$lists['fields'][$merge_var] = JHTML::_('select.genericlist', $fields, 'rsm_merge_vars['.$merge_var.']', null, 'value', 'text', isset($row->rsm_merge_vars[$merge_var]) ? $row->rsm_merge_vars[$merge_var] : null);
			}
		
		
		$lists['published'] = RSFormProHelper::renderHTML('select.booleanlist','rsm_published','class="inputbox"',$row->rsm_published);
		
		echo '<div id="rsmaildiv">';
			include JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsmail.php';
		echo '</div>';
	}
	
	function rsfp_bk_onAfterShowFormEditTabsTab()
	{
		$doc = JFactory::getDocument();
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfprsmail');
		
		$doc->addStyleDeclaration("ul.rsform_leftnav li a#rsmail span {
				background: url('".JURI::root()."administrator/components/com_rsform/assets/images/icons/rsmail.png') no-repeat scroll 10px center transparent;
		}");
		
		echo '<li><a href="javascript: void(0);" id="rsmail"><span>'.JText::_('RSFP_RSMAIL_INTEGRATION').'</span></a></li>';
	}
	
	function rsfp_f_onAfterFormProcess($args)
	{
		$db 	= JFactory::getDBO();
		$lang 	= JFactory::getLanguage();
		$jconfig = JFactory::getConfig();
		$ltag 	= $lang->getTag();
		
		$lang->load('com_rsmail',JPATH_SITE);
		
		$formId = (int) $args['formId'];
		$SubmissionId = (int) $args['SubmissionId'];
		
		$db->setQuery("SELECT * FROM #__rsform_rsmail WHERE `form_id`='".$formId."' AND `rsm_published`='1'");
		if ($row = $db->loadObject())
		{
			if (!$row->rsm_list_id) return;
			
			if (file_exists(JPATH_SITE.'/components/com_rsmail/helpers/helper.php'))
				require_once JPATH_SITE.'/components/com_rsmail/helpers/helper.php';
			else
				return true;
			
			// Get a new instance of the RSMail! helper
			$rsmail = new rsmHelper(); 
			
			list($replace, $with) = RSFormProHelper::getReplacements($SubmissionId);
			
			$row->rsm_merge_vars = @unserialize($row->rsm_merge_vars);
			if ($row->rsm_merge_vars === false)
				$row->rsm_merge_vars = array();
			
			if (!isset($row->rsm_merge_vars['rsm_email']))
				return;
			
			$form = JRequest::getVar('form');
			
			$email_address = @$form[$row->rsm_merge_vars['rsm_email']];
			
			$merge_vars = array();
			$email = $email_address;
			foreach ($row->rsm_merge_vars as $tag => $field)
			{
				if (empty($tag)) continue;
				if ($tag == 'rsm_email') continue;
				
				if (!isset($form[$field]))
					$form[$field] = '';
				
				if (is_array($form[$field]))
				{
					array_walk($form[$field], array('plgSystemRSFPRsmail', '_escapeCommas'));
					$form[$field] = implode(',', $form[$field]);
				}
				
				$merge_vars[$tag] = $form[$field];
			}
			
			$list_id = $row->rsm_list_id;
			
			// Subscribe action - Subscribe, Unsubscribe or Let the user choose
			$subscribe = null;
			if ($row->rsm_action == 1)
				$subscribe = true;
			elseif ($row->rsm_action == 0)
				$subscribe = false;
			elseif ($row->rsm_action == 2 && isset($form[$row->rsm_action_field]))
			{
				if (is_array($form[$row->rsm_action_field]))
					foreach ($form[$row->rsm_action_field] as $i => $value)
					{
						$value = strtolower(trim($value));
						if ($value == 'subscribe')
						{
							$subscribe = true;
							break;
						}
						elseif ($value == 'unsubscribe')
						{
							$subscribe = false;
							break;
						}
					}
				else
				{
					$form[$row->rsm_action_field] = strtolower(trim($form[$row->rsm_action_field]));
					if ($form[$row->rsm_action_field] == 'subscribe')
						$subscribe = true;
					elseif ($form[$row->rsm_action_field] == 'unsubscribe')
						$subscribe = false;
				}
			}
			
			// Get RSMail! configuration
			$config = $this->_getConfig();
			
			// Prepare list
			$list = $rsmail->setList($row->rsm_list_id, $merge_vars);
			
			$db->setQuery("SELECT ListName FROM #__rsmail_lists WHERE IdList = ".$row->rsm_list_id);
			$listname = $db->loadResult();
			
			/* $subscribe = true - subscribe user
			$subscribe = false - unsubscribe user
			$subscribe = null - do nothing */
			if ($subscribe === true)
			{
				$state = $config['confirm_email'] == 1 ? 0 : 1;
				
				// Subscribe user
				$idsubscriber = $rsmail->subscribe($email, $list, $state, null, true);
				
				if ($idsubscriber)
				{
					// The user must confirm his subscription
					if(!$state)
					{
						$hash = md5($row->rsm_list_id.$idsubscriber.$email);
						$rsmail->confirmation($row->rsm_list_id, $email, $hash);
					}
					
					//send notifications
					$rsmail->notifications($row->rsm_list_id, $email, $merge_vars);
					
				}
			}
			elseif ($subscribe === false)
			{
				// Unsubscribe user
				$unsubscribe = $rsmail->usubscribe($email, $row->rsm_list_id);
				
				if ($unsubscribe && $config['unsubscribe_email'])
				{
					$to			= $email;
					$from		= $config['unsubscribe_from'];
					$fromName	= $config['unsubscribe_fromname'];
					$subject 	= $config['unsubscribe_subject'];
					$type		= $config['unsubscribe_type'];
					
					$db->setQuery("SELECT `text` FROM #__rsmail_emails WHERE `type` = 'unsubscribe' AND lang = '".$db->escape($ltag)."' ");
					$message	= $db->loadResult();
					
					$secret 	= md5($email);
					$activateSubscription = '<a href="'.JURI::root().'index.php?option=com_rsmail&task=activatesubscribe&secret='.$secret.'&lists='.base64_encode($row->rsm_list_id).'">'.JText::_('RSM_CLICK_TO_ACTIVATE').'</a>';
					
					$bad		= array('{newsletter}','{email}','{activatesubscription}');
					$good		= array($listname,$email,$activateSubscription);

					$subject 	= str_replace($bad,$good,$subject);
					$message 	= str_replace($bad,$good,$message);

					RSFormProHelper::sendMail($from ,$fromName, $to, $subject, $message, $type);
				}
			}
		}
	}
	
	function rsfp_bk_onSwitchTasks()
	{
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfprsmail');
		
		$plugin_task = JRequest::getVar('plugin_task');
		
		if ($plugin_task == 'rsm_get_merge_vars')
		{
			if (file_exists(JPATH_SITE.'/components/com_rsmail/helpers/helper.php'))
				require_once JPATH_SITE.'/components/com_rsmail/helpers/helper.php';
			else
				return true;
			
			// Get a new instance of the RSMail! helper
			$rsmail = new rsmHelper();
			// Get list fields
			$results = $rsmail->getFields(JRequest::getVar('list_id'));
			
			if (!empty($results)) echo 'rsm_email_'.JText::_('RSFP_RSM_EMAIL');
			echo is_array($results) && !empty($results) ? "\n".implode("\n",$results) : '';
			jexit();
		}
	}
	
	function _getFields($formId)
	{
		$db = JFactory::getDBO();
		
		$db->setQuery("SELECT p.PropertyValue FROM #__rsform_components c LEFT JOIN #__rsform_properties p ON (c.ComponentId=p.ComponentId) WHERE c.FormId='".(int) $formId."' AND p.PropertyName='NAME' ORDER BY c.Order");
		return $db->loadColumn();
	}
	
	function _getConfig()
	{
		$db 	= JFactory::getDBO();
		$config = array();
		
		$db->setQuery("SELECT * FROM `#__rsmail_config`");
		$results = $db->loadObjectList();
		
		if (!empty($results))
			foreach ($results as $result)
				$config[$result->ConfigName] = $result->ConfigValue;
				
		return $config;
	}
	
	function _escapeCommas(&$item)
	{
		$item = str_replace(',', '\,', $item);
	}
}