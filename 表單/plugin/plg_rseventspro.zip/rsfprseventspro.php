<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * RSForm! Pro system plugin
 */
	
class plgSystemRSFPRSEventspro extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatibility we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	function plgSystemRSFPRSEventspro( &$subject, $config )
	{
		parent::__construct( $subject, $config );
		$this->newComponents = array(30,31,32,33,34);
	}
	
	function canRun()
	{
		if (file_exists(JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsform.php') && file_exists(JPATH_SITE.'/components/com_rseventspro/helpers/rseventspro.php'))
		{
			$lang = JFactory::getLanguage();
			$lang->load('plg_system_rsfprseventspro');
			
			require_once JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsform.php';
			require_once JPATH_SITE.'/components/com_rseventspro/helpers/rseventspro.php';
			
			return true;
		}
		
		return false;
	}
	
	/*
		Event Triggered Functions
	*/
	function rsfp_bk_onAfterShowComponents()
	{
		if (!self::canRun()) return;
		
		$html = '';
		
		$html .= '<li class="rsform_navtitle">'.JText::_('RSFP_RSEPRO_LABEL').'</li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(30);return false;" id="rsfpc30"><span id="textbox">'.JText::_('RSFP_RSEPRO_NAME').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(31);return false;" id="rsfpc31"><span id="textbox">'.JText::_('RSFP_RSEPRO_EMAIL').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(32);return false;" id="rsfpc32"><span id="rseprotickets">'.JText::_('RSFP_RSEPRO_TICKETS').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(33);return false;" id="rsfpc33"><span id="dropdown">'.JText::_('RSFP_RSEPRO_PAYMENTS').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(34);return false;" id="rsfpc34"><span id="textbox">'.JText::_('RSFP_RSEPRO_COUPON').'</span></a></li>';
		
		echo $html;
	}
	
	function rsfp_f_onBeforeFormValidation($args)
	{
		if (!self::canRun()) return;
		
		$form   = JRequest::getVar('form');
		$formId = (int) $form['formId'];
		
		$exists = RSFormProHelper::componentExists($formId, $this->newComponents);
		if (!empty($exists))
		{			
			$db 	= JFactory::getDBO();
			$cid 	= JRequest::getInt('cid');
			
			if ($cid && JRequest::getCmd('option') == 'com_rseventspro' && $this->_getHasForm($cid, $formId))
			{
				$db->setQuery("SELECT COUNT(id) FROM #__rseventspro_users WHERE ide = ".$cid." AND email = '".$db->escape($form['RSEProEmail'])."'");
				$registered = $db->loadResult();
				
				$db->setQuery("SELECT `value` FROM `#__rseventspro_config` WHERE `name` = 'multi_registration'");
				$multiplereg = $db->loadResult();
				
				if ($registered && $multiplereg == 0)
				{
					JError::raiseWarning(500, JText::_('RSEPRO_REGISTRATION_ERROR5'));
					$args['invalid'][] = $this->_getComponentId('RSEProEmail', $formId);
				}
			}
		}
	}
	
	function rsfp_f_onAfterFormProcess($args)
	{
		if (!self::canRun()) return;
		
		$exists = RSFormProHelper::componentExists($args['formId'], $this->newComponents);
		if (!empty($exists))
		{			
			$db 	= JFactory::getDBO();
			$cid 	= JRequest::getInt('cid');
			
			if ($cid && JRequest::getCmd('option') == 'com_rseventspro' && $this->_getHasForm($cid, $args['formId']))
			{
				$result = rseventsproHelper::saveRegistration($args['SubmissionId']);
				
				$form = JRequest::getVar('form');
				if ($form['RSEProName'])
				{
					$hasPrice = 0;
					$tickets = JRequest::getVar('tickets');
					
					if (empty($tickets))
					{
						$db->setQuery("SELECT price FROM #__rseventspro_tickets WHERE id = ".(int) $form['RSEProTickets']." ");
						if ($db->loadResult() > 0) $hasPrice = 1;
					} 
					else 
					{
						foreach ($tickets as $ticket => $quantity)
						{
							$db->setQuery("SELECT price FROM #__rseventspro_tickets WHERE id = ".(int) $ticket." ");
							if ($db->loadResult() > 0) $hasPrice = 1;
						}
					}
					
					if ($hasPrice)
					{
						echo rseventsproHelper::redirect(true,$result['message'],$result['url'],true);
						exit();
					}
				}
			}
		}
	}
	
	function rsfp_f_onBeforeStoreSubmissions($args)
	{
		if (!self::canRun()) return;
		
		$db = JFactory::getDBO();
		$post =& $args['post'];
		
		$db->setQuery("SELECT `value` FROM `#__rseventspro_config` WHERE `name` = 'multi_tickets'");
		$multipleTickets = $db->loadResult();
		
		$thestring = '';
		
		if ($multipleTickets)
		{
			$tickets = JRequest::getVar('tickets');
			
			if (!empty($tickets))
			{
				$tmp = array();
				foreach ($tickets as $ticket => $quantity)
				{
					$db->setQuery("SELECT `name` FROM `#__rseventspro_tickets` WHERE `id` = ".(int) $ticket." ");
					$ticketName = $db->loadResult();
					$ticketno = $quantity < 0 ? 1 : $quantity;
					
					$tmp[] = $ticketno.' x '.$ticketName;
				}
				
				$thestring .= !empty($tmp) ? implode(' , ',$tmp) : '';
			} else 
			{
				$ticket = $post['RSEProTickets'];				
				$db->setQuery("SELECT `name` FROM `#__rseventspro_tickets` WHERE `id` = ".(int) $ticket." ");
				$ticketName = $db->loadResult();
				
				$quantity = JRequest::getInt('from',0) == 1 ? JRequest::getInt('number') : JRequest::getInt('numberinp');
				$quantity = !empty($quantity) ? (int) $quantity : 1;
				
				$thestring .= $quantity.' x '.$ticketName;
			}
		} else 
		{
			$ticket = $post['RSEProTickets'];
			$db->setQuery("SELECT `name` FROM `#__rseventspro_tickets` WHERE `id` = ".(int) $ticket." ");
			$ticketName = $db->loadResult();
			
			$quantity = JRequest::getInt('from',0) == 1 ? JRequest::getInt('number') : JRequest::getInt('numberinp');
			$quantity = !empty($quantity) ? (int) $quantity : 1;
			
			$thestring .= $quantity.' x '.$ticketName;
		}
		
		$post['RSEProTickets'] = $thestring;
		
		$payment = $post['RSEProPayment'];
		$payment = is_array($payment) ? $payment[0] : $payment;
		$post['RSEProPayment'] = rseventsproHelper::getPayment($payment);
	}
	
	function _getHasForm($ide, $formId)
	{
		if (!self::canRun()) return;
		
		static $cache;
		if (!isset($cache[$formId]))
		{
			$db = JFactory::getDBO();
			$db->setQuery("SELECT count(id) FROM #__rseventspro_events WHERE form = ".(int) $formId." AND id = ".(int) $ide." ");
			
			$cache[$formId] = $db->loadResult();
		}
		
		return $cache[$formId];
	}
	
	function _getComponentId($name, $formId)
	{
		if (!self::canRun()) return;
		
		if (method_exists('RSFormProHelper', 'getComponentId'))
			return RSFormProHelper::getComponentId($name, $formId);
		
		static $cache;
		if (!is_array($cache))
			$cache = array();
			
		if (empty($formId))
		{
			$formId = JRequest::getInt('formId');
			if (empty($formId))
			{
				$post   = JRequest::getVar('form');
				$formId = (int) @$post['formId'];
			}
		}
		
		if (!isset($cache[$formId][$name]))
			$cache[$formId][$name] = RSFormProHelper::componentNameExists($name, $formId);
		
		return $cache[$formId][$name];
	}
	
	function getPayments()
	{
		if (!self::canRun()) return;
		
		if (JRequest::getCmd('option') != 'com_rseventspro' && JRequest::getCmd('layout') != 'subscribe') return;
		
		$db			= JFactory::getDBO();
		$cid		= JRequest::getInt('cid');
		$payments	= array();
		
		$db->setQuery("SELECT payments FROM #__rseventspro_events WHERE id = ".$cid." ");
		$eventPayments	= $db->loadResult();
		$payment_items	= rseventsproHelper::getPayments(false,$eventPayments);
		$default_payment= rseventsproHelper::getConfig('default_payment');
		
		if (!empty($payment_items))
		{
			foreach ($payment_items as $payment)
			{
				$default = $default_payment == $payment->value ? '[c]' : '';
				$payments[] = $payment->value.'|'.$payment->text.$default;
			}
		}
		
		if (!empty($payments))
			return implode("\n",$payments);
		
		return '';
	}
	
	function getTickets()
	{
		if (!self::canRun()) return;
		
		if (JRequest::getCmd('option') != 'com_rseventspro' && JRequest::getCmd('layout') != 'subscribe') return;
		
		$db		  = JFactory::getDBO();
		$cid	  = JRequest::getInt('cid');
		$return   = array();
		
		$db->setQuery("SELECT * FROM #__rseventspro_tickets WHERE ide = ".$cid." ");
		$tickets = $db->loadObjectList();
		
		if (!empty($tickets))
		{
			foreach ($tickets as $ticket)
			{
				$checkticket = rseventsproHelper::checkticket($ticket->id);				
				if ($checkticket == -1) continue;
				
				$price = $ticket->price > 0 ? ' - '.rseventsproHelper::currency($ticket->price) : ' - '.JText::_('RSEPRO_FREE');
				$return[] = $ticket->id.'|'.$ticket->name.$price;
			}
		}
		
		if (!empty($return))
			return implode("\n",$return);
		
		return;
	}
	
	function rsfp_beforeUserEmail($args)
	{
		if (JRequest::getCmd('option') == 'com_rseventspro' || JRequest::getCmd('layout') == 'subscribe')
		{
			$text			= $args['userEmail']['text'];
			$subject		= $args['userEmail']['subject'];
			$placeholders	= $this->placeholders(array('subject' => $subject, 'body' => $text),JRequest::getInt('cid'),'');
			
			$args['userEmail']['text'] = $placeholders['body'];
			$args['userEmail']['subject'] = $placeholders['subject'];
		}
	}
	
	function rsfp_beforeAdminEmail($args)
	{
		if (JRequest::getCmd('option') == 'com_rseventspro' || JRequest::getCmd('layout') == 'subscribe')
		{			
			$text			= $args['adminEmail']['text'];
			$subject		= $args['adminEmail']['subject'];
			$placeholders	= $this->placeholders(array('subject' => $subject, 'body' => $text),JRequest::getInt('cid'),'');
			
			$args['adminEmail']['text'] = $placeholders['body'];
			$args['adminEmail']['subject'] = $placeholders['subject'];
		}
	}
	
	function rsfp_beforeAdditionalEmail($args)
	{
		if (JRequest::getCmd('option') == 'com_rseventspro' || JRequest::getCmd('layout') == 'subscribe')
		{
			$text			= $args['additionalEmail']['text'];
			$subject		= $args['additionalEmail']['subject'];
			$placeholders	= $this->placeholders(array('subject' => $subject, 'body' => $text),JRequest::getInt('cid'),'');
			
			$args['additionalEmail']['text'] = $placeholders['body'];
			$args['additionalEmail']['subject'] = $placeholders['subject'];
		}
	}
	
	function rsfp_f_onAfterShowThankyouMessage($args)
	{
		if (JRequest::getCmd('option') == 'com_rseventspro' || JRequest::getCmd('layout') == 'subscribe')
		{
			$db  = JFactory::getDBO();
			$cid = JRequest::getInt('cid');
			
			$db->setQuery("SELECT name FROM #__rseventspro_events WHERE id = ".$cid."");
			$name = $db->loadResult();
			
			$text = $args['output'];
			$text = $this->placeholders($text,$cid,'');
			
			if (rseventsproHelper::getConfig('modal') == 0) 
			{			
				$replace = '<a class="btn button" href="'.rseventsproHelper::route('index.php?option=com_rseventspro&layout=show&cid='.rseventsproHelper::sef($cid,$name)).'">'.JText::_('RSEPRO_BACK_BTN').'</a>';
				$pattern	= '#<input type="button" class="rsform-submit-button" name="continue"(.*?)/>#is';
				preg_match($pattern,$text,$match);
				
				if (empty($match))
					$text .= '<br />'.$replace;
				else 
					$text = preg_replace($pattern,$replace,$text);
			}
			
			$args['output'] = $text;
		}
	}
	
	function rsfp_f_onInitFormDisplay($args)
	{
		if (JRequest::getCmd('option') == 'com_rseventspro' || JRequest::getCmd('layout') == 'subscribe')
		{		
			$text = $args['formLayout'];
			$text = $this->placeholders($text,JRequest::getInt('cid'),'');
			$args['formLayout'] = $text;
		}
	}
	
	function rsfp_bk_onBeforeCreateFrontComponentBody($args)
	{
		if (JRequest::getCmd('option') == 'com_rseventspro' && JRequest::getCmd('layout') == 'subscribe')
		{
			if (!empty($args['data']['DEFAULTVALUE']))
			{
				$defaulttext = $args['data']['DEFAULTVALUE'];
				$defaulttext = $this->placeholders($defaulttext,JRequest::getInt('cid'),'');
				$args['data']['DEFAULTVALUE'] = $defaulttext;
			}
			
			if (!empty($args['data']['TEXT']))
			{
				$text = $args['data']['TEXT'];
				$text = $this->placeholders($text,JRequest::getInt('cid'),'');
				$args['data']['TEXT'] = $text;
			}
		}
	}
	
	function placeholders($text,$ide,$name)
	{
		require_once JPATH_SITE.'/components/com_rseventspro/helpers/rseventspro.php';
		
		return rseventsproEmails::placeholders($text,$ide, $name);
	}
}