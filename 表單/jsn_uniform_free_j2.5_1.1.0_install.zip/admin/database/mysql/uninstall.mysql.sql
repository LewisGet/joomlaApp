DROP TABLE `#__jsn_uniform_forms`;
DROP TABLE `#__jsn_uniform_fields`;
DROP TABLE `#__jsn_uniform_templates`;
DROP TABLE `#__jsn_uniform_data`;
DROP TABLE `#__jsn_uniform_emails`;
DROP TABLE `#__jsn_uniform_config`;
DROP TABLE `#__jsn_uniform_messages`;
DROP TABLE `#__jsn_uniform_form_pages`;