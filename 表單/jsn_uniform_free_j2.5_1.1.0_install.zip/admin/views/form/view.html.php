<?php

/**
 * @version     $Id: view.html.php 19013 2012-11-28 04:48:47Z thailv $
 * @package     JSNUniform
 * @subpackage  Form
 * @author      JoomlaShine Team <support@joomlashine.com>
 * @copyright   Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license     GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

require_once JPATH_COMPONENT_ADMINISTRATOR . DS . 'libraries/joomlashine/layout.php';

/**
 * View class for a list of Form.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_uniform
 * @since       1.5
 */
class JSNUniformViewForm extends JView
{

	protected $_document;
	protected $_formLayout;

	/**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  mixed  A string if successful, otherwise a JError object.
	 *
	 * @see     fetch()
	 * @since   11.1
	 */
	public function display($tpl = null)
	{
		$session = JFactory::getSession();
		$this->urlAction = JRequest::getString('tmpl', '');

		$this->_document = JFactory::getDocument();
		$this->_item = $this->get('Item');

		$this->checkSubmitModal = false;
		$seesionQueue = $session->get('application.queue');
		if ($seesionQueue[0]['type'] != "warning")
		{
			unset($_SESSION["__form-design-" . $this->_item->form_id]);
			unset($_SESSION["__form-design-"]);
			if ($seesionQueue[0])
			{
				if ($this->urlAction == "component")
				{
					$this->checkSubmitModal = true;
				}
			}
		}
		$formContent = $this->_item->form_content;
		$this->_listPage = JSNUniformHelper::getListPage($formContent, $this->_item->form_id);
		$this->_formLayout = new JSNUniformLayout(JSN_UNIFORM_PAGEDESIGN_LAYOUTS_PATH);
		$this->_form = $this->get('Form');
		$this->_fromEmail = array();
		if (empty($this->_item->form_id))
		{
			$this->_fromConfig = $this->get('DataConfig');
			$this->formAction = 0;
			$this->formActionData = '';
			foreach ($this->_fromConfig as $formConfig)
			{
				if (isset($formConfig->name) && $formConfig->name == 'email_notification')
				{
					$this->_fromEmail = json_decode($formConfig->value);
				}
				if (isset($formConfig->name) && $formConfig->name == 'form_action')
				{
					$this->formAction = $formConfig->value;
				}
			}
			foreach ($this->_fromConfig as $formConfig)
			{
				if ($this->formAction == 1 && $formConfig->name == 'form_action_url')
				{
					$this->formActionData = $formConfig->value;
				}
				if ($this->formAction == 2 && $formConfig->name == 'form_action_menu')
				{
					$this->formActionData = json_decode($formConfig->value);
				}
				if ($this->formAction == 3 && $formConfig->name == 'form_action_article')
				{
					$this->formActionData = json_decode($formConfig->value);
				}
				if ($this->formAction == 4 && $formConfig->name == 'form_action_message')
				{
					$this->formActionData = $formConfig->value;
				}
			}
		}
		else
		{
			$this->_fromEmail = $this->get('FormEmail');
		}
		$this->form_page = isset($formContent[0]->page_content) ? $formContent[0]->page_content : "";
		if (isset($this->_item->form_captcha) && $this->_item->form_captcha == 0)
		{
			$this->checkedCaptchaNo = "checked";
			$this->checkedCaptchaYes = "";
		}
		else
		{
			$this->checkedCaptchaNo = "";
			$this->checkedCaptchaYes = "checked";
		}
		$this->actionForm = array(
			'redirect_to_url' => "",
			'menu_item' => "",
			'menu_item_title' => "",
			'article' => "",
			'article_title' => "",
			'message' => "",
			'action' => "1"
		);
		$this->actionForm = JSNUniformHelper::actionFrom($this->_item->form_post_action, $this->_item->form_post_action_data);

		$config = JSNConfigHelper::get();
		// Get messages
		$msgs = '';
		if (!$config->get('disable_all_messages'))
		{
			$msgs = JSNUtilsMessage::getList('FORMS');
			$msgs = count($msgs) ? JSNUtilsMessage::showMessages($msgs) : '';
		}
		// Assign variables for rendering
		$this->assignRef('msgs', $msgs);
		JRequest::setVar('hidemainmenu', true);
		parent::display($tpl);
		$this->_addAssets();
		$this->_addToolbar();

	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return void
	 * 
	 * @since	1.6
	 */
	private function _addToolbar()
	{
		$bar = JToolBar::getInstance('toolbar');
		JToolBarHelper::title(JText::_('JSN_UNIFORM_FORM_PAGETITLE'), 'uniform-forms');
		JToolBarHelper::apply('form.apply');
		JToolBarHelper::save('form.save');
		$menu = '';
		$optionMenus = JSNUniformHelper::getOptionMenus();
		if (count($optionMenus))
		{
			foreach ($optionMenus as $option)
			{
				$menu .= '<li><a class="action-save-show" href="&task=launchAdapter&type=menu&menutype=' . $option->value . '">' . $option->text . '</a></li>';
			}
		}
		$bar->appendButton('Custom', '<ul class="jsn-menu clearafter">
					 <li class="menu-name"><a href="#" onclick="return false;"><span class="icon-32-save icon-menu"></span>' . JText::_('JSN_UNIFORM_SAVE_AND_SHOW') . '</a>
					    <ul class="jsn-submenu">
						<li class="parent primary first"><a href="javascript:void(0);"><span class="jsn-icon24 jsn-icon-joomla jsn-icon-component"></span>' . JText::_('JSN_UNIFORM_FORM_VIA_MENU_ITEM_COMPONENT') . '</a>
						    <ul class="jsn-list-items">' . $menu . '</ul>
						</li>
						<li class="parent primary"><a class="action-save-show" href="&task=launchAdapter&type=module"><span class="jsn-icon24 jsn-icon-joomla jsn-icon-module"></span>' . JText::_('JSN_UNIFORM_FORM_IN_MODULE_POSITION_MODULE') . '</a></li>
						<li class="parent primary"><a id="article-content-plugin" href="javascript:void(0);"><span class="jsn-icon24 jsn-icon-joomla jsn-icon-plugin"></span>' . JText::_('JSN_UNIFORM_FORM_INSIDE_ARTICLE_CONTENT_PLUGIN') . '</a></li>
					    </ul>
					  </li>
					</ul>');

		JToolBarHelper::cancel('form.cancel', 'JSN_UNIFORM_CLOSE');
		JToolBarHelper::divider();
		JSNUniformHelper::buttonMenu();
		JToolBarHelper::divider();
		$bar->appendButton('Custom', '<a href="javascript:void(0);" id="jsn-help" class="toolbar"><span class="icon-32-help" title="' . JText::_('JSN_UNIFORM_HELP') . '" type="Custom"></span>' . JText::_('JSN_UNIFORM_HELP') . '</a>');

	}

	/**
	 * Add the libraries css and javascript
	 *
	 * @return void
	 * 
	 * @since	1.6
	 */
	private function _addAssets()
	{

		if (preg_match('/msie/i', $_SERVER['HTTP_USER_AGENT']))
		{
			JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-ui/css/ui-bootstrap/jquery-ui-1.8.16.ie.css');
		}
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-ui/css/ui-bootstrap/jquery-ui-1.9.0.custom.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/bootstrap/css/bootstrap.min.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/joomlashine/css/jsn-gui.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/joomlashine/css/jsn-view-launchpad.css');
		JSNHtmlAsset::addStyle(JURI::base(true) . '/components/com_uniform/assets/css/uniform.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-tipsy/tipsy.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-jwysiwyg/jquery.wysiwyg.css');
		$formSubmitter = isset($this->_item->form_submitter) ? json_decode($this->_item->form_submitter) : "";

		$formAction = 0;
		$formActionData = '';
		if (!empty($this->formAction))
		{
			$formAction = $this->formAction;
			$formActionData = isset($this->formActionData) ? $this->formActionData : '';
		}
		$arrayTranslated = array('JSN_UNIFORM_EMAIL_SETTINGS',
			'JSN_UNIFORM_SELECT_MENU_ITEM',
			'JSN_UNIFORM_SELECT_ARTICLE',
			'JSN_UNIFORM_FORM_APPEARANCE',
			'JSN_UNIFORM_SELECT',
			'JSN_UNIFORM_SAVE',
			'JSN_UNIFORM_CANCEL',
			'JSN_UNIFORM_ADD_FIELD',
			'JSN_UNIFORM_BUTTON_SAVE',
			'JSN_UNIFORM_BUTTON_CANCEL',
			'JSN_UNIFORM_CONFIRM_CONVERTING_FORM',
			'JSN_UNIFORM_UPGRADE_EDITION_TITLE',
			'JSN_UNIFORM_YOU_HAVE_REACHED_THE_LIMITATION_OF_10_FIELD_IN_FREE_EDITION',
			'JSN_UNIFORM_YOU_HAVE_REACHED_THE_LIMITATION_OF_1_PAGE_IN_FREE_EDITION',
			'JSN_UNIFORM_UPGRADE_EDITION',
			'JSN_UNIFORM_CONFIRM_SAVE_FORM',
			'JSN_UNIFORM_NO_EMAIL',
			'JSN_UNIFORM_NO_EMAIL_DES',
			'JSN_UNIFORM_CONFIRM_DELETING_A_FIELD',
			'JSN_UNIFORM_CONFIRM_DELETING_A_FIELD_DES',
			'JSN_UNIFORM_BTN_BACKUP',
			'JSN_UNIFORM_IF_CHECKED_VALUE_DUPLICATION',
			'JSN_UNIFORM_EMAIL_SUBMITTER_TITLE',
			'JSN_UNIFORM_EMAIL_ADDRESS_TITLE',
			'JSN_UNIFORM_LAUNCHPAD_PLUGIN_SYNTAX',
			'JSN_UNIFORM_LAUNCHPAD_PLUGIN_SYNTAX_DES',
			'JSN_UNIFORM_FORM_LIMIT_FILE_EXTENSIONS',
			'JSN_UNIFORM_FOR_SECURITY_REASONS_FOLLOWING_FILE_EXTENSIONS',
			'JSN_UNIFORM_FORM_LIMIT_FILE_SIZE',
			'STREET ADDRESS',
			'ADDRESS LINE 2',
			'CITY',
			'POSTAL/ZIP CODE',
			'STATE/PROVINCE/REGION',
			'FIRST',
			'MIDDLE',
			'LAST',
			'JSN_UNIFORM_ALLOW_USER_CHOICE',
			'JSN_UNIFORM_SET_ITEM_PLACEHOLDER',
			'JSN_UNIFORM_SET_ITEM_PLACEHOLDER_DES',
			'JSN_UNIFORM_SHOW_DATE_FORMAT',
			'JSN_UNIFORM_SHOW_TIME_FORMAT',
			'JSN_UNIFORM_ENABLE_RANGE_SELECTION',
			'JSN_UNIFORM_YOU_CAN_NOT_HIDE_THE_COPYLINK'
		);
		$params = JComponentHelper::getParams('com_media');
		$listEx = '';
		$extensions = $params->get('upload_extensions');
		if ($extensions)
		{
			$extensions = explode(",", $extensions);
			$exs = array();
			foreach ($extensions as $ex)
			{
				$exs[] = strtolower($ex);
			}
			$listEx = implode(", ", array_unique($exs));
		}
		$extensions = str_replace(",", ", ", $extensions);
		$limitSize = $params->get('upload_maxsize');
		$configSizeSever = (int) (ini_get('post_max_size'));
		if ($limitSize > $configSizeSever)
		{
			$limitSize = $configSizeSever;
		}
		if ($limitSize > (int) (ini_get('upload_max_filesize')))
		{
			$limitSize = (int) (ini_get('upload_max_filesize'));
		}
		$session = JFactory::getSession();
		$openArticle = JRequest::getVar('opentarticle', '');
		$this->pageContent = $session->get('page_content', '', 'form-design-' . $this->_item->form_id);
		JSNHtmlAsset::registerDepends('uniform/libs/jquery.tmpl', array('jquery'));
		JSNHtmlAsset::registerDepends('uniform/libs/jquery-ui-timepicker-addon', array('jquery', 'jquery.ui'));
		JSNHtmlAsset::registerDepends('uniform/libs/jquery.placeholder', array('jquery'));
		$this->edition = defined('JSN_UNIFORM_EDITION') ? strtolower(JSN_UNIFORM_EDITION) : "free";
		JSNHtmlAsset::addScript(JSN_URL_ASSETS . '/3rd-party/jquery/jquery-1.8.2.js');
		JSNHtmlAsset::addScriptLibrary('jquery.ui', '3rd-party/jquery-ui/js/jquery-ui-1.9.0.custom.min', array('jquery'));
		$titleForm = isset($_GET['form']) ? $_GET['form'] : '';
		echo JSNHtmlAsset::loadScript('uniform/form', array('opentArticle' => $openArticle,
			'baseZeroClipBoard' => JSN_URL_ASSETS . '/3rd-party/jquery-zeroclipboard/ZeroClipboard.swf',
			'pageContent' => $this->pageContent,
			'edition' => $this->edition,
			'checkSubmitModal' => $this->checkSubmitModal,
			'urlAction' => $this->urlAction,
			'form_style' => $this->_item->form_style,
			'dataEmailSubmitter' => $formSubmitter,
			'language' => JSNUtilsLanguage::getTranslated($arrayTranslated),
			'formActionData' => $formActionData,
			'formAction' => $formAction,
			'limitEx' => $listEx,
			'limitSize' => $limitSize,
			'titleForm' => $titleForm
				)
				, true);

	}

}