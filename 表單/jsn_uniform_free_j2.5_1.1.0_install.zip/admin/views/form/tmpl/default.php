<?php

/**
 * @version     $Id: default.php 19013 2012-11-28 04:48:47Z thailv $
 * @package     JSNUniform
 * @subpackage  Form
 * @author      JoomlaShine Team <support@joomlashine.com>
 * @copyright   Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license     GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */
defined('_JEXEC') or die('Restricted access');
// Display messages
if (JRequest::getInt('ajax') != 1)
{
	echo $this->msgs;
}

?>
<div class="jsn-page-settings jsn-bootstrap">
    <form name="adminForm"  method="post" id="adminForm" class="hide">
<?php echo $this->_form->getInput('form_id') ?>
		<div class="jsn-tabs">
			<ul>
				<li class="active"><a href="#detail" ><?php echo JText::_('JSN_UNIFORM_FORM_DETAIL'); ?></a></li>
				<li ><a href="#form-design"><?php echo JText::_('JSN_UNIFORM_FORM_DESIGN'); ?></a></li>
				<li ><a href="#form-action"><?php echo JText::_('JSN_UNIFORM_FORM_ACTION'); ?></a></li>
			</ul>
			<div class="tab-pane active" id="detail">
				<div class="row-fluid jsn-padding-large form-horizontal">
					<div class="span6">
						<div class="control-group">
							<label class="control-label jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_SET_THE_FORM_TITLE'); ?>"><?php echo JText::_('JSN_UNIFORM_FORM_TITLE'); ?></label>
							<div class="controls">
<?php echo $this->_form->getInput('form_title') ?>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_SET_THE_FORM_DES'); ?>"><?php echo JText::_('JSN_UNIFORM_FORM_DESC'); ?></label>
							<div class="controls">
<?php echo $this->_form->getInput('form_description') ?>
							</div>
						</div>
					</div>
					<div class="span6">
						<div class="control-group">
							<label class="control-label jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_SELECT_THE_FORM_STATUS_TO_INDICATE'); ?>"><?php echo JText::_('JSTATUS'); ?></label>
							<div class="controls">
<?php echo $this->_form->getInput('form_state') ?>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_SELECT_THE_USER_GROUP'); ?>"><?php echo JText::_('JFIELD_ACCESS_LABEL'); ?></label>
							<div class="controls">
<?php echo $this->_form->getInput('form_access') ?>
							</div>	
						</div>
						<div class="control-group">
							<label class="control-label jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_SELECT_IF_YOU_WANT_TO_SHOW_RECAPTCHA'); ?>"><?php echo JText::_('JSN_UNIFORM_FORM_ENABLE_CAPTCHA'); ?></label>
							<div class="controls">
								<label class="radio jsn-captcha inline">
									<input type="radio" <?php echo $this->checkedCaptchaNo; ?> value="0" name="jform[form_captcha]" id="jform_form_captcha0">
<?php echo JText::_('JNO'); ?>
								</label>
								<label class="radio jsn-captcha inline">
									<input type="radio" <?php echo $this->checkedCaptchaYes; ?> value="1" name="jform[form_captcha]" id="jform_form_captcha1">
<?php echo JText::_('JYES'); ?>
								</label>
							</div>	
						</div>
					</div>
				</div>
			</div>
			<div id="form-design">
				<div class="jsn-page">
					<div class="jsn-form-bar">
						<div class="control-group ">
							<label class="control-label jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_SELECT_TO_SHOW_FORM_FIELD_IN_SINGLE_PAGE'); ?>"><?php echo JText::_('JSN_UNIFORM_TYPE'); ?></label>
							<div class="controls">
<?php echo $this->_form->getInput('form_type') ?>
							</div>	
						</div>
						<div class="control-group">
							<label class="control-label jsn-captcha inline jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_SELECT_TO_SHOW_FORM_FIELD_TITLE_AND_ELEMENT'); ?>"><?php echo JText::_('JSN_UNIFORM_FORM_LAYOUT'); ?></label>
							<div class="controls">
<?php echo $this->_form->getInput('form_style') ?>
							</div>	
						</div>
						<div class="control-group">
							<label class="control-label jsn-captcha inline jsn-label-des-tipsy" original-title="<?php echo JText::_('JSN_UNIFORM_FORM_STYLE_DES'); ?>"><?php echo JText::_('JSN_UNIFORM_FORM_STYLE'); ?></label>
							<div class="controls">
<?php echo $this->_form->getInput('form_theme') ?>
							</div>	
						</div>
					</div>
					<div class="jsn-pane jsn-bgpattern pattern-sidebar">
<?php echo $this->_listPage; ?>
						<div id="form-design-content" class="<?php echo $this->_item->form_theme ?>">
							<div id="form-container" class="jsn-section-content">
								<div id="page-loading" class="jsn-bgloading hide"><i class="jsn-icon32 jsn-icon-loading"></i></div>
<?php echo $this->_formLayout->load($this->_item->form_layout) ?>
								<div class="ui-sortable jsn-sortable-disable">
									<div class="form-actions ui-state-default jsn-iconbar-trigger">
										<div class="btn-toolbar">
											<?php

											$edition = defined('JSN_UNIFORM_EDITION') ? JSN_UNIFORM_EDITION : "free";
											if (strtolower($edition) == "free")
											{

												?>
												<button class="btn btn-primary jsn-form-submit" onclick="return false;"><?php echo $this->_item->form_btn_submit_text ? JText::_($this->_item->form_btn_submit_text) : JText::_('SUBMIT'); ?></button>
	<?php

}
else
{

	?>
												<button onclick = "return false;" class = "btn jsn-form-prev hide"><?php echo $this->_item->form_btn_prev_text ? JText::_($this->_item->form_btn_prev_text) : JText::_('PREV'); ?></button>
												<button onclick="return false;" class="btn jsn-form-next btn-primary hide"><?php echo $this->_item->form_btn_next_text ? JText::_($this->_item->form_btn_next_text) : JText::_('NEXT'); ?></button>
												<button class="btn btn-primary jsn-form-submit hide" onclick="return false;"><?php echo $this->_item->form_btn_submit_text ? JText::_($this->_item->form_btn_submit_text) : JText::_('SUBMIT'); ?></button>
	<?php

}

?>
									<?php echo $this->_form->getInput('form_btn_next_text') ?>
									<?php echo $this->_form->getInput('form_btn_prev_text') ?>
									<?php echo $this->_form->getInput('form_btn_submit_text') ?>
										</div>
										<div class="jsn-iconbar">
											<a class="element-edit" title="Edit Button Action" onclick="return false;" href="#"><i class="icon-pencil"></i></a>
										</div>
									</div>
									<?php

									if (strtolower($edition) == "free")
									{

										?>
										<div class="settings-footer ui-state-default jsn-iconbar-trigger">
											<div class="jsn-text-center"><a target="_blank" href="http://www.joomlashine.com/joomla-extensions/jsn-uniform.html">Joomla forms builder</a> by <a target="_blank" href="http://www.joomlashine.com">JoomlaShine</a></div>
											<div class="jsn-iconbar">
												<a class="element-delete" title="Delete footer coppyright" onclick="return false;" href="#"><i class="icon-trash"></i></a>
											</div>
										</div>
	<?php

}

?>
								</div>
							</div>
							<input type="hidden" value="<?php echo htmlentities($this->form_page) ?>" id="jform_form_content" name="jform[form_content]">
						</div>
					</div>
				</div>
			</div>
			<div id="form-action" class="form-horizontal">
				<div class="row-fluid">
					<div class="span6">
						<fieldset id="email">
							<legend>
<?php echo JText::_('JSN_UNIFORM_FORM_EMAIL_NOTIFICATION'); ?>
							</legend>
<?php echo JSNUniformHelper::getListEmailNotification($this->_fromEmail); ?>
							<div class="control-group jsn-items-list-container">
								<label class="control-label jsn-label-des-tipsy"  original-title="<?php echo JText::_('JSN_UNIFORM_SELECT_EMAIL_FORM_FIELD'); ?>">
<?php echo JText::_('JSN_UNIFORM_SEND_TO_SUBMITTER'); ?>
								</label>
								<div class="controls">
									<button class="btn btn-icon pull-right  jsn-label-des-tipsy" id="btn_email_submit"  original-title="<?php echo JText::_('JSN_UNIFORM_EMAIL_CONTENT'); ?>" onclick="return false;" title="<?php echo JText::_('JSN_UNIFORM_EMAIL_CONTENT'); ?>"><i class="icon-envelope"></i></button>	
									<div class="email-submitters"><div id="emailSubmitters" class="jsn-items-list ui-sortable"></div></div>
								</div>
							</div>
						</fieldset>
					</div>
					<div class="span6">
						<fieldset id="postaction">
							<legend>
<?php echo JText::_('JSN_UNIFORM_POST_SUBMISSION_ACTION'); ?>
							</legend>
							<div class="control-group">
								<label  class="control-label jsn-label-des-tipsy"  original-title="<?php echo JText::_('JSN_UNIFORM_SELECT_THE_ACTION_TO_TAKE_AFTER'); ?>"><?php echo JText::_('JSN_UNIFORM_ALERT_FORM_SUBMITSSION'); ?></label>
								<div class="controls">
<?php echo $this->_form->getInput('form_post_action') ?>
								</div>
							</div>
							<div class="control-group hide" id="form1">
								<label  class="control-label"><?php echo JText::_('JSN_UNIFORM_URL'); ?></label>
								<div class="controls">
									<input type="text" placeholder="<?php echo JText::_('JSN_UNIFORM_PLACEHOLDER_REDIRECT_TO_URL'); ?>" class="jsn-input-xlarge-fluid" value="<?php echo $this->actionForm['redirect_to_url']; ?>" id="form_post_action_data1" name="form_post_action_data1" >
								</div>
							</div>
							<div class="control-group hide" id="form2">
								<label  class="control-label"><?php echo JText::_('JSN_UNIFORM_MENU_ITEM'); ?></label>
								<div class="controls">
									<div class="row-fluid input-append">
										<input type="hidden" class="jsn-input-large-fluid" id="form_post_action_data2" name="form_post_action_data2" value="<?php echo $this->actionForm['menu_item']; ?>" id="form_post_action_data2">
										<input type="text" placeholder="<?php echo JText::_('JSN_UNIFORM_PLACEHOLDER_REDIRECT_TO_TO_MENU_ITEM'); ?>"  disabled="disabled" class="jsn-input-large-fluid" value="<?php echo $this->actionForm['menu_item_title']; ?>" name="fr2_form_action_data_title" id="fr2_form_action_data_title"><button class="btn" id="list-menuit" onclick="return false;"><?php echo JText::_('JSN_UNIFORM_SELECTED'); ?></button>
									</div>
								</div>
							</div>
							<div class="control-group hide" id="form3">
								<label  class="control-label"><?php echo JText::_('JSN_UNIFORM_ARTICLE'); ?></label>
								<div class="controls ">
									<div class="row-fluid input-append">
										<input type="hidden" class="jsn-input-large-fluid" id="form_post_action_data3" name="form_post_action_data3" value="<?php echo $this->actionForm['article']; ?>" id="form_post_action_data3">
										<input type="text" placeholder="<?php echo JText::_('JSN_UNIFORM_PLACEHOLDER_SHOW_ARTICLE'); ?>" class="jsn-input-large-fluid" disabled="disabled" value="<?php echo $this->actionForm['article_title']; ?>" name="fr3_form_action_data_title" id="fr3_form_action_data_title"><button class="btn" id="list-article" onclick="return false;"><?php echo JText::_('JSN_UNIFORM_SELECTED'); ?></button>
									</div>
								</div>
							</div>
							<div class="control-group hide" id="form4"> 
								<label  class="control-label"><?php echo JText::_('JSN_UNIFORM_CUSTOM_MESSAGE'); ?></label>
								<div class="controls">
									<textarea id="form_post_action_data4" placeholder="<?php echo JText::_('JSN_UNIFORM_PLACEHOLDER_SHOW_CUSTOM_MESSAGE'); ?>" name="form_post_action_data4" class="jsn-input-xlarge-fluid" rows="10"><?php echo $this->actionForm['message']; ?></textarea>
								</div>
							</div>
						</fieldset>
					</div>
				</div>
			</div>
		</div>
		<div id="dialog-plugin">
			<div class="ui-dialog-content-inner jsn-bootstrap">
				<p><?php echo JText::_('JSN_UNIFORM_LAUNCHPAD_PLUGIN_SYNTAX_DES'); ?></p>
				<div id="jsn-clipboard">
					<span class="jsn-clipboard-input">
						<input type="text" value="" name="plugin" class="input-xlarge" id="syntax-plugin">
						<span class="jsn-clipboard-checkicon icon-ok"></span>
					</span>
					<span id="jsn-clipboard-container">
						<button class="btn" id="jsn-clipboard-button">Copy to clipboard</button>
					</span>
				</div>
			</div>
		</div>
<?php echo $this->_form->getInput('form_layout') ?>
		<input type="hidden" name="option" value="com_uniform" />
		<input type="hidden" name="redirect_url" id="redirectUrl" value="" />
		<input type="hidden" name="redirect_url_form" id="redirectUrlForm" value="" />
		<input type="hidden" name="open_article" id="open-article" value="" />
		<input type="hidden" name="task" id="jsn-task" value="" />
<?php echo JHtml::_('form.token'); ?>
    </form>
</div>
<?php

// Display footer
$getTmpl = JFactory::getApplication()->input->getVar('tmpl', '');
if ($getTmpl != 'component')
{
	JSNHtmlGenerate::footer();
}
