<?php

/**
 * @version     $Id: view.html.php 19013 2012-11-28 04:48:47Z thailv $
 * @package     JSNUniform
 * @subpackage  Configuration
 * @author      JoomlaShine Team <support@joomlashine.com>
 * @copyright   Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license     GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Configuration view of JSN Framework Sample component
 *
 * @package     Joomla.Administrator
 * @subpackage  com_uniform
 * @since       1.5
 */
class JSNUniformViewConfiguration extends JSNConfigView
{

	/**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  mixed  A string if successful, otherwise a JError object.
	 *
	 * @see     fetch()
	 * @since   11.1
	 */
	function display($tpl = null)
	{
		// Get config parameters
		$config = JSNConfigHelper::get();
		$this->_document = JFactory::getDocument();
		$this->_config = JSNConfigHelper::get();

		// Set the toolbar
		JToolBarHelper::title(JText::_('JSN_UNIFORM_CONFIGURATION_SETTING'), 'maintenance');

		// Get messages
		$msgs = '';
		if (!$config->get('disable_all_messages'))
		{
			$msgs = JSNUtilsMessage::getList('CONFIGURATION');
			$msgs = count($msgs) ? JSNUtilsMessage::showMessages($msgs) : '';
		}

		// Assign variables for rendering
		$this->assignRef('msgs', $msgs);

		$this->_addToolbar();
		// Display the template
		parent::display($tpl);
		$this->_addAssets();
	}

	/**
	 * Add the libraries css and javascript
	 *
	 * @return void
	 * 
	 * @since	1.6
	 */
	private function _addAssets()
	{
		$formAction = $this->_config->get('form_action');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-ui/css/ui-bootstrap/jquery-ui-1.9.0.custom.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/bootstrap/css/bootstrap.min.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/joomlashine/css/jsn-gui.css');
		JSNHtmlAsset::addStyle(JURI::base(true) . '/components/com_uniform/assets/css/uniform.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-tipsy/tipsy.css');
		$this->_document->addScriptDeclaration(" var currentAction = {$formAction}; ");
		$arrayTranslated = array(
		'JSN_UNIFORM_BUTTON_SAVE',
		'JSN_UNIFORM_BUTTON_CANCEL',
		'JSN_UNIFORM_EMAIL_SUBMITTER_TITLE',
		'JSN_UNIFORM_EMAIL_ADDRESS_TITLE',
		'JSN_UNIFORM_YOU_CAN_NOT_HIDE_THE_COPYLINK',
		'JSN_UNIFORM_UPGRADE_EDITION_TITLE',
		'JSN_UNIFORM_UPGRADE_EDITION',
		'JSN_UNIFORM_SELECT_THE_ACTION_TO_TAKE_AFTER',
		'JSN_UNIFORM_SET_THE_FOLDER_TO_STORE',
		'JSN_SAMPLE_DISABLE_SHOW_COPYRIGHT_DES'
		);
		JSNHtmlAsset::addScript(JSN_URL_ASSETS . '/3rd-party/jquery/jquery-1.8.2.js');
		JSNHtmlAsset::addScriptLibrary('jquery.ui', '3rd-party/jquery-ui/js/jquery-ui-1.9.0.custom.min', array('jquery'));
		$edition = defined('JSN_UNIFORM_EDITION') ? strtolower(JSN_UNIFORM_EDITION) : "free";
		echo JSNHtmlAsset::loadScript(
		'jsn/core', array('lang' => JSNUtilsLanguage::getTranslated(array('JSN_EXTFW_GENERAL_LOADING', 'JSN_EXTFW_GENERAL_CLOSE')))
		,true);

		echo JSNHtmlAsset::loadScript(
		'jsn/config', array('language' => array('JSN_EXTFW_GENERAL_CLOSE' => JText::_('JSN_EXTFW_GENERAL_CLOSE')))
		,true);
		echo JSNHtmlAsset::loadScript('uniform/configuration', array('language' => JSNUtilsLanguage::getTranslated($arrayTranslated), 'edition' => $edition), true);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return void
	 * 
	 * @since	1.6
	 */
	private function _addToolBar()
	{
		JToolBarHelper::title(JText::_('JSN_UNIFORM_CONFIGURATION_MANAGER'), 'uniform-config');
		$bar = JToolBar::getInstance('toolbar');
		// JToolBarHelper::apply('configuration.apply');
		JSNUniformHelper::buttonMenu();
		JToolBarHelper::divider();
		$bar->appendButton('Custom', '<a href="javascript:void(0);" id="jsn-help" class="toolbar"><span class="icon-32-help" title="' . JText::_('JSN_UNIFORM_HELP') . '" type="Custom"></span>' . JText::_('JSN_UNIFORM_HELP') . '</a>');
	}

}
