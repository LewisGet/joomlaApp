<?php

/**
 * @version     $Id: uniform.php 19093 2012-11-30 02:25:56Z thailv $
 * @package     JSNUniform
 * @subpackage  Helper
 * @author      JoomlaShine Team <support@joomlashine.com>
 * @copyright   Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license     GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 *
 */
defined('_JEXEC') or die('Restricted access');

/**
 * JSNUniform form helper
 *
 * @package     Joomla.Administrator
 * @subpackage  com_uniform
 * @since       1.6
 */
class JSNUniformHelper
{

	/**
	 * Configure the Linkbar.
	 *
	 * @param   string  $vName  The name of the active view.
	 *
	 * @return void
	 *
	 * @since	1.6
	 */
	public static function addSubmenu($vName = 'forms')
	{
		// Get Joomla version
		$joomlaVersion = new JVersion;

		if (version_compare($joomlaVersion->RELEASE, '3.0', '<'))
		{
			JSubMenuHelper::addEntry(
					JText::_('JSN_UNIFORM_SUBMENU_FORMS'), 'index.php?option=com_uniform&view=forms', $vName == 'forms'
			);
			JSubMenuHelper::addEntry(
					JText::_('JSN_UNIFORM_SUBMENU_SUBMISSION'), 'index.php?option=com_uniform&view=submissions', $vName == 'submissions'
			);
			JSubMenuHelper::addEntry(
					JText::_('JSN_UNIFORM_SUBMENU_CONFIGURATION'), 'index.php?option=com_uniform&view=configuration', $vName == 'configuration'
			);
			JSubMenuHelper::addEntry(
					JText::_('JSN_UNIFORM_SUBMENU_ABOUT'), 'index.php?option=com_uniform&view=about', $vName == 'about'
			);
		}

	}

	/**
	 * Setup menu button.
	 *
	 * @return  void
	 */
	public static function buttonMenu()
	{
		// Import Joomla toolbar library
		jimport('joomla.html.toolbar');
		// Add a custom menu button
		$toolbar = JToolBar::getInstance('toolbar');
		$toolbar->addButtonPath(JPATH_COMPONENT_ADMINISTRATOR . DS . 'helpers');
		$toolbar->appendButton('JSNMenuButton');

	}
	/**
	 * Setup menu add new form button.
	 *
	 * @return  void
	 */
	public static function buttonAddNewForm()
	{
		// Import Joomla toolbar library
		jimport('joomla.html.toolbar');
		// Add a custom menu button
		$toolbar = JToolBar::getInstance('toolbar');
		$toolbar->addButtonPath(JPATH_COMPONENT_ADMINISTRATOR . DS . 'helpers');
		$toolbar->appendButton('JSNAddNewFormButton');

	}
	/**
	 * Genrate published options
	 *
	 * @return array
	 */
	public static function publishedOptions()
	{
		// Build the active state filter options.
		$options = array();
		$options[] = JHtml::_('select.option', '1', 'JSN_UNIFORM_PUBLISHED');
		$options[] = JHtml::_('select.option', '0', 'JSN_UNIFORM_UNPUBLISHED');

		return $options;

	}

	/**
	 * Word limiter
	 *
	 * @param   string   $str       String input
	 *
	 * @param   integer  $limit     Limit number
	 *
	 * @param   string   $end_char  End char
	 *
	 * @return string
	 */
	public static function wordLimiter($str, $limit = 100, $end_char = '&#8230;')
	{
		if (trim($str) == '')
		{
			return $str;
		}

		preg_match('/\s*(?:\S*\s*){' . (int) $limit . '}/', $str, $matches);

		if (strlen($matches[0]) == strlen($str))
		{
			$end_char = '';
		}

		return rtrim($matches[0]) . $end_char;

	}

	/**
	 * Get module info
	 *
	 * @return type
	 */
	public static function getModuleInfo()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__extensions');
		$query->where('element=\'mod_uniform\' AND type=\'module\'');
		$db->setQuery($query);
		$result = $db->loadObject();
		return $result;

	}

	/**
	 * get component info
	 *
	 * @return type
	 */
	public static function getComponentInfo()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__extensions');
		$query->where('element=\'com_uniform\' AND type=\'component\'');
		$db->setQuery($query);
		$result = $db->loadObject();
		return $result;

	}

	/**
	 * Get options Menus
	 *
	 * @return object list
	 */
	public static function getOptionMenus()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('menutype As value, title As text');
		$query->from('#__menu_types');
		$query->order('title');
		$db->setQuery($query);
		$menus = $db->loadObjectList();
		// Check for a database error.
		if ($db->getErrorNum())
		{
			JError::raiseWarning(500, $db->getErrorMsg());
		}
		return $menus;

	}

	/**
	 * Get data forms
	 *
	 * @param   integer  $limit  Limit number
	 *
	 * @return object list
	 */
	public static function getForms($limit = "")
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__jsn_uniform_forms');
		$query->order("form_id DESC");
		if (empty($limit))
		{
			$db->setQuery($query);
		}
		else
		{
			$db->setQuery($query, 0, $limit);
		}
		$forms = $db->loadObjectList();
		// Check for a database error.
		if ($db->getErrorNum())
		{
			JError::raiseWarning(500, $db->getErrorMsg());
		}
		return $forms;

	}

	/**
	 * Get user name by id
	 *
	 * @return type
	 */
	public static function getUserNameById()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('id,username');
		$query->from('#__users');
		$db->setQuery($query);
		$items = $db->loadObjectList();
		$forms = array();
		if (count($items))
		{
			foreach ($items as $item)
			{
				$forms[$item->id] = $item->username;
			}
		}
		return $forms;

	}

	/**
	 * Get options forms
	 *
	 * @return object list
	 */
	public static function getOptionForms()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('form_id As value, form_title As text');
		$query->from('#__jsn_uniform_forms');
		$query->where('form_state = 1');
		$query->order('form_id DESC');
		$db->setQuery($query);
		$forms = $db->loadObjectList();
		$listForm = array();
		foreach ($forms as $form)
		{
			$query = $db->getQuery(true);
			$query->select(count("field_id"))->from('#__jsn_uniform_fields')->where('form_id=' . (int) $form->value);
			$db->setQuery($query);
			if ($db->loadResult())
			{
				$listForm[] = $form;
			}
		}
		return $listForm;

	}

	/**
	 * get data submission by field
	 *
	 * @param   int  $fieldId  Field Id
	 * @param   int  $formId   Form Id
	 *
	 * @return object
	 */
	public static function getDataSumbissionByField($fieldId, $formId)
	{
		$db = JFactory::getDBO();
		if (JSNUniformHelper::checkTableSql('#__jsn_uniform_submissions_' . (int) $formId))
		{
			$db->setQuery("SHOW COLUMNS FROM " . $db->quoteName('#__jsn_uniform_submissions_' . (int) $formId));
			$listColumn = $db->loadObjectList();
			foreach ($listColumn as $coulumn)
			{
				if (isset($coulumn->Field) && $coulumn->Field && $coulumn->Field == "sb_" . $fieldId)
				{
					$query = $db->getQuery(true);
					$query->select(count("data_id"))->from($db->quoteName('#__jsn_uniform_submissions_' . (int) $formId))->where('`sb_' . (int) $fieldId . '` != "" ');
					$db->setQuery($query);
					return $db->loadResult();
				}
			}
		}

	}

	/**
	 * Replace type field
	 *
	 * @param   string  $type  Type field
	 *
	 * @return string
	 */
	public static function replaceField($type)
	{
		$type = str_replace(array("email", "single-line-text", "file-upload", "currency", "phone", "website", "dropdown", "choices", "date", "country", "number"), "varchar(255)", $type);
		$type = str_replace(array("address", "checkboxes", "name", "paragraph-text", "list"), "longtext", $type);
		return $type;

	}

	/**
	 * Check table in database
	 *
	 * @param   string  $table  Name table
	 *
	 * @return boolen
	 */
	public static function checkTableSql($table)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$prefix = $db->getPrefix();
		$table = str_replace("#__", "", $table);
		$tableName = $prefix . $table;
		$app = JFactory::getApplication();
		$dbName = $app->getCfg('db');
		$query->select('TABLE_NAME')->from('INFORMATION_SCHEMA.TABLES')->where("TABLE_NAME LIKE " . $db->Quote($tableName) . " AND TABLE_SCHEMA = " . $db->quote($dbName));
		$db->setQuery($query);
		if (!$db->loadResult())
		{
			return false;
		}
		return true;

	}

	/**
	 * Set position field
	 *
	 * @param   int    $idForm  Id form
	 *
	 * @param   array  $data    Data field
	 *
	 * @return void
	 */
	public static function setPositionFields($idForm, $data)
	{
		$infoData = new stdClass;
		$infoData->identifier = $data['fields']['identifier'];
		$infoData->field_view = $data['field_view'];

		$db = JFactory::getDBO();
		$query = "REPLACE INTO `#__jsn_uniform_config` (name, value) VALUES ('position_form_" . (int) $idForm . "'," . $db->quote(json_encode($infoData)) . ")";
		$db->setQuery($query);
		if (!$db->execute())
		{
			JError::raiseWarning(500, $db->getErrorMsg());
		}

	}

	/**
	 * Get postion fields
	 *
	 * @param   int  $idForm  Id Form
	 *
	 * @return object
	 */
	public static function getPositionFields($idForm)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('value')->from('#__jsn_uniform_config')->where('name = ' . '"position_form_' . (int) $idForm . '"');
		$db->setQuery($query);
		return $db->loadObject();

	}

	/**
	 * Get action form submission
	 *
	 * @param   int     $action      Action value
	 *
	 * @param   string  $actionData  Action data
	 *
	 * @return array
	 */
	public static function actionFrom($action = null, $actionData = null)
	{
		$redirectToUrl = "";
		$menuItem = "";
		$menuItemTitle = "";
		$article = "";
		$articleTitle = "";
		$message = "";
		if (isset($action))
		{
			switch ($action)
			{
				case 1:
					$redirectToUrl = $actionData;
					break;
				case 2:
					$db = JFactory::getDBO();
					$query = $db->getQuery(true);
					$query->select('id,title')->from('#__menu')->where('id = ' . (int) $actionData);
					$db->setQuery($query);
					$dataMenu = $db->loadObject();
					if ($dataMenu)
					{
						$menuItem = $dataMenu->id;
						$menuItemTitle = $dataMenu->title;
					}
					break;
				case 3:
					$db = JFactory::getDBO();
					$query = $db->getQuery(true);
					$query->select('id,title')->from('#__content')->where('id = ' . (int) $actionData);
					$db->setQuery($query);
					$dataContent = $db->loadObject();
					if ($dataContent)
					{
						$article = $dataContent->id;
						$articleTitle = $dataContent->title;
					}
					break;
				case 4:
					$message = $actionData;
					break;
			}
		}
		else
		{
			$action = 0;
		}
		return array('redirect_to_url' => $redirectToUrl, 'menu_item' => $menuItem, 'menu_item_title' => $menuItemTitle, 'article' => $article, 'article_title' => $articleTitle, 'message' => $message, 'action' => $action);

	}

	/**
	 * Get layout & themes form
	 *
	 * @param   string  $action  Action layout
	 *
	 * @return xml
	 */
	public static function getLayoutsThemes($action)
	{
		$dir = JPATH_ROOT . DS . "administrator" . DS . "components" . DS . "com_uniform" . DS . "assets" . DS . $action . DS;
		$dataXML = "";
		$files = array();
		if (is_dir($dir))
		{
			if ($handle = opendir($dir))
			{
				while (false !== ($file = readdir($handle)))
				{
					if ($file != '.' && $file != '..' && $file != 'CSV' && $file != 'index.html')
					{
						$files[] = $file;
					}
				}
			}
			closedir($handle);
			$dataXML = array();
			$i = 0;
			foreach ($files as $fi)
			{
				$filePath = JPath::clean($dir . $fi . '/uniform.xml');
				if (is_file($filePath))
				{
					$i++;
					$xml = JFactory::getXML($filePath);
					$dataXML[$i]['type'] = $xml->getName();
					$dataXML[$i]['title'] = $xml->name;
					$dataXML[$i]['description'] = $xml->description;
					$dataXML[$i]['images'] = JURI::root() . '/administrator/components/com_uniform/assets/' . $action . '/' . $fi . "/thumbnail.png";
					$dataXML[$i]['folder'] = $fi;
				}
			}
		}
		return $dataXML;

	}

	/**
	 * get data folder upload in data default config
	 *
	 * @param   String  $name  Name field
	 *
	 * @return Object
	 */
	public static function getDataConfig($name)
	{
		$db = JFactory::getDBO();
		$db->setQuery(
				$db->getQuery(true)
						->select('*')
						->from("#__jsn_uniform_config")
						->where("name=" . $db->Quote($name))
		);
		return $db->loadObject();

	}

	/**
	 * Get data field
	 *
	 * @param   string   $fieldType   Field type
	 *
	 * @param   object   $submission  Data submission
	 *
	 * @param   string   $key         Key field
	 *
	 * @param   int      $formId      Form id
	 *
	 * @param   boolean  $linkImg     Link Imgages
	 *
	 * @param   boolean  $checkNull   Check validate null
	 * 
	 * @param   string   $action      Action data
	 *
	 * @return html code
	 */
	public static function getDataField($fieldType, $submission, $key, $formId, $linkImg = false, $checkNull = true, $action = '')
	{
		switch ($fieldType)
		{
			case "datetime":
				$checkdate = @explode(" ", @$submission->$key);
				$checkdate = @explode("-", @$checkdate[0]);
				if (@$checkdate[0] != '0000' && @$checkdate[1] != '00' && @$checkdate[2] != '00')
				{
					$dateTime = new DateTime(@$submission->$key);
					$contentField = $dateTime->format("j F Y");
				}
				break;
			case "name":
				if (!empty($submission->$key))
				{
					$jsonName = json_decode($submission->$key);
					if ($jsonName)
					{
						$nameTitle = isset($jsonName->title) ? $jsonName->title . " " : '';
						$nameFirst = isset($jsonName->first) ? $jsonName->first . " " : '';
						$nameLast = isset($jsonName->last) ? $jsonName->last : '';
						$nameSuffix = isset($jsonName->suffix) ? $jsonName->suffix . " " : '';
						if (!empty($jsonName->first) || !empty($jsonName->last) || !empty($jsonName->suffix))
						{
							$contentField = $nameTitle . $nameFirst . $nameSuffix . $nameLast;
						}
						else
						{
							$contentField = '';
						}
					}
					else
					{
						$contentField = $submission->$key;
					}
				}

				break;
			case "file-upload":
				$jsonFile = json_decode(@$submission->$key);
				if (!empty($jsonFile))
				{
					$configFolderUpload = self::getDataConfig("folder_upload");
					$url = isset($configFolderUpload->value) ? $configFolderUpload->value : "images/jsnuniform/";
					$url = str_replace("//", "/", $url . '/jsnuniform_uploads/' . $formId . '/' . $jsonFile->link);
					$link = JURI::root() . $url;

					$fileName = explode(".", $jsonFile->name);
					if ($action == "export")
					{
						$contentField = isset($jsonFile->name) ? $link : "N/A";
					}
					else if ($action == "email")
					{
						$contentField = isset($jsonFile->name) ? "<a href=\"{$link}\">{$jsonFile->name}</a>" : "N/A";
					}
					else
					{
						if (in_array(strtolower(array_pop($fileName)), array("jpg", "gif", "jpeg", "png")))
						{
							if ($linkImg)
							{
								$contentField = isset($jsonFile->name) ? "<img src=\"{$link}\" />" : "N/A";
							}
							else
							{
								$contentField = isset($jsonFile->name) ? "<a href=\"{$link}\" class=\"thumbnail\" target=\"_blank\"><img src=\"{$link}\" /></a>" : "N/A";
							}
						}
						else
						{
							$contentField = isset($jsonFile->name) ? "<a href=\"{$link}\">{$jsonFile->name}</a>" : "N/A";
						}
					}
				}
				break;
			case "address":
				if (!empty($submission->$key))
				{
					$jsonAddress = json_decode($submission->$key);
					if ($jsonAddress)
					{
						$nameStreet = !empty($jsonAddress->street) ? $jsonAddress->street . ", " : '';
						$nameLine2 = !empty($jsonAddress->line2) ? $jsonAddress->line2 . ", " : '';
						$nameCity = !empty($jsonAddress->city) ? $jsonAddress->city . ", " : '';
						$nameCode = !empty($jsonAddress->code) ? $jsonAddress->code . " " : '';
						$nameState = !empty($jsonAddress->state) ? $jsonAddress->state . " " : '';
						$nameCountry = !empty($jsonAddress->country) ? $jsonAddress->country . " " : '';
						$contentField = $nameStreet . $nameLine2 . $nameCity . $nameState . $nameCode . $nameCountry;
					}
					else
					{
						$contentField = $submission->$key;
					}
				}
				else
				{
					$contentField = '';
				}

				break;
			case ($fieldType == "checkboxes" || $fieldType == "list"):
				if (!empty($submission->$key))
				{
					$jsonName = json_decode($submission->$key);
					if ($action == "email")
					{
						if (!empty($jsonName) && is_array($jsonName))
						{
							$listCheckBox = '';
							foreach ($jsonName as $item)
							{
								$listCheckBox .= '<li style="padding:0;">' . $item . '</li>';
							}
							if ($listCheckBox)
							{
								$contentField = "<ul style=\"padding:0 0px 0px 10px;margin:0;\">{$listCheckBox}</ul>";
							}
							else
							{
								$contentField = '';
							}
						}
					}
					else
					{
						if (empty($jsonName))
						{
							$jsonName = explode("\n", $submission->$key);
							$contentField = implode("<br/>", $jsonName);
						}
						else if (!empty($jsonName) && is_array($jsonName))
						{
							$contentField = implode("<br/>", $jsonName);
						}
						else
						{
							$contentField = $submission->$key;
						}
					}
				}
				else
				{
					$contentField = '';
				}

				break;
			default:
				if ($checkNull)
				{
					$contentField = isset($submission->$key) ? $submission->$key : "<span>N/A</span>";
				}
				else
				{
					$contentField = isset($submission->$key) ? $submission->$key : "";
				}
				break;
		}
		return isset($contentField) ? $contentField : "";

	}

	/**
	 * Delete Directory
	 *
	 * @param   string  $dirName  Directory Url
	 *
	 * @return void
	 */
	public static function deleteDirectory($dirName)
	{
		$dirName = JPath::clean($dirName);
		$dirHandle = "";
		if (is_dir($dirName))
		{
			$dirHandle = opendir($dirName);
		}
		if (!$dirHandle)
		{
			return false;
		}
		while ($file = readdir($dirHandle))
		{
			if ($file != "." && $file != "..")
			{
				if (!is_dir($dirName . "/" . $file))
				{
					unlink($dirName . "/" . $file);
				}
				else
				{
					self::deleteDirectory($dirName . '/' . $file);
				}
			}
		}
		closedir($dirHandle);
		rmdir($dirName);
		return true;

	}

	/**
	 * Get select Form
	 *
	 * @param   string   $name   Name form
	 *
	 * @param   int      $id     Id form
	 *
	 * @param   boolean  $btn    Button
	 *
	 * @param   string   $value  Value form
	 *
	 * @return  html code
	 */
	public static function getSelectForm($name, $id = null, $btn = false, $value = null)
	{
		$enabledCSS = 'hide';
		$menuid = JRequest::getInt('id');
		$formID = $value;
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		//build the list of categories
		$query->select('uf.form_title AS text, uf.form_id AS id')->from('#__jsn_uniform_forms AS uf')->where('uf.form_state = 1');
		$db->setQuery($query);
		$data = $db->loadObjectList();
		$results[] = JHTML::_('select.option', '0', '- ' . JText::_('JSN_UNIFORM_SELECT_FORM') . ' -', 'id', 'text');
		$results = array_merge($results, $data);
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/bootstrap/css/bootstrap.min.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-ui/css/ui-bootstrap/jquery-ui-1.9.0.custom.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/joomlashine/css/jsn-gui.css');
		JSNHtmlAsset::addStyle(JURI::base(true) . '/components/com_uniform/assets/css/uniform.css');
		$arrayTranslated = array('JSN_UNIFORM_UPGRADE_EDITION_TITLE', 'JSN_UNIFORM_YOU_HAVE_REACHED_THE_LIMITATION_OF_3_FORM_IN_FREE_EDITION', 'JSN_UNIFORM_UPGRADE_EDITION');
		$edition = defined('JSN_UNIFORM_EDITION') ? JSN_UNIFORM_EDITION : "free";
		$baseUrl = JURI::base(true);
		JSNHtmlAsset::addScript(JSN_URL_ASSETS . '/3rd-party/jquery/jquery-1.8.2.js');
		JSNHtmlAsset::addScriptLibrary('jquery.ui', '3rd-party/jquery-ui/js/jquery-ui-1.9.0.custom.min', array('jquery'));
		JSNHtmlAsset::addScriptPath('uniform', $baseUrl . '/components/com_uniform/assets/js');
		JSNHtmlAsset::addScriptPath('uniform/3rd', $baseUrl . '/components/com_uniform/assets/3rd-party');

		if ($data)
		{
			$enabledCSS = '';
			if (!$menuid && !$formID)
			{
				$value = $data[0]->id;
			}
		}
		if ($btn)
		{
			$listForm = JHTML::_('select.genericList', $results, $name, 'title="' . ((!$data) ? JText::_('JSN_UNIFORM_DO_NOT_HAVE_ANY_FORM') : '') . '" class="jform_request_form_id"', 'id', 'text');
			$html = '<div class="jsn-uniform-plg-editor-container jsn-bootstrap">
						<div class="jsn-uniform-plg-editor-wrapper">
							<h3 class="jsn-section-header">' . JText::_('JSN_UNIFORM_MODULE_LIST_FORM_DES') . '</h3>
							<div class="setting">
								<ul>
									<li>
										<label style="float:left;">' . JText::_('JSN_UNIFORM_MODULE_LIST_FORM') . '</label>
										' . $listForm . '
											<a id="form-icon-edit"  action="article" href="javascript: void(0);" target="_blank" title="' . JText::_('JSN_UNIFORM_EDIT_SELECTED_FORM') . '"><span class="jsn-icon16 jsn-icon-pencil"></span></a>
											<a id="form-icon-add" action="article" href="javascript: void(0);" title="' . JText::_('JSN_UNIFORM_CREATE_NEW_FORM') . '"><span class="jsn-icon16 jsn-icon-plus"></span></a>
									</li>
								</ul>
							</div>
							<div class="insert">
								<div class="form-actions">
									<button disabled="disabled" id="select-forms" onclick="" name="button_installation_data" type="button" class="btn">' . JText::_('JSN_UNIFORM_BTN_SELECTED') . '</button>
								</div>
							</div>
						</div>
					</div>';
			$html .=JSNHtmlAsset::loadScript('uniform/formmodule', array('edition' => $edition, 'language' => JSNUtilsLanguage::getTranslated($arrayTranslated)), true);
			return $html;
		}
		else
		{
			$listForm = JHTML::_('select.genericList', $results, $name, 'title="' . ((!$data) ? JText::_('JSN_UNIFORM_DO_NOT_HAVE_ANY_FORM') : '') . '" class="jform_request_form_id"', 'id', 'text', $value, $id);
			$html = "<div id='jsn-form-icon-warning'>";
			$html .= $listForm;
			$html .= "<span id =\"form-icon-warning\" class=\"" . $enabledCSS . "\" title='" . JText::_('JSN_UNIFORM_FIELD_DES_FORM_WARNING') . "'><span class=\"jsn-icon16 jsn-icon-warning-sign\"></span></span>";
			$html .= "<a id=\"form-icon-edit\" href=\"javascript: void(0);\" target=\"_blank\" title=\"" . JText::_('JSN_UNIFORM_EDIT_SELECTED_FORM') . "\"><span class=\"jsn-icon16 jsn-icon-pencil\"></span></a>";
			$html .= "<a id=\"form-icon-add\" href=\"javascript: void(0);\" title=\"" . JText::_('JSN_UNIFORM_CREATE_NEW_FORM') . "\"><span class=\"jsn-icon16 jsn-icon-plus\"></span></a>";
			$html .= "<span id='select-forms'></span>";
		}
		$html .= "</div><div id=\"jsn-modal\"></div>" . JSNHtmlAsset::loadScript('uniform/formmodule', array('edition' => $edition, 'language' => JSNUtilsLanguage::getTranslated($arrayTranslated)), true);
		return $html;

	}

	/**
	 * Get list page form
	 *
	 * @param   string  $formContent  Form content
	 * @param   int     $formId       Form Id
	 *
	 * @return  html code
	 */
	public static function getListPage($formContent, $formId = 0)
	{
		$session = JFactory::getSession();

		$listPage = $session->get('form_list_page', '', 'form-design-' . $formId);
		$edition = defined('JSN_UNIFORM_EDITION') ? JSN_UNIFORM_EDITION : "free";
		$option = "";
		$defaultListpage = "";
		$dataValue = "";
		$pageContent = array();

		if (isset($formContent))
		{
			foreach ($formContent as $i => $fContent)
			{
				$session->set('form_page_' . $fContent->page_id, $fContent->page_content, 'form-design-' . $formId);
				if (count(json_decode($fContent->page_content)))
				{
					$pageContent[] = $fContent->page_id;
				}
				if ($i == 0)
				{
					$defaultListpage .= "<div data-value='{$fContent->page_id}' id=\"form-design-header\" class=\"jsn-section-header\"><div class=\"jsn-iconbar-trigger page-title\"><h1>{$fContent->page_title}</h1><div class=\"jsn-iconbar\"><a href=\"javascript:void(0)\" title=\"Edit page\" class=\"element-edit\"><i class=\"icon-pencil\"></i></a><a href=\"javascript:void(0)\" title=\"Delete page\" class=\"element-delete\"><i class=\"icon-trash\"></i></a></div></div><div class=\"jsn-page-actions jsn-buttonbar\"><div class=\"jsn-page-pagination pull-left btn-group\"><button onclick=\"return false;\" class=\"btn btn-icon prev-page\"><i class=\"icon-arrow-left\"></i></button><button onclick=\"return false;\" class=\"btn btn-icon next-page\"><i class=\"icon-arrow-right\"></i></button></div><button onclick=\"return false;\" class=\"btn btn-success new-page\">" . JText::_("JSN_UNIFORM_FORM_NEW_PAGE") . "</button></div><div class=\"clearbreak\"></div>";
					$dataValue = $fContent->page_id;
				}
				$option .= "<li id=\"{$fContent->page_id}\" data-value='{$fContent->page_id}' class=\"page-items\"><input type=\"hidden\" value=\"{$fContent->page_title}\" data-id=\"{$fContent->page_id}\" name=\"name_page[{$fContent->page_id}]\"/></li>";
			}
			if (count($pageContent))
			{
				$session->set('page_content', json_encode($pageContent), 'form-design-' . $formId);
			}
		}
		elseif ($listPage)
		{
			$listPages = json_decode($listPage);
			foreach ($listPages as $i => $page)
			{
				if ($i == 0)
				{
					$defaultListpage .= "<div data-value='{$page[0]}' id=\"form-design-header\" class=\"jsn-section-header\"><div class=\"jsn-iconbar-trigger page-title\"><h1>{$page[1]}</h1><div class=\"jsn-iconbar\"><a href=\"javascript:void(0)\" title=\"Edit page\" class=\"element-edit\"><i class=\"icon-pencil\" ></i></a><a href=\"javascript:void(0)\" title=\"Delete page\" class=\"element-delete\"><i class=\"icon-trash\" ></i></a></div></div><div class=\"jsn-page-actions jsn-buttonbar\"><div class=\"jsn-page-pagination pull-left btn-group\"><button onclick=\"return false;\" class=\"btn btn-icon prev-page\"><i class=\"icon-arrow-left\"></i></button><button onclick=\"return false;\" class=\"btn btn-icon next-page\"><i class=\"icon-arrow-right\"></i></button></div><button onclick=\"return false;\" class=\"btn btn-success new-page\">" . JText::_("JSN_UNIFORM_FORM_NEW_PAGE") . "</button></div><div class=\"clearbreak\"></div>";
					$dataValue = $page[0];
				}
				$option .= "<li id=\"{$page[0]}\" data-value='{$page[0]}' class=\"page-items\"><input type=\"hidden\" value=\"{$page[1]}\" data-id=\"{$page[0]}\" name=\"name_page[{$page[0]}]\"/></li>";
			}
		}
		else
		{
			$randomID = rand(1000000, 10000000000);
			$defaultListpage = "<div data-value='{$randomID}' id=\"form-design-header\" class=\"jsn-section-header\"><div class=\"jsn-iconbar-trigger page-title\"><h1>Page 1</h1><div class=\"jsn-iconbar\"><a href=\"javascript:void(0)\" title=\"Edit page\" class=\"element-edit\"><i class=\"icon-pencil\"></i></a><a href=\"javascript:void(0)\" title=\"Delete page\" class=\"element-delete\"><i class=\"icon-trash\" ></i></a></div></div><div class=\"jsn-page-actions jsn-buttonbar\"><div class=\"jsn-page-pagination pull-left btn-group\"><button onclick=\"return false;\" class=\"btn btn-icon prev-page\"><i class=\"icon-arrow-left\"></i></button><button onclick=\"return false;\" class=\"btn btn-icon next-page\"><i class=\"icon-arrow-right\"></i></button></div><button onclick=\"return false;\" class=\"btn btn-success new-page\">" . JText::_("JSN_UNIFORM_FORM_NEW_PAGE") . "</button></div><div class=\"clearbreak\"></div>";
			$dataValue = $randomID;
			$option = '<li id="new_' . $randomID . '" data-value="' . $randomID . '" class="page-items"><input type="hidden" value="Page 1" data-id="' . $randomID . '" name="name_page[' . $randomID . ']"/></li>';

			if (!empty($_GET['form']))
			{
				$getSampleForm = JSNUniformHelper::getSampleForm($_GET['form']);
				$session->set('form_page_' . $randomID, $getSampleForm, 'form-design-' . $formId);
				$sessionPage = JFactory::getSession();
				$sessionPage->set('form_list_page', json_encode(array($randomID, 'Page 1')), 'form-design-' . $formId);
			}
		}
		if (strtolower($edition) == "free")
		{
			$defaultListpage = "<div class=\"hide\" id=\"form-design-header\" data-value=\"{$dataValue}\">";
		}
		$select = "{$defaultListpage} <ul class=\"jsn-page-list hide\">{$option}</ul></div>";
		return $select;

	}
	/**
	 * Get Sample Form
	 *
	 * @param   string  $formType  Form Type
	 *
	 * @return  html code
	 */
	public static function getSampleForm($formType)
	{
		switch ($formType)
		{
			case 'Contact Us':
				return '[{"type":"name","position":"left","identify":"name","label":"Name","instruction":"","options":{"label":"Name","instruction":"","required":"1","format":"Extended","items":[{"text":"Mrs","checked":false},{"text":"Mr","checked":true},{"text":"Ms","checked":false},{"text":"Baby","checked":false},{"text":"Master","checked":false},{"text":"Prof","checked":false},{"text":"Dr","checked":false},{"text":"Gen","checked":false},{"text":"Rep","checked":false},{"text":"Sen","checked":false},{"text":"St","checked":false}],"identify":"jsn_tmp_721799"}},{"type":"paragraph-text","position":"left","identify":"when_is_the_best_time_to_contact_you_","label":"When is the best time to contact you?","instruction":"","options":{"label":"When is the best time to contact you?","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"8","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_477590"}},{"type":"paragraph-text","position":"left","identify":"what_is_the_best_way_to_contact_you_","label":"What is the best way to contact you?","instruction":"","options":{"label":"What is the best way to contact you?","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"8","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_448875"}},{"type":"email","position":"left","identify":"email","label":"Email","instruction":"","options":{"label":"Email","instruction":"","required":"1","noDuplicates":0,"size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_181757"}},{"type":"address","position":"left","identify":"address","label":"Address","instruction":"","options":{"label":"Address","instruction":"","required":"1","country":[{"text":"Afghanistan","checked":true},{"text":"Albania","checked":false},{"text":"Algeria","checked":false},{"text":"Andorra","checked":false},{"text":"Angola","checked":false},{"text":"Antigua and Barbuda","checked":false},{"text":"Argentina","checked":false},{"text":"Armenia","checked":false},{"text":"Australia","checked":false},{"text":"Austria","checked":false},{"text":"Azerbaijan","checked":false},{"text":"Bahamas","checked":false},{"text":"Bahrain","checked":false},{"text":"Bangladesh","checked":false},{"text":"Barbados","checked":false},{"text":"Belarus","checked":false},{"text":"Belgium","checked":false},{"text":"Belize","checked":false},{"text":"Benin","checked":false},{"text":"Bhutan","checked":false},{"text":"Bolivia","checked":false},{"text":"Bosnia and Herzegovina","checked":false},{"text":"Botswana","checked":false},{"text":"Brazil","checked":false},{"text":"Brunei","checked":false},{"text":"Bulgaria","checked":false},{"text":"Burkina Faso","checked":false},{"text":"Burundi","checked":false},{"text":"Cambodia","checked":false},{"text":"Cameroon","checked":false},{"text":"Canada","checked":false},{"text":"Cape Verde","checked":false},{"text":"Central African Republic","checked":false},{"text":"Chad","checked":false},{"text":"Chile","checked":false},{"text":"China","checked":false},{"text":"Colombi","checked":false},{"text":"Comoros","checked":false},{"text":"Congo (Brazzaville)","checked":false},{"text":"Congo","checked":false},{"text":"Costa Rica","checked":false},{"text":"Cote d\'Ivoire","checked":false},{"text":"Croatia","checked":false},{"text":"Cuba","checked":false},{"text":"Cyprus","checked":false},{"text":"Czech Republic","checked":false},{"text":"Denmark","checked":false},{"text":"Djibouti","checked":false},{"text":"Dominica","checked":false},{"text":"Dominican Republic","checked":false},{"text":"East Timor (Timor Timur)","checked":false},{"text":"Ecuador","checked":false},{"text":"Egypt","checked":false},{"text":"El Salvador","checked":false},{"text":"Equatorial Guinea","checked":false},{"text":"Eritrea","checked":false},{"text":"Estonia","checked":false},{"text":"Ethiopia","checked":false},{"text":"Fiji","checked":false},{"text":"Finland","checked":false},{"text":"France","checked":false},{"text":"Gabon","checked":false},{"text":"Gambia, The","checked":false},{"text":"Georgia","checked":false},{"text":"Germany","checked":false},{"text":"Ghana","checked":false},{"text":"Greece","checked":false},{"text":"Grenada","checked":false},{"text":"Guatemala","checked":false},{"text":"Guinea","checked":false},{"text":"Guinea-Bissau","checked":false},{"text":"Guyana","checked":false},{"text":"Haiti","checked":false},{"text":"Honduras","checked":false},{"text":"Hungary","checked":false},{"text":"Iceland","checked":false},{"text":"India","checked":false},{"text":"Indonesia","checked":false},{"text":"Iran","checked":false},{"text":"Iraq","checked":false},{"text":"Ireland","checked":false},{"text":"Israel","checked":false},{"text":"Italy","checked":false},{"text":"Jamaica","checked":false},{"text":"Japan","checked":false},{"text":"Jordan","checked":false},{"text":"Kazakhstan","checked":false},{"text":"Kenya","checked":false},{"text":"Kiribati","checked":false},{"text":"Korea, North","checked":false},{"text":"Korea, South","checked":false},{"text":"Kuwait","checked":false},{"text":"Kyrgyzstan","checked":false},{"text":"Laos","checked":false},{"text":"Latvia","checked":false},{"text":"Lebanon","checked":false},{"text":"Lesotho","checked":false},{"text":"Liberia","checked":false},{"text":"Libya","checked":false},{"text":"Liechtenstein","checked":false},{"text":"Lithuania","checked":false},{"text":"Luxembourg","checked":false},{"text":"Macedonia","checked":false},{"text":"Madagascar","checked":false},{"text":"Malawi","checked":false},{"text":"Malaysia","checked":false},{"text":"Maldives","checked":false},{"text":"Mali","checked":false},{"text":"Malta","checked":false},{"text":"Marshall Islands","checked":false},{"text":"Mauritania","checked":false},{"text":"Mauritius","checked":false},{"text":"Mexico","checked":false},{"text":"Micronesia","checked":false},{"text":"Moldova","checked":false},{"text":"Monaco","checked":false},{"text":"Mongolia","checked":false},{"text":"Morocco","checked":false},{"text":"Mozambique","checked":false},{"text":"Myanmar","checked":false},{"text":"Namibia","checked":false},{"text":"Nauru","checked":false},{"text":"Nepa","checked":false},{"text":"Netherlands","checked":false},{"text":"New Zealand","checked":false},{"text":"Nicaragua","checked":false},{"text":"Niger","checked":false},{"text":"Nigeria","checked":false},{"text":"Norway","checked":false},{"text":"Oman","checked":false},{"text":"Pakistan","checked":false},{"text":"Palau","checked":false},{"text":"Panama","checked":false},{"text":"Papua New Guinea","checked":false},{"text":"Paraguay","checked":false},{"text":"Peru","checked":false},{"text":"Philippines","checked":false},{"text":"Poland","checked":false},{"text":"Portugal","checked":false},{"text":"Qatar","checked":false},{"text":"Romania","checked":false},{"text":"Russia","checked":false},{"text":"Rwanda","checked":false},{"text":"Saint Kitts and Nevis","checked":false},{"text":"Saint Lucia","checked":false},{"text":"Saint Vincent","checked":false},{"text":"Samoa","checked":false},{"text":"San Marino","checked":false},{"text":"Sao Tome and Principe","checked":false},{"text":"Saudi Arabia","checked":false},{"text":"Senegal","checked":false},{"text":"Serbia and Montenegro","checked":false},{"text":"Seychelles","checked":false},{"text":"Sierra Leone","checked":false},{"text":"Singapore","checked":false},{"text":"Slovakia","checked":false},{"text":"Slovenia","checked":false},{"text":"Solomon Islands","checked":false},{"text":"Somalia","checked":false},{"text":"South Africa","checked":false},{"text":"Spain","checked":false},{"text":"Sri Lanka","checked":false},{"text":"Sudan","checked":false},{"text":"Suriname","checked":false},{"text":"Swaziland","checked":false},{"text":"Sweden","checked":false},{"text":"Switzerland","checked":false},{"text":"Syria","checked":false},{"text":"Taiwan","checked":false},{"text":"Tajikistan","checked":false},{"text":"Tanzania","checked":false},{"text":"Thailand","checked":false},{"text":"Togo","checked":false},{"text":"Tonga","checked":false},{"text":"Trinidad and Tobago","checked":false},{"text":"Tunisia","checked":false},{"text":"Turkey","checked":false},{"text":"Turkmenistan","checked":false},{"text":"Tuvalu","checked":false},{"text":"Uganda","checked":false},{"text":"Ukraine","checked":false},{"text":"United Arab Emirates","checked":false},{"text":"United Kingdom","checked":false},{"text":"United States","checked":false},{"text":"Uruguay","checked":false},{"text":"Uzbekistan","checked":false},{"text":"Vanuatu","checked":false},{"text":"Vatican City","checked":false},{"text":"Venezuela","checked":false},{"text":"Vietnam","checked":false},{"text":"Yemen","checked":false},{"text":"Zambia","checked":false},{"text":"Zimbabwe","checked":false}],"identify":"jsn_tmp_746859"}},{"type":"website","position":"left","identify":"website","label":"Website","instruction":"","options":{"label":"Website","instruction":"","required":0,"noDuplicates":0,"size":"jsn-input-medium-fluid","value":"http:\/\/","identify":"jsn_tmp_269016"}},{"type":"single-line-text","position":"left","identify":"company","label":"Company","instruction":"","options":{"label":"Company","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"limitType":"Words","size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_383883"}},{"type":"single-line-text","position":"left","identify":"message_subject","label":"Message Subject","instruction":"","options":{"label":"Message Subject","instruction":"","required":"1","limitation":0,"limitMin":0,"limitMax":0,"limitType":"Words","size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_938869"}},{"type":"paragraph-text","position":"left","identify":"message","label":"Message","instruction":"","options":{"label":"Message","instruction":"","required":"1","limitation":0,"limitMin":0,"limitMax":0,"rows":"8","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_15779"}},{"type":"file-upload","position":"left","identify":"attached_file","label":"Attached File","instruction":"","options":{"label":"Attached File","instruction":"","required":0,"allowedExtensions":"png,jpg,gif,zip,rar,txt,doc,pdf","maxSize":0,"maxSizeUnit":"KB","identify":"jsn_tmp_851365"}}]';
				break;
			case 'Customer Feedback':
				return '[{"type":"name","position":"left","identify":"name","label":"Name","instruction":"","options":{"label":"Name","instruction":"","required":"1","format":"Normal","items":[{"text":"Mrs","checked":false},{"text":"Mr","checked":true},{"text":"Ms","checked":false},{"text":"Baby","checked":false},{"text":"Master","checked":false},{"text":"Prof","checked":false},{"text":"Dr","checked":false},{"text":"Gen","checked":false},{"text":"Rep","checked":false},{"text":"Sen","checked":false},{"text":"St","checked":false}],"identify":"jsn_tmp_859991"}},{"type":"email","position":"left","identify":"email","label":"Email","instruction":"","options":{"label":"Email","instruction":"","required":"1","noDuplicates":0,"size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_600109"}},{"type":"address","position":"left","identify":"address","label":"Address","instruction":"","options":{"label":"Address","instruction":"","required":0,"country":[{"text":"Afghanistan","checked":true},{"text":"Albania","checked":false},{"text":"Algeria","checked":false},{"text":"Andorra","checked":false},{"text":"Angola","checked":false},{"text":"Antigua and Barbuda","checked":false},{"text":"Argentina","checked":false},{"text":"Armenia","checked":false},{"text":"Australia","checked":false},{"text":"Austria","checked":false},{"text":"Azerbaijan","checked":false},{"text":"Bahamas","checked":false},{"text":"Bahrain","checked":false},{"text":"Bangladesh","checked":false},{"text":"Barbados","checked":false},{"text":"Belarus","checked":false},{"text":"Belgium","checked":false},{"text":"Belize","checked":false},{"text":"Benin","checked":false},{"text":"Bhutan","checked":false},{"text":"Bolivia","checked":false},{"text":"Bosnia and Herzegovina","checked":false},{"text":"Botswana","checked":false},{"text":"Brazil","checked":false},{"text":"Brunei","checked":false},{"text":"Bulgaria","checked":false},{"text":"Burkina Faso","checked":false},{"text":"Burundi","checked":false},{"text":"Cambodia","checked":false},{"text":"Cameroon","checked":false},{"text":"Canada","checked":false},{"text":"Cape Verde","checked":false},{"text":"Central African Republic","checked":false},{"text":"Chad","checked":false},{"text":"Chile","checked":false},{"text":"China","checked":false},{"text":"Colombi","checked":false},{"text":"Comoros","checked":false},{"text":"Congo (Brazzaville)","checked":false},{"text":"Congo","checked":false},{"text":"Costa Rica","checked":false},{"text":"Cote d\'Ivoire","checked":false},{"text":"Croatia","checked":false},{"text":"Cuba","checked":false},{"text":"Cyprus","checked":false},{"text":"Czech Republic","checked":false},{"text":"Denmark","checked":false},{"text":"Djibouti","checked":false},{"text":"Dominica","checked":false},{"text":"Dominican Republic","checked":false},{"text":"East Timor (Timor Timur)","checked":false},{"text":"Ecuador","checked":false},{"text":"Egypt","checked":false},{"text":"El Salvador","checked":false},{"text":"Equatorial Guinea","checked":false},{"text":"Eritrea","checked":false},{"text":"Estonia","checked":false},{"text":"Ethiopia","checked":false},{"text":"Fiji","checked":false},{"text":"Finland","checked":false},{"text":"France","checked":false},{"text":"Gabon","checked":false},{"text":"Gambia, The","checked":false},{"text":"Georgia","checked":false},{"text":"Germany","checked":false},{"text":"Ghana","checked":false},{"text":"Greece","checked":false},{"text":"Grenada","checked":false},{"text":"Guatemala","checked":false},{"text":"Guinea","checked":false},{"text":"Guinea-Bissau","checked":false},{"text":"Guyana","checked":false},{"text":"Haiti","checked":false},{"text":"Honduras","checked":false},{"text":"Hungary","checked":false},{"text":"Iceland","checked":false},{"text":"India","checked":false},{"text":"Indonesia","checked":false},{"text":"Iran","checked":false},{"text":"Iraq","checked":false},{"text":"Ireland","checked":false},{"text":"Israel","checked":false},{"text":"Italy","checked":false},{"text":"Jamaica","checked":false},{"text":"Japan","checked":false},{"text":"Jordan","checked":false},{"text":"Kazakhstan","checked":false},{"text":"Kenya","checked":false},{"text":"Kiribati","checked":false},{"text":"Korea, North","checked":false},{"text":"Korea, South","checked":false},{"text":"Kuwait","checked":false},{"text":"Kyrgyzstan","checked":false},{"text":"Laos","checked":false},{"text":"Latvia","checked":false},{"text":"Lebanon","checked":false},{"text":"Lesotho","checked":false},{"text":"Liberia","checked":false},{"text":"Libya","checked":false},{"text":"Liechtenstein","checked":false},{"text":"Lithuania","checked":false},{"text":"Luxembourg","checked":false},{"text":"Macedonia","checked":false},{"text":"Madagascar","checked":false},{"text":"Malawi","checked":false},{"text":"Malaysia","checked":false},{"text":"Maldives","checked":false},{"text":"Mali","checked":false},{"text":"Malta","checked":false},{"text":"Marshall Islands","checked":false},{"text":"Mauritania","checked":false},{"text":"Mauritius","checked":false},{"text":"Mexico","checked":false},{"text":"Micronesia","checked":false},{"text":"Moldova","checked":false},{"text":"Monaco","checked":false},{"text":"Mongolia","checked":false},{"text":"Morocco","checked":false},{"text":"Mozambique","checked":false},{"text":"Myanmar","checked":false},{"text":"Namibia","checked":false},{"text":"Nauru","checked":false},{"text":"Nepa","checked":false},{"text":"Netherlands","checked":false},{"text":"New Zealand","checked":false},{"text":"Nicaragua","checked":false},{"text":"Niger","checked":false},{"text":"Nigeria","checked":false},{"text":"Norway","checked":false},{"text":"Oman","checked":false},{"text":"Pakistan","checked":false},{"text":"Palau","checked":false},{"text":"Panama","checked":false},{"text":"Papua New Guinea","checked":false},{"text":"Paraguay","checked":false},{"text":"Peru","checked":false},{"text":"Philippines","checked":false},{"text":"Poland","checked":false},{"text":"Portugal","checked":false},{"text":"Qatar","checked":false},{"text":"Romania","checked":false},{"text":"Russia","checked":false},{"text":"Rwanda","checked":false},{"text":"Saint Kitts and Nevis","checked":false},{"text":"Saint Lucia","checked":false},{"text":"Saint Vincent","checked":false},{"text":"Samoa","checked":false},{"text":"San Marino","checked":false},{"text":"Sao Tome and Principe","checked":false},{"text":"Saudi Arabia","checked":false},{"text":"Senegal","checked":false},{"text":"Serbia and Montenegro","checked":false},{"text":"Seychelles","checked":false},{"text":"Sierra Leone","checked":false},{"text":"Singapore","checked":false},{"text":"Slovakia","checked":false},{"text":"Slovenia","checked":false},{"text":"Solomon Islands","checked":false},{"text":"Somalia","checked":false},{"text":"South Africa","checked":false},{"text":"Spain","checked":false},{"text":"Sri Lanka","checked":false},{"text":"Sudan","checked":false},{"text":"Suriname","checked":false},{"text":"Swaziland","checked":false},{"text":"Sweden","checked":false},{"text":"Switzerland","checked":false},{"text":"Syria","checked":false},{"text":"Taiwan","checked":false},{"text":"Tajikistan","checked":false},{"text":"Tanzania","checked":false},{"text":"Thailand","checked":false},{"text":"Togo","checked":false},{"text":"Tonga","checked":false},{"text":"Trinidad and Tobago","checked":false},{"text":"Tunisia","checked":false},{"text":"Turkey","checked":false},{"text":"Turkmenistan","checked":false},{"text":"Tuvalu","checked":false},{"text":"Uganda","checked":false},{"text":"Ukraine","checked":false},{"text":"United Arab Emirates","checked":false},{"text":"United Kingdom","checked":false},{"text":"United States","checked":false},{"text":"Uruguay","checked":false},{"text":"Uzbekistan","checked":false},{"text":"Vanuatu","checked":false},{"text":"Vatican City","checked":false},{"text":"Venezuela","checked":false},{"text":"Vietnam","checked":false},{"text":"Yemen","checked":false},{"text":"Zambia","checked":false},{"text":"Zimbabwe","checked":false}],"identify":"jsn_tmp_319579"}},{"type":"single-line-text","position":"left","identify":"company","label":"Company","instruction":"","options":{"label":"Company","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"limitType":"Words","size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_437796"}},{"type":"choices","position":"left","identify":"how_would_you_rate_our_customer_support_","label":"How would you rate our customer support?","instruction":"","options":{"label":"How would you rate our customer support?","instruction":"","required":0,"randomize":0,"layout":"jsn-columns-count-one","items":[{"text":"Excellent","checked":false},{"text":"Good","checked":false},{"text":"Fair","checked":false},{"text":"Poor","checked":false},{"text":"Terrible","checked":false}],"value":"","identify":"jsn_tmp_226978"}},{"type":"paragraph-text","position":"left","identify":"feedback","label":"Feedback","instruction":"","options":{"label":"Feedback","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"8","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_750906"}}]';
				break;
			case 'Job Application':
				return '[{"type":"name","position":"left","identify":"name","label":"Name","instruction":"","options":{"label":"Name","instruction":"","required":"1","format":"Extended","items":[{"text":"Mrs","checked":false},{"text":"Mr","checked":true},{"text":"Ms","checked":false},{"text":"Baby","checked":false},{"text":"Master","checked":false},{"text":"Prof","checked":false},{"text":"Dr","checked":false},{"text":"Gen","checked":false},{"text":"Rep","checked":false},{"text":"Sen","checked":false},{"text":"St","checked":false}],"identify":"jsn_tmp_484544"}},{"type":"choices","position":"left","identify":"gender","label":"Gender","instruction":"","options":{"label":"Gender","instruction":"","required":"1","randomize":0,"layout":"jsn-columns-count-no","items":[{"text":"Male","checked":false},{"text":"Female","checked":false}],"value":"","identify":"jsn_tmp_709858"}},{"type":"date","position":"left","identify":"date_of_birth","label":"Date of Birth","instruction":"","options":{"label":"Date of Birth","instruction":"","required":"1","enableRageSelection":0,"size":"jsn-input-small-fluid","timeFormat":0,"dateFormat":"1","identify":"jsn_tmp_480445","dateValue":"","dateValueRange":"","dateOptionFormat":"mm\/dd\/yy","timeOptionFormat":"hh:mm tt"}},{"type":"email","position":"left","identify":"email","label":"Email","instruction":"","options":{"label":"Email","instruction":"","required":"1","noDuplicates":0,"size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_351177"}},{"type":"phone","position":"left","identify":"phone","label":"Phone","instruction":"","options":{"label":"Phone","instruction":"","required":0,"format":"1-field","value":"","identify":"jsn_tmp_324795","oneField":"","twoField":"","threeField":""}},{"type":"address","position":"left","identify":"address","label":"Address","instruction":"","options":{"label":"Address","instruction":"","required":0,"country":[{"text":"Afghanistan","checked":true},{"text":"Albania","checked":false},{"text":"Algeria","checked":false},{"text":"Andorra","checked":false},{"text":"Angola","checked":false},{"text":"Antigua and Barbuda","checked":false},{"text":"Argentina","checked":false},{"text":"Armenia","checked":false},{"text":"Australia","checked":false},{"text":"Austria","checked":false},{"text":"Azerbaijan","checked":false},{"text":"Bahamas","checked":false},{"text":"Bahrain","checked":false},{"text":"Bangladesh","checked":false},{"text":"Barbados","checked":false},{"text":"Belarus","checked":false},{"text":"Belgium","checked":false},{"text":"Belize","checked":false},{"text":"Benin","checked":false},{"text":"Bhutan","checked":false},{"text":"Bolivia","checked":false},{"text":"Bosnia and Herzegovina","checked":false},{"text":"Botswana","checked":false},{"text":"Brazil","checked":false},{"text":"Brunei","checked":false},{"text":"Bulgaria","checked":false},{"text":"Burkina Faso","checked":false},{"text":"Burundi","checked":false},{"text":"Cambodia","checked":false},{"text":"Cameroon","checked":false},{"text":"Canada","checked":false},{"text":"Cape Verde","checked":false},{"text":"Central African Republic","checked":false},{"text":"Chad","checked":false},{"text":"Chile","checked":false},{"text":"China","checked":false},{"text":"Colombi","checked":false},{"text":"Comoros","checked":false},{"text":"Congo (Brazzaville)","checked":false},{"text":"Congo","checked":false},{"text":"Costa Rica","checked":false},{"text":"Cote d\'Ivoire","checked":false},{"text":"Croatia","checked":false},{"text":"Cuba","checked":false},{"text":"Cyprus","checked":false},{"text":"Czech Republic","checked":false},{"text":"Denmark","checked":false},{"text":"Djibouti","checked":false},{"text":"Dominica","checked":false},{"text":"Dominican Republic","checked":false},{"text":"East Timor (Timor Timur)","checked":false},{"text":"Ecuador","checked":false},{"text":"Egypt","checked":false},{"text":"El Salvador","checked":false},{"text":"Equatorial Guinea","checked":false},{"text":"Eritrea","checked":false},{"text":"Estonia","checked":false},{"text":"Ethiopia","checked":false},{"text":"Fiji","checked":false},{"text":"Finland","checked":false},{"text":"France","checked":false},{"text":"Gabon","checked":false},{"text":"Gambia, The","checked":false},{"text":"Georgia","checked":false},{"text":"Germany","checked":false},{"text":"Ghana","checked":false},{"text":"Greece","checked":false},{"text":"Grenada","checked":false},{"text":"Guatemala","checked":false},{"text":"Guinea","checked":false},{"text":"Guinea-Bissau","checked":false},{"text":"Guyana","checked":false},{"text":"Haiti","checked":false},{"text":"Honduras","checked":false},{"text":"Hungary","checked":false},{"text":"Iceland","checked":false},{"text":"India","checked":false},{"text":"Indonesia","checked":false},{"text":"Iran","checked":false},{"text":"Iraq","checked":false},{"text":"Ireland","checked":false},{"text":"Israel","checked":false},{"text":"Italy","checked":false},{"text":"Jamaica","checked":false},{"text":"Japan","checked":false},{"text":"Jordan","checked":false},{"text":"Kazakhstan","checked":false},{"text":"Kenya","checked":false},{"text":"Kiribati","checked":false},{"text":"Korea, North","checked":false},{"text":"Korea, South","checked":false},{"text":"Kuwait","checked":false},{"text":"Kyrgyzstan","checked":false},{"text":"Laos","checked":false},{"text":"Latvia","checked":false},{"text":"Lebanon","checked":false},{"text":"Lesotho","checked":false},{"text":"Liberia","checked":false},{"text":"Libya","checked":false},{"text":"Liechtenstein","checked":false},{"text":"Lithuania","checked":false},{"text":"Luxembourg","checked":false},{"text":"Macedonia","checked":false},{"text":"Madagascar","checked":false},{"text":"Malawi","checked":false},{"text":"Malaysia","checked":false},{"text":"Maldives","checked":false},{"text":"Mali","checked":false},{"text":"Malta","checked":false},{"text":"Marshall Islands","checked":false},{"text":"Mauritania","checked":false},{"text":"Mauritius","checked":false},{"text":"Mexico","checked":false},{"text":"Micronesia","checked":false},{"text":"Moldova","checked":false},{"text":"Monaco","checked":false},{"text":"Mongolia","checked":false},{"text":"Morocco","checked":false},{"text":"Mozambique","checked":false},{"text":"Myanmar","checked":false},{"text":"Namibia","checked":false},{"text":"Nauru","checked":false},{"text":"Nepa","checked":false},{"text":"Netherlands","checked":false},{"text":"New Zealand","checked":false},{"text":"Nicaragua","checked":false},{"text":"Niger","checked":false},{"text":"Nigeria","checked":false},{"text":"Norway","checked":false},{"text":"Oman","checked":false},{"text":"Pakistan","checked":false},{"text":"Palau","checked":false},{"text":"Panama","checked":false},{"text":"Papua New Guinea","checked":false},{"text":"Paraguay","checked":false},{"text":"Peru","checked":false},{"text":"Philippines","checked":false},{"text":"Poland","checked":false},{"text":"Portugal","checked":false},{"text":"Qatar","checked":false},{"text":"Romania","checked":false},{"text":"Russia","checked":false},{"text":"Rwanda","checked":false},{"text":"Saint Kitts and Nevis","checked":false},{"text":"Saint Lucia","checked":false},{"text":"Saint Vincent","checked":false},{"text":"Samoa","checked":false},{"text":"San Marino","checked":false},{"text":"Sao Tome and Principe","checked":false},{"text":"Saudi Arabia","checked":false},{"text":"Senegal","checked":false},{"text":"Serbia and Montenegro","checked":false},{"text":"Seychelles","checked":false},{"text":"Sierra Leone","checked":false},{"text":"Singapore","checked":false},{"text":"Slovakia","checked":false},{"text":"Slovenia","checked":false},{"text":"Solomon Islands","checked":false},{"text":"Somalia","checked":false},{"text":"South Africa","checked":false},{"text":"Spain","checked":false},{"text":"Sri Lanka","checked":false},{"text":"Sudan","checked":false},{"text":"Suriname","checked":false},{"text":"Swaziland","checked":false},{"text":"Sweden","checked":false},{"text":"Switzerland","checked":false},{"text":"Syria","checked":false},{"text":"Taiwan","checked":false},{"text":"Tajikistan","checked":false},{"text":"Tanzania","checked":false},{"text":"Thailand","checked":false},{"text":"Togo","checked":false},{"text":"Tonga","checked":false},{"text":"Trinidad and Tobago","checked":false},{"text":"Tunisia","checked":false},{"text":"Turkey","checked":false},{"text":"Turkmenistan","checked":false},{"text":"Tuvalu","checked":false},{"text":"Uganda","checked":false},{"text":"Ukraine","checked":false},{"text":"United Arab Emirates","checked":false},{"text":"United Kingdom","checked":false},{"text":"United States","checked":false},{"text":"Uruguay","checked":false},{"text":"Uzbekistan","checked":false},{"text":"Vanuatu","checked":false},{"text":"Vatican City","checked":false},{"text":"Venezuela","checked":false},{"text":"Vietnam","checked":false},{"text":"Yemen","checked":false},{"text":"Zambia","checked":false},{"text":"Zimbabwe","checked":false}],"identify":"jsn_tmp_840267"}},{"type":"paragraph-text","position":"left","identify":"which_position_are_you_applying_for_","label":"Which position are you applying for?","instruction":"","options":{"label":"Which position are you applying for?","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"3","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_849757"}},{"type":"paragraph-text","position":"left","identify":"are_you_willing_to_relocate_","label":"Are you willing to relocate?","instruction":"","options":{"label":"Are you willing to relocate?","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"3","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_30786"}},{"type":"paragraph-text","position":"left","identify":"when_can_you_start_","label":"When can you start?","instruction":"","options":{"label":"When can you start?","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"3","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_221957"}},{"type":"paragraph-text","position":"left","identify":"portfolio_web_site","label":"Portfolio Web Site","instruction":"","options":{"label":"Portfolio Web Site","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"3","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_275768"}},{"type":"paragraph-text","position":"left","identify":"salary_requirement","label":"Salary Requirement","instruction":"","options":{"label":"Salary Requirement","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"3","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_457473"}},{"type":"file-upload","position":"left","identify":"resume_or_cv","label":"Resume or CV","instruction":"","options":{"label":"Resume or CV","instruction":"","required":0,"allowedExtensions":"png,jpg,gif,zip,rar,txt,doc,pdf","maxSize":0,"maxSizeUnit":"KB","identify":"jsn_tmp_727578"}}]';
				break;
			case 'Event Registration':
				return '[{"type":"number","position":"left","identify":"number_of_attendance","label":"Number of Attendance","instruction":"","options":{"label":"Number of Attendance","instruction":"","required":"1","limitation":0,"limitMin":0,"limitMax":0,"size":"jsn-input-small-fluid","value":"","identify":"jsn_tmp_841112"}},{"type":"name","position":"left","identify":"name","label":"Name","instruction":"","options":{"label":"Name","instruction":"","required":"1","format":"Extended","items":[{"text":"Mrs","checked":false},{"text":"Mr","checked":true},{"text":"Ms","checked":false},{"text":"Baby","checked":false},{"text":"Master","checked":false},{"text":"Prof","checked":false},{"text":"Dr","checked":false},{"text":"Gen","checked":false},{"text":"Rep","checked":false},{"text":"Sen","checked":false},{"text":"St","checked":false}],"identify":"jsn_tmp_676286"}},{"type":"address","position":"left","identify":"address","label":"Address","instruction":"","options":{"label":"Address","instruction":"","required":"1","country":[{"text":"Afghanistan","checked":true},{"text":"Albania","checked":false},{"text":"Algeria","checked":false},{"text":"Andorra","checked":false},{"text":"Angola","checked":false},{"text":"Antigua and Barbuda","checked":false},{"text":"Argentina","checked":false},{"text":"Armenia","checked":false},{"text":"Australia","checked":false},{"text":"Austria","checked":false},{"text":"Azerbaijan","checked":false},{"text":"Bahamas","checked":false},{"text":"Bahrain","checked":false},{"text":"Bangladesh","checked":false},{"text":"Barbados","checked":false},{"text":"Belarus","checked":false},{"text":"Belgium","checked":false},{"text":"Belize","checked":false},{"text":"Benin","checked":false},{"text":"Bhutan","checked":false},{"text":"Bolivia","checked":false},{"text":"Bosnia and Herzegovina","checked":false},{"text":"Botswana","checked":false},{"text":"Brazil","checked":false},{"text":"Brunei","checked":false},{"text":"Bulgaria","checked":false},{"text":"Burkina Faso","checked":false},{"text":"Burundi","checked":false},{"text":"Cambodia","checked":false},{"text":"Cameroon","checked":false},{"text":"Canada","checked":false},{"text":"Cape Verde","checked":false},{"text":"Central African Republic","checked":false},{"text":"Chad","checked":false},{"text":"Chile","checked":false},{"text":"China","checked":false},{"text":"Colombi","checked":false},{"text":"Comoros","checked":false},{"text":"Congo (Brazzaville)","checked":false},{"text":"Congo","checked":false},{"text":"Costa Rica","checked":false},{"text":"Cote d\'Ivoire","checked":false},{"text":"Croatia","checked":false},{"text":"Cuba","checked":false},{"text":"Cyprus","checked":false},{"text":"Czech Republic","checked":false},{"text":"Denmark","checked":false},{"text":"Djibouti","checked":false},{"text":"Dominica","checked":false},{"text":"Dominican Republic","checked":false},{"text":"East Timor (Timor Timur)","checked":false},{"text":"Ecuador","checked":false},{"text":"Egypt","checked":false},{"text":"El Salvador","checked":false},{"text":"Equatorial Guinea","checked":false},{"text":"Eritrea","checked":false},{"text":"Estonia","checked":false},{"text":"Ethiopia","checked":false},{"text":"Fiji","checked":false},{"text":"Finland","checked":false},{"text":"France","checked":false},{"text":"Gabon","checked":false},{"text":"Gambia, The","checked":false},{"text":"Georgia","checked":false},{"text":"Germany","checked":false},{"text":"Ghana","checked":false},{"text":"Greece","checked":false},{"text":"Grenada","checked":false},{"text":"Guatemala","checked":false},{"text":"Guinea","checked":false},{"text":"Guinea-Bissau","checked":false},{"text":"Guyana","checked":false},{"text":"Haiti","checked":false},{"text":"Honduras","checked":false},{"text":"Hungary","checked":false},{"text":"Iceland","checked":false},{"text":"India","checked":false},{"text":"Indonesia","checked":false},{"text":"Iran","checked":false},{"text":"Iraq","checked":false},{"text":"Ireland","checked":false},{"text":"Israel","checked":false},{"text":"Italy","checked":false},{"text":"Jamaica","checked":false},{"text":"Japan","checked":false},{"text":"Jordan","checked":false},{"text":"Kazakhstan","checked":false},{"text":"Kenya","checked":false},{"text":"Kiribati","checked":false},{"text":"Korea, North","checked":false},{"text":"Korea, South","checked":false},{"text":"Kuwait","checked":false},{"text":"Kyrgyzstan","checked":false},{"text":"Laos","checked":false},{"text":"Latvia","checked":false},{"text":"Lebanon","checked":false},{"text":"Lesotho","checked":false},{"text":"Liberia","checked":false},{"text":"Libya","checked":false},{"text":"Liechtenstein","checked":false},{"text":"Lithuania","checked":false},{"text":"Luxembourg","checked":false},{"text":"Macedonia","checked":false},{"text":"Madagascar","checked":false},{"text":"Malawi","checked":false},{"text":"Malaysia","checked":false},{"text":"Maldives","checked":false},{"text":"Mali","checked":false},{"text":"Malta","checked":false},{"text":"Marshall Islands","checked":false},{"text":"Mauritania","checked":false},{"text":"Mauritius","checked":false},{"text":"Mexico","checked":false},{"text":"Micronesia","checked":false},{"text":"Moldova","checked":false},{"text":"Monaco","checked":false},{"text":"Mongolia","checked":false},{"text":"Morocco","checked":false},{"text":"Mozambique","checked":false},{"text":"Myanmar","checked":false},{"text":"Namibia","checked":false},{"text":"Nauru","checked":false},{"text":"Nepa","checked":false},{"text":"Netherlands","checked":false},{"text":"New Zealand","checked":false},{"text":"Nicaragua","checked":false},{"text":"Niger","checked":false},{"text":"Nigeria","checked":false},{"text":"Norway","checked":false},{"text":"Oman","checked":false},{"text":"Pakistan","checked":false},{"text":"Palau","checked":false},{"text":"Panama","checked":false},{"text":"Papua New Guinea","checked":false},{"text":"Paraguay","checked":false},{"text":"Peru","checked":false},{"text":"Philippines","checked":false},{"text":"Poland","checked":false},{"text":"Portugal","checked":false},{"text":"Qatar","checked":false},{"text":"Romania","checked":false},{"text":"Russia","checked":false},{"text":"Rwanda","checked":false},{"text":"Saint Kitts and Nevis","checked":false},{"text":"Saint Lucia","checked":false},{"text":"Saint Vincent","checked":false},{"text":"Samoa","checked":false},{"text":"San Marino","checked":false},{"text":"Sao Tome and Principe","checked":false},{"text":"Saudi Arabia","checked":false},{"text":"Senegal","checked":false},{"text":"Serbia and Montenegro","checked":false},{"text":"Seychelles","checked":false},{"text":"Sierra Leone","checked":false},{"text":"Singapore","checked":false},{"text":"Slovakia","checked":false},{"text":"Slovenia","checked":false},{"text":"Solomon Islands","checked":false},{"text":"Somalia","checked":false},{"text":"South Africa","checked":false},{"text":"Spain","checked":false},{"text":"Sri Lanka","checked":false},{"text":"Sudan","checked":false},{"text":"Suriname","checked":false},{"text":"Swaziland","checked":false},{"text":"Sweden","checked":false},{"text":"Switzerland","checked":false},{"text":"Syria","checked":false},{"text":"Taiwan","checked":false},{"text":"Tajikistan","checked":false},{"text":"Tanzania","checked":false},{"text":"Thailand","checked":false},{"text":"Togo","checked":false},{"text":"Tonga","checked":false},{"text":"Trinidad and Tobago","checked":false},{"text":"Tunisia","checked":false},{"text":"Turkey","checked":false},{"text":"Turkmenistan","checked":false},{"text":"Tuvalu","checked":false},{"text":"Uganda","checked":false},{"text":"Ukraine","checked":false},{"text":"United Arab Emirates","checked":false},{"text":"United Kingdom","checked":false},{"text":"United States","checked":false},{"text":"Uruguay","checked":false},{"text":"Uzbekistan","checked":false},{"text":"Vanuatu","checked":false},{"text":"Vatican City","checked":false},{"text":"Venezuela","checked":false},{"text":"Vietnam","checked":false},{"text":"Yemen","checked":false},{"text":"Zambia","checked":false},{"text":"Zimbabwe","checked":false}],"identify":"jsn_tmp_885160"}},{"type":"email","position":"left","identify":"email","label":"Email","instruction":"","options":{"label":"Email","instruction":"","required":"1","noDuplicates":0,"size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_471658"}},{"type":"phone","position":"left","identify":"phone","label":"Phone","instruction":"","options":{"label":"Phone","instruction":"","required":0,"format":"1-field","value":"","identify":"jsn_tmp_978072","oneField":"","twoField":"","threeField":""}},{"type":"single-line-text","position":"left","identify":"company","label":"Company","instruction":"","options":{"label":"Company","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"limitType":"Words","size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_963935"}},{"type":"choices","position":"left","identify":"t_shirt_size","label":"T-Shirt Size","instruction":"","options":{"label":"T-Shirt Size","instruction":"","required":0,"randomize":0,"layout":"jsn-columns-count-three","items":[{"text":"S","checked":false},{"text":"M","checked":false},{"text":"L","checked":false},{"text":"XL","checked":false},{"text":"XXL","checked":false},{"text":"3XL","checked":false}],"value":"","identify":"jsn_tmp_41996"}},{"type":"paragraph-text","position":"left","identify":"message","label":"Message","instruction":"","options":{"label":"Message","instruction":"","required":0,"limitation":0,"limitMin":0,"limitMax":0,"rows":"8","size":"jsn-input-xlarge-fluid","limitType":"Words","value":"","identify":"jsn_tmp_496497"}}]';
				break;
			case 'Voting Form':
				return '[{"type":"name","position":"left","identify":"name","label":"Name","instruction":"","options":{"label":"Name","instruction":"","required":"1","format":"Extended","items":[{"text":"Mrs","checked":false},{"text":"Mr","checked":true},{"text":"Ms","checked":false},{"text":"Baby","checked":false},{"text":"Master","checked":false},{"text":"Prof","checked":false},{"text":"Dr","checked":false},{"text":"Gen","checked":false},{"text":"Rep","checked":false},{"text":"Sen","checked":false},{"text":"St","checked":false}],"identify":"jsn_tmp_83149"}},{type":"choices","position":"left","identify":"multiple_choice","label":"Multiple Choice","instruction":"","options":{"label":"Multiple Choice","instruction":"","required":"1","randomize":0,"layout":"jsn-columns-count-no","items":[{"text":"Male","checked":false},{"text":"Female","checked":false}],"value":"","identify":"jsn_tmp_580389"}},{"type":"date","position":"left","identify":"date_of_birth","label":"Date of Birth","instruction":"","options":{"label":"Date of Birth","instruction":"","required":0,"enableRageSelection":0,"size":"jsn-input-small-fluid","timeFormat":0,"dateFormat":"1","identify":"jsn_tmp_475674","dateValue":"","dateValueRange":"","dateOptionFormat":"mm\/dd\/yy","timeOptionFormat":"hh:mm tt"}},{"type":"email","position":"left","identify":"email","label":"Email","instruction":"","options":{"label":"Email","instruction":"","required":"1","noDuplicates":0,"size":"jsn-input-medium-fluid","value":"","identify":"jsn_tmp_458467"}},{"type":"address","position":"left","identify":"address","label":"Address","instruction":"","options":{"label":"Address","instruction":"","required":0,"country":[{"text":"Afghanistan","checked":true},{"text":"Albania","checked":false},{"text":"Algeria","checked":false},{"text":"Andorra","checked":false},{"text":"Angola","checked":false},{"text":"Antigua and Barbuda","checked":false},{"text":"Argentina","checked":false},{"text":"Armenia","checked":false},{"text":"Australia","checked":false},{"text":"Austria","checked":false},{"text":"Azerbaijan","checked":false},{"text":"Bahamas","checked":false},{"text":"Bahrain","checked":false},{"text":"Bangladesh","checked":false},{"text":"Barbados","checked":false},{"text":"Belarus","checked":false},{"text":"Belgium","checked":false},{"text":"Belize","checked":false},{"text":"Benin","checked":false},{"text":"Bhutan","checked":false},{"text":"Bolivia","checked":false},{"text":"Bosnia and Herzegovina","checked":false},{"text":"Botswana","checked":false},{"text":"Brazil","checked":false},{"text":"Brunei","checked":false},{"text":"Bulgaria","checked":false},{"text":"Burkina Faso","checked":false},{"text":"Burundi","checked":false},{"text":"Cambodia","checked":false},{"text":"Cameroon","checked":false},{"text":"Canada","checked":false},{"text":"Cape Verde","checked":false},{"text":"Central African Republic","checked":false},{"text":"Chad","checked":false},{"text":"Chile","checked":false},{"text":"China","checked":false},{"text":"Colombi","checked":false},{"text":"Comoros","checked":false},{"text":"Congo (Brazzaville)","checked":false},{"text":"Congo","checked":false},{"text":"Costa Rica","checked":false},{"text":"Cote d\'Ivoire","checked":false},{"text":"Croatia","checked":false},{"text":"Cuba","checked":false},{"text":"Cyprus","checked":false},{"text":"Czech Republic","checked":false},{"text":"Denmark","checked":false},{"text":"Djibouti","checked":false},{"text":"Dominica","checked":false},{"text":"Dominican Republic","checked":false},{"text":"East Timor (Timor Timur)","checked":false},{"text":"Ecuador","checked":false},{"text":"Egypt","checked":false},{"text":"El Salvador","checked":false},{"text":"Equatorial Guinea","checked":false},{"text":"Eritrea","checked":false},{"text":"Estonia","checked":false},{"text":"Ethiopia","checked":false},{"text":"Fiji","checked":false},{"text":"Finland","checked":false},{"text":"France","checked":false},{"text":"Gabon","checked":false},{"text":"Gambia, The","checked":false},{"text":"Georgia","checked":false},{"text":"Germany","checked":false},{"text":"Ghana","checked":false},{"text":"Greece","checked":false},{"text":"Grenada","checked":false},{"text":"Guatemala","checked":false},{"text":"Guinea","checked":false},{"text":"Guinea-Bissau","checked":false},{"text":"Guyana","checked":false},{"text":"Haiti","checked":false},{"text":"Honduras","checked":false},{"text":"Hungary","checked":false},{"text":"Iceland","checked":false},{"text":"India","checked":false},{"text":"Indonesia","checked":false},{"text":"Iran","checked":false},{"text":"Iraq","checked":false},{"text":"Ireland","checked":false},{"text":"Israel","checked":false},{"text":"Italy","checked":false},{"text":"Jamaica","checked":false},{"text":"Japan","checked":false},{"text":"Jordan","checked":false},{"text":"Kazakhstan","checked":false},{"text":"Kenya","checked":false},{"text":"Kiribati","checked":false},{"text":"Korea, North","checked":false},{"text":"Korea, South","checked":false},{"text":"Kuwait","checked":false},{"text":"Kyrgyzstan","checked":false},{"text":"Laos","checked":false},{"text":"Latvia","checked":false},{"text":"Lebanon","checked":false},{"text":"Lesotho","checked":false},{"text":"Liberia","checked":false},{"text":"Libya","checked":false},{"text":"Liechtenstein","checked":false},{"text":"Lithuania","checked":false},{"text":"Luxembourg","checked":false},{"text":"Macedonia","checked":false},{"text":"Madagascar","checked":false},{"text":"Malawi","checked":false},{"text":"Malaysia","checked":false},{"text":"Maldives","checked":false},{"text":"Mali","checked":false},{"text":"Malta","checked":false},{"text":"Marshall Islands","checked":false},{"text":"Mauritania","checked":false},{"text":"Mauritius","checked":false},{"text":"Mexico","checked":false},{"text":"Micronesia","checked":false},{"text":"Moldova","checked":false},{"text":"Monaco","checked":false},{"text":"Mongolia","checked":false},{"text":"Morocco","checked":false},{"text":"Mozambique","checked":false},{"text":"Myanmar","checked":false},{"text":"Namibia","checked":false},{"text":"Nauru","checked":false},{"text":"Nepa","checked":false},{"text":"Netherlands","checked":false},{"text":"New Zealand","checked":false},{"text":"Nicaragua","checked":false},{"text":"Niger","checked":false},{"text":"Nigeria","checked":false},{"text":"Norway","checked":false},{"text":"Oman","checked":false},{"text":"Pakistan","checked":false},{"text":"Palau","checked":false},{"text":"Panama","checked":false},{"text":"Papua New Guinea","checked":false},{"text":"Paraguay","checked":false},{"text":"Peru","checked":false},{"text":"Philippines","checked":false},{"text":"Poland","checked":false},{"text":"Portugal","checked":false},{"text":"Qatar","checked":false},{"text":"Romania","checked":false},{"text":"Russia","checked":false},{"text":"Rwanda","checked":false},{"text":"Saint Kitts and Nevis","checked":false},{"text":"Saint Lucia","checked":false},{"text":"Saint Vincent","checked":false},{"text":"Samoa","checked":false},{"text":"San Marino","checked":false},{"text":"Sao Tome and Principe","checked":false},{"text":"Saudi Arabia","checked":false},{"text":"Senegal","checked":false},{"text":"Serbia and Montenegro","checked":false},{"text":"Seychelles","checked":false},{"text":"Sierra Leone","checked":false},{"text":"Singapore","checked":false},{"text":"Slovakia","checked":false},{"text":"Slovenia","checked":false},{"text":"Solomon Islands","checked":false},{"text":"Somalia","checked":false},{"text":"South Africa","checked":false},{"text":"Spain","checked":false},{"text":"Sri Lanka","checked":false},{"text":"Sudan","checked":false},{"text":"Suriname","checked":false},{"text":"Swaziland","checked":false},{"text":"Sweden","checked":false},{"text":"Switzerland","checked":false},{"text":"Syria","checked":false},{"text":"Taiwan","checked":false},{"text":"Tajikistan","checked":false},{"text":"Tanzania","checked":false},{"text":"Thailand","checked":false},{"text":"Togo","checked":false},{"text":"Tonga","checked":false},{"text":"Trinidad and Tobago","checked":false},{"text":"Tunisia","checked":false},{"text":"Turkey","checked":false},{"text":"Turkmenistan","checked":false},{"text":"Tuvalu","checked":false},{"text":"Uganda","checked":false},{"text":"Ukraine","checked":false},{"text":"United Arab Emirates","checked":false},{"text":"United Kingdom","checked":false},{"text":"United States","checked":false},{"text":"Uruguay","checked":false},{"text":"Uzbekistan","checked":false},{"text":"Vanuatu","checked":false},{"text":"Vatican City","checked":false},{"text":"Venezuela","checked":false},{"text":"Vietnam","checked":false},{"text":"Yemen","checked":false},{"text":"Zambia","checked":false},{"text":"Zimbabwe","checked":false}],"identify":"jsn_tmp_538561"}},{"type":"phone","position":"left","identify":"phone","label":"Phone","instruction":"","options":{"label":"Phone","instruction":"","required":0,"format":"1-field","value":"","identify":"jsn_tmp_673980","oneField":"","twoField":"","threeField":""}},{"type":"choices","position":"left","identify":"overall_how_satisfied_were_you_with_the_product_service_","label":"Overall, how satisfied were you with the product \/ service? ","instruction":"","options":{"label":"Overall, how satisfied were you with the product \/ service? ","instruction":"","required":"1","randomize":0,"layout":"jsn-columns-count-one","items":[{"text":"Very Satisfied","checked":false},{"text":"Satisfied","checked":false},{"text":"Neutral","checked":false},{"text":"Unsatisfied","checked":false},{"text":"Very Unsatisfied","checked":false},{"text":"N\/A ","checked":false}],"value":"","identify":"jsn_tmp_921222"}}]';
				break;
		}

	}

	/**
	 * Get List Email Notification
	 *
	 * @param   type  $items  Items Email
	 *
	 * @return string
	 */
	public static function getListEmailNotification($items = array())
	{
		$html = '<div class="control-group jsn-items-list-container">
		    <label  class="control-label jsn-label-des-tipsy"  original-title="' . JText::_('JSN_UNIFORM_SPECIFY_EMAIL_ADDRESS') . '">' . JText::_('JSN_UNIFORM_SEND_EMAIL_TO') . '</label>
		    <div class="controls">
			<button class="btn btn-icon pull-right jsn-label-des-tipsy"  data-placement="top" id="btn_email_list" original-title="' . JText::_('JSN_UNIFORM_EMAIL_CONTENT') . '" title="' . JText::_('JSN_UNIFORM_EMAIL_CONTENT') . '" onclick="return false;"><i class="icon-envelope"></i></button>
			<div class="email-addresses">
			    <div id="emailAddresses" class="jsn-items-list ui-sortable">
			    ';
		$script = array();
		if (!empty($items) && count($items))
		{
			foreach ($items as $email)
			{
				if (!empty($email->email_address))
				{
					$script[] = "'" . $email->email_address . "'";
					$emailName = isset($email->email_name) ? $email->email_name : "";
					$emailUserId = isset($email->user_id) ? $email->user_id : "";
					$emailId = isset($email->email_id) ? $email->email_id : "";
					$html .= '<div class="jsn-item ui-state-default jsn-iconbar-trigger" data-email="' . $email->email_address . '" id="email_' . preg_replace('/[^a-zA-Z0-9-_]/i', "_", $email->email_address) . '">
					    <input type="hidden" value="' . $emailName . '" name="form_email_notification_name[' . $email->email_address . ']">
					    <input type="hidden" value="' . $emailId . '" name="semail_id[' . $email->email_address . ']">
					    <input type="hidden" value="' . $emailUserId . '" name="form_email_notification_user_id[' . $email->email_address . ']">
					    <input type="hidden" value="' . $email->email_address . '" name="form_email_notification[]">
					    <span class="email-address">' . $email->email_address . '</span>
					    <div class="jsn-iconbar">
						<a data-email="' . $email->email_address . '" class="element-edit" title="Edit email" href="javascript:void(0)"><i class="icon-pencil"></i></a>
						<a data-email="' . $email->email_address . '" class="element-delete" title="Delete email" href="javascript:void(0)"><i class="icon-trash"></i></a>
					    </div>
					</div>';
				}
			}
		}
		$html .= '<script> var listemail=[' . implode(",", $script) . '];</script>
			    </div>
			    <a href="#" onclick="return false;" id="show-div-add-email" class="jsn-add-more">' . JText::_('JSN_UNIFORM_ADD_MORE_EMAIL') . '</a>
			    <div id="addMoreEmail" class="jsn-form-bar">
				<div class="control-group input-append">
				    <input  name="nemail" class="input-medium" id="input_new_email" type="text">
				    <button class="btn" id="email-select" href="#myModal" onclick="return false;">' . JText::_('JSN_UNIFORM_EMAIL_SELECT') . '</button>
				</div>
				<div class="control-group">
				    <button class="btn btn-icon" onclick="return false;" id="add-email" title="' . JText::_('JSN_UNIFORM_BUTTON_SAVE') . '" ><i class="icon-ok"></i></button>
				    <button class="btn btn-icon"  onclick="return false;" id="close-email" title="' . JText::_('JSN_UNIFORM_BUTTON_CANCEL') . '"><i class="icon-remove"></i></button>
				</div>
				<div class="control-group"></div>
			    </div>
			</div>
		    </div>
		</div>';
		return $html;

	}

	/**
	 * Load Page Form
	 *
	 * @param   int     $formId    Form Id
	 * @param   String  $formName  Form Name
	 * @param   String  $formType  Form Type
	 *
	 * @return string
	 */
	public static function generateHTMLPages($formId, $formName, $formType = "")
	{
		$baseUrl = JURI::base(true);
		$html = "";
		// Load language
		$lang = JFactory::getLanguage();
		$lang->load('com_uniform');
		JSNHtmlAsset::addScriptPath('uniform', $baseUrl . '/components/com_uniform/assets/js');
		JSNHtmlAsset::addScriptPath('uniform/3rd', $baseUrl . '/components/com_uniform/assets/3rd-party');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-ui/css/ui-bootstrap/jquery-ui-1.9.0.custom.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/bootstrap/css/bootstrap.min.css');
		JSNHtmlAsset::addStyle(JSN_UNIFORM_ASSETS_URI . '/css/form.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/joomlashine/css/jsn-gui.css');
		JSNHtmlAsset::addStyle(JSN_URL_ASSETS . '/3rd-party/jquery-tipsy/tipsy.css');
		JSNHtmlAsset::addScript(JSN_URL_ASSETS . '/3rd-party/jquery/jquery-1.8.2.js');
		JSNHtmlAsset::addScript(JSN_UNIFORM_ASSETS_URI . '/js/jsn_uniform_noconflict.js');
		JSNHtmlAsset::addScriptLibrary('jquery.ui', '3rd-party/jquery-ui/js/jquery-ui-1.9.0.custom.min', array('jquery'));
		JSNHtmlAsset::registerDepends('uniform/libs/jquery.placeholder', array('jquery'));
		JSNHtmlAsset::registerDepends('uniform/libs/jquery-ui-timepicker-addon', array('jquery', 'jquery.ui'));
		$db = JFactory::getDBO();
		$db->setQuery($db->getQuery(true)->from('#__jsn_uniform_forms')->select('*')->where('form_id=' . (int) $formId));
		$items = $db->loadObject();

		$db->setQuery($db->getQuery(true)->from('#__jsn_uniform_form_pages')->select('*')->where('form_id=' . (int) $formId));
		$formPages = $db->loadObjectList();

		$settings = array('formName' => $formName, 'contentForm' => $formPages);
		$arrayTranslated = array('JSN_UNIFORM_CONFIRM_FIELD_MAX_LENGTH', 'JSN_UNIFORM_CONFIRM_FIELD_MIN_LENGTH', 'JSN_UNIFORM_CAPTCHA_PUBLICKEY', 'JSN_UNIFORM_BUTTON_BACK', 'JSN_UNIFORM_BUTTON_NEXT', 'JSN_UNIFORM_BUTTON_RESET', 'JSN_UNIFORM_BUTTON_SUBMIT', 'JSN_UNIFORM_CONFIRM_FIELD_CANNOT_EMPTY', 'JSN_UNIFORM_CONFIRM_FIELD_INVALID');
		if ($items)
		{
			$dataSumbission = '';
			$classForm = isset($items->form_style) ? $items->form_style : '';
			if ($formType != 'ajax')
			{
				$html .= "<div class=\"jsn-uniform jsn-master\"><div class=\"jsn-bootstrap\">";
				$html .= "<form name='form_{$formName}' action=\"" . JRoute::_('index.php?option=com_uniform&task=form.save&form_id=' . $items->form_id) . "\" method=\"post\" class=\"form-validate {$classForm}\" enctype=\"multipart/form-data\" >";
				$html .= "<div id=\"page-loading\" class=\"jsn-bgloading\"><i class=\"jsn-icon32 jsn-icon-loading\"></i></div>";
				$html .= "<div class=\"jsn-form-container {$items->form_theme}\">";
			}
			$html .= "<div class=\"message-uniform\"> </div>";
			foreach ($formPages as $i => $contentForm)
			{
				$formTemplate = isset($contentForm->page_template) ? json_decode($contentForm->page_template) : "";
				$htmlForm = "";
				if (!empty($formTemplate->dataField) && !empty($formTemplate->dataFormLayout))
				{
					$htmlForm .= JSNFormGenerateHelper::generate($formTemplate->dataField, $formTemplate->dataFormLayout, $dataSumbission);
				}
				$html .= "<div data-value=\"{$contentForm->page_id}\" class=\"jsn-form-content hide\">{$htmlForm}";
				if ($i + 1 == count($formPages))
				{
					if (!empty($items->form_captcha) && $items->form_captcha == 1)
					{
						$html .= "<script type=\"text/javascript\" src=\"http://api.recaptcha.net/js/recaptcha_ajax.js\"></script>";
						$html .= "<div id=\"" . md5(date("Y-m-d H:i:s") . $i . $formName) . "\"  publickey=\"" . JSN_UNIFORM_CAPTCHA_PUBLICKEY . "\" class=\"form-captcha control-group\"></div>";
					}
				}
				$html .= "</div>";
			}
			$btnNext = !empty($items->form_btn_next_text) ? $items->form_btn_next_text : "Next";
			$btnPrev = !empty($items->form_btn_prev_text) ? $items->form_btn_prev_text : "Prev";
			$btnSubmit = !empty($items->form_btn_submit_text) ? $items->form_btn_submit_text : "Submit";
			$html .= '<div class="form-actions">
			<div class="btn-toolbar">
			    <button class="btn prev hide" onclick="return false;">' . JText::_($btnNext) . '</button>
			    <button class="btn next btn-primary hide" onclick="return false;">' . JText::_($btnPrev) . '</button>
			    <button type="submit" class="btn btn-primary jsn-form-submit hide" >' . JText::_($btnSubmit) . '</button>
			</div>
		     </div>';
			$formId = isset($items->form_id) ? $items->form_id : "";
			$postAction = isset($items->form_post_action) ? $items->form_post_action : "";
			$postActionData = isset($items->form_post_action_data) ? $items->form_post_action_data : "";
			$edition = defined('JSN_UNIFORM_EDITION') ? JSN_UNIFORM_EDITION : "free";
			if (strtolower($edition) == "free")
			{
				$html .= "<div class=\"jsn-text-center\"><a href=\"http://www.joomlashine.com/joomla-extensions/jsn-uniform.html\" target=\"_blank\">" . JText::_('JSN_UNIFORM_POWERED_BY') . "</a> by <a href=\"http://www.joomlashine.com\" target=\"_blank\">JoomlaShine</a></div>";
			}
			if ($formType != 'ajax')
			{
				$html .= "</div>";
				$html .= "<input type=\"hidden\" name=\"task\" value=\"form.save\" />";
				$html .= "<input type=\"hidden\" name=\"option\" value=\"com_uniform\" />";
				$html .= "<input type=\"hidden\" name=\"form_id\" value=\"{$formId}\" />";
				$html .= "<input type=\"hidden\" id=\"form_post_action\" name=\"form_post_action\" value=\"{$postAction}\" />";
				$html .= "<input type=\"hidden\" name=\"form_post_action_data\" value=\"{$postActionData}\" />";
				$html .= JHtml::_('form.token');
				$html .= "</form>";
				$html .= "</div></div>";
				$html .= JSNHtmlAsset::loadScript('uniform/form', array('language' => JSNUtilsLanguage::getTranslated($arrayTranslated), 'settings' => $settings, 'pathRoot' => JURI::root()), true);
			}
		}
		return $html;

	}

}
