<?php

/**
 * @version     $Id: uniform.php 19013 2012-11-28 04:48:47Z thailv $
 * @package     JSNUniform
 * @subpackage  Uniform
 * @author      JoomlaShine Team <support@joomlashine.com>
 * @copyright   Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license     GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */
defined('_JEXEC') or die('Restricted access');

// import joomla controller library
jimport('joomla.application.component.controller');

require_once JPATH_COMPONENT_ADMINISTRATOR . DS . 'uniform.defines.php';
require_once JPATH_COMPONENT_ADMINISTRATOR . DS . 'helpers' . DS . 'uniform.php';

JLoader::register('JSNUniformUpload', dirname(__FILE__) . DS . 'helpers' . DS . 'form.php');
JLoader::register('Browser', dirname(__FILE__) . DS . 'helpers' . DS . 'browser.php');

// Get an instance of the controller prefixed by Uniform
$controller = JController::getInstance('JSNUniform');

// Perform the Request task
$controller->execute(JRequest::getCmd('task'));

// Redirect if set by the controller
$controller->redirect();
