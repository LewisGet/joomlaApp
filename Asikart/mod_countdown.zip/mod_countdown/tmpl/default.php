<?php
/**
 * @package		Asikart.Module
 * @subpackage	mod_countdown
 * @copyright	Copyright (C) 2012 Asikart.com, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;
$doc = JFactory::getDocument();
$doc->addStyleSheet('modules/mod_countdown/css/reset.css');
$doc->addStyleSheet('modules/mod_countdown/css/styles.css');
$doc->addScript('modules/mod_countdown/js/countdown.js');

$format = 'Y-m-d H:i:s';

$title 		= $params->get('title', 'Coming Soon...');
$deadline 	= $params->get('deadline', date($format));

?>
<script>

	jQuery(document).ready(function(){
		jQuery("#countdown").countdown({
			date: "<?php echo JHtml::_('date', $deadline, $format, null); ?>",
			format: "on"
		},

		function() {
			// callback function
		});
	});

</script>
<div class="countdown-module-wrap<?php echo $moduleclass_sfx; ?>">
	<div class="countdown-module-wrap-inner">
		
		<h1><?php echo $title; ?></h1>

		<ul id="countdown">
			<li>
				<span class="days">00</span>
				<p class="timeRefDays">days</p>
			</li>
			<li>
				<span class="hours">00</span>
				<p class="timeRefHours">hours</p>
			</li>
			<li>
				<span class="minutes">00</span>
				<p class="timeRefMinutes">minutes</p>
			</li>
			<li>
				<span class="seconds">00</span>
				<p class="timeRefSeconds">seconds</p>
			</li>
		</ul>

	</div>
</div>