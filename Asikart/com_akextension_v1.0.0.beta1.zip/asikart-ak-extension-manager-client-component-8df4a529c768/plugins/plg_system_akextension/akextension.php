<?php
/**
 * @package		Asikart.Plugin
 * @subpackage	system.plg_akextension
 * @copyright	Copyright (C) 2012 Asikart.com, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * Akextension System Plugin
 *
 * @package		Joomla.Plugin
 * @subpackage	System.akextension
 * @since		1.5
 */
class plgSystemAkextension extends JPlugin
{
	
	public static $_self ;
	
	/**
	 * Constructor
	 *
	 * @access      public
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       1.6
	 */
    public function __construct(&$subject, $config)
    {
		parent::__construct( $subject, $config );
		$this->loadLanguage();
		$this->app = JFactory::getApplication();
		
		self::$_self = $this ;
    }
	
	
	
	/*
	 * function getInstance
	 */
	
	public static function getInstance()
	{
		return self::$_self ;
	}
	
	
	// Events
	// ======================================================================================
	
	
	/*
	 * function onAfterRoute
	 * @param 
	 */
	
	public function onAfterRoute()
	{
		$option = JRequest::getVar('option') ;
		if( 'com_installer' != $option ) return true;
		
		$lang 	= JFactory::getLanguage();
		$lang->load('com_akextension', JPATH_BASE.'/components/com_akextension', null, false, false);
		
		
		if( JVERSION >= 3 ) {
			JHtmlSidebar::addEntry(
				JText::_('COM_AKEXTENSION_ONLINE_INSTALL_TITLE'),
				'index.php?option=com_akextension&view=searchs',
				false
			);
		}else{
			JSubMenuHelper::addEntry(
				JText::_('COM_AKEXTENSION_ONLINE_INSTALL_TITLE'),
				'index.php?option=com_akextension&view=searchs',
				false
			);
		}
		
	}
	
	
}
