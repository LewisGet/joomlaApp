<?php

class AKFilter {
	
	public static function test() {
		echo 'test' ;
	}
	
}


