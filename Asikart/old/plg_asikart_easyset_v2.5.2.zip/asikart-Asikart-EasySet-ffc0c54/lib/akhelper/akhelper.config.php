<?php

class AKConfig extends JObject {

	public $extension_type 	= 3 ; // ( 1: component, 2: module, 3: plugin )

	public $extension_name 	= 'asikart_easyset' ;
	
	public $plugin_group	= 'system' ;
	
	public $module_position	= 0 ; // ( 0: site, 1: admin )
	
	public $akhelper_path 	= '' ;
	
}


