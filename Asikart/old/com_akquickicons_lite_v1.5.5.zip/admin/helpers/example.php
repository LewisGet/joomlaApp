<?php
/**
 * @package     AKHelper
 * @subpackage  main
 *
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */


// No direct access
defined('_JEXEC') or die;


class AkquickiconsHelperExample {
	
	/*
	 * function getText
	 * @param $text
	 */
	
	public static function getText($text = 'This is example function.')
	{
		return $text ;
	}
	
}


