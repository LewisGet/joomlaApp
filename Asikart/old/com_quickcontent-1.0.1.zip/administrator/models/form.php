<?php
/**
 * @version     1.0.0
 * @package     com_quickcontent
 * @copyright   Copyright (C) 2011. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Created by com_combuilder - http://www.notwebdesign.com
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.modeladmin');

/**
 * Quickcontent model.
 */
class QuickcontentModelform extends JModelAdmin
{
	/**
	 * @var		string	The prefix to use with controller messages.
	 * @since	1.6
	 */
	protected $text_prefix = 'COM_QUICKCONTENT';


	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param	type	The table type to instantiate
	 * @param	string	A prefix for the table class name. Optional.
	 * @param	array	Configuration array for model. Optional.
	 * @return	JTable	A database object
	 * @since	1.6
	 */
	public function getTable($type = 'Form', $prefix = 'QuickcontentTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param	array	$data		An optional array of data for the form to interogate.
	 * @param	boolean	$loadData	True if the form is to load its own data (default case), false if not.
	 * @return	JForm	A JForm object on success, false on failure
	 * @since	1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Initialise variables.
		$app	= JFactory::getApplication();

		// Get the form.
		$form = $this->loadForm('com_quickcontent.form', 'form', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form)) {
			return false;
		}

		return $form;
	}
	
	public function getFormParams($data = array(), $loadData = true) {
		$form = new JObject();
		$form->blog 	= $this->blogForm ;
		$form->list 	= $this->listForm ;
		$form->article 	= $this->articleForm ;
		return $form ;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return	mixed	The data for the form.
	 * @since	1.6
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_quickcontent.edit.form.data', array());

		if (empty($data)) {
			$data = $this->getItem();
		}
		
		return $data;
	}
	
	protected function preprocessForm(JForm $form, $data, $group = 'content') {
		
		$blogXML 	= JPath::clean(JPATH_ROOT.DS.'components/com_content/views/category/tmpl/blog.xml');
		$listXML 	= JPath::clean(JPATH_ROOT.DS.'components/com_content/views/category/tmpl/default.xml');
		$articleXML	= JPath::clean(JPATH_ROOT.DS.'components/com_content/views/article/tmpl/default.xml');
		$menuXML	= JPath::clean(JPATH_BASE.DS.'components/com_menus/models/forms/item_component.xml' );
		
		// set list params
		$listParams = simplexml_load_file( $listXML );
		$listParams->fields[1]['name'] = 'list' ;
		
		// set blog params
		$blogParams = simplexml_load_file( $blogXML );
		$blogParams->fields[1]['name'] = 'blog' ;
		
		// set article params
		$articleParams = simplexml_load_file( $articleXML );
		$articleParams->fields[1]['name'] = 'article' ;
		
		// create Form
		$this->listForm = JForm::getInstance( 'list' , $listParams->asXML() , array( 'control' => 'jform' ) , true , '/metadata' ) ;
		$this->blogForm = JForm::getInstance( 'blog' , $blogParams->asXML() , array('control' => 'jform') , true , '/metadata' ) ;
		$this->articleForm = JForm::getInstance( 'article' , $articleParams->asXML() , array('control' => 'jform') , true , '/metadata' ) ;
		
		// set menu xml
		$menuParams = simplexml_load_file( $menuXML );
		
		$menuParams->fields[0]['name'] = 'list' ;
		$this->listForm->load( $menuParams->asXML() , true , '/form' );
		
		$menuParams->fields[0]['name'] = 'blog' ;
		$this->blogForm->load( $menuParams->asXML() , true , '/form' );
		
		$menuParams->fields[0]['name'] = 'article' ;
		$this->articleForm->load( $menuParams->asXML() , true , '/form' );
		
		
		// bind data
		$data->list = json_decode( $data->list ) ;
		$data->blog = json_decode( $data->blog ) ;
		$data->article = json_decode( $data->article ) ;
		
		$this->listForm->bind( $data );
		$this->blogForm->bind( $data );
		$this->articleForm->bind( $data );
	
		parent::preprocessForm($form, $data);
	}

	/**
	 * Method to get a single record.
	 *
	 * @param	integer	The id of the primary key.
	 *
	 * @return	mixed	Object on success, false on failure.
	 * @since	1.6
	 */
	public function getItem($pk = null)
	{
		if ($item = parent::getItem($pk)) {

			//Do any procesing on fields here if needed

		}

		return $item;
	}

	/**
	 * Prepare and sanitise the table prior to saving.
	 *
	 * @since	1.6
	 */
	protected function prepareTable(&$table)
	{
		jimport('joomla.filter.output');

		if (empty($table->id)) {

			// Set ordering to the last item if not set
			if (@$table->ordering === '') {
				$db = JFactory::getDbo();
				$db->setQuery('SELECT MAX(ordering) FROM #__quickcontent');
				$max = $db->loadResult();
				$table->ordering = $max+1;
			}

		}
	}

}