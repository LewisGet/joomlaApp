<?php
// Require the base controller
AK::requireOnce( JPATH_ROOT.DS.'administrator'.DS.$com_dir.DS.'helpers'.DS.'helper2.php' );

// Set submenu
if( AK::_( 'app.isAdmin' ) ) require_once $akhelper_path.DS.'component.submenu.php' ;

// Access check.
if (!JFactory::getUser()->authorise('core.manage', $extension_name)) {
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

// Include dependancies
jimport('joomla.application.component.controller');

$controller	= JController::getInstance( ucfirst( $akconfig->get('extension_name') ) );
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();
