<?php

$submenu[] = '' ;
$submenu[] = '' ;


foreach( $submenu as $val ):
	if( $val ) :
		JSubMenuHelper::addEntry( JText::_($val) , "index.php?option={$option}&{$view}={$val}" );
	endif;
endforeach;
?>
