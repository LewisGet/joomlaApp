<?php

$akconfig->extension_type 	= 1 ; // ( 1: component, 2: module, 3: plugin )

$akconfig->extension_name 	= 'quickcontent' ;
	
$akconfig->plugin_group		= '' ;
	
$akconfig->module_position	= 0 ; // ( 0: site, 1: admin )
	
$akconfig->akhelper_path 	= '' ;
