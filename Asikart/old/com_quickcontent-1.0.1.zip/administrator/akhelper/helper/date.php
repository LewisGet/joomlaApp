<?php

class AKDate {
	function execute ($func , $date = 'now') 
	{
		$object =& JFactory::getDate($dtae);
		
        if (is_callable( array( $object, $func ) ))
        {
            $temp = func_get_args();
            array_shift( $temp );
			array_shift( $temp );
            
            $args = array();
            foreach ($temp as $k => $v) {
                $args[] = &$temp[$k];
            }
            return call_user_func_array( array( $object, $func ), $args );
        }
        else
        {
            JError::raiseWarning( 0, $object.'::'.$func.' not supported.' );
            return false;
        }
	}
	
	function toFormat($date='now' , $format='%Y-%m-%d %H:%M:%S') {
		return self::execute( 'toFormat' , $date , $format );
	}
}

?>
