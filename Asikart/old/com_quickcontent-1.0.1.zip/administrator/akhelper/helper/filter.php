<?php

class AKFilter {
	
	function test() {
		echo 'test' ;
	}
	
}

?>
