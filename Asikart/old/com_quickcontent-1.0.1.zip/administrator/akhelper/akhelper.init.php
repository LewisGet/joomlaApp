<?php

//get config
$akconfig 		= new JObject();
require_once dirname(__FILE__).DS.'akhelper.config.php' ;

//some setting
$option 		= JRequest::getVar( 'option' ) ;
$com_dir 		= 'components'.DS.$option ;
$com_name		= str_replace( 'com_' , '' , $option );

//set akhelper path
$akhelper_path  = dirname(__FILE__) ;

//Define 
require_once ( $akhelper_path.DS.'akhelper.defines.php' ) ;

//Load AKHelper
if( !class_exists( 'AKHelper' ) )
	require_once ($akhelper_path.DS.'akhelper.php') ;

//set component portal
require_once ($akhelper_path.DS.'component.portal.php') ;