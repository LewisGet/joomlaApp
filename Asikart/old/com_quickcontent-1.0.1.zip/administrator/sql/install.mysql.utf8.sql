CREATE TABLE IF NOT EXISTS `#__quickcontent` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `ordering` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL default '1',
  `checked_out` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `content` mediumtext NOT NULL,
  `menutype` varchar(255) NOT NULL,
  `delete_existing` int(3) NOT NULL,
  `category_menutype` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `list` text NOT NULL,
  `blog` text NOT NULL,
  `article` text NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;