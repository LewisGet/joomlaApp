<?php
/**
 * @version     1.0.0
 * @package     com_quickcontent
 * @copyright   Copyright (C) 2011. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Created by com_combuilder - http://www.notwebdesign.com
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

/**
 * View to edit
 */
class QuickcontentViewForm extends JView
{
	protected $state;
	protected $item;
	protected $form;

	/**
	 * Display the view
	 */
	public function display($tpl = null)
	{
		$this->state	= $this->get('State');
		$this->item		= $this->get('Item');
		$this->form		= $this->get('Form');
		
		$this->params = JComponentHelper::getParams( 'com_quickcontent' ) ;
		
		$this->formParams = $this->get( 'FormParams' );

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}
		
		// load content language
		$lang =& JFactory::getLanguage();
		
		$lang->load( 'com_content' , JPATH_BASE, null, true, true );
		$lang->load( 'com_menus' , JPATH_BASE, null, true, true );
		
		// set Editor
		$editor = JFactory::getEditor( $this->params->get( 'editor' , 'tinymce' ) );
		$params['mode'] = 2 ;
		$this->editor = $editor->display ( 'jform[content]' , $this->item->content , '650px' , '500px' , 650 , 500 , false , null , null ,null , $params );
		
		$this->addToolbar();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 */
	protected function addToolbar()
	{
		JRequest::setVar('hidemainmenu', true);

		$user		= JFactory::getUser();
		$isNew		= ($this->item->id == 0);
        if (isset($this->item->checked_out)) {
		    $checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $user->get('id'));
        } else {
            $checkedOut = false;
        }
		$canDo		= QuickcontentHelper::getActions();

		JToolBarHelper::title(JText::_('COM_QUICKCONTENT_TITLE_FORM'), 'form.png');

		// If not checked out, can save the item.
		if (!$checkedOut && ($canDo->get('core.edit')||($canDo->get('core.create'))))
		{

			JToolBarHelper::apply('form.apply', 'JTOOLBAR_APPLY');
			JToolBarHelper::save('form.save', 'JTOOLBAR_SAVE');
		}
		if (!$checkedOut && ($canDo->get('core.create'))){
			JToolBarHelper::custom('form.save2new', 'save-new.png', 'save-new_f2.png', 'JTOOLBAR_SAVE_AND_NEW', false);
		}
		// If an existing item, can save to a copy.
		if (!$isNew && $canDo->get('core.create')) {
			JToolBarHelper::custom('form.save2copy', 'save-copy.png', 'save-copy_f2.png', 'JTOOLBAR_SAVE_AS_COPY', false);
		}
		if (empty($this->item->id)) {
			JToolBarHelper::cancel('form.cancel', 'JTOOLBAR_CANCEL');
		}
		else {
			JToolBarHelper::cancel('form.cancel', 'JTOOLBAR_CLOSE');
		}

	}
	
	public function showParams( $id ) {
		$fieldSets = $this->formParams->$id->getFieldsets( $id );
		
		echo JHtml::_('sliders.start','menu-sliders-'.$id); 
		
		foreach ($fieldSets as $name => $fieldSet) :
			$label = !empty($fieldSet->label) ? $fieldSet->label : 'COM_MENUS_'.$name.'_FIELDSET_LABEL';
			echo JHtml::_('sliders.panel',JText::_($label), $name.'-options');
				if (isset($fieldSet->description) && trim($fieldSet->description)) :
					echo '<p class="tip">'.$this->escape(JText::_($fieldSet->description)).'</p>';
				endif;
				?>
			<div class="clr"></div>
			<fieldset class="panelform">
				<ul class="adminformlist">
					<?php foreach ($this->formParams->$id->getFieldset($name) as $field) : ?>
						<li><?php echo $field->label; ?>
						<?php echo $field->input; ?></li>
					<?php endforeach; ?>
				</ul>
			</fieldset>
		<?php endforeach;
	 echo JHtml::_('sliders.end'); 
	}
}
