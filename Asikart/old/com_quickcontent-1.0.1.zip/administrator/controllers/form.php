<?php
/**
 * @version     1.0.0
 * @package     com_quickcontent
 * @copyright   Copyright (C) 2011. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Created by com_combuilder - http://www.notwebdesign.com
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Form controller class.
 */
class QuickcontentControllerForm extends JControllerForm
{

    function __construct() {
        $this->view_list = 'list';
        parent::__construct();
    }
	
	function save() {
		
		$post = JRequest::get( 'post' );
		
		$post['jform']['list'] = new JRegistry($post['jform']['list']) ;
		$post['jform']['list'] = $post['jform']['list']->toString();
		
		$post['jform']['blog'] = new JRegistry($post['jform']['blog']) ;
		$post['jform']['blog'] = $post['jform']['blog']->toString();
		
		$post['jform']['article'] = new JRegistry($post['jform']['article']) ;
		$post['jform']['article'] = $post['jform']['article']->toString();
		
		JRequest::setVar( 'jform' , $post['jform'] ) ;
		
		parent::save();
	}
	
}