DROP TABLE  `#__userxtd_fields`;
DROP TABLE  `#__userxtd_profiles`;