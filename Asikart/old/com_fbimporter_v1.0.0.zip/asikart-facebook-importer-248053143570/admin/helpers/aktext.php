<?php
/**
 * @version     1.0.0
 * @package     com_payany
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Created by AKHelper - http://asikart.com
 */

// No direct access
defined('_JEXEC') or die;

/**
 * Payany helper.
 */
class AKText
{
	
	static function __callStatic($name, $args)
	{
		$args[0] = strtoupper( 'COM_FBIMPORTER_'.$args[0] );
		
		return call_user_func_array( array( 'JText' , $name ) , $args );
	}
}
