<?php
/**
 * @package		Joomla.Administrator
 * @subpackage	com_menus
 * @copyright	Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

?>
<?php 
    
    //get the form of request .           
	$fieldSets = $this->form->getFieldsets('request');
        
    // Fieldset        
	if (!empty($fieldSets)) {	    	   		     
        //將外層array去掉 
        $fieldSets = array_shift($fieldSets);
                
        $label = !empty($fieldSets->label) ? $fieldSets->label : 'COM_AMM_'.$fieldSets->name.'_FIELDSET_LABEL';
             
        echo JHtml::_('sliders.panel', JText::_($label), $fieldSets->name.'-options');         
            ?>
		<fieldset id="fildset-<?php echo $this->current_group . '-' . $fieldSets->name; ?>" class="adminform ">		    
			<?php foreach($this->form->getFieldset('request') as $field ): ?>      
                <div class="control-group" id="<?php echo $field->id; ?>-wrap">
                    <?php echo $field->label; ?>
                    <div class="controls">
                        <?php echo $field->input; ?>
                    </div>
                </div>
            <?php endforeach; ?>						
		</fieldset>	
<?php
	 }
    
    //get the form of params .    
    $current_param = 'params';
	$fieldSets = $this->form->getFieldsets($current_param);
        
	foreach ($fieldSets as $name => $fieldSet) :
		$label = !empty($fieldSet->label) ? $fieldSet->label : 'COM_AMM_'.$name.'_FIELDSET_LABEL';		
		echo JHtml::_('sliders.panel', JText::_($label), $name.'-options');			
			?>
		<fieldset id="fildset-<?php echo $this->current_group . '-' . $name; ?>" class="adminform ">		    		
				<?php foreach ($this->form->getFieldset($name) as $field) : ?>
					<div class="control-group" id="<?php echo $field->id; ?>-wrap">
                    <?php echo $field->label; ?>
                    <div class="controls">
                        <?php echo $field->input; ?>
                    </div>
                </div>
				<?php endforeach; ?>			
		</fieldset>
<?php endforeach;?>
<?php

	$fieldSets = $this->form->getFieldsets('associations');

	foreach ($fieldSets as $name => $fieldSet) :
		$label = !empty($fieldSet->label) ? $fieldSet->label : 'COM_AMM_'.$name.'_FIELDSET_LABEL';
		echo JHtml::_('sliders.panel', JText::_($label), $name.'-options');
			
			?>
		
		<fieldset class="panelform">
		    <legend><?php echo $fieldSet->label ? JText::_($fieldSet->label) : JText::_('COM_AMM_'.$fieldSet->name.'_FIELDSET_LABEL'); ?></legend>
			<ul class="adminformlist">
				<?php foreach ($this->form->getFieldset($name) as $field) : ?>
					<li><?php echo $field->label; ?>
					<?php echo $field->input; ?></li>
				<?php endforeach; ?>
			</ul>
		</fieldset>
<?php endforeach;?>
