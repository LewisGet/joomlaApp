<?php

// no direct access
defined('_JEXEC') or die;

JFormHelper::loadFieldClass('list');

class JFormFieldMenutype extends JFormFieldList
{
    public $type = "Menutype";
    
    protected function getOptions()
    {
        // Initialize variables.
        $options = array();
 
        
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query->select('a.title as text , a.menutype as value');
        $query->from('#__menu_types as a');
        $db->setQuery($query);

        $options = $db->loadObjectList();
      
        $options = array_merge(parent::getOptions(), $options);
        
        reset($options);

        return $options;               
    }
}
