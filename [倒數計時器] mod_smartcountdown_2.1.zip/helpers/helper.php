<?php
/**
 * @package Module Smart Countdown for Joomla! 2.5 -3.0
 * @version 2.1: helper.php
 * @author Alex Polonski
 * @copyright (C) 2012-2013 - Alex Polonski
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/
// no direct access
defined('_JEXEC') or die;
jimport('joomla.event.dispatcher');

class modSmartCountdownHelper
{
	static function getCountdown($params)
	{
		// compatibility with 2.0.6 settings
		
		// count up it obsolete and will be erased after the first
		// save settings
		// do this just for seamless upgrade
		if($params->get('show_countup', 1) == 0) {
			$params->set('show_countdown', -2);
		}
		
		// value = 1 is not used in this version, if found in settings,
		// effectively replace it by auto option
		if($params->get('show_countdown', 1) == 1) {
			$params->set('show_countdown', -1);
		}
		//////// END CAMPATIBILITY \\\\\\\\
		
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result = $dispatcher->trigger('onCountdownGetEventsQueue', array('mod_smartcountdown', $params));
		if(in_array(false, $result, true)) {
			return false;
		}
		$plugins_enabled = false;
		
		$events_queue = array();
		foreach($result as $queue) {
			if($queue === true) {
				continue;
			}
			$plugins_enabled = true;
			/**
			 * Queue format: 2-dimensional array
			 * 1-st dimension - events indexed by start time
			 * 2-nd dimension - events indexed by end time
			 */
			
			// Concatenate titles for duplicate-time events
			$titles = array();
			foreach($queue as $time => $group) {
				foreach(array_reverse($group, true) as $event) {
					if(isset($titles[$event['start']])) {
						$titles[$event['start']][''] = $event['title'].', '.$titles[$event['start']][''];
					} else {
						$titles[$event['start']][''] = $event['title'];
					}
					
					$titles[$event['start']][$event['up_limit']] = $titles[$event['start']][''];
				}
			}
			
			// Set event text (countdown or countup)
			$lang = JFactory::getLanguage();
			$tag = strtolower($lang->getTag());
			
			foreach($queue as $time => $group) {
				foreach($group as $event) {
					while(isset($events_queue[$time])) {
						// time is used as a pure index here to be able to order
						// events later. Advancing time here assures that all
						// events from all plugins will be added to the queue
						// and ordered by their start time or the order the
						// plugin provides in case of time duplicates
						$time++;
					}
					
					$text_down = $params->get('text_down_'.$tag,
						$params->get('text_down_def', JText::_('MOD_SMARTCDPRO_TEXT_DOWN_DEFAULT')));
					$text_up = $params->get('text_up_'.$tag,
						$params->get('text_up_def', JText::_('MOD_SMARTCDPRO_TEXT_UP_DEFAULT')));
					
					// construct event texts
					$replace = array("\n", "\r\n", "\r");
					$event['text_down'] = str_replace($replace, '<br />', $text_down).' '.$titles[$event['start']][$event['up_limit']];
					$event['text_up'] = str_replace($replace, '<br />', $text_up).' '.$titles[$event['start']][$event['up_limit']];
					$event['text'] = $event['diff_js'] > 0 ? $event['text_down'] : $event['text_up'];
					
					$events_queue[$time] = $event;
				}
			}
		}
		
		if(empty($result) || !$plugins_enabled) {
			return self::getInternal($params);
		}
		
		ksort($events_queue, SORT_NUMERIC);
		$events_queue = array_values($events_queue);
		
		return $events_queue;
	}
	
	private static function getInternal($params)
	{
		$deadline = $params->get('deadline', '');
			
		// Explicitly disable caching for this module
		$params->set('cache', 0);
		
		if($deadline)
		{
			$deadline = JFactory::getDate($deadline);
			$date = JFactory::getDate('now');
			$diff_js = $deadline->format('U', false) - $date->format('U', false);
			
			// Check if an option is set for current mode (countdown/countup)
			
			// for auto-countdowns always show
			$show_countdown = $params->get('show_countdown', -1);
			if($show_countdown >= 0 && $diff_js > $show_countdown) {
				return false;
			} 
			if($show_countdown < -2 && $diff_js <= $show_countdown) {
				return false;
			}
			
			if($show_countdown >= -1) {
				$up_limit = PHP_INT_MAX;
			} elseif($show_countdown == -2) {
				$up_limit = 0;
			} else {
				$up_limit = $show_countdown * -1;
			}
			
			// Set event text (countdown or countup)
			$lang = JFactory::getLanguage();
			$tag = strtolower($lang->getTag());
			
			// First try to find language specific strings, then fall back to
			// uni-language string (if no localization plugin is installed) and
			// as last resource use default text from ini file
			$text_down = $params->get('text_down_'.$tag,
					$params->get('text_down_def', JText::_('MOD_SMARTCDPRO_TEXT_DOWN_DEFAULT')));
			$text_up = $params->get('text_up_'.$tag,
					$params->get('text_up_def', JText::_('MOD_SMARTCDPRO_TEXT_UP_DEFAULT')));

			// strip new lines from texts to make them valid js strings
			$replace = array("\n", "\r\n", "\r");
			$text_down = str_replace($replace, ' ', $text_down);
			$text_up = str_replace($replace, ' ', $text_up);
					
			$text = $diff_js > 0 ? $text_down : $text_up;
						
			// Calculate values for php output (for users without js and for first page load)
			$seconds = $diff_js > 0 ? $diff_js : $diff_js * -1;
			$days_diff = floor($seconds / 86400);
			$diff_time = gmdate('H:i:s', $seconds);
			list($h_diff, $i_diff, $s_diff) = explode(':', $diff_time);
			
			// Process on event goto option
			if($params->get('event_goto', 0))
			{
				$event_goto_url = $params->get('event_goto_url', '');
				$event_goto_menu = empty($event_goto_url) ? $params->get('event_goto_menu', 0) : 0;
			}
			else 
			{
				$event_goto_menu = 0;
				$event_goto_url = '';
				$event_goto_link = '';
			}
			if($event_goto_menu)
			{
				$menu = JFactory::getApplication()->getMenu();
				$item = $menu->getItem($event_goto_menu);
				
				$router = JSite::getRouter();
				if ($router->getMode() == JROUTER_MODE_SEF)
				{
					$event_goto_link = 'index.php?Itemid='.$event_goto_menu;
				}
				else
				{
					$event_goto_link = $item->link.'&Itemid='.$event_goto_menu;
				}
				$event_goto_link .= '&lang='.substr($item->language, 0, 2);
				if (strcasecmp(substr($event_goto_link, 0, 4), 'http') && (strpos($event_goto_link, 'index.php?') !== false))
				{
					$event_goto_link = JRoute::_($event_goto_link, true, $item->params->get('secure'));
				}
				else
				{
					$event_goto_link = JRoute::_($event_goto_link);
				}
				$event_goto_link = JURI::getInstance()->toString(array('scheme', 'host')).$event_goto_link;
			}
			if($event_goto_url)
			{
				// workaround for duplicated 'http://' prefix prepended to url
				// for relative urls (e.g. index.php)
				if(strripos($event_goto_url, 'http') !== 0)
				{
					$event_goto_url = substr($event_goto_url, stripos($event_goto_url, '://') + 3);
				}
				$event_goto_link = $event_goto_url;
				// ignore empty url
				if(substr($event_goto_link, -3) == '://')
				{
					$event_goto_link = '';
				}
			}
			
			// build result
			$result = array();
			// construct events queue with one entry only
			$result[] = array(
					'diff_js' => $diff_js,
					'up_limit' => $up_limit,
					'text' => $text,
					'text_down' => $text_down,
					'text_up' => $text_up,
					'diff_php' => array('days' => $days_diff, 'hours' => $h_diff, 'minutes' => $i_diff, 'seconds' => $s_diff),
					'event_goto_link' => $event_goto_link
			);
			return $result;
		}
		return false;
	}
	
	static function getDigitsConfig($xml, $scale = 1.0)
	{
		libxml_use_internal_errors(true);
				
		$xml = simplexml_load_string($xml);
		
		foreach (libxml_get_errors() as $error)
		{
			JLog::add(JText::_('MOD_SMARTCOUNTDOWN').': ' . $error->message, JLog::WARNING);
		}
		if(empty($xml))
		{
			return false;
		}
		
		$digitsConfig = array();
		
		// global settings
		$digitsConfig['name'] = $xml['name'] ? (string)$xml['name'] : 'Custom';
		$digitsConfig['description'] = $xml['description'] ? (string)$xml['description'] : '';
		
		$digitsConfig['images_folder'] = JURI::root().($xml['images_folder'] ? (string)$xml['images_folder'] : '');
		
		// get all digit scopes configurations
		foreach($xml->digit as $digit) {
			
			// scope attribute may contain more than one value (comma-separated list)
			$scopes = explode(',', (string)$digit['scope']);
			
			foreach($scopes as $scope) {
				// init config for all scopes in list
				$digitsConfig['digits'][$scope] = array();
			}
			
			// construct digit style
			$styles = '';
			foreach($digit->styles->style as $value) {
				$attrs = array();
				foreach($value->attributes() as $k => $v) {
					$attrs[$k] = (string)$v;
				}
				
				// Scale the value if it has 'scalable' attribute set
				$result = !empty($attrs['scalable']) ? $scale * $attrs['value'] : $attrs['value'];
				$styles .= $attrs['name'].':'.$result.(!empty($attrs['unit']) ? $attrs['unit'] : '').';';
			}
			
			// for digit style - if background set, prepend images_folder
			$styles = preg_replace('#url\((\S+)\)#', 'url('.$digitsConfig['images_folder'].'$1)', $styles);
			
			foreach($scopes as $scope) {
				// set styles for all scopes in list
				$digitsConfig['digits'][$scope]['style'] = $styles;
			}
			
			// get modes (down and up)
			foreach($digit->modes->mode as $groups) {
				
				$attrs = $groups->attributes();
				$mode = (string)$attrs['name'];
				
				foreach($groups as $group) {
					
					$grConfig = array();
					
					$grAttrs = $group->attributes();
					foreach($grAttrs as $k => $v) {
						$grConfig[$k] = (string)$v;
					}
					
					$grConfig['elements'] = array();
					
					// get all elements for the group
					foreach($group as $element) {
						// default values to use if attribute is missing
						$elConfig = array('filename_base' => '', 'filename_ext' => '', 'value_type' => '');
						
						$elAttrs = $element->attributes();
						foreach($elAttrs as $k => $v) {
							$elConfig[$k] = (string)$v;
						}
						
						$elConfig['styles'] = self::getElementStyles($element->styles, $digitsConfig['images_folder']);
						$elConfig['tweens'] = self::getElementTweens($element->tweens);
						
						$grConfig['elements'][] = $elConfig;
					}
					
					foreach($scopes as $scope) {
						// set fx configuration for all scopes in list
						$digitsConfig['digits'][$scope][$mode][] = $grConfig;
					}
				}
			}
		}
		
		return $digitsConfig;
	}
	
	private static function getElementStyles($styles, $images_folder)
	{
		$result = '';
		
		if(empty($styles)) {
			return $result;
		}
		
		$tpl = '%s:%s;';
		$styles = $styles->children();
		
		for($i = 0; $count = count($styles), $i < $count; $i++) {
			$result .= sprintf($tpl, $styles[$i]->getName(), (string)$styles[$i]);
		}
		
		// if styles contain background - prepend images_folder
		$result = preg_replace('#url\((\S+)\)#', 'url('.$images_folder.'$1)', $result);

		return $result;
	}
	
	private static function getElementTweens($tweens)
	{
		$result = new stdClass();
		
		if(empty($tweens)) {
			return $result;
		}
		
		$tweens = $tweens->children();
		
		for($i = 0; $count = count($tweens), $i < $count; $i++) {
			$name = $tweens[$i]->getName();
			$result->$name = explode(',', (string)$tweens[$i]);
		}
		
		return $result;
	}
	
	public static function getLayoutConfig($params)
	{
		$config = array();
		
		$config['hide_zero_fields'] = $params->get('hide_zero_fields', 1);
		$config['display_seconds'] = $params->get('display_seconds', 1);

		$module_width = $params->get('module_width', '');
		$module_padding = $params->get('module_padding', 0);
		$module_background = $params->get('module_background', '');
		$module_style = ($module_width ? 'width:'.$module_width.'px;' : '');
		$module_style .= ($module_padding ? 'padding:'.$module_padding.'px;' : '');
		$module_style .= ($module_background ? 'background:'.str_replace('"', "'", $module_background).';' : '');
		if($params->get('global_center', 1)) {
			// add global horizontal centering feature
			$module_style .= ($params->get('global_center', 1) ? 'text-align:center;' : '');
			$config['wrapper_class'] = ' class="scdp-wrapper-center"';
		} else {
			$config['wrapper_class'] = '';
		}
		$config['module_style'] = $module_style;
		
		$event_text_size = $params->get('event_text_size', 20);
		$event_text_style = $params->get('event_text_style', '');
		$event_text_style = 'font-size:'.$event_text_size.'px;'.$event_text_style;
		$config['event_text_style'] = $event_text_style;
		
		$numbers_style = $params->get('digits_style', '');
		$config['numbers_style'] = $numbers_style;
		
		
		$labels_size = $params->get('labels_size', 20);
		$labels_style = $params->get('labels_style', '');
		$labels_style = 'font-size:'.$labels_size.'px;'.$labels_style;
		$config['labels_style'] = $labels_style;
		
		if($params->get('overload_labels', 0)) {
			$tpl = $params->get('overload_labels_tpl', '');
		}
		else {
			$tpl = '%|%|%|%';
		}
		$tpl = explode('|', $tpl);
		$tpl = array_slice(array_pad($tpl, 4, ''), 0, 4);
		
		$config['label_types'] = array_combine(array('days', 'hours', 'minutes', 'seconds'), $tpl);
		$config['separator_image'] = $params->get('separator_image', '');
		
		$textPosition = $params->get('text_position', 'top');
		$labelsPosition = $params->get('labels_position', 'right');
		
		$textBeforeCounter = $textPosition == 'left' || $textPosition == 'top';
		$labelsBeforeNumbers = $labelsPosition == 'left' || $labelsPosition == 'top';
		
		$config['text_layout_class'] = $textPosition == 'left' || $textPosition == 'right' ? 'horz' : 'vert';
		$config['counter_layout_class'] = $params->get('counter_layout', 'column');
		$config['units_layout_class'] = $labelsPosition == 'left' || $labelsPosition == 'right' ? 'horz' : 'vert';
		
		$config['text_before_counter'] = $textBeforeCounter;
		$config['labels_before_numbers'] = $labelsBeforeNumbers;
		
		$config['counter_style'] = $params->get('counter_style', '');
		if(strpos($config['counter_style'], 'margin') === false) {
			// use 'text_spacing' setting if no margins are set in 'counter_style'
			$text_spacing = $params->get('text_spacing', 6);
			$config['counter_style'] = $config['counter_style'].'margin-'.$textPosition.':'.$text_spacing.'px;';
		}
		if($params->get('global_center', 1)) {
			// add global horizontal centering feature
			$config['counter_style'] .= 'display:inline-block;';
		}
		
		$units_spacing = $params->get('units_spacing', 4);
		$units_style = $config['counter_layout_class'] == 'column' ?
			'padding:'.($units_spacing / 2).'px 0;' :
			'padding:0 '.($units_spacing / 2).'px;' ;
		$config['units_style'] = $units_style;
		
		$labels_spacing = $params->get('numbers_lables_spacing', 8);
		$labels_margin = 'margin-'.$labelsPosition.':'.$labels_spacing.'px;';
		$config['numbers_style'] = $labels_margin.$config['numbers_style'];
		
		$config['module_style'] = $config['module_style'] ? ' style="'.$config['module_style'].'"' : '';
		$config['event_text_style'] = $config['event_text_style'] ? ' style="'.$config['event_text_style'].'"' : '';
		$config['counter_style'] = $config['counter_style'] ? ' style="'.$config['counter_style'].'"' : '';
		
		// special for reserved space setting for day digits
		$min_days_width = $params->get('min_days_width', 0) == '' ? 0 : $params->get('min_days_width', 0);
		$config['days_number_style'] = ' style="'.$config['numbers_style'].'min-width:'.$min_days_width.'px;"';
		
		$config['numbers_style'] = $config['numbers_style'] ? ' style="'.$config['numbers_style'].'"' : '';
		$config['labels_style'] = $config['labels_style'] ? ' style="'.$config['labels_style'].'"' : '';
		
		return $config;
	}
	
	public static function getNumber($name, $values)
	{
		$assets = array(
			'days' => array(6, null), 
			'hours' => array(4, 2),
			'minutes' => array(2, 2),
			'seconds' => array(0, 2)
		);

		// digits floating left, so we start with the highest digit here...
		$digits = array_reverse(array_slice($values, $assets[$name][0], $assets[$name][1], true), true);
		$value = implode('', $digits);
		
		return array('digits' => $digits, 'value' => $value);
	}
}

