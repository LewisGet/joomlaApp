<?php 
$document->addScript($qs->www  . 'js/main.js');
$mainframe = JFactory::getApplication();

if (ini_get('allow_url_fopen') != 1) {
	$mainframe->enqueueMessage('You must enable the option allow_url_fopen in php.ini so QuickSell can verify every transactions, otherwise orders will not work!');
}
if (JPluginHelper::isEnabled('content','quicksellbuttons') == false) {
	$mainframe->enqueueMessage('You must install and enable the "Content - QuickSellButtons" plugin, it converts the code generated in backend to order buttons.');
}

?>
<img src="<?php echo $qs->www ?>images/clouds.png" style="margin-left:256px;" />
<div id="cpanel">
<div class="icon-wrapper joomla3iconwrapper">
	<div class="icon joomla3icon">
		<a href="<?php echo $qs->link ?>&task=config">
			<img src="<?php echo $qs->www ?>images/icon-48-config.png" alt="">			<span>Settings</span></a>
	</div>
</div>
<div class="icon-wrapper joomla3iconwrapper">
	<div class="icon joomla3icon">
		<a href="<?php echo $qs->link ?>&amp;task=home">
			<img src="<?php echo $qs->www ?>images/icon-48-category.png" alt="">			<span>Upload</span></a>
	</div>
</div>
<div class="icon-wrapper joomla3iconwrapper">
	<div class="icon joomla3icon">
		<a href="<?php echo $qs->link ?>&amp;task=files">
			<img src="<?php echo $qs->www ?>images/icon-48-media.png" alt="">			<span>Files</span></a>
	</div>
</div>
<div class="icon-wrapper joomla3iconwrapper">
	<div class="icon joomla3icon">
		<a href="<?php echo $qs->link ?>&amp;task=orders">
			<img src="<?php echo $qs->www ?>images/icon-48-user.png" alt="">			<span>Orders</span></a>
	</div>
</div>
<div class="icon-wrapper joomla3iconwrapper">
	<div class="icon joomla3icon">
		<a href="<?php echo $qs->link ?>&amp;task=stats">
			<img src="<?php echo $qs->www ?>images/stats.png" alt="">			<span>Statistics</span></a>
	</div>
</div>
<div class="icon-wrapper joomla3iconwrapper">
	<div class="icon joomla3icon">
		<a href="<?php echo $qs->link ?>&amp;task=help">
			<img src="<?php echo $qs->www ?>images/icon-48-user-profile.png" alt="">			<span>Help</span></a>
	</div>
</div></div>