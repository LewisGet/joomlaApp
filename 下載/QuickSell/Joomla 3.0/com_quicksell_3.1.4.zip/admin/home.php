<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Base
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
JToolbarHelper::title('QuickSell for Joomla - Upload files');

$document =& JFactory::getDocument();

$www = JURI::base() . 'components/com_quicksell/';


$document->addScript($qs->www  . 'js/main.js');



?><form method="POST" target="">
    <div id="uploader">
        <p>You browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 support.</p>
    </div>
    </form>


<?php 
//$qs->finish($items);
?>
