<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Base
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
JToolbarHelper::save('config','Save configuration');
//JToolbarHelper::media_manager( 'banners', $alt = 'Upload' );

if ($qs->j3) {
$document->addScriptDeclaration('
$(function() {
		//$(".iButton").iButton();
		$("div.iPhone").addClass("j3Config").removeClass("iPhone");
});	');
	} else {
$document->addScriptDeclaration('
		jQuery.noConflict();
		$jq = jQuery.noConflict();
$jq(function() {
		$jq(".iButton").iButton();
});	');
}




switch (JRequest::getVar('action')) {
	case "save":
		if ($qs->saveConfig(JRequest::get('post'))) {
			$mainframe->enqueueMessage('Configuration saved!');
			$qs->loadConfig();
		}
		break;
}
$groups = $qs->getGroups();
//print_r($qs->cfg);

?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="floatLeft">
<h1 class="configTitle">General Configuration</h1>
<div id="generalConfig" class="iPhone">
  <p>
  <label for="pp">PayPal account</label>
  <input name="pp" type="text" id="pp" value="<?php echo $qs->cfg['pp']; ?>">
  
</p>
<p>
  <label for="currency">Default Currency</label>
  <select name="currency" id="currency">
  <?php 
  foreach ($qs->ppcurrencies as $code => $name) {
  	?>
  	<option value="<?php echo $code;?>" <?php if ($qs->cfg['currency'] == $code) echo ' selected'; ?>><?php echo $name; ?></option>
  	<?php 
  }
  ?>
  </select>
</p>
<p>
  <label for="ppsandbox">Sandbox (test mode)</label>
<input type="checkbox" class="iButton" name="ppsandbox" <?php if ($qs->cfg['ppsandbox'] == 'on') { echo ' checked';} ?> id="ppsandbox">
</p>

<p>
  <label for="emailDelivery">Email Delivery</label>
<input type="checkbox" class="iButton" name="emailDelivery" <?php if ($qs->cfg['emailDelivery'] == 'on') { echo ' checked';} ?> id="emailDelivery">
</p>
<p>
  <label for="attachFile">Attach File(s)</label>
<input type="checkbox" class="iButton" name="attachFile" <?php if ($qs->cfg['attachFile'] == 'on') { echo ' checked';} ?> id="attachFile">
</p>

<p>
  <label for="useThankYouPage">Thank you page</label>
<input type="checkbox" class="iButton" name="useThankYouPage" <?php if ($qs->cfg['useThankYouPage'] == 'on') { echo ' checked';} ?> id="useThankYouPage">
</p>


</div>
<h1 class="configTitle">Optional Configuration</h1>
<div id="generalConfig" class="iPhone">


<p>
  <label for="requireRegistration">Require Registration?</label>
  <input type="checkbox" class="iButton" name="requireRegistration" <?php if ($qs->cfg['requireRegistration'] == 'on') { echo ' checked';} ?> id="requireRegistration">
</p>

<!--
<p>
  <label for="silentRegistration">Silent Registration</label>
  <input type="checkbox" class="iButton" name="silentRegistration" <?php if ($qs->cfg['silentRegistration'] == 'on') { echo ' checked';} ?> id="silentRegistration">
</p>
-->
<p>
  
  <label for="useVat">Use VAT</label>
<input type="checkbox" class="iButton" name="useVat" <?php if ($qs->cfg['useVat'] == 'on') { echo ' checked';} ?> id="useVat">
</p>
<p>
  <label for="tax">VAT Percentage</label>
  <input name="tax" type="text" id="tax" value="<?php echo @(float)$qs->cfg['tax']; ?>">
</p>
<p>
  <label for="downloads_per_order">Downloads per order</label>
  <input name="downloads_per_order" type="text" id="downloads_per_order" value="<?php echo $qs->cfg['downloads_per_order']; ?>">
</p>
<p>
  <label for="link_expiration">Link Expiration</label>
  <input name="link_expiration" type="text" id="link_expiration" value="<?php echo $qs->cfg['link_expiration']; ?>">
</p>
<p>
<label for="encryptPdf">Encrypt PDF</label>
<input type="checkbox" class="iButton" name="encryptPdf" <?php if ($qs->cfg['encryptPdf'] == 'on') { echo ' checked';} ?> id="encryptPdf">
</p>
<p>
<label for="allowPrint">Allow PDF Printing</label>
<input type="checkbox" class="iButton" name="allowPrint" <?php if ($qs->cfg['allowPrint'] == 'on') { echo ' checked';} ?> id="allowPrint">
</p>

<p>
  <label for="pdfOrientation">PDF Orientation</label>
<select name="pdfOrientation" id="pdfOrientation">
  <?php 
  foreach ($qs->pdfOrientations as $orientation => $name) {
  	?>
  	<option value="<?php echo $orientation;?>" <?php if ($qs->cfg['pdfOrientation'] == $orientation) echo ' selected'; ?>><?php echo $name; ?></option>
  	<?php 
  }
  ?>
</select>
</p>
  



</div>
</div>
<div class="floatLeft">
<h1 class="configTitle">Free Download Groups</h1>
<div id="generalConfig" class="iPhone">
<?php foreach ($groups as $row) {?>
<p>
	<label><?php echo $row->title; ?></label>
	<input type="checkbox" class="iButton" name="freeDownloadGroups[<?php echo $row->id; ?>]" <?php if ($qs->cfg['freeDownloadGroups'][$row->id] == 'on') { echo ' checked';} ?>>
</p>
<?php } ?>
</div>
</div>

<div class="floatLeft">
<h1 class="configTitle">PayPal settings (optional)</h1>
<div id="generalConfig" class="iPhone">
  <p>
      <label for="use_ssl">SSL encryption</label>
  <input type="checkbox" class="iButton" name="use_ssl" <?php if ($qs->cfg['use_ssl'] == 'on') { echo ' checked';} ?> id="use_ssl">
</p>
<p>
  <label for="use_curl">Use CURL</label>
<input type="checkbox" class="iButton" name="use_curl" <?php if ($qs->cfg['use_curl'] == 'on') { echo ' checked';} ?> id="use_curl">
</p>
<p>
  <label for="send_export">Send IPN Details</label>
<input type="checkbox" class="iButton" name="send_export" <?php if ($qs->cfg['send_export'] == 'on') { echo ' checked';} ?> id="send_export">
</p>
<p>
  <label for="cbt">Return button text</label>
  <input name="cbt" type="text" id="cbt" value="<?php echo $qs->cfg['cbt']; ?>">
</p>
<p>
  <label for="rm">Return Method</label>
<select name="rm" id="rm">
  <?php 
  foreach ($qs->rm as $rm => $name) {
  	?>
  	<option value="<?php echo $rm;?>" <?php if ($qs->cfg['rm'] == $rm) echo ' selected'; ?>><?php echo $name; ?></option>
  	<?php 
  }
  ?>
</select>
</p>

<p>
  <label for="lc">PayPal language</label>
<select name="lc" id="lc">
  <?php 
  foreach ($qs->lc as $lc => $name) {
  	?>
  	<option value="<?php echo $lc;?>" <?php if ($qs->cfg['lc'] == $lc) echo ' selected'; ?>><?php echo $name; ?></option>
  	<?php 
  }
  ?>
</select>
</p>

</div>
</div>



<div style="clear:both; margin-top:15px; width:100%; display:block;">
<h1 style="margin-top:15px; margin-left:0px;"><br />Email Delivery Settings</h1>
<h2>Email Subject</h2>
<input type="text" name="emailDeliverySubject" value="<?php echo $qs->cfg['emailDeliverySubject']; ?>" style="width:100%;" />
<h2>Email Body</h2>
<?php 
$editor = JFactory::getEditor();
echo $editor->display( 'emailDeliveryBody', $qs->cfg['emailDeliveryBody'], '100%', '400', '20', '20');
?>
<div style="clear:both; text-align:center;">
<h4>Please note, you can use the text "%%downloadlink%%" (without quotes) in the Email Delivery text and it will be replaced by download link(s).</h4>
</div>
</div>
<div style="clear:both;">
<h2>Thank you page content</h2>
<?php 
$editor = JFactory::getEditor();
echo $editor->display( 'thankYouPage', $qs->cfg['thankYouPage'], '100%', '400', '20', '20');
?>
<div style="clear:both; text-align:center;""><h4>You can use the text %%downloadlink%% in the thank you page, and it will be replaced with the download link(s).</h4></div>
</div>
<div style="clear:both;">
<img src="<?php echo $qs->www; ?>images/please_note.png" style="margin-top:15px;" />
</div>
<input type="hidden" name="action" value="save" />
<input type="hidden" name="option" value="com_quicksell" />
<input type="hidden" name="task" id="task" value="config" />
</form>