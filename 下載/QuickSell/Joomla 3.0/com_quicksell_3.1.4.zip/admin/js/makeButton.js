var $jq = jQuery.noConflict();

$jq(function() {
	//$jq(".iButton").iButton();
	$jq(':radio[name=ppbutton]').click(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/\}(.*?)\{/g, "}"  + $jq(this).attr('src') + "{"));
	});
	$jq(':radio[name=ppbutton]').first().click();
	$jq('#title').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/title="(.+?)??"/g, 'title="' + $jq(this).val() + '"'));
	});
	$jq('#price').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/price="(.+?)??"/g, 'price="' + $jq(this).val() + '"'));
	});
	$jq('#currency').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/currency="(.+?)??"/g, 'currency="' + $jq(this).val() + '"'));
	});
	$jq('#customPayPal').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/customPayPal="(.+?)??"/g, 'customPayPal="' + $jq(this).val() + '"'));
	});
	$jq('#discount_rate').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/discount_rate="(.+?)??"/g, 'discount_rate="' + $jq(this).val() + '"'));
	});
	$jq('#return_url').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/return_url="(.+?)??"/g, 'return_url="' + $jq(this).val() + '"'));
	});
	$jq('#notification_email').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/notification_email="(.+?)??"/g, 'notification_email="' + $jq(this).val() + '"'));
	});
	$jq('#rm').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/rm="(.+?)??"/g, 'rm="' + $jq(this).val() + '"'));
	});
	$jq('#cbt').change(function() {
		var subject = $jq('#code').val();
		$jq('#code').val(subject.replace(/cbt="(.+?)??"/g, 'cbt="' + $jq(this).val() + '"'));
	});
	$jq('#requireRegistration').change(function() {
		var subject = $jq('#code').val();
		if ($jq(this).is(':checked')) {
			$jq('#code').val(subject.replace(/requireRegistration="(.+?)??"/g, 'requireRegistration="on"'));
		} else {
			$jq('#code').val(subject.replace(/requireRegistration="(.+?)??"/g, 'requireRegistration=""'));
		}
	});

	$jq('#emailDelivery').change(function() {
		var subject = $jq('#code').val();
		if ($jq(this).is(':checked')) {
			$jq('#code').val(subject.replace(/emailDelivery="(.+?)??"/g, 'emailDelivery="on"'));
		} else {
			$jq('#code').val(subject.replace(/emailDelivery="(.+?)??"/g, 'emailDelivery=""'));
		}
	});
	$jq('textarea').click(function() {
		$jq(this).focus();
		$jq(this).select();
		
	});
	
});