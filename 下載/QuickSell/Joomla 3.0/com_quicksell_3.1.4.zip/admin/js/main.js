jQuery.noConflict();

$jq = jQuery.noConflict();
$jq(function() {
	$jq("#uploader").pluploadQueue({
		// General settings
		runtimes : 'gears,flash,silverlight,browserplus,html5',
		url : 'index.php?&option=com_quicksell&task=upload&format=raw',
		max_file_size : '5000mb',
		chunk_size : '1mb',
		unique_names : false,

		// Resize images on clientside if we can
		//resize : {width : 320, height : 240, quality : 90},

		// Specify what files to browse for
		filters : [
			{title : "All files", extensions : "*"},
			{title : "Image files", extensions : "jpg,gif,png"},
			{title : "PDF Documents", extensions : "pdf"},
			{title : "Zip files", extensions : "zip"}

		],

		// Flash settings
		flash_swf_url : 'components/com_quicksell/js/plupload.flash.swf',

		// Silverlight settings
		silverlight_xap_url : 'components/com_quicksell/plupload/js/plupload.silverlight.xap'
	});

	// Client side form validation
	$jq('form').submit(function(e) {
        var uploader = $jq('#uploader').pluploadQueue();

        // Files in queue upload them first
        if (uploader.files.length > 0) {
            // When all files are uploaded submit form
            uploader.bind('StateChanged', function() {
                if (uploader.files.length === (uploader.total.uploaded + uploader.total.failed)) {
                    $jq('form')[0].submit();
                }
            });
                
            uploader.start();
        } else {
            //alert('You must queue at least one file.');
        }

        return false;
    });
    var uploader = $jq('#uploader').pluploadQueue();
    uploader.bind('UploadComplete', function(up, files) {
    	//$jq('#uploader').slideUp();
    	setTimeout("document.location = 'index.php?&option=com_quicksell&task=files&uploaded=1'",1500);
    });
    uploader.bind('FileUploaded', function(up, file) {
    	//console.log(file);
    	$jq.get('index.php?&option=com_quicksell&task=addToDb&filename=' + file.name);
    });

    $jq("#finish").click(function() {
    	$.post("index.php?&option=com_quicksell&task=finish", $jq("#priceForm").serialize(), function(data) {
    		  $jq('#step2').slideUp();
    		  $jq('#step3').html(data).slideDown();
    		  $jq(".pagetitle h2").hide().text("QuickSell for Joomla - Your Buy Now buttons (Step 3/3)").fadeIn();
    		  $jq('.fileFinish').hover(function() {
    			      $jq(this).addClass('hoverUp');
    			    }, function() {
    			      $jq(this).removeClass('hoverUp');
    			    });
    		  common();
    		  $jq("input[type=radio], textarea, select, button").uniform();
    		  $jq("textarea").focus(function(){
    			    // Select field contents
    			    this.select();
    		  });
    	});
    	
    });
    $jq("input[type=radio], textarea, select, button").uniform();
    common();
});
function common() {
	  ppbuttonclick();
	  $jq(".tip, .tiptip").tipTip();
	  $jq('.ppbutton').click();
}
function ppbuttonclick() {
    $jq('.ppbutton').click(function() {
    	var code = $jq('.code' + $jq(this).attr('rel'));
    	var val = code.val();
    	//val = val.replace(/\}([\s\S]+?)\{/ig, "}" + $jq(this).attr('value') + "{");
    	var result = val.replace(/\}(.+?)?\{/ig, "}" + $jq(this).attr('value') + "{");
    	//alert(val);
    	code.val(result);
    });	
}