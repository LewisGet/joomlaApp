

CREATE TABLE IF NOT EXISTS `#__quicksell_bundles` (
  `file_id` int(11) NOT NULL,
  `files` text NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `#__quicksell_config` (
  `name` varchar(32) NOT NULL,
  `value` longtext NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `#__quicksell_config`
--

INSERT IGNORE INTO `#__quicksell_config` (`name`, `value`) VALUES
('config', 'a:19:{s:2:"pp";s:31:"seller_1295423751_biz@motov.net";s:8:"currency";s:3:"EUR";s:15:"useThankYouPage";s:2:"on";s:3:"tax";s:2:"20";s:19:"downloads_per_order";s:1:"9";s:15:"link_expiration";s:9:"168 hours";s:14:"pdfOrientation";s:8:"portrait";s:18:"freeDownloadGroups";a:1:{i:8;s:2:"on";}s:7:"use_ssl";s:2:"on";s:8:"use_curl";s:2:"on";s:11:"send_export";s:2:"on";s:3:"cbt";s:14:"Return to site";s:2:"rm";s:1:"0";s:20:"emailDeliverySubject";s:32:"Email Delivery - Order complete!";s:17:"emailDeliveryBody";s:204:"PGgxPlRoYW5rIHlvdSBmb3IgeW91ciBvcmRlciE8L2gxPg0KPHA+UGxlYXNlIGNoZWNrIG9uIHRoZSBhdHRhY2htZW50LCBpdCdzIGEgY29weSBvZiB0aGUgZmlsZSB5b3Ugb3JkZXJlZC48L3A+DQo8cD5UaGFua3MhPC9wPg0KPHA+JSVkb3dubG9hZGxpbmslJTwvcD4=";s:12:"thankYouPage";s:169:"<h1>Thank you for your order!</h1>\r\n<p>You have successfully ordered! Please use the link(s) below to download your copy:</p>\r\n<p>%%downloadlink%%</p>\r\n<p>Thank you!</p>";s:6:"action";s:4:"save";s:6:"option";s:13:"com_quicksell";s:4:"task";s:6:"config";}');

-- --------------------------------------------------------

--
-- Table structure for table `#__quicksell_files`
--

CREATE TABLE IF NOT EXISTS `#__quicksell_files` (
  `file_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) DEFAULT NULL,
  `published` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`file_id`),
  UNIQUE KEY `filename` (`filename`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=246 ;



-- --------------------------------------------------------

--
-- Table structure for table `#__quicksell_orders`
--

CREATE TABLE IF NOT EXISTS `#__quicksell_orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mc_gross` float NOT NULL,
  `protection_eligibility` varchar(32) NOT NULL,
  `payer_id` varchar(255) NOT NULL,
  `tax` float NOT NULL,
  `payment_date` bigint(22) NOT NULL,
  `payment_status` varchar(32) NOT NULL,
  `charset` varchar(32) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `mc_fee` float NOT NULL,
  `notify_version` varchar(32) NOT NULL,
  `custom` text NOT NULL,
  `payer_status` varchar(32) NOT NULL,
  `business` varchar(255) NOT NULL,
  `num_cart_items` int(11) NOT NULL,
  `verify_sign` varchar(255) NOT NULL,
  `payer_email` varchar(255) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `payer_business_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `receiver_email` varchar(255) NOT NULL,
  `payment_fee` float NOT NULL,
  `receiver_id` varchar(255) NOT NULL,
  `mc_currency` varchar(3) NOT NULL,
  `residence_country` varchar(32) NOT NULL,
  `transaction_subject` text NOT NULL,
  `published` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `downloads` int(11) DEFAULT '0',
  `key` varchar(32) NOT NULL,
  `notification_email` varchar(255) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=73 ;

