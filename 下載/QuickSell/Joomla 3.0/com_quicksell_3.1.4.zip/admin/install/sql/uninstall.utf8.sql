drop table #__quicksell_orders;
drop table #__quicksell_config;
drop table #__quicksell_files;
drop table #__quicksell_bundles;