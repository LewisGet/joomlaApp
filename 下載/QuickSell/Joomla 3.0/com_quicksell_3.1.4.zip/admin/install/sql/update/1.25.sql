CREATE TABLE IF NOT EXISTS `#__quicksell_bundles` (
  `file_id` int(11) NOT NULL,
  `files` text NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;