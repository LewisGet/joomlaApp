<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Base
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
include_once 'class.php';

JTable::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.'/tables');

$task = JRequest::getVar('task');
$option = 'com_quicksell';





error_reporting(0);






$qs = new QuickSell();
$document =& JFactory::getDocument();
$mainframe =& JFactory::getApplication();

$document->addStyleSheet($qs->www . 'js/jquery.plupload.queue/css/jquery.plupload.queue.css');
$document->addStyleSheet($qs->www . 'css/uniform.default.css');
$document->addStyleSheet($qs->www . 'css/tipTip.css');

if ( version_compare( JVERSION, '3.0.0', '>=' ) == 1) {
	$document->addStyleSheet($qs->www . 'css/joomla3.css');
	$qs->j3 = 1;
}

///
$document->addScript('https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js');
$document->addScript('https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js');

$document->addScript('http://bp.yahooapis.com/2.4.21/browserplus-min.js');
$document->addScript($qs->www . 'js/plupload.full.js');
$document->addScript($qs->www . 'js/jquery.plupload.queue/jquery.plupload.queue.js');
$document->addScript($qs->www . 'js/jquery.uniform.min.js');
$document->addScript($qs->www . 'js/jquery.tipTip.minified.js');

$document->addScript($qs->www . 'ibutton/lib/jquery.ibutton.js');
$document->addScript($qs->www . 'ibutton/lib/jquery.easing.1.3.js');
$document->addScript($qs->www . 'ibutton/lib/jquery.metadata.js');
$document->addStyleSheet($qs->www . "ibutton/css/jquery.ibutton.css");


$document->addStyleDeclaration('.icon-48-generic {
background-image: url(' . $qs->www . '/images/quicksell_logo.png) !important;
}
');

$document->addStyleSheet($qs->www . 'css/style.css');

JToolbarHelper::title('QuickSell for Joomla');
//JRequest::getVar('task') == '' || JRequest::getVar('task') == 'home'
JSubMenuHelper::addEntry("Welcome", 'index.php?&option=com_quicksell&task=landing',JRequest::getVar('task') == '' || JRequest::getVar('task') == 'landing');
JSubMenuHelper::addEntry("Configure", 'index.php?&option=com_quicksell&task=config',JRequest::getVar('task') == 'config');
JSubMenuHelper::addEntry("Upload", 'index.php?&option=com_quicksell&task=home',JRequest::getVar('task') == 'home');
JSubMenuHelper::addEntry("Files", 'index.php?&option=com_quicksell&task=files',JRequest::getVar('task') == 'files');
JSubMenuHelper::addEntry("Orders", 'index.php?&option=com_quicksell&task=orders',JRequest::getVar('task') == 'orders');
JSubMenuHelper::addEntry("Statistics", 'index.php?&option=com_quicksell&task=stats',JRequest::getVar('task') == 'stats');
JSubMenuHelper::addEntry("Help", 'index.php?&option=com_quicksell&task=help',JRequest::getVar('task') == 'help');

switch ($task) {
	case "upload":
		include_once('upload.php');
		break;
	case "landing":
		include_once('landing.php');
		break;
	case "home":
		include_once('home.php');
		break;
	case "finish":
		include_once('finish.php');
		break;
	case "files":
		include_once('files.php');
		break;
	case "orders":
		include_once('orders.php');
		break;
	case "help":
		include_once('help.php');
		break;
	case "config":
		$configfile = JPATH_COMPONENT_ADMINISTRATOR.'/'.'config.php';
		include_once($configfile);
		break;
	case "addToDb":
		include_once('addToDb.php');
		break;
	case "makeButton":
		include_once('makeButton.php');
		break;
	case "publishfile":
		include_once('publishfile.php');
		break;
	case "unpublishfile":
		include_once('unpublishfile.php');
		break;
	case "deletefiles":
		include_once('deletefiles.php');
		break;
	case "publishorder":
		include_once('publishorder.php');
		break;
	case "unpublishorder":
		include_once('unpublishorder.php');
		break;
	case "deleteorders":
		include_once('deleteorders.php');
		break;
	case "ipn":
		include('ipn.php');
		break;
	case "stats":
		include('stats.php');
		break;
	case "makeBundle":
		include('makeBundle.php');
		break;
	case "removeBundle":
		include('removeBundle.php');
		break;
	default:
		include_once('landing.php');
		break;
}
?>