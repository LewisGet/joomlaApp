<?php 
$table = JTable::getInstance('Files', 'Table');
$filename = preg_replace('/[^\w\.\s\-_]+/', '', JRequest::getVar('filename'));

$table->reset();
$table->set('filename',$filename);
$table->set('published',1);
$table->store();

//mail('deian@motov.net','debug',print_r(JRequest::get('get'),true));
?>