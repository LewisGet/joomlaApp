<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Base
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

jimport('joomla.application.component.controller');

/**
 * QuickSell Controller.
 *
 * @package    QuickSell
 * @subpackage Controllers
 */

JTable::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.DS.'tables');
if (defined('DS') == false) {
	define('DS','/');
}
require_once(JPATH_COMPONENT_ADMINISTRATOR . DS . 'class.php');
error_reporting(E_ALL);
class QuickSellController extends JControllerLegacy
{
	function uploadprocess() {
		$post = JRequest::get('post');
		$my =& JFactory::getUser();
		die(print_r($post,true));
	}
	function ipn() {
		require_once 'ipnlistener.php';
		$listener = new IpnListener();
		$qs = new QuickSell();
		if (@$qs->cfg['ppsandbox'] == 'on') {
			$listener->use_sandbox = true;
		}
		if ($qs->cfg['use_ssl'] == 'on') {
			$listener->use_ssl = true;
		} else {
			$listener->use_ssl = false;
		}
		if ($qs->cfg['use_curl'] == 'on') {
			$listener->use_curl = true;
		} else {
			$listener->use_curl = false;
		}

		try {
			$listener->requirePostMethod();
			$verified = $listener->processIpn();
		} catch (Exception $e) {
			error_log($e->getMessage());
			exit(0);
		}
		if ($qs->cfg['verify_transactions'] != 'on') {
			$verified = 1;
		}
		if ($verified) {
			/*
			 Once you have a verified IPN you need to do a few more checks on the POST
			fields--typically against data you stored in your database during when the
			end user made a purchase (such as in the "success" page on a web payments
					standard button). The fields PayPal recommends checking are:
		
			1. Check the $_POST['payment_status'] is "Completed"
			2. Check that $_POST['txn_id'] has not been previously processed
			3. Check that $_POST['receiver_email'] is your Primary PayPal email
			4. Check that $_POST['mc_gross'] and $_POST['payment_currency']
			are correct
		
			Since implementations on this varies, I will leave these checks out of this
			example and just send an email using the getTextReport() method to get all
			of the details about the IPN.
			*/
			$errors = 0;
			$custom = explode("|", base64_decode(JRequest::getVar('custom')));
			$jc = new JConfig();
			
			
			$post = JRequest::get('post');
			//mail('deian@motov.net','ipn',print_r($_POST,true) . print_r($custom,true));
				
			$paypalEmail = $custom['6'];
			if ($paypalEmail == '') {
				$paypalEmail = $qs->cfg['pp'];
			}
			$filename = $custom['0'];
			$user_id = $custom['1'];
			$my =& JFactory::getUser($user_id);
			$mc_gross = $custom['2'];
			if ($mc_gross == 0) {
				die();
			}
			$currency = $custom['3'];
			
			////error_log(print_r($qs->cfg, true));
			////error_log(print_r($custom, 1));
			if ($qs->cfg['emailDelivery'] != 'on') {
				$emailDelivery = $custom['4'];
			} else {
				$emailDelivery = 'on';
			}
			
			$notification_email = $custom['7'];
			$md5 = $custom['8'];
			array_pop($custom);
			$custom = implode("|", $custom);
			$check = md5($custom . $jc->secret);
			
			if ($md5 != $check) {
				$errors++;
			}
			error_log($custom . 'errors ' . $errors . " md5 $md5 check $check");
			//if ($post['payment_status'] != 'Completed' || $qs->txn_id_exists($post['txn_id']) || $post['receiver_email'] != $paypalEmail || ($post['mc_gross'] - $post['tax'] + $post['discount'] != $mc_gross)) {
			if ($post['payment_status'] != 'Completed' || $qs->txn_id_exists($post['txn_id']) || strtolower($post['receiver_email']) != strtolower($paypalEmail) || ($post['mc_gross'] - $post['tax'] + $post['discount'] != $mc_gross)) {
				$errors++;
			}
			//mail('deian@motov.net','errors',$errors . "\n" . $post['payment_status'] . "\n" . $post['txn_id'] . "\n" . $post['receiver_email'] . "\n" . $paypalEmail . "\n" . $post['mc_gross'] . "\n" . $mc_gross);
			if ($qs->cfg['send_export'] == 'on') {
				mail($post['receiver_email'], 'Verified Order on ' . $_SERVER["SERVER_NAME"], $listener->getTextReport());
	 			//notification email update since 1.21
				if ($notification_email != '') {
					mail($notification_email, 'Verified Order on ' . $_SERVER["SERVER_NAME"], $listener->getTextReport());
				}
			}
			
			
			$table = JTable::getInstance('orders', 'Table');
			$table->reset();
			$table->bind(JRequest::get('post'));
			$table->set('user_id',$user_id);
			$table->set('payment_date',time());
			$table->set('published','1');
			$table->set('downloads','0');
			$table->set('filename',$filename);
			$table->set('notification_email',$notification_email);
			$table->set('key',JRequest::getVar('key'));
			
			if ($errors == 0 && $table->get('payment_status') == 'Completed') {
	 			if (!$table->store()) {
	 				//mail('deian@motov.net','error', $table->getError() );
	 			}
	 			$u =& JURI::getInstance( );
	 			
	 			//error_log('before email delivery');
	 			if ($emailDelivery == 'on') {
	 				
	 				if ($my->id == 0) {
	 					$emailDeliveryEmail = $post['payer_email'];
	 				} else {
	 					$emailDeliveryEmail = $my->email;
	 				}
	 				////error_log($emailDeliveryEmail);
	 				$attachment = $qs->cfg['storageDir'] . DS . $filename;
	 				
	 				if (pathinfo($attachment,PATHINFO_EXTENSION) == 'pdf' && $qs->cfg['encryptPdf'] == 'on') {
	 					$password = $emailDeliveryEmail;
	 					$destfile = $jc->tmp_path . DS . md5($emailDeliveryEmail) . '_' . basename($attachment);
	 					require_once('fpdi' . DS . 'FPDI_Protection.php');
	 					$pdf = new FPDI_Protection();
	 					if ($qs->cfg['pdfOrientation'] == 'portrait') {
	 						$pdf->FPDF('P', 'in', array('8','11'));
	 					} else {
	 						$pdf->FPDF('P', 'in', array('11','8'));
	 					}
	 					$pagecount = $pdf->setSourceFile($attachment);
	 					for ($loop = 1; $loop <= $pagecount; $loop++) {
	 						$tplidx = $pdf->importPage($loop);
	 						$pdf->addPage();
	 						$pdf->useTemplate($tplidx);
	 					}
	 					
	 					if ($qs->cfg['allowPrint'] == 'on') {
		 					$pdf->SetProtection(array('print' => 'print'), $password, "");
	 					} else {
		 					$pdf->SetProtection(array(), $password);
	 					}
	 					$pdf->Output($destfile, 'F');
	 					$attachment = $destfile;
	 				}
	 				
	 				
	 				$conf =& JFactory::getConfig();
	 				$mail = JFactory::getMailer();
	 				//error_log('line - ' . __LINE__);
	 				$mail->IsHTML(true);
	 				//$mail->to = array();
	 				$mail->addRecipient(JRequest::getVar('payer_email'));
	 				//error_log('line - ' . __LINE__);
	 				$file = $qs->file($table->filename);
	 				if ($qs->bundle($file->file_id) == '') {
	 					$downloadlink = JRoute::_($u->getScheme() . '://' . $u->getHost() . substr($qs->downloadlink($table,'&filename=' . $file->filename),0));
	 				} else {
	 					foreach ($qs->bundleFiles($file->file_id) as $bundleFile) {
	 						//$downloadlink .= JRoute::_(JURI::root() . substr($qs->downloadlink($table,'&filename=' . $bundleFile->filename),1)) . "<br />";
	 						$downloadlink .= '<a class="downloadlink" href="' . JRoute::_($u->getScheme() . '://' . $u->getHost() . substr($qs->downloadlink($table,'&filename=' . $bundleFile->filename),0)) . '">Download <em>' . $table->item_name . ' (' . $bundleFile->filename . ')</em></a><br />';
	 					}
	 				}
	 				//error_log('line - ' . __LINE__);
	 				
	 				$qs->cfg['emailDeliveryBody'] = str_replace('%%downloadlink%%', $downloadlink, $qs->cfg['emailDeliveryBody'], $qs->cfg['emailDeliveryBody']);
	 				$mail->setBody($qs->cfg['emailDeliveryBody']);
	 				
	 				$mail->setSubject($qs->cfg['emailDeliverySubject']);
	 				if ($conf->getValue('config.mailer') == 'smtp') {
	 					$mail->useSMTP($conf->getValue('config.smtpauth'),$conf->getValue('config.smtphost'),$conf->getValue('config.smtpuser'),$conf->getValue('config.smtppass'),$conf->getValue('config.smtpsecure'),$conf->getValue('config.smtpport'));
	 				}
	 				//error_log('line - ' . __LINE__);
	 				if ($qs->cfg['attachFile'] == 'on') {
	 					$mail->addAttachment($attachment);
	 				}
	 				$mail->setSender($conf->getValue('config.mailfrom'));
	 				////error_log(print_r($mail, 1));
	 				//error_log('before send');
	 				if ($mail->Send()) {
		 				//error_log('success mail to' . $emailDeliveryEmail);
	 				} else {
		 				//error_log('mail not sent to ' . $emailDeliveryEmail);
	 				}
	 				//error_log('email routine over');
	 				
	 			}
			}
		
		} else {
			/*
			 An Invalid IPN *may* be caused by a fraudulent transaction attempt. It's
			a good idea to have a developer or sys admin manually investigate any
			invalid IPN.
			*/
			mail($post['receiver_email'], 'Invalid IPN', $listener->getTextReport());
		}

	}
	function readfile_chunked( $filename, $retbytes = true ) {
		$chunksize = 1 * (1024 * 1024); // how many bytes per chunk
		$buffer = '';
		$cnt = 0;
		$handle = fopen( $filename, 'rb' );
		if ( $handle === false ) {
			return false;
		}
		ob_end_clean(); //added to fix ZIP file corruption
		ob_start(); //added to fix ZIP file corruption
		header( 'Content-Type:' ); //added to fix ZIP file corruption
		while ( !feof( $handle ) ) {
			$buffer = fread( $handle, $chunksize );
			//$buffer = str_replace("ï»¿","",$buffer);
			echo $buffer;
			ob_flush();
			flush();
			if ( $retbytes ) {
				$cnt += strlen( $buffer );
			}
		}
		$status = fclose( $handle );
		if ( $retbytes && $status ) {
			return $cnt; // return num. bytes delivered like readfile() does.
		}
		return $status;
	}
	function download() {
		$qs = new QuickSell();
		$my =& JFactory::getUser();
		$order_id = JRequest::getInt('order_id');
		$key = JRequest::getVar('key');
		
		$jc = new JConfig();
		
		if ($order_id > 0) {
			$table = JTable::getInstance('orders', 'Table');
			$table->load($order_id);
			$password = $table->payer_email;
			//$file = $qs->cfg['storageDir'] . DS . $table->filename;			
			//todo: check if it's bundled
			$filename = preg_replace('/[^\w\.\s\-_]+/', '', JRequest::getVar('filename'));
			if ($filename == '') {
				$filename = $table->filename;
			}
			$file = $qs->cfg['storageDir'] . DS . $filename;
			if ($key != $table->key) {
				die();
			}
		} else if ($qs->inFreeDownloadGroup($my->id)) {
			$password = $my->email;
			$file = $qs->cfg['storageDir'] . DS . JRequest::getVar('filename');	
		}
		if (pathinfo($file,PATHINFO_EXTENSION) == 'pdf' && @$qs->cfg['encryptPdf'] == 'on') {
			$destfile = $jc->tmp_path . DS . 'protected_' . basename($file,'.pdf');
			require_once('fpdi' . DS . 'FPDI_Protection.php');
			$pdf = new FPDI_Protection();
			if ($qs->cfg['pdfOrientation'] == 'portrait') {
				$pdf->FPDF('P', 'in', array('8','11'));
			} else {
				$pdf->FPDF('P', 'in', array('11','8'));
			}
			$pagecount = $pdf->setSourceFile($file);
			for ($loop = 1; $loop <= $pagecount; $loop++) {
				$tplidx = $pdf->importPage($loop);
				$pdf->addPage();
				$pdf->useTemplate($tplidx);
			}
	 		//$pdf->SetProtection(array(), $password);
	 		if ($qs->cfg['allowPrint'] == 'on') {
		 	$pdf->SetProtection(array('print' => 'print'), $password, "");
	 		} else {
		 		$pdf->SetProtection(array(), $password);
	 		}
	 		$pdf->Output($destfile, 'F');
			$isPdf = true;
		}
		
		//die($file);
		if (($qs->canDownload($table->order_id) && file_exists($file) && $table->published == 1) || $qs->inFreeDownloadGroup($my->id)) {
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename='.basename($file));
			header('Content-Transfer-Encoding: binary');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			ob_clean();
			flush();
			
			if ($isPdf == true) {
				//readfile($destfile);
				$this->readfile_chunked($destfile);
			} else {
				$this->readfile_chunked($file);
				//readfile($file);
			}
			
			$qs->countDownload($table->order_id);
			exit;
		} else {
			JError::raiseError('403','Sorry, you have reached the maximum amount of downloads for this order, you need to purchase the file again.');
		}
	}}//class
	
