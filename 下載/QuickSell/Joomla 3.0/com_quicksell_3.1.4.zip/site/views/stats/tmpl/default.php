<?php 
$document = JFactory::getDocument();
$today = strtotime("tomorrow");
$start_period = strtotime("-30 days",$today);
//echo "<h2>" . date("F, j Y H:i:s",$today) . " to " . date("F, j Y H:i:s",$start_period);
$usedCurrencies = $this->qs->getUsedCurrencies();

//$document->addScript('administrator/components/com_quicksell/js/main.js');
$document->addScript('http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js');
$my =& JFactory::getUser();
$db =& JFactory::getDBO();

//print_r($usedCurrencies);
//die('ddd'  . __LINE__);
?>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Year');
        <?php
	        //die('ddd'  . __LINE__);
        	foreach ($usedCurrencies as $row) {
	        	//die('ddd'  . __LINE__);
	        	echo "data.addColumn('number', '{$row->mc_currency}');\r\n";
	        	//die('ddd'  . __LINE__);
        	}
        ?>
        
        data.addRows([
<?php 

//die('ddd'  . __LINE__);

for ($i=0;$i<31;$i++) {
	unset($todayPerCurrency);
	$d++;
	$dstart = strtotime("-$d days",$today);
	$dend = $dstart + 86400;
	$date = date("M/d/Y",$dstart);
	foreach ($usedCurrencies as $row) {
		$mc_currency = $row->mc_currency;
		$db->setQuery("select sum(mc_gross) from #__quicksell_orders where mc_currency = '{$row->mc_currency}' and payment_date between $dstart and $dend and notification_email = '" . $my->email . "'");
		//echo ($db->getQuery());
		$todayPerCurrency[] = floatval($db->loadResult());
	}
	$out[] = "['$date', " . implode(", ",$todayPerCurrency) . "]";
	
}
echo implode(", \r\n", $out);
?>
          ]);

        var options = {
          width: jQuery('#chart_div').parent().width(), height: 500,
          title: 'Sales for the last 30 days',
          hAxis: {title: 'Year', titleTextStyle: {color: 'red'}}
        };

        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
<div id="chart_div"></div>