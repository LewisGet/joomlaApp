<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Views
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

//-- Import the JView class
jimport('joomla.application.component.view');

/**
 * HTML View class for the QuickSell Component.
 *
 * @package QuickSell
 */
class quicksellVieworder extends JViewLegacy
{
    /**
     * QuickSell view display method.
     *
     * @param string $tpl The name of the template file to parse;
     *
     * @return void
     */
    public function display($tpl = null)
    {
    	$this->qs = new QuickSell();
        $this->greeting = "Hello World!";

        parent::display($tpl);
    }//function
}//class
