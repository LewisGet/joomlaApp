<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Views
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
$my =& JFactory::getUser();
$mainframe =& JFactory::getApplication();
$params =& $mainframe->getPageParameters('com_quicksell');

defined('_JEXEC') || die('=;)');
//print_r($params);
$file_id = JRequest::getVar('file_id');
//die($file_id);
$file = $this->qs->fileById($file_id);

//die('dsa');
//die(print_r($file,true));
$array = array(
		'2' => $file->filename,
		'4' => $params->get('price'),
		'6' => $params->get('title'),
		'8' => $params->get('currency'),
		'10' => $params->get('customPaypal'),
		'12' => $params->get('emailDelivery'),
		'14' => $params->get('requireRegistration'),
		'16' => $params->get('discount_rate'),
		'18' => $params->get('return_url')
);
if ($array[8] == 0) {
	$array[8] = $this->qs->cfg['currency'];
}
if ($array[10] == '') {
	$array[10] = $this->qs->cfg['pp'];
}
//die(print_r($array,true));
error_reporting(0);
echo $this->qs->makeForm($array,1);
?>