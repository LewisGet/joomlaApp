<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Views
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
$my =& JFactory::getUser();
$mainframe =& JFactory::getApplication();
$doc = JFactory::getDocument();
$params =& $mainframe->getPageParameters('com_quicksell');

defined('_JEXEC') || die('=;)');

//$file = $this->qs->fileById(JRequest::getInt('file_id'));

$row =& JTable::getInstance('orders', 'Table');	
$row->loadByKey(JRequest::getVar('key'));
$file = $this->qs->file($row->filename);
//print_r($file);
$u =& JURI::getInstance( );
//$downloadlink = JRoute::_($u->getScheme() . '://' . $u->getHost() . substr($this->qs->downloadlink($row,'&filename=' . $file->filename),0));



$file = $this->qs->file($row->filename);
	 				if (@$this->qs->bundle($file->file_id) == '') {
	 					$downloadlink = '<a class="downloadlink" href="' . JRoute::_($u->getScheme() . '://' . $u->getHost() . substr(@$this->qs->downloadlink($row,'&filename=' . $file->filename),0)) . '">Download <em>' . $row->item_name . ' (' . @$file->filename . ')</em></a><br />';
	 				} else {
	 					foreach ($this->qs->bundleFiles($file->file_id) as $bundleFile) {
	 						//$downloadlink .= JRoute::_(JURI::root() . substr($this->qs->downloadlink($row,'&filename=' . $bundleFile->filename),1)) . "<br />";
	 						@$downloadlink .= '<a class="downloadlink" href="' . JRoute::_($u->getScheme() . '://' . $u->getHost() . substr($this->qs->downloadlink($row,'&filename=' . $bundleFile->filename),0)) . '">Download <em>' . $row->item_name . ' (' . $bundleFile->filename . ')</em></a><br />';
	 					}
	 				}
if ($row->key == '') {
	//print_r($row);
	$mainframe->enqueueMessage('<b>Your order is not confirmed yet, this page will refresh in 5 seconds!</b> Please do not navigate away from the page until we receive your order confirmation.','info');
	$js = 'setTimeout("location.reload(true);",5000);';
	$doc->addScriptDeclaration($js);
	$downloadlink = '<script type="text/javascript">
	' . $js . '
			</script>';
	//JError::raiseError('No such order!',403);
} else {
	echo str_replace('%%downloadlink%%',$downloadlink,$this->qs->cfg['thankYouPage']);
}



?>