<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSellButtons
 * @subpackage Base
 * @author     Deian Motov {@link http://motov.net}
 * @author     Created on 13-Nov-2011
 * @license    GNU/GPL
 */

//-- No direct access
error_reporting(0);

defined('_JEXEC') || die('=;)');

jimport('joomla.plugin.plugin');

/**
 * Content Plugin.
 *
 * @package    QuickSellButtons
 * @subpackage Plugin
 */
function makeButton($result) {
		require_once(JPATH_ADMINISTRATOR . DS . "components" . DS . 'com_quicksell' . DS . 'class.php');
		JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_quicksell'.DS.'tables');
		//echo '<pre>' . print_r($result,true) . '</pre>';
		return QuickSell::makeForm($result);
		
/* 		$jc = new JConfig();
		$qs = new QuickSell();
		$my =& JFactory::getUser();
		
		$return = JURI::base() . substr($_SERVER['REQUEST_URI'],1); 
    	$cancel_return = $return;
    	$notify_url = JURI::base() . "index.php?&option=com_quicksell&task=ipn";
    	$title = $result['3'];
    	$price = $result['2'];
    	$customPayPal = $result['5'];
    	if ($customPayPal == '') {
    		$customPayPal = $qs->cfg['pp'];
    	}
    	
    	//echo "<pre>" . print_r($result,true). "</pre>";
    	
    	$emailDelivery = $result['6'];
    	$requireRegistration = $result['7'];
    	$discount_rate = $result['8'];
		
    	$ppurl = "https://www.paypal.com/cgi-bin/webscr";    	
		if ($qs->cfg['ppsandbox'] == 'on') {
			$ppurl = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
		}
    	
		
    	$currency = $result['4'];
    	if ($currency == '') {
    		$currency = $qs->cfg['currency'];
    	}
    	$button = JURI::base() . 'administrator/components/com_quicksell/images/buttons/' . $result['9'];
    	$custom[] = $result['1'];
		$custom[] = (int)$my->id;
		$custom[] = $price;
		$custom[] = $currency;
		$custom[] = $emailDelivery;
		$custom[] = $requireRegistration;
		$custom[] = $customPayPal;
		
    	$custom = implode("|", $custom);
    	$custom .= "|" .  md5($custom . $jc->sectet);
    	
    	//echo $custom;
    	
    	$uniqueId = md5(microtime());
    	$pp = explode("@", $customPayPal);
    	$tax_rate = $qs->cfg['useVat'] == 'on' ? $qs->cfg['tax'] : '0';
    	$form = '
<form method="post" name="dmp_order_form" action="' . $ppurl . '">
 <input type="hidden" name="rm" value="2" />
 
 <input type="hidden" name="discount_rate" value="' . (int)$discount_rate . '" />
 
 <input type="hidden" name="cmd" value="_xclick" />
 <input type="hidden" name="charset" value="utf-8" />
 <input type="hidden" name="no_shipping" value="1"/>
 <input type="hidden" name="button_subtype" value="products" />
 <input type="hidden" name="return" value="' . $return . '"/>
<input type="hidden" name="cancel_return" value="' . $cancel_return . '"/>
<input type="hidden" name="notify_url" value="' . $notify_url. '"/>
<input type="hidden" name="item_name" value="' . $title . '"/>
<input type="hidden" name="item_number" value="1"/>
 <input type="hidden" name="tax_rate" value="' . $tax_rate . '" />
<input type="hidden" name="amount" value="' . $price . '"/>
<input type="hidden" name="upload" value="1"/>
<input type="hidden" name="custom" value="' . base64_encode($custom) . '"/>
<input type="hidden" name="business" id="' . $uniqueId . '" value=""/>
<input type="hidden" name="receiver_email" id="' . $uniqueId . '0xff" value=""/>
<input type="hidden" name="currency_code" value="' . $currency . '"/>
<input type="hidden" name="cbt" value="Click here to return to your download page!"/>
 <input type="hidden" name="no_note" value="1" />
<input type="image" onClick="document.getElementById(\'' . $uniqueId . '\').value = \'' . $pp[0] . '\' + String.fromCharCode(64) + \'' . $pp[1] . '\'; document.getElementById(\'' . $uniqueId . '0xff\').value = \'' . $pp[0] . '\' + String.fromCharCode(64) + \'' . $pp[1] . '\'; return true;" style="border:none;" src="' . $button . '" />
</form>';
    	
		$file = $qs->file($result['1']);
		if ($file->published == 0) {
			return false;
		}
		if ($my->id == 0 && $qs->cfg['requireRegistration'] == 'on') {
			return '<img src="' . $qs->www . '/images/warning.png" />';
		}
		$post = JRequest::get('post');
		$table = JTable::getInstance('orders', 'Table');
		if ($post['txn_id'] != '') {
			$txn_id = $post['txn_id'];
		} else {
			$txn_id = JRequest::getVar('tx','get');
		}

		$table->loadByTxn($txn_id);
		//print_r($table);
		
		$custom = $post['custom'];
		if ($custom == '') {
			$custom = JRequest::getVar('cm');
		}
		//print_r($post);
		$custom = explode("|", base64_decode($custom));
		$filename = $custom['0'];
		//print_r($file);
		if ($qs->canDownload($table->order_id) && $filename == $file->filename) {
			return '<a href="' . $qs->downloadlink($table) . '">Download <em>' . $table->item_name . ' (' . $table->filename . ')</em></a>';
		}
		if ($qs->inFreeDownloadGroup($my->id)) {
			return '<a href="' . $qs->downloadlink($table) . '&filename=' . $file->filename . '">Download <em>' . $title . ' (' . $file->filename . ')</em></a>';
		}
		return $form; */
}
class plgContentQuickSellButtons extends JPlugin
{
    /**
     * Example after delete method.
     *
     * @param	string	The context for the content passed to the plugin.
     * @param	object	The data relating to the content that was deleted.
     * @return	boolean
     * @since	1.6
     */
    public function onContentAfterDelete($context, $data)
    {
        return true;
    }//function

    /**
     * Example after display content method
     *
     * Method is called by the view and the results are imploded and displayed in a placeholder
     *
     * @param	string		The context for the content passed to the plugin.
     * @param	object		The content object.  Note $article->text is also available
     * @param	object		The content params
     * @param	int			The 'page' number
     * @return	string
     * @since	1.6
     */
    public function onContentAfterDisplay($context, &$article, &$params, $limitstart)
    {
        return '';
    }//function

    /**
     * Example after save content method
     * Article is passed by reference, but after the save, so no changes will be saved.
     * Method is called right after the content is saved
     *
     * @param	string		The context of the content passed to the plugin (added in 1.6)
     * @param	object		A JTableContent object
     * @param	bool		If the content is just about to be created
     * @since	1.6
     */
    public function onContentAfterSave($context, &$article, $isNew)
    {
        return true;
    }//function

    /**
     * Example after display title method
     *
     * Method is called by the view and the results are imploded and displayed in a placeholder
     *
     * @param	string		The context for the content passed to the plugin.
     * @param	object		The content object.  Note $article->text is also available
     * @param	object		The content params
     * @param	int			The 'page' number
     * @return	string
     * @since	1.6
     */
    public function onContentAfterTitle($context, &$article, &$params, $limitstart)
    {
        return '';
    }//function

    /**
     * Example before delete method.
     *
     * @param	string	The context for the content passed to the plugin.
     * @param	object	The data relating to the content that is to be deleted.
     * @return	boolean
     * @since	1.6
     */
    public function onContentBeforeDelete($context, $data)
    {
        return true;
    }//function

    /**
     * Example before display content method
     *
     * Method is called by the view and the results are imploded and displayed in a placeholder
     *
     * @param	string		The context for the content passed to the plugin.
     * @param	object		The content object.  Note $article->text is also available
     * @param	object		The content params
     * @param	int			The 'page' number
     * @return	string
     * @since	1.6
     */
    public function onContentBeforeDisplay($context, &$article, &$params, $limitstart)
    {
        return '';
    }//function

    /**
     * Example before save content method
     *
     * Method is called right before content is saved into the database.
     * Article object is passed by reference, so any changes will be saved!
     * NOTE:  Returning false will abort the save with an error.
     *You can set the error by calling $article->setError($message)
     *
     * @param	string		The context of the content passed to the plugin.
     * @param	object		A JTableContent object
     * @param	bool		If the content is just about to be created
     * @return	bool		If false, abort the save
     * @since	1.6
     */
    public function onContentBeforeSave($context, &$article, $isNew)
    {
        return true;
    }//function

    /**
     * Example after delete method.
     *
     * @param	string	The context for the content passed to the plugin.
     * @param	array	A list of primary key ids of the content that has changed state.
     * @param	int		The value of the state that the content has been changed to.
     * @return	boolean
     * @since	1.6
     */
    public function onContentChangeState($context, $pks, $value)
    {
        return true;
    }//function

    /**
     * Example prepare content method
     *
     * Method is called by the view
     *
     * @param	string	The context of the content being passed to the plugin.
     * @param	object	The content object.  Note $article->text is also available
     * @param	object	The content params
     * @param	int		The 'page' number
     * @since	1.6
     */
    public function onPrepareContent( &$article, &$params, $limitstart )
    {
		//$form = print_r($result,true);
		if ($this->params->get('htmlentities') == 1) {
			$article->text = preg_replace_callback('%\{quicksell( file="(.+?)?")?( price="([0-9.]+?)?")?( title="(.+?)?")?( currency="([a-z][a-z][a-z])?")?( customPayPal="(.+?)??")?( emailDelivery="(on)?")?( requireRegistration="(on)?")?( discount_rate="(.+?)??")?( return_url="(.+?)??")?( notification_email="(.+?)??")?( rm="(.+?)??")?( cbt="(.+?)??")?( sales_limit="(.+?)??")?\}(.+?)\{/quicksell\}%si', 'makeButton', html_entity_decode($article->text, ENT_QUOTES, 'UTF-8'));
		} else {
			$article->text = preg_replace_callback('%\{quicksell( file="(.+?)?")?( price="([0-9.]+?)?")?( title="(.+?)?")?( currency="([a-z][a-z][a-z])?")?( customPayPal="(.+?)??")?( emailDelivery="(on)?")?( requireRegistration="(on)?")?( discount_rate="(.+?)??")?( return_url="(.+?)??")?( notification_email="(.+?)??")?( rm="(.+?)??")?( cbt="(.+?)??")?( sales_limit="(.+?)??")?\}(.+?)\{/quicksell\}%si', 'makeButton', $article->text);
		}
    	
    }//function
}//class
