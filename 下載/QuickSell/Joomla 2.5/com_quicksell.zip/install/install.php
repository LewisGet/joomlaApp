<?php
	
	jimport( 'joomla.filesystem.file' );

	$htaccess = "deny from all";
	JFile::write('components/com_quicksell/uploads/.htaccess',$htaccess);
	$mainframe =& JFactory::getApplication();
	$mainframe->enqueueMessage('Adding .htaccess file (deny from all) to the uploads directory to prevent unauthorized downloads - OK');
?>