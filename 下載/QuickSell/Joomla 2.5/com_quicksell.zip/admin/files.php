<?php 
defined('_JEXEC') || die('=;)');
JToolbarHelper::deleteListX('Really delete these files? They will not be available for sale anymore!','deletefiles','Delete Files');
JToolbarHelper::publishList('publishfile','Publish');
JToolbarHelper::unpublishList('unpublishfile','Unpublish');
JToolbarHelper::archiveList('makeBundle','Make Bundle');
JToolbarHelper::archiveList('removeBundle','Remove Bundle');
//archiveList(
JHTML::_('behavior.modal', 'a.modal', $params);

if (JRequest::getVar('uploaded') == 1) {
	$mainframe->enqueueMessage('Files have been uploaded! Please make "Buy Now" buttons using the form below!');
}

$document->addScript($qs->www  . 'js/main.js');


jimport('joomla.html.pagination');
// prepare the pagination values


$limit = $mainframe->getUserStateFromRequest('global.list.limit','limit', $mainframe->getCfg('list_limit'));
$limitstart = $mainframe->getUserStateFromRequest(JRequest::getVar('option').'limitstart','limitstart', 0);

$files = $qs->getFiles($limit,$limitstart);

$total = $qs->getTotal('files');

// create the pagination object
$_pagination = new JPagination($total, $limitstart,$limit);
$_pagination_footer = $_pagination->getListFooter();

?>
<form action="index.php" method="get" name="adminForm" id="adminForm">
	<fieldset id="filter-bar">
		<div class="filter-search fltlft">
			<label class="filter-search-lbl" for="filter_search">Filter: </label>
			<input type="text" name="filter_search" id="filter_search" value="<?php echo JRequest::getVar('filter_search'); ?>" title="Search title or alias. Prefix with id: to search for an article id.">

			<button type="submit" onClick="document.adminForm.limitstart.value=0; Joomla.submitform();return false;">Search</button>
			<button type="button" onclick="document.id('filter_search').value='';this.form.submit();">Clear</button>
		</div>
		<div class="filter-select fltrt"></div>
	</fieldset>
  <div class="clr"> </div>

	<table style="width:100%;" class="adminlist">
		<thead>
			<tr>
				<th width="1%">
					<input type="checkbox" name="checkall-toggle" value="" title="Check All" onclick="Joomla.checkAll(this)">
				</th>
				<th> Filename				</th>
				<th width="5%"> Sell &amp; Download</th>
				<th width="5%">Size</th>
				<th width="10%">Make Button</th>
			</tr>
		</thead>
		  <tfoot>
		    <tr>
		      <td colspan="5"><?php echo $_pagination_footer; ?></td>
		    </tr>
		  </tfoot>
		<tbody>
		<?php
		
		//print_r($files);
		$i=0;
		foreach ($files as $row) {
			$i++;
			//print_r($row);
			unset($bundled);
			$bundle = $qs->bundle($row['file_id']);
			
			if ($bundle) {
				//echo $bundle;
				$bundled = "Bundled with ";
				$bundled_files = explode("|", $bundle);
				//print_r($bundled_files);
				foreach ($bundled_files as $bundled_file_id) {
					unset($tmp);
					$tmp = $qs->fileById($bundled_file_id);
					//print_r($tmp);
					if ($tmp->filename != $row['file']) {
						$bundled .= ' ' . $tmp->filename;
					}
				}
			}
		?>
			<tr class="row<?php echo fmod($i,2) != 0 ? '1':'0'; ?>">
				<td class="center">
					<input type="checkbox" id="cb<?php echo $row['file_id']; ?>" name="cid[]" value="<?php echo $row['file_id']; ?>" onclick="isChecked(this.checked);" title="Checkbox for row 1">				</td>
				<td>
				  <a rel="{size: {x: 800, y: 550}, handler : 'iframe'}" class="modal" href="<?php echo $qs->link; ?>&tmpl=component&task=makeButton&filename=<?php echo $row['file']; ?>"><?php echo $row['file']; ?></a> <?php echo $bundled; ?></td>
				<td align="center"><?php echo $row['published']; ?></td>
				<td class="center"><?php echo $row['size']; ?></td>
				<td class="center"><a rel="{size: {x: 800, y: 550}, handler : 'iframe'}" class="modal" href="<?php echo $qs->link; ?>&tmpl=component&task=makeButton&filename=<?php echo $row['file']; ?>"><img src="<?php echo $qs->www; ?>/images/buttons/paypal_button.png" /></a></td>
			</tr>
		<?php 
		}
		?>
		</tbody>
	</table>

		

	<div>
		<input type="hidden" name="task" value="files">
		<input type="hidden" name="option" value="<?php echo $option; ?>">
		<input type="hidden" name="boxchecked" value="0">
  </div>
</form>