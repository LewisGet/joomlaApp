<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Base
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */
error_reporting(0); //temporary
//-- No direct access
defined('_JEXEC') || die('=;)');
class QuickSell {
	function __construct() {
		$this->www = JURI::base() . 'components/com_quicksell/';
		$this->cfg = array();
		$this->link = 'index.php?&option=com_quicksell';
		$this->ppcurrencies = array('EUR' => 'Euro',
'USD' => 'US Dollar',
'GBP' => 'Pounds Sterling',
'AUD' => 'Australian Dollar',
'CAD' => 'Canadian Dollar',
'JPY' => 'Japan Yen',
'NZD' => 'New Zealand Dollar',
'CHF' => 'Swiss Franc',
'HKD' => 'Hong Kong Dollar',
'SGD' => 'Singapore Dollar',
'SEK' => 'Sweden Krona',
'DKK' => 'Danish Krone',
'PLN' => 'New Zloty',
'NOK' => 'Norwegian Krone',
'HUF' => 'Forint',
'CZK' => 'Czech Koruna',
'BRL' => 'Brazilian Real',
'TWD' => 'Taiwan New Dollar',
				
				'TRY' => 'Turkish Lira',
				
				'THB' => 'Thai Baht');
		$this->pdfOrientations = array('portrait' => 'Portrait', 'landscape' => 'Landscape');
		$this->lc = array(
'' => '-- Optional --',
'AU' => 'Australia',
'AT' => 'Austria',
'BE' => 'Belgium',
'BR' => 'Brazil',
'CA' => 'Canada',
'CH' => 'Switzerland',
'CN' => 'China',
'DE' => 'Germany',
'ES' => 'Spain',
'GB' => 'United Kingdom',
'FR' => 'France',
'IT' => 'Italy',
'NL' => 'Netherlands',
'PL' => 'Poland',
'PT' => 'Portugal',
'RU' => 'Russia',
'US' => 'United States',
'da_DK' => 'Danish',
'he_IL' => 'Hebrew',
'id_ID' => 'Indonesian',
'jp_JP' => 'Japanese',
'no_NO' => 'Norwegian',
'pt_BR' => 'Brazilian Portuguese',
'ru_RU' => 'Russian',
'sv_SE' => 'Swedish',
'th_TH' => 'Thai',
'tr_TR' => 'Turkish',
'zh_CN' => 'Chinese (China)',
'zh_HK' => 'Chinese (Hong Kong)',
'zh_TW' => 'Chinese (Taiwan)'
		);
		
		$this->rm = array('0' => '0 - GET','1' => '1 - GET (no vars)','2' => '2 - POST');
		$this->verify_transactions = array('0' => 'No', '1' => 'Yes');
		$this->loadConfig();
		$this->cfg['storageDir'] = JPATH_COMPONENT_ADMINISTRATOR . DS . 'uploads';
		$db =& JFactory::getDBO();
		jimport('joomla.version');
		$version = new JVersion();
		if (substr($version->getShortVersion(),0,3) == '1.5') {
			$this->is15 = true;
		}
	}
	function loadConfig() {
		$db =& JFactory::getDBO();
		$db->setQuery("select value from #__quicksell_config where name = 'config'");
		$row = $db->loadResult();
		$this->cfg = unserialize($row);
		$this->cfg['emailDeliveryBody'] = base64_decode($this->cfg['emailDeliveryBody']);
	}
	function saveConfig($array) 
	{
		$db =& JFactory::getDBO();
		$array['emailDeliveryBody'] = JRequest::getVar('emailDeliveryBody', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$array['thankYouPage'] = JRequest::getVar('thankYouPage', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$array['emailDeliveryBody'] = base64_encode($array['emailDeliveryBody']);
		$data = serialize($array);
		$db->setQuery("update #__quicksell_config set value = " . $db->Quote($data));
		return $db->query();
	}
	function finish($items) {
		foreach ($items as $item) {
			$this->itemFinish($item);
		}
	}
	function getButtons() {
		$mydir = dirname(__FILE__);
		$imgdir = $mydir . DS . 'images' . DS . 'buttons';
		$buttons = scandir($imgdir);
		foreach ($buttons as $b) {
			$ext = pathinfo($imgdir . DS . $b,PATHINFO_EXTENSION);
			$ext = strtolower($ext);
			if ($ext == 'jpg' || $ext == 'png' || $ext == 'gif') {
			//echo "$b $ext<br />";
				$out[] = $b;
			}
		}
		return $out;
	}
	function itemFinish($item) {
		//print_r($item);
		?>
<div class="fileFinish">
<h2 class="tiptip" title="Filename of the file for sale."><?php echo $item['name']; ?></h2>
<p>Select button</p>
<?php
foreach ($this->getButtons() as $button) {
	$md5 = md5($item['name']);
	if (strlen($button) > 2) {
		$i++;
		$checked = $i == 1 ? 'checked=checked' : '';	
		echo '<div class="buttonDiv">';
		echo '<input class="ppbutton" type="radio" order="' . $i . '" rel="' . $md5 . '" name="ppbutton[' . $md5 . ']" value="' . $button . '" ' . $checked . '><br />';
		echo "<img src=\"{$this->www}/images/buttons/$button\" />";
		echo '</div>'; 
	}
}
?>
<p style="clear:both;">Code to copy and paste into the article to make the button appear:<br>
  <label for="code"></label>

  <textarea title="Please copy and paste this code into the article, where you want the button to appear to your visitors." class="tiptip code<?php echo $md5; ?>">{quicksell file='<?php echo $item['name']; ?>' price='<?php echo $item['price']; ?>' title='<?php echo $item['title']; ?>' currency='<?php echo $item['currency']; ?>' customPayPal='<?php echo $item['customPayPal']; ?>' doEmailDelivery='<?php echo $item['doEmailDelivery']; ?>' requireRegistration='<?php echo $item['requireRegistration']; ?>'}{/quicksell}</textarea>

</p>
</div>
		<?php
	}
	function getFiles($limit,$limitstart) {
		$folder = dirname(__FILE__) . DS . 'uploads';
		$files = scandir($folder);
		unset($files[0]);
		unset($files[1]);
		$htaccess = @array_search(".htaccess", $files);
		unset($files[$htaccess]);
		//print_r($files);
		sort($files);
		//print_r($files);
		$search = JRequest::getVar('filter_search');
		$where = 1;
		if ($search != '') {
			$where = "filename like '%$search%'";
		}
		$db =& JFactory::getDBO();
		$db->setQuery("select * from #__quicksell_files where $where",$limitstart,$limit);
		//echo $db->getQuery();
		$dir = $db->loadAssocList();
		$i=0;
		foreach ($dir as $file) {
			$filesArray[] = $file['filename'];
			//$id = JHTML::_('grid.id', ++$i, $file->file_id);
			unset($tmp);
			$tmp['file_id'] = $file['file_id'];
			$file['id'] = $file['file_id'];	
			$tmp['file'] = $file['filename'];
			$tmp['folder'] = $folder;
			$tmp['size'] = $this->formatBytes(filesize($folder . DS . $file['filename']));
			$tmp['accessed'] = date("F d Y H:i:s.", fileatime($folder . DS . $filename));
			$tmp['created'] = date("F d Y H:i:s.", filectime($folder . DS . $filename));
			$tmp['modified'] = date("F d Y H:i:s.", filemtime($folder . DS . $filename));
			$tmp['published'] = JHTML::_('grid.published', (object)$file, $file['file_id']);
			$tmp['published'] = str_replace('\'publish\'', '\'publishfile\'', $tmp['published']);
			$tmp['published'] = str_replace('\'unpublish\'', '\'unpublishfile\'', $tmp['published']);
			$out[] = $tmp;
		}
		foreach ($files as $f) {
			if (in_array($f, $filesArray) == false && $f != 'index.html') {
				$table = JTable::getInstance('Files', 'Table');
				$table->reset();
				$table->set('filename',$f);
				$table->set('published',1);
				$table->store();
			}			
		}
		return $out;
	}
	function formatBytes($bytes, $precision = 2) { 
	    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 
	
	    $bytes = max($bytes, 0); 
	    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
	    $pow = min($pow, count($units) - 1); 
	
	    // Uncomment one of the following alternatives
	     $bytes /= pow(1024, $pow);
	    // $bytes /= (1 << (10 * $pow)); 
	
	    return round($bytes, $precision) . ' ' . $units[$pow]; 
	} 
	function getUserTypes() {
		$database = &JFactory::getDBO();
		$database->setQuery("SELECT *  FROM `#__usergroups`");
		return $database->loadAssocList();
	}	
	function getTotal($what) {
		$search = JRequest::getVar('filter_search');
		$where = 1;
		if ($search != '') {
			if ($what == 'files') {
				$where = "filename like '%$search%'";
			}
			if ($what == 'orders') {
				$filter_search = $search;
			$where = "(CONVERT(`order_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`user_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`mc_gross` USING utf8) LIKE '%$filter_search%' OR CONVERT(`filename` USING utf8) LIKE '%$filter_search%' OR CONVERT(`protection_eligibility` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`tax` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payment_date` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payment_status` USING utf8) LIKE '%$filter_search%' OR CONVERT(`charset` USING utf8) LIKE '%$filter_search%' OR CONVERT(`first_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`mc_fee` USING utf8) LIKE '%$filter_search%' OR CONVERT(`notify_version` USING utf8) LIKE '%$filter_search%' OR CONVERT(`custom` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_status` USING utf8) LIKE '%$filter_search%' OR CONVERT(`business` USING utf8) LIKE '%$filter_search%' OR CONVERT(`num_cart_items` USING utf8) LIKE '%$filter_search%' OR CONVERT(`verify_sign` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_email` USING utf8) LIKE '%$filter_search%' OR CONVERT(`txn_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`item_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_business_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`last_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`receiver_email` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payment_fee` USING utf8) LIKE '%$filter_search%' OR CONVERT(`receiver_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`mc_currency` USING utf8) LIKE '%$filter_search%' OR CONVERT(`residence_country` USING utf8) LIKE '%$filter_search%' OR CONVERT(`transaction_subject` USING utf8) LIKE '%$filter_search%' OR CONVERT(`published` USING utf8) LIKE '%$filter_search%')";
			}
		}
		$db =& JFactory::getDBO();
		$db->setQuery("select count(*) from #__quicksell_$what where $where");
		return $db->loadResult();
	}
	function getGroups() {
		jimport('joomla.version');
		$version = new JVersion();
		$db =& JFactory::getDBO();
		if (substr($version->getShortVersion(),0,3) != '1.5') {
			$query = "select id, title from #__usergroups";
			$db->setQuery($query);
		} else {
			$query = "select `id`, `value` as `title` from #__core_acl_aro_groups where parent_id > 17";
			$db->setQuery($query);
		}
		return $db->loadObjectList();
	}
	function publishfile($cid) {
		$table = JTable::getInstance('Files', 'Table');
		//print_r($cid);
		foreach ($cid as $c => $id) {
			if ($table->load($id)) {
				$table->set('published',1);
				$table->store();
			}
		}
	}
	function unpublishfile($cid) {
		$table = JTable::getInstance('Files', 'Table');
		//print_r($cid);
		foreach ($cid as $c => $id) {
			if ($table->load($id)) {
				$table->set('published',0);
				$table->store();				
			}
		}
	}
	function deletefile($cid) {
		$table = JTable::getInstance('Files', 'Table');
		jimport('joomla.filesystem.file');
		foreach ($cid as $c => $id) {
			if ($table->load($id)) {
				$filename = $table->get('filename');
				$table->delete();
			}
			$file = $this->cfg['storageDir'] . DS . $filename;
			JFile::delete($file);
			@unlink($file);
		}	

	}
	function deleteorder($cid) {
		$table = JTable::getInstance('Orders', 'Table');
		foreach ($cid as $c => $id) {
			if ($table->load($id)) {
				$table->delete();
			}
		}
	}
	function getOrders($limit,$limitstart) {
		$db =& JFactory::getDBO();
		$where = 1;
		$filter_search = JRequest::getVar('filter_search');
		if ($filter_search != '') {
			$where = "(CONVERT(`order_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`user_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`mc_gross` USING utf8) LIKE '%$filter_search%' OR CONVERT(`filename` USING utf8) LIKE '%$filter_search%' OR CONVERT(`protection_eligibility` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`tax` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payment_date` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payment_status` USING utf8) LIKE '%$filter_search%' OR CONVERT(`charset` USING utf8) LIKE '%$filter_search%' OR CONVERT(`first_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`mc_fee` USING utf8) LIKE '%$filter_search%' OR CONVERT(`notify_version` USING utf8) LIKE '%$filter_search%' OR CONVERT(`custom` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_status` USING utf8) LIKE '%$filter_search%' OR CONVERT(`business` USING utf8) LIKE '%$filter_search%' OR CONVERT(`num_cart_items` USING utf8) LIKE '%$filter_search%' OR CONVERT(`verify_sign` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_email` USING utf8) LIKE '%$filter_search%' OR CONVERT(`txn_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`item_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payer_business_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`last_name` USING utf8) LIKE '%$filter_search%' OR CONVERT(`receiver_email` USING utf8) LIKE '%$filter_search%' OR CONVERT(`payment_fee` USING utf8) LIKE '%$filter_search%' OR CONVERT(`receiver_id` USING utf8) LIKE '%$filter_search%' OR CONVERT(`mc_currency` USING utf8) LIKE '%$filter_search%' OR CONVERT(`residence_country` USING utf8) LIKE '%$filter_search%' OR CONVERT(`transaction_subject` USING utf8) LIKE '%$filter_search%' OR CONVERT(`published` USING utf8) LIKE '%$filter_search%')";
		}
		$db->setQuery("select * from #__quicksell_orders where $where order by order_id desc",$limitstart,$limit);
		return $db->loadObjectList();
	}



	function publishorder($cid) {
		$table = JTable::getInstance('orders', 'Table');
		//print_r($cid);
		foreach ($cid as $c => $id) {
			if ($table->load($id)) {
				$table->set('published',1);
				$table->store();
			}
		}
	}
	function unpublishorder($cid) {
		$table = JTable::getInstance('orders', 'Table');
		//print_r($cid);
		foreach ($cid as $c => $id) {
			if ($table->load($id)) {
				$table->set('published',0);
				$table->store();
			}
		}
	}

	function txn_id_exists($txn_id) {
		$db =& JFactory::getDBO();
		$txn_id = $db->Quote($txn_id);
		$db->setQuery("select count(order_id) from #__quicksell_orders where txn_id = $txn_id limit 1");
		return $db->loadResult();
	}
	function file($filename) {
		$db = JFactory::getDBO();
		$db->setQuery("select * from #__quicksell_files where filename = '$filename' or file_id = '$filename'");
		//die($db->getQuery());
		return $db->loadObject();
	}
	function fileById($file_id) {
		$db = JFactory::getDBO();
		$db->setQuery("select * from #__quicksell_files where file_id = '$file_id'");
		//die($db->getQuery());
		return $db->loadObject();
	}
	function loadMyOrders() {
		$db =& JFactory::getDBO();
		$my =& JFactory::getUser();
		$db->setQuery("select * from #__quicksell_orders where user_id = " . $my->id . " order by order_id desc");
		return $db->loadObjectList();
	}
	function downloadlink($order,$additional = null) {
		return JRoute::_($this->link . '&task=download&format=raw&key=' . $order->key . '&order_id=' . $order->order_id . $additional);
	}
	function canDownload($order_id) {
		$qs = new QuickSell();
		$table = JTable::getInstance('orders', 'Table');
		$table->load($order_id);
		//die($qs->cfg['link_expiration']);
		if ($qs->cfg['link_expiration'] != '') {
			$payment_date = $table->payment_date;
			$strtotime = strtotime($qs->cfg['link_expiration'],0);
			$time = time();
			if (time() > $payment_date + $strtotime) {
				return false;
			}
		}
		if ($table->downloads < $qs->cfg['downloads_per_order'] && $order_id > 0) { 
			return true; 
		} else {
			return false;
		}
	}
	function countDownload($order_id) {
		$table = JTable::getInstance('orders', 'Table');
		$table->load($order_id);
		$table->set('downloads',$table->downloads + 1);
		$table->store();
	}
	function inFreeDownloadGroup($my_id) {
		$my =& JFactory::getUser($my_id);
		$db =& JFactory::getDBO();
		if ($this->is15 == false) {
			foreach ($my->groups as $name => $id) {
				if (@array_key_exists($id, $this->cfg['freeDownloadGroups'])) {
					return true;
				}
			}
		} else {
			$db->setQuery("select id from #__core_acl_aro_groups where value = '{$my->usertype}'");
			$id = $db->loadResult();
			if (@array_key_exists($id, $this->cfg['freeDownloadGroups'])) {
				return true;
			}
		}
	}
	function sumSales($period = null) {
		$db =& JFactory::getDBO();
		$db->setQuery("select sum(mc_gross) from #__quicksell_orders where payment_date > $period");
		return $db->loadResult();
	}
	function getUsedCurrencies() {
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT distinct(mc_currency) FROM `#__quicksell_orders` WHERE 1");
		return $db->loadObjectList();		
	}
	function makeForm($result,$silent = null) {
		$jc = new JConfig();
		$qs = new QuickSell();
		$my = JFactory::getUser();
		$doc = JFactory::getDocument();
		//$return = JURI::base() . substr($_SERVER['REQUEST_URI'],1);
		//firefox - back from paypal fix: adding $key to ident the order
		$key = md5(microtime());
		$return = JRoute::_(JURI::current() . '?&key=' . $key);
		//echo $return;
		$get = JRequest::get('get');
		//print_r($get);
		$url = 'index.php?&key=' . $key;
		foreach ($get as $k => $v) {
			$url .= "&$k=$v";
		}
		$u =& JURI::getInstance();
		$return = $u->getScheme() . '://' . $u->getHost() . JRoute::_($url); // subdir fix
		jimport( 'joomla.application.component.helper' );
		$joomsefexists = JFolder::exists('components/com_sef');
		if ($joomsefexists) {
			if (JComponentHelper::isEnabled( 'com_sef',true)) {
				$return .= '?&key=' . $key;
			}
		}
		//
		
		$notify_url = JURI::base() . "index.php?&option=com_quicksell&task=ipn&key=$key";
		$title = $result['6'];
		$price = $result['4'];
		$customPayPal = $result['10'];
		if ($customPayPal == '') {
			$customPayPal = $qs->cfg['pp'];
		}
				 
		$emailDelivery = $result['12'];
		$requireRegistration = $result['14'];
		$discount_rate = $result['16'];
		if ($result['18'] != '') {
			$return = $result['18'];
		}
		if ($qs->cfg['useThankYouPage'] == 'on') {
			$return = JRoute::_($u->getScheme() . '://' . $u->getHost() . $u->getPath() . '?option=com_quicksell&view=thankyou&Itemid=' . JRequest::getVar('Itemid') . '&key=' . $key);
		}
		$notification_email = $result['20'];
		
		$rm = $result['22'];
		$cbt = $result['24'];
		$sales_limit = $result['26'];
		
		if ($sales_limit > 0 && $qs->sales_limit($result['2'],$sales_limit)) {
			return false;
		}

		if (empty($rm)) { $rm = $qs->cfg['rm']; }
		if (empty($cbt)) { $cbt = $qs->cfg['cbt']; }
		$ppurl = "https://www.paypal.com/cgi-bin/webscr";
		if ($qs->cfg['ppsandbox'] == 'on') {
			$ppurl = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
		}

		$currency = $result['8'];
		if ($currency == '') {
			$currency = $qs->cfg['currency'];
		}
		$button = JURI::base() . 'administrator/components/com_quicksell/images/buttons/' . $result['27'];
		$custom[] = $result['2']; //filename
		$custom[] = (int)$my->id;
		$custom[] = $price;
		$custom[] = $currency;
		$custom[] = $emailDelivery;
		$custom[] = $requireRegistration;
		$custom[] = $customPayPal;
		$custom[] = $notification_email;
		
		$custom = implode("|", $custom);
		$custom .= "|" .  md5($custom . $jc->sectet);
		 
		//echo $custom;
		$uniqueId = md5(microtime());
		$pp = explode("@", $customPayPal);
		$tax_rate = $qs->cfg['useVat'] == 'on' ? $qs->cfg['tax'] : '0';
		$form = '
		<form method="post" name="dmp_order_form" action="' . $ppurl . '">
		<input type="hidden" name="rm" value="' . $rm . '" />
		<input type="hidden" name="discount_rate" value="' . (int)$discount_rate . '" />
		<input type="hidden" name="cmd" value="_xclick" />
		<input type="hidden" name="charset" value="utf-8" />
		<input type="hidden" name="lc" value="' . ($qs->cfg['lc'] != '' ? $qs->cfg['lc'] : '') . '" />
		<input type="hidden" name="no_shipping" value="1"/>
		<input type="hidden" name="button_subtype" value="products" />
		<input type="hidden" name="return" value="' . $return . '"/>
		<input type="hidden" name="cancel_return" value="' . $cancel_return . '"/>
		<input type="hidden" name="notify_url" value="' . $notify_url. '"/>
		<input type="hidden" name="item_name" value="' . $title . '"/>
		<input type="hidden" name="item_number" value="1"/>
		<input type="hidden" name="tax_rate" value="' . $tax_rate . '" />
		<input type="hidden" name="amount" value="' . $price . '"/>
		<input type="hidden" name="upload" value="1"/>
		<input type="hidden" name="custom" value="' . base64_encode($custom) . '"/>
		<input type="hidden" name="business" id="' . $uniqueId . '" value=""/>
		<input type="hidden" name="receiver_email" id="' . $uniqueId . '0xff" value=""/>
		<input type="hidden" name="currency_code" value="' . $currency . '"/>
		<input type="hidden" name="cbt" value="' . $cbt . '"/>
		<input type="hidden" name="no_note" value="1" />
		<input type="image" name="submitorder" onClick="document.getElementById(\'' . $uniqueId . '\').value = \'' . $pp[0] . '\' + String.fromCharCode(64) + \'' . $pp[1] . '\'; document.getElementById(\'' . $uniqueId . '0xff\').value = \'' . $pp[0] . '\' + String.fromCharCode(64) + \'' . $pp[1] . '\'; return true;" style="border:none;" src="' . $button . '" />
		</form>';
		//echo 'ddd	';
		if ($silent != null) {
			$form .= '
			<script>
			document.getElementsByName("submitorder")[0].click();
			</script>
			';
		}
		//problem
		//die(print_r($qs,true));
		$file = $qs->file($result[2]);
		
		if ($file->published == 0) {
			return false;
		}

		//die('bla');
		//problem
		
		if ($my->id == 0 && $qs->cfg['requireRegistration'] == 'on') {
			return '<img src="' . $qs->www . '/images/warning.png" />';
		}
		
		
		//checking if download link should appear.
		$post = JRequest::get('post');
		$table = JTable::getInstance('orders', 'Table');
		
		$key = JRequest::getVar('key');
		
		$table->loadByKey($key);
		if ($table->key == '' && JRequest::getVar('key') != '' && $GLOBALS['messageAdded'] == 0) {
			$mainframe = JFactory::getApplication();
			$mainframe->enqueueMessage('<b>Your order is not confirmed yet, this page will refresh in 5 seconds!</b> Please do not navigate away from the page until we receive your order confirmation.','info');
			$js = 'setTimeout("location.reload(true);",5000);';
			$form = '<script type="text/javascript">
			' . $js . '
			</script>';
			$doc->addScriptDeclaration($js);
			$GLOBALS['messageAdded']++;
			return $form;
		}
		//print_r($table);
		
// 		$custom = $post['custom'];
// 		if ($custom == '') {
// 			//$custom = JRequest::getVar('cm');
			
// 		}
		$custom = $table->custom;
		//print_r($post);
		$custom = explode("|", base64_decode($custom));
		$filename = $custom['0'];
		//print_r($file);
		//die('ok');
		if ($qs->canDownload($table->order_id) && strtolower($filename) == strtolower($file->filename)) { 
			if ($silent == 1) {
				header("Location: " . $qs->downloadlink($table));
				die();
			}
			//die($file->file_id);
			if ($qs->bundle($file->file_id) != '') {
				unset($out);
				$bundleFiles = $qs->bundleFiles($file->file_id);
				//print_r($bundleFiles);
				foreach ($bundleFiles as $file) {
					$out .= '<a class="downloadlink" href="' . $qs->downloadlink($table,'&filename=' . $file->filename) . '">Download <em>' . $table->item_name . ' (' . $file->filename . ')</em></a><br />';
				}
				return $out;
			} else {
				return '<a href="' . $qs->downloadlink($table,'&filename=' . $file->filename) . '">Download <em>' . $table->item_name . ' (' . $table->filename . ')</em></a>';
			}
			
		}
		if ($qs->inFreeDownloadGroup($my->id)) {
			if ($silent == 1) {
				header("Location: " . $qs->downloadlink($table));
				die();
			}
			if ($qs->bundle($file->file_id) != '') {
				//die(print_r($file,true));
				unset($out);
				$bundleFiles = $qs->bundleFiles($file->file_id);
				//print_r($bundleFiles);
				foreach ($bundleFiles as $file) {
					$out .= '<a class="downloadlink" href="' . $qs->downloadlink($table,'&filename=' . $file->filename) . '">Download <em>' . $title . ' (' . $file->filename . ')</em></a><br />';
				}
				return $out;
			} else {
				//die(print_r($file,true));
				return '<a href="' . $qs->downloadlink($file,'&filename=' . $file->filename) . '">Download <em>' . $title . ' (' . $file->filename . ')</em></a>';
			}
			//die(print_r($file,true));
		}
		return $form;
	}
	function makeBundle($cid) {
		//print_r($cid);
		$db =& JFactory::getDBO();
		$table = JTable::getInstance('bundles', 'Table');
		foreach ($cid as $c => $file_id) {
			$file_id = (int)$file_id;
			$files = implode('|', $cid);
			$db->setQuery("select * from #__quicksell_bundles where `file_id` = '$file_id'");
			$result = $db->loadObject();
			if (!$result) {
				$db->setQuery("insert into #__quicksell_bundles values ($file_id, " . $db->Quote($files) . ")");
				echo $db->getQuery() . "<br />";
				$db->query();
			} else {
				$db->setQuery("update #__quicksell_bundles set files = " . $db->Quote($files) . " where file_id = $file_id");
				echo $db->getQuery() . "<br />";
				$db->query();
			}
		}
	}
	function removeBundle($cid) {
		foreach ($cid as $i => $file_id) {
			$table = JTable::getInstance('bundles', 'Table');
			$table->load($file_id);
			$table->delete();
		}
	}
	function bundle($file_id) {
		$table = JTable::getInstance('bundles', 'Table');
		$table->load($file_id);
		return $table->files;
	}
	function bundleFiles($file_id) {
		$bundle = $this->bundle($file_id);
		$bundle_file_ids = explode("|",$bundle);
		if (is_array($bundle_file_ids)) {
			//die(print_r($bundle_file_ids,true));
			foreach ($bundle_file_ids as $i => $file_id) {				
				$out[] = $this->file($file_id);
			}
		}
		//print_r($out);	
		return $out;
	}
	function sales_limit($filename,$sales_limit) {
		$db =& JFactory::getDBO();
		$db->setQuery("select count(*) from #__quicksell_orders where filename = " . $db->Quote($filename));
		if ($db->loadResult() >= $sales_limit) {
			return true;
		}
	}
}
?>