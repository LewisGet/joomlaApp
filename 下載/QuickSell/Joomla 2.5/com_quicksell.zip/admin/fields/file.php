<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die();



class JFormFieldFile extends JFormField
{
	protected $type 		= 'QuickSell';

	protected function getInput() {
		
		$db = &JFactory::getDBO();

       //build the list of categories
		$query = 'SELECT a.filename AS text, a.file_id AS value'
		. ' FROM #__quicksell_files AS a'
		. ' WHERE a.published = 1'
		. ' ORDER BY a.filename asc';
		$db->setQuery( $query );
		$result = $db->loadObjectList();
		
		// TODO - check for other views than category edit
		$view 	= JRequest::getVar( 'view' );

		$tree = array();
		$text = '';
		
		//$tree = PhocaGalleryRenderAdmin::CategoryTreeOption($phocagallerys, $tree, 0, $text, $catId);
		
		foreach ($result as $row) {
			$tree[] = JHTML::_('select.option', $row->value, $row->text);
		}
		
		array_unshift($tree, JHTML::_('select.option', '', '- Select a file -', 'value', 'text'));
		
		return JHTML::_('select.genericlist',  $tree,  $this->name, 'class="inputbox"', 'value', 'text', $this->value, $this->file_id );
	}
}
?>