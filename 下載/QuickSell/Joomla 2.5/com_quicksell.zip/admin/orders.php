<?php 
//JToolbarHelper::addNew('editOrder','New');
JToolbarHelper::publishList('publishorder','Publish');
JToolbarHelper::unpublishList('unpublishorder','Unpublish');
JToolbarHelper::deleteListX('Really delete these orders?','deleteorders','Delete');
defined('_JEXEC') || die('=;)');
jimport('joomla.html.pagination');
// prepare the pagination values
$db = JFactory::getDBO();
$total = $qs->getTotal('orders');

$limit = $mainframe->getUserStateFromRequest('global.list.limit','limit', $mainframe->getCfg('list_limit'));
$limitstart = $mainframe->getUserStateFromRequest(JRequest::getVar('option').'limitstart','limitstart', 0);

// create the pagination object
$_pagination = new JPagination($total, $limitstart,$limit);
$_pagination_footer = $_pagination->getListFooter();

if (JRequest::getVar('action') == 'add') {
	$row = JTable::getInstance('orders', 'Table');
	$row->set('user_id',JRequest::getInt('user_id'));
	//$row->set('file_id',JRequest::getInt('user_id'));
	$row->set('published',1);
	$row->set('key',md5(time() + 'QuickSell Rocks'));
	$row->set('payment_status','Completed');
	$row->set('payment_date',time());
	$row->set('txn_id','none');
	$file = $qs->fileById(JRequest::getInt('file_id'));
	$row->set('item_name',$file->filename);
	$row->set('filename',$file->filename);
	if (!$row->store()) {
	        JError::raiseError(500, $row->getError() );
	}
}

$orders = $qs->getOrders($limit,$limitstart);


if (count($orders) < 1) {
	$mainframe->enqueueMessage('Are your orders going in a loop with a message to wait 5 more seconds for the page to refresh? If that\'s the case, please go to your PayPal profile under "My Selling Tools -> Instant Payment Notifications and select status Enabled, and for your url use http://' . $_SERVER['HTTP_HOST'] . '. This might also happen if you test on http://localhost/, because PayPal is unable to connect to QuickSell and notify it about the order!');
}

$document->addScript($qs->www  . 'js/main.js');


?><form action="index.php" method="get" name="adminForm" id="adminForm">
  <fieldset id="filter-bar">
		<div class="filter-search">
			<label class="filter-search-lbl" for="filter_search">Filter:</label>
			<input type="text" name="filter_search" id="filter_search" value="<?php echo JRequest::getVar('filter_search'); ?>">
			<button type="submit" onClick="document.adminForm.limitstart.value=0; Joomla.submitform();return false;">Search</button>
			<button type="button" onclick="document.id('filter_search').value='';this.form.submit();">Clear</button>
		</div>
	</fieldset>
<table class="adminlist">
<thead>
<tr>
<th width="10" nowrap="nowrap"><a href="javascript:tableOrdering('order_id','asc','');" title="Click to sort by this column">ID</th>
<th width="10">
<input type="checkbox" name="checkall-toggle" value="" title="Check All" onclick="Joomla.checkAll(this)">
</th>

<th>User</th>

<th>Gross</th>
<th>Currency</th>
<th> Date</th>
	
<th>Payment Status</th>
	
<th>First Name</th>
<th>Last Name</th>
<th>Fee</th>
	
<th>Notify Version</th>
	
<th>Payer Status</th>
	
<th>Business</th>
	
<th>Payer Email</th>
	
<th>Item Name</th>
	
<th>Payer Business Name</th>
	

	
<th>Receiver Email</th>
	
<th>Residence Country</th>
	

<th width="5%" align="center">Published</th>

<th width="5%" align="center">Downloads</th>

</tr>
</thead>
		  <tfoot>
		    <tr>
		      <td colspan="19"><?php echo $_pagination_footer; ?></td>
		    </tr>
		  </tfoot>
<tbody>
<?php 
//SELECT *  FROM `motov_lab`.`jos_quicksell_orders` WHERE (CONVERT(`order_id` USING utf8) LIKE '%Deian%' OR CONVERT(`user_id` USING utf8) LIKE '%Deian%' OR CONVERT(`mc_gross` USING utf8) LIKE '%Deian%' OR CONVERT(`protection_eligibility` USING utf8) LIKE '%Deian%' OR CONVERT(`payer_id` USING utf8) LIKE '%Deian%' OR CONVERT(`tax` USING utf8) LIKE '%Deian%' OR CONVERT(`payment_date` USING utf8) LIKE '%Deian%' OR CONVERT(`payment_status` USING utf8) LIKE '%Deian%' OR CONVERT(`charset` USING utf8) LIKE '%Deian%' OR CONVERT(`first_name` USING utf8) LIKE '%Deian%' OR CONVERT(`mc_fee` USING utf8) LIKE '%Deian%' OR CONVERT(`notify_version` USING utf8) LIKE '%Deian%' OR CONVERT(`custom` USING utf8) LIKE '%Deian%' OR CONVERT(`payer_status` USING utf8) LIKE '%Deian%' OR CONVERT(`business` USING utf8) LIKE '%Deian%' OR CONVERT(`num_cart_items` USING utf8) LIKE '%Deian%' OR CONVERT(`verify_sign` USING utf8) LIKE '%Deian%' OR CONVERT(`payer_email` USING utf8) LIKE '%Deian%' OR CONVERT(`txn_id` USING utf8) LIKE '%Deian%' OR CONVERT(`item_name` USING utf8) LIKE '%Deian%' OR CONVERT(`payer_business_name` USING utf8) LIKE '%Deian%' OR CONVERT(`last_name` USING utf8) LIKE '%Deian%' OR CONVERT(`receiver_email` USING utf8) LIKE '%Deian%' OR CONVERT(`payment_fee` USING utf8) LIKE '%Deian%' OR CONVERT(`receiver_id` USING utf8) LIKE '%Deian%' OR CONVERT(`mc_currency` USING utf8) LIKE '%Deian%' OR CONVERT(`residence_country` USING utf8) LIKE '%Deian%' OR CONVERT(`transaction_subject` USING utf8) LIKE '%Deian%' OR CONVERT(`published` USING utf8) LIKE '%Deian%')


foreach ($orders as $row) {
	$i++;
?>
<tr class="row<?php echo fmod($i,2) == 0 ? '1' : '0'; ?>">
<td><?php echo $row->order_id; ?></td>
<td><input type="checkbox" id="cb<?php echo $row->order_id; ?>" name="cid[]" value="<?php echo $row->order_id; ?>" onclick="isChecked(this.checked);" title="Checkbox for row <?php echo $row->order_id; ?>"></td>
<td>
    <?php
    
    if ($row->user_id > 0) {
    	$user = JFactory::getUser($row->user_id);
    	echo "{$user->username} ({$user->name})";
    	 
    } else {
    	echo "Non-registered user.";
    }
    
    ?>    
</td>

<td>
    <?php echo $row->mc_gross; ?>    
</td>
<td>
  <?php echo $row->mc_currency; ?>    
</td>
<td>
  <?php echo date("H:i, F, j Y",$row->payment_date); ?> 
</td>
<td>
  <?php echo $row->payment_status; ?>    
</td>
<td>
  <?php echo $row->first_name; ?>    
</td>
<td>
    <?php echo $row->last_name; ?>    
</td>
<td>
    <?php echo $row->payment_fee; ?>    
</td>
<td>
    <?php echo $row->notify_version; ?>    
</td>
<td>
    <?php echo $row->payer_status; ?>    
</td>
<td>
  <?php echo $row->business; ?>    
</td>
<td>
  <?php echo $row->payer_email; ?>   
</td>
<td>
  <span title="<?php echo $row->filename; ?>"><?php echo $row->item_name; ?></span>
</td>
<td>
    <?php echo $row->payer_business_name; ?>
</td>

<td>
  <?php echo $row->receiver_email; ?>
</td>
<td>
  <?php echo $row->residence_country; ?>    
</td>


<td align="center">
<?php 
$published = JHTML::_('grid.published', $row, $row->order_id);
$published = str_replace('publish\'','publishorder\'',$published);
echo $published;
?>
</td>

<td>
  <?php echo $row->downloads; ?>    
</td>

</tr>
<?php 
}
?>
</tbody>
</table>
<div class="">


<fieldset class="batch">
	<legend>Manually add order to specific user</legend>
	<p>If you want to add an order to an user manually, you can do it using this form. You must select the file and the user that the order will be added to.<br /><b>Please note:</b> The bundled files will also be available as a download for this user.</p>

<label>Select user</label>
<select name="user_id" id="user_id">
<?php
$db = JFactory::getDBO();	
$db->setQuery("select * from #__users where block = 0 order by id");
$result = $db->loadObjectList();
foreach ($result as $row) {
	echo "<option value=\"$row->id\">$row->name (id: $row->id username: $row->username)</option>\n";
}
?>
</select>
<label>Select file</label>
<select name="file_id" id="file_id">
<?php
$files = $qs->getFiles(10000,0);
//print_r($files);
if (count($files > 1)) {
	foreach ($files as $row) {
		echo "<option value=\"$row[file_id]\">$row[file]</option>";
	}
}
?>	
</select>
<div style="clear:both;"></div>
	<button type="submit" onclick="document.id('action').value='add';this.form.submit();">
		Process	</button>
</fieldset>
</div>
<input type="hidden" name="option" value="com_quicksell">
<input type="hidden" name="task" value="orders">
<input type="hidden" name="action" id="action" value="">
<input type="hidden" name="boxchecked" value="">
</form>