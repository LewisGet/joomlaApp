<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Base
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
$document->addScript($qs->www . 'js/makeButton.js');
$document->addScript($qs->www . 'ibutton/lib/jquery.ibutton.js');
$document->addScript($qs->www . 'ibutton/lib/jquery.easing.1.3.js');
$document->addScript($qs->www . 'ibutton/lib/jquery.metadata.js');
$document->addStyleSheet($qs->www . "ibutton/css/jquery.ibutton.css");
?><form action="index.php" method="get" id="makeButtonForm">
<div style="float:left; width:50%;">

<p>
  <label for="title">Title:</label>
  <input type="text" name="title" id="title" placeholder="Enter title of the file">
</p> 
<p>
  <label for="title">Price:</label>
  <input type="text" name="price" id="price" placeholder="0.00">
</p> 
 <p><label for="currency">Currency:</label>
    <select name="currency" id="currency">
    <option value="">-- (optional) --</option> 
  <?php 
  foreach ($qs->ppcurrencies as $code => $name) {
  	?>
  	<option value="<?php echo $code;?>"><?php echo $name; ?></option>
  	<?php 
  }
  ?>
  </select>
</p> 
<a href="#" class="optionalSettingToggle">Show/hide optional settings</a>
<p class="optionalSetting">
  <label for="title">Custom PayPal: </label> <input type="text" name="customPayPal" id="customPayPal" placeholder="(optional) Custom PayPal account">
</p>
 <p class="optionalSetting">
  <label for="discount_rate">Discount rate: </label> <input type="text" name="discount_rate" id="discount_rate" placeholder="0.00">
</p>
<p class="optionalSetting">
  <label for="return_url">Return URL (ONLY if sending user to another page): </label> <input type="text" name="return_url" id="return_url" placeholder="(optional) http://">
</p>
<p class="optionalSetting">
  <label for="notification_email">Notification E-mail: </label> <input type="text" name="notification_email" id="notification_email" placeholder="(optional) your@email">
</p>
<p class="optionalSetting">
  <label for="cbt">Return button text: </label> <input type="text" name="cbt" id="cbt" placeholder="(optional) Click here to download!">
</p>
 <p class="optionalSetting"><label for="rm">Return method:</label>
    <select name="rm" id="rm">
    <option value="">-- (optional) --</option> 
  <?php 
  foreach ($qs->rm as $rm => $name) {
  	?>
  	<option value="<?php echo $rm;?>"><?php echo $name; ?></option>
  	<?php 
  }
  ?>
  </select>
</p> 
 <p class="optionalSetting">
   <label for="requireRegistration">Require Registration</label>
   <input type="checkbox" name="requireRegistration" id="requireRegistration" class="iButton">
 </p>
 <p class="optionalSetting">
   <label for="emailDelivery">Email Delivery</label>
   <input type="checkbox" name="emailDelivery" id="emailDelivery" class="iButton">
 </p>
 <p class="optionalSetting">
  <label for="sales_limit">Sales limit: </label> <input type="text" name="sales_limit" id="sales_limit" placeholder="0">
</p>
 </div>
 <div style="float:right; width:50%; text-align:center;"><?php 
 $buttons = $qs->getButtons();
 
 foreach ($buttons as $b) {
 	
 	?>
 	<div style="float:left; text-align:center;">
 	<input type="radio" name="ppbutton" src="<?php echo $b; ?>" /><br />
 	<img src="<?php echo $qs->www; ?>images/buttons/<?php echo $b; ?>" />
 	</div>
 	<?php 
 }
 ?></div>
 <div style="clear:both">
 <textarea name="code" cols="" rows="6" id="code" style="width:100%;">{quicksell file="<?php echo JRequest::getVar('filename'); ?>" price="" title="" currency="" customPayPal="" emailDelivery="" requireRegistration="" discount_rate="" return_url="" notification_email="" rm="" cbt="" sales_limit=""}btn_buynowCC_LG.gif{/quicksell}</textarea>
<p align=center>Please copy this code to the article, where you want the order button to appear.</p>
 </div>
</form>