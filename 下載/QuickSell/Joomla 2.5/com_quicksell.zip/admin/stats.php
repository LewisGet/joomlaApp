<?php 
$today = strtotime("tomorrow");
$start_period = strtotime("-30 days",$today);
//echo "<h2>" . date("F, j Y H:i:s",$today) . " to " . date("F, j Y H:i:s",$start_period);
$usedCurrencies = $qs->getUsedCurrencies();

$document->addScript($qs->www  . 'js/main.js');


$db =& JFactory::getDBO();
?>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Year');
        <?php
        	foreach ($usedCurrencies as $row) {
        		echo "data.addColumn('number', '{$row->mc_currency}');\r\n";
        	}
        ?>
        
        data.addRows([
<?php 
//          ['2004', 1000, 400],
for ($i=0;$i<31;$i++) {
	unset($todayPerCurrency);
	$d++;
	$dstart = strtotime("-$d days",$today);
	$dend = $dstart + 86400;
	$date = date("M/d/Y",$dstart);
	foreach ($usedCurrencies as $row) {
		$mc_currency = $row->mc_currency;
		$db->setQuery("select sum(mc_gross) from #__quicksell_orders where mc_currency = '{$row->mc_currency}' and payment_date between $dstart and $dend");
		//echo ($db->getQuery());
		$dbloadresult = floatval($db->loadResult());
		$todayPerCurrency[] = $dbloadresult;
		$perCurrencyTotal[$row->mc_currency] += $dbloadresult;
	}
	$out[] = "['$date', " . implode(", ",$todayPerCurrency) . "]";
	
}
echo implode(", \r\n", $out);
foreach ($perCurrencyTotal as $currency => $amount) {
	$totalSales[] = $currency . " " . number_format($amount, 2);
}
$totalSales = implode(", ", $totalSales);
?>
          ]);

        var options = {
          width: jQuery('#chart_div').width(), height: 500,
          title: 'Sales for the last 30 days <?php echo $totalSales; ?>',
          hAxis: {title: 'Year', titleTextStyle: {color: 'red'}}
        };

        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
<div id="chart_div"></div>