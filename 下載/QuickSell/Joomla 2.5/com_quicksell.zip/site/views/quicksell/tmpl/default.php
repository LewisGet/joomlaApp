<?php
/**
 * @version SVN: $Id: builder.php 469 2011-07-29 19:03:30Z elkuku $
 * @package    QuickSell
 * @subpackage Views
 * @author     Deian Motov {@link motov.net}
 * @author     Created on 27-Sep-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
$my =& JFactory::getUser();
if ($my->id == 0) {
	JError::raiseError('403','You must login first.');
}
$this->myOrders = $this->qs->loadMyOrders();
if (count($this->myOrders) > 0) {
	?>
	<h1>Your orders</h1>
	<?php 
	foreach ($this->myOrders as $row) {
	unset($downloadlink);
	?>
	
	<h3>Order #<?php echo $row->order_id; ?></h3>
	<p>Taken on <?php echo date("F j, Y, g:i a" ,$row->payment_date); ?> via PayPal with transaction id #<?php echo $row->txn_id; ?>
	<br />
	<?php
	if ($this->qs->canDownload($row->order_id)) {
		$u =& JURI::getInstance( );
		$file = $this->qs->file($row->filename);
	 				if ($this->qs->bundle($file->file_id) == '') {
	 					$downloadlink = '<a class="downloadlink" href="' . JRoute::_($u->getScheme() . '://' . $u->getHost() . substr($this->qs->downloadlink($row,'&filename=' . $file->filename),0)) . '">Download <em>' . $row->item_name . ' (' . $file->filename . ')</em></a><br />';
	 				} else {
	 					foreach ($this->qs->bundleFiles($file->file_id) as $bundleFile) {
	 						//$downloadlink .= JRoute::_(JURI::root() . substr($this->qs->downloadlink($row,'&filename=' . $bundleFile->filename),1)) . "<br />";
	 						$downloadlink .= '<a class="downloadlink" href="' . JRoute::_($u->getScheme() . '://' . $u->getHost() . substr($this->qs->downloadlink($row,'&filename=' . $bundleFile->filename),0)) . '">Download <em>' . $row->item_name . ' (' . $bundleFile->filename . ')</em></a><br />';
	 					}
	 				}
	 				echo $downloadlink;
		
	} else { ?>
	You have reached the maximum downloads or your download link has expired, please place a new order to be able to download again.
	<?php } ?>
	</p>
	<?php
	}
} else {
	?>
	<h1>Sorry, you have not made any orders yet.</h1>
	<?php 
}
?>

