<?php
/**
* @package   ZOO
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

/**
 * Plugin helper class.
 *
 * @package Component.Helpers
 * @since 2.0
 */
class PluginHelper extends AppHelper {

	/**
	 * Enable Joomla plugin.
	 *
	 * @param string $plugin
	 *
	 * @since 2.0
	 */
	public function enable($plugin) {

		if ($this->app->joomla->isVersion('1.5')) {
			$this->app->database->query("UPDATE #__plugins SET published = 1 WHERE element = '$plugin'");
		} else {
			$this->app->database->query("UPDATE #__extensions SET enabled = 1 WHERE element = '$plugin'");
		}
	}

}