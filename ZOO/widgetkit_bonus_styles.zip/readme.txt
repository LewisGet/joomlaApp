 ________ __     __                __   __  __ __ __   
|  |  |  |__|.--|  |.-----..-----.|  |_|  |/  |__|  |_ 
|  |  |  |  ||  _  ||  _  ||  -__||   _|     <|  |   _|
|________|__||_____||___  ||_____||____|__|\__|__|____|
                    |_____|

                  # Bonus Styles #


This Widgetkit style package contains new widget styles. Browse through the different folders to see for which widgets additional styles are available.

To add a bonus style, follow these steps:

1. Download and unzip this package.

2. Browse to your favorite widget style and copy the bonus style folder.

   For example: Copy the folder slideshow/styles/downtown

3. Go to your website and copy bonus style folder to styles folder of the widget.

   Joomla example: Copy to media/widgetkit/widgets/slideshow/styles
   WordPress example: Copy to wp-content/plugins/widgetkit/widgets/slideshow/styles

4. Now you can select the new bonus style in the widget settings in the Widgetkit administration.