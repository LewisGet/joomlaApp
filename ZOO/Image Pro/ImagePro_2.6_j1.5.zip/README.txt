
Updating from 2.5 or earlier to 2.5.1+
=======================================

Step 1. Make a general site backup with Akeeba Backup or similar - https://www.akeebabackup.com
Step 2. Install the free ZL Framework plugin - https://www.zoolanders.com/extensions/zlfw
Step 3. Enable the ZLFW plugin
Step 4. Install this plugin
Step 5. Check everything is OK and report any issue on https://www.zoolanders.com/support


Translations
==============
All elements language files are stored in plugins/system/zoo_zlelements/zoo_zlelements/language folder