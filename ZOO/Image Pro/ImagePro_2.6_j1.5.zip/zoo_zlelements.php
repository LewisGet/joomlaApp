<?php
/**
* @package		ZL Elements
* @author    	JOOlanders, SL http://www.zoolanders.com
* @copyright 	Copyright (C) JOOlanders, SL
* @license   	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Import library dependencies
jimport('joomla.plugin.plugin');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

class plgSystemZoo_zlelements extends JPlugin {
	
	/**
	 * onAfterInitialise handler
	 *
	 * Adds ZOO event listeners
	 *
	 * @access	public
	 * @return null
	 */
	function onAfterInitialise(){
	
		// make sure ZOO exist
		if (!JFile::exists(JPATH_ADMINISTRATOR.'/components/com_zoo/config.php')
				|| !JComponentHelper::getComponent('com_zoo', true)->enabled) {
			return;
		}
		
		// load zoo
		require_once(JPATH_ADMINISTRATOR.'/components/com_zoo/config.php');
		
		// check if Zoo > 2.4 is loaded
		if (!class_exists('App')) {
			return;
		}
		
		// Get the ZOO App instance
		$this->app = App::getInstance('zoo');

		/* respect the below order */
		
		// 1. register plugin path
		$plg_path = $this->app->joomla->isVersion('1.5') ? 'plugins/system/zoo_zlelements/' : 'plugins/system/zoo_zlelements/zoo_zlelements/';
		if ($path = $this->app->path->path('root:'.$plg_path)) {
			$this->app->path->register($path, 'zlpath');
		}
		
		// 2. load default and current language
		$this->app->system->language->load('plg_system_zoo_zlelements', JPATH_ADMINISTRATOR, 'en-GB', true);
		$this->app->system->language->load('plg_system_zoo_zlelements', JPATH_ADMINISTRATOR, null, true);

		// 3. register elements path
		if ($path = $this->app->path->path('zlpath:elements')) {
			$this->app->path->register($path, 'elements');
		}

		// 4. check and perform installation tasks
		if(!$this->checkInstallation()) return;

		// mix and load individual elements lang files
		foreach ($this->app->path->dirs('zlpath:elements') as $element)
		{
			if ($this->app->path->path("zlpath:elements/$element/language"))
			{
				// move files to common folder and delete the individual
				JFile::move(
					$this->app->path->path("zlpath:elements/$element/language/en-GB/en-GB.plg_system_zoo_zlelements_$element.ini"),
					$this->app->path->path("zlpath:language/en-GB")."/en-GB.plg_system_zoo_zlelements_$element.ini"
				);
				JFolder::delete($this->app->path->path("zlpath:elements/$element/language"));
			}

			$this->app->system->language->load("plg_system_zoo_zlelements_$element", $this->app->path->path('zlpath:'), 'en-GB', true);
			$this->app->system->language->load("plg_system_zoo_zlelements_$element", $this->app->path->path('zlpath:'), null, true);
		}

		// register fields path
		if ($path = $this->app->path->path('zlpath:fields')) {
			$this->app->path->register($path, 'zlfields');
		}
		
		// register helpers
		if ($path = $this->app->path->path('zlpath:helpers/')) {
			$this->app->path->register($path, 'helpers');
			$this->app->loader->register('ZlHelper', 'helpers:zlhelper.php');
		}

		// register controllers
		if ($path = $this->app->path->path('zlpath:controllers/')) {
			$this->app->path->register($path, 'controllers');
		}
		
		// register events
		$this->app->event->register('TypeEvent');
		$this->app->event->dispatcher->connect('element:afterdisplay', array($this, 'afterDisplay'));
		//$this->app->event->dispatcher->connect('submission:init', array($this, 'submissionInit'));
		// $this->app->event->dispatcher->connect('type:editdisplay', array($this, 'editTypeDisplay'));
		$this->app->event->dispatcher->connect('type:beforesave', array($this, 'beforeTypeSave'));

	}
	
	/*
	 * Type Functions
	 */
	public static function editTypeDisplay($event) {
		$type = $event->getSubject();
		$zoo = $type->app;
		$html = '<div class="element element-name"><strong>ZOOlanders Elements - qTip Style</strong>';
		
			// qtip
			jimport('joomla.html.parameter.element');
			$zoo->loader->register('JElementQtip', 'zlfw:fields/type/qtip.php');
			$qtip = $zoo->object->create('JElementQtip');
			$html .= $qtip->fetchElement('qtip', $type->config->find('zl.qtip'), null, 'zl');
		
		$html .= '</div>';

		$event['html'] = str_ireplace('</fieldset>', $html.'</fieldset>', $event['html']);
	}
	
	public static function beforeTypeSave($event) {
		$type = $event->getSubject();
		$type->config->set('zl', JRequest::getVar('zl'));
	}
	
	/*
	 * submission fix
	 */
	public static function submissionInit($event) {
		$zoo = App::getInstance('zoo');
	
		// load ui
		//$zoo->document->addStylesheet('zlpath:assets/css/zl_ui.css');
	}
	
	/*
	 * class fix for all elements that extends zoo ones
	 */
	public static function afterDisplay($event)
	{
		$element = $event['element'];

		if ($event['element']->getElementType() == 'relateditemspro') {
			$event['html'] = preg_replace('/class="element element-relateditemspro/', '$0 element-relateditems', $event['html']);
		}	
		if ($event['element']->getElementType() == 'relatedcategoriespro') {
			$event['html'] = preg_replace('/class="element element-relatedcategoriespro/', '$0 element-relatedcategories', $event['html']);
		}
		if ($event['element']->getElementType() == 'imagepro') {
			$event['html'] = preg_replace('/class="element element-imagepro/', '$0 element-image', $event['html']);
		}
		if ($event['element']->getElementType() == 'downloadpro') {
			$event['html'] = preg_replace('/class="element element-downloadpro/', '$0 element-download', $event['html']);
		}
	}
	
	/*
		Function: biRelate
			Triggered on item:saved event for RI Pro Bi-relation feature
	*/
	public static function biRelate($event) {

		// init vars
		$item = $event->getSubject();
		$elements = $item->getElements();
		$app = $item->app;
		$db = $app->database;
		
		// birelate the items
		foreach($elements as $element){
			if($element->getElementType() == 'relateditemspro'){
			
				// filter the elements and get the relations
				$chosenElms = $element->config->find('application._chosenelms', array());
				$ritems = $element->getRelatedItems(false); // get's even unpublsihed items
				
				// associate actual $item to it's relations
				if (!empty($ritems) && !empty($chosenElms)) foreach ($ritems as $ritem){
					foreach ($chosenElms as $relement_id) {
						if ($relement = $ritem->getElement($relement_id)) {
							// bi-related element found on item
							$relement->addRelation($item->id);
						}
					}					
				}
				
				// in same step search items marked to be Removed and remove
				foreach ($chosenElms as $relement_id) {
					$query = 'DELETE FROM #__zoo_relateditemsproxref'
							.' WHERE remove = 1' 
							.' AND ritem_id = '.$item->id
							.' AND element_id='.$db->Quote($relement_id);
					$db->query($query);
				}
			}
		}
		
		return null;
	}
	
	/**
	 *  checkInstallation
	 */
	public function checkInstallation(){
	
		$app = JFactory::getApplication();
		$zoo = App::getInstance('zoo');
	
		if($app->isAdmin())
		{
			// ZL Framework integration
			$fw = JPluginHelper::isEnabled('system', 'zlframework');
			if( !$fw )
			{
				$app->enqueueMessage(JText::_('PLG_ZLELEMENTS_ZLFW_MISSING'), 'notice');
				return false;
			} 
			else 
			{
				// Fix ordering of the plugins
				$fw_path = $zoo->joomla->isVersion('1.5') ? 'plugins/system/zlframework/helpers' : 'plugins/system/zlframework/zlframework/helpers';
				$zoo->loader->register('ZlfwHelper', 'root:'.$fw_path.'/zlfwhelper.php');
				$zoo->zlfw->checkPluginOrder('zoo_zlelements');
			}
			
			// Check for dependencies
			if(!class_exists('ZldependencyHelper'))
			{
				$zoo->error->raiseNotice(0, "ZL Framework minimum version required: 2.5.1");
				return;
			}
			
			// Run only if we have the minimum versions installed
			if(!$zoo->zldependency->check("zlpath:dependencies.config", 'ZOOlanders Elements'))
			{
				return;
			}

			// remove depricated files/folders
			if ($path = $zoo->path->path('zlpath:control.json'))
			{
				$ctrl = json_decode(file_get_contents($path), true);
				foreach ($ctrl['files'] as $file){
					if ($file = $zoo->path->path($file)) JFile::delete($file);
				}
				
				foreach ($ctrl['folders'] as $folder){
					if ($folder = $zoo->path->path($folder)) JFolder::delete($folder);
				}
			}
		}

		// perform this both on admin and site
		if ($path = $zoo->path->path('elements:relateditemspro')) {
			// register events
			$zoo->event->dispatcher->connect('item:saved', array($this, 'biRelate'));
		}
		
		return true;
	}
}