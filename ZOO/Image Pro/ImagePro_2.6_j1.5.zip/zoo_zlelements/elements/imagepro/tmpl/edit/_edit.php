<?php
/**
* @package		ZL Elements
* @author    	JOOlanders, SL http://www.zoolanders.com
* @copyright 	Copyright (C) JOOlanders, SL
* @license   	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

$widgetkit	 = $this->app->zlfw->checkExt('com_widgetkit');
$custom_link = $this->config->find('specific._custom_link', 0)
?>

<div class="repeatable-content">

	<div class="row">
		<?php echo $this->app->html->_('control.text', $this->getControlName('file'), $this->get('file'), 'class="image-element filespro file" title="'.JText::_('PLG_ZLFRAMEWORK_IMAGE').'" placeholder="'.JText::_('PLG_ZLFRAMEWORK_IMAGE').'"'); ?>
		<?php echo $this->getFileDetailsDom() ?>
    </div>

	<div class="more-options">
		<div class="trigger">
			<div>
				<?php if ($widgetkit) : ?><div class="spotlight button"><?php echo JText::_('PLG_ZLFRAMEWORK_SPOTLIGHT'); ?></div><?php endif; ?>
				<?php if ($widgetkit) : ?><div class="lightbox button"><?php echo JText::_('PLG_ZLFRAMEWORK_LIGHTBOX'); ?></div><?php endif; ?>
				<?php if ($custom_link) : ?><div class="link button"><?php echo JText::_('PLG_ZLFRAMEWORK_LINK'); ?></div><?php endif; ?>
				<div class="title button"><?php echo JText::_('PLG_ZLFRAMEWORK_TITLE'); ?></div>
				
			</div>
		</div>

		
		<div class="title options">

			<div class="row">
				<?php echo $this->app->html->_('control.text', $this->getControlName('title'), $this->get('title'), 'maxlength="255" title="'.JText::_('PLG_ZLFRAMEWORK_TITLE').'" placeholder="'.JText::_('PLG_ZLFRAMEWORK_TITLE').'"'); ?>
			</div>

		</div>

		
		<?php if ($this->config->find('specific._custom_link', 0)) : ?>
		<div class="link options">

			<div class="row">
				<?php echo $this->app->html->_('control.text', $this->getControlName('link'), $this->get('link'), 'size="60" maxlength="255" title="'.JText::_('PLG_ZLFRAMEWORK_LINK').'" placeholder="'.JText::_('PLG_ZLFRAMEWORK_LINK').'"'); ?>
			</div>

			<div class="row">
				<strong><?php echo JText::_('PLG_ZLFRAMEWORK_NEW_WINDOW'); ?></strong>
				<?php echo $this->app->html->_('select.booleanlist', $this->getControlName('target'), $this->get('target'), $this->get('target')); ?>
			</div>

			<div class="row">
				<?php echo $this->app->html->_('control.text', $this->getControlName('rel'), $this->get('rel'), 'size="60" maxlength="255" title="'.JText::_('PLG_ZLFRAMEWORK_REL').'" placeholder="'.JText::_('PLG_ZLFRAMEWORK_REL').'"'); ?>
			</div>
		</div>
		<?php endif; ?>
		
		
		<div class="lightbox options">
			<div class="row">
				<?php echo $this->app->html->_('control.text', $this->getControlName('file2'), $this->get('file2'), 'class="image-subelement filespro file" style="width:345px;" title="'.JText::_('PLG_ZLELEMENTS_IMGP_LIGHTBOX_IMAGE').'"'); ?>
				<?php echo $this->getFileDetailsDom($this->get('file2')) ?>
			</div>
		</div>

		<div class="spotlight options">
			<div class="row">
				<?php echo $this->app->html->_('control.arraylist', array(
					'' => 'None',
					'default' => 'Default',
					'top' => 'Top',
					'bottom' => 'Bottom',
					'left' => 'Left',
					'right' => 'Right',
					'fade' => 'Fade'
				), array(), $this->getControlName('spotlight_effect'), null, 'value', 'text', $this->get('spotlight_effect')); ?>
			</div>

			<div class="row">
				<?php echo $this->app->html->_('control.text', $this->getControlName('caption'), $this->get('caption'), 'size="60" style="width:200px;margin-right:5px;" title="'.JText::_('PLG_ZLFRAMEWORK_CAPTION').'" placeholder="'.JText::_('PLG_ZLFRAMEWORK_CAPTION').'"'); ?>
			</div>
		</div>

	</div>
	
</div>