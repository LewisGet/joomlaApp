/* Copyright (C) ZOOlanders.com - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only */
(function ($) {
    var a = function () {};
    $.extend(a.prototype, {
        name: "ImageSubmissionpro",
        options: {
            uri: ""
        },
        initialize: function (a, c) {
            this.options = $.extend({}, this.options, c);
            var b = this;
			
			// on each new image apply
			var element = a.closest('.filespro');
            element.find('p.add a').bind('click', function () {
				b.apply(element.find('[type="file"]'));
			});
			
			// first init
			b.apply(element.find('[type="file"]'));
		},
		apply: function (inputs)
		{
			var b = this;
				
			inputs.each(function (c) {
				
				if (!$(this).data('initialized')) { 
				
					var input = $(this),
						element = input.closest('.image-element'),
						select_image = element.find("input.image");
						
					element.find('[type="file"]').bind('change', function()
					{
						var name = $(this).val().replace(/^.*[\/\\]/g, '');
						element.find('input.filename').val(name);
					});
					element.find("span.image-cancel").bind("click", function () {
						select_image.val("");
						b.sanatize(element, select_image)
					});
					b.sanatize(element, select_image)
					
				$(this).data('initialized', !0);}
			})
		
        },
        sanatize: function (element, select_image) {
            select_image.val() ? (element.find("div.image-select").addClass("hidden"), element.find("div.image-preview").removeClass("hidden")) : (element.find("div.image-select").removeClass("hidden"), element.find("div.image-preview").addClass("hidden"))
        }
    });
    $.fn[a.prototype.name] = function () {
        var e = arguments,
            c = e[0] ? e[0] : null;
        return this.each(function () {
            var b = $(this);
            if (a.prototype[c] && b.data(a.prototype.name) && c != "initialize") b.data(a.prototype.name)[c].apply(b.data(a.prototype.name), Array.prototype.slice.call(e, 1));
            else if (!c || $.isPlainObject(c)) {
                var f = new a;
                a.prototype.initialize && f.initialize.apply(f, $.merge([b], e));
                b.data(a.prototype.name, f)
            } else $.error("Method " + c + " does not exist on jQuery." + a.name)
        })
    }
})(jQuery);