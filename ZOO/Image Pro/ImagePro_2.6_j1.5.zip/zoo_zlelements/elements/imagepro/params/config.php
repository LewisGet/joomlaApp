<?php
/**
* @package		ZL Elements
* @author    	JOOlanders, SL http://www.zoolanders.com
* @copyright 	Copyright (C) JOOlanders, SL
* @license   	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// load config
require_once(JPATH_ADMINISTRATOR . '/components/com_zoo/config.php');

	$edit_path = array();
	$edit_path[] = 'zlpath:elements\/'.$element->getElementType().'\/tmpl\/edit';
	if (is_object($element->getType())) $edit_path[] = 'applications:'.$element->getType()->getApplication()->getGroup().'\/elements\/'.$element->getElementType().'\/tmpl\/edit'; // zoo template overide path

	return
	'{
		"_edit_sublayout":{
			"type": "layout",
			"label": "PLG_ZLELEMENTS_IMGP_EDIT_SUBLAYOUT",
			"default": "_edit.php",
			"specific": {
				"path":"'.implode(',', $edit_path).'",
				"regex":'.json_encode('^([_][_A-Za-z0-9]*)\.php$').',
				"min_opts":"2"
			}
		},
		"_custom_link":{
			"type": "checkbox",
			"label": "PLG_ZLELEMENTS_IMGP_CUSTOM_LINK",
			"help": "PLG_ZLELEMENTS_IMGP_CUSTOM_LINK_DESC",
			"default": "0",
			"specific":{
				"label":"Enable"
			}
		}
	}';