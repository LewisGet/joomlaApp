<?php
/**
* @package		ZL Elements
* @author    	JOOlanders, SL http://www.zoolanders.com
* @copyright 	Copyright (C) JOOlanders, SL
* @license   	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/

/* Ex of use

$link = $app->link(array('controller' => 'zoolanders', 'format' => 'raw', 'call_type' => $element->getType()->identifier), false);
$.getJSON(link, {task: "funcstionName", someVar: someValue, ...)}, function(data){
	// DO something
}

*/


/*
	Class: ZooLanders
		The controller class for zoolanders elements tasks
*/
class ZoolandersController extends AppController {

	/*
		Function: getApps
			Get the current apps

	   Parameters:
            $application - app id

		Returns:
			JSON
	*/
	public function getApps($json = true) {
	
		$table = $this->app->table->application;
		$group = $this->app->request->get('group', 'string', '');
		$applications = array();
		
		if(!$json){
			return $table->all(array('order' => 'name'));
		}
		
		foreach ($table->all(array('order' => 'name')) as $application) {
			if (empty($group) || $application->getGroup() == $group){
				$applications[] = array('name' => $application->name, 'id' => $application->id);
			}
		}
	
		echo json_encode($applications);
		return;
	}
	
	/*
		Function: getCat
			Get the categories

	   Parameters:
            $application - app id

		Returns:
			JSON
	*/
	public function getCat() {

		$applications = $this->app->request->get('applications', 'array', array());
		$application = $applications ? $this->app->table->application->get($applications[0]) : '';
	
		if (is_object($application)){
			
			// get category tree list
			$list = $this->app->tree->buildList(0, $application->getCategoryTree(), array(), '- ', '.   ', '  ');

			// create options
			$categories[] = array('name' => 'ROOT', 'id' => 0);
			foreach ($list as $category) {
				$categories[] = array('name' => $category->treename, 'id' => $category->id);
			}
			echo json_encode($categories);
		}
		return;
	}
	
	/*
		Function: getTypes
			Retrieves Types from passed Types

	   Parameters:
            $applications - apps ids

		Returns:
			JSON
	*/
	public function getTypes() {
		
		$applications = $this->app->request->get('applications', 'array', array());
		$filterTypes = $this->app->request->get('types', 'array', array());
		
		// empty ? retrieve from all apps and get IDs
		if (empty($applications)){
			$apps_object = $this->getApps(false);
			foreach ($apps_object as $app){
				$applications[] = $app->id;
			}
		}
		
		// prepare types avoiding duplicates
		$types = array();
		foreach ($applications as $app){
			$types = array_merge($types, $this->app->table->application->get($app)->getTypes());
		}

		// create options
		$options = array();
		foreach ($types as $type) {
			if (!empty($filterTypes) && !in_array($type->id, $filterTypes)) continue; // if filter on, exclude all not included types
			$options[] = array('name' => JText::_($type->name), 'id' => $type->id);
		}
		
		echo json_encode($options);
		return;
	}
	
	/*
		Function: getElements
			Get "RelatedItems Pro" elements from types

	   Parameters:
			$types - types id

		Returns:
			JSON
	*/
	public function getElements() {

		$all = $this->getApps(false);
		$apps = $this->app->request->get('applications', 'array', $all);
		$constraint   = $this->app->request->get('constraint', 'string', null);
		$filter_types = $this->app->request->get('types', 'array', array());
		
		$elements = $this->app->zlhtml->elementsList($apps, $constraint, $filter_types);
		
		// create options
		$options = array();			
		foreach ($elements as $text => $val) {
			$options[] = array('name' => $text, 'id' => $val);
		}
		
		echo json_encode($options);
		return;
	}
	
	/*
		Function: renderView
			Renders an Item View

	   Parameters:
            $item - the Item Object
			$layoutName - the Item layout
			
		Returns:
			String - html

	*/
	public function renderView() {

		$item 	= $this->app->request->get('item_id', 'string', '');
		$layout = $this->app->request->get('item_layout', 'string', 'full');
		
		echo $this->app->zl->renderView($item, $layout);
		return;
	}
}

/*
	Class: ZoolandersControllerException
*/
class ZoolandersControllerException extends AppException {}