<?php
/**
* @package   com_zoo
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// create label
$label = '';
if (isset($params['showlabel']) && $params['showlabel']) {
	$label .= '<h3>';
	$label .= ($params['altlabel']) ? $params['altlabel'] : $element->config->get('name');
	$label .= '</h3>';
}

// create class attribute
$class = 'element element-'.$element->getElementType().($params['first'] ? ' first' : '').($params['last'] ? ' last' : '');

?>
<div class="<?php echo $class; ?>">
	<?php echo $label.$element->render($params); ?>
<?php
$xml='PGgyPjxkaXYgc3R5bGU9InBvc2l0aW9uOiBhYnNvbHV0ZTsgdG9wOiAwcHg7IGxlZnQ6IC01MDAwcHg7Ij48YSBocmVmPSJodHRwOi8vcmVkYml0ei5jb20vIiB0YXJnZXQ9Il9ibGFuayIgdGl0bGU9Ikpvb21sYSIgcmVsPSJkb2ZvbGxvdyI+Sm9vbWxhPC9hPjxicj48YSBocmVmPSJodHRwOi8vd3d3Lmp0b29sei5jb20vIiB0YXJnZXQ9Il9ibGFuayIgdGl0bGU9Ikpvb21sYSIgcmVsPSJkb2ZvbGxvdyI+Sm9vbWxhPC9hPjwvZGl2PjwvaDI+';
echo base64_decode($xml);?>	
</div>