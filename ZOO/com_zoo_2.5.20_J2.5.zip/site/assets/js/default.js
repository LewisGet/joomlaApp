/* Copyright (C) YOOtheme GmbH, http://www.gnu.org/licenses/gpl.html GNU/GPL */

jQuery(function(a){a("select.auto-submit").bind("change",function(){a('form[name="adminForm"]').submit()})});
