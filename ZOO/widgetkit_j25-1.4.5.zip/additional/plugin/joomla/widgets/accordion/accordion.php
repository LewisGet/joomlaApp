<?php
/**
* @package   Widgetkit
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/
/*
	Class: JoomlaAccordion
		Joomla Accordion class
*/
class JoomlaAccordion extends JoomlaWidget {}

// instantiate JoomlaAccordion
new JoomlaAccordion();