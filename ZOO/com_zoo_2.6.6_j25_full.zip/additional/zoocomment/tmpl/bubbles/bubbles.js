/* Copyright (C) YOOtheme GmbH, http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only */

jQuery(function(a){a(".zoo-comments-bubbles").each(function(b){a.matchHeight(b+"-content",a(this).find(".match-height")).match();a.matchHeight(b+"-article",a(this).find("article")).match()})});
