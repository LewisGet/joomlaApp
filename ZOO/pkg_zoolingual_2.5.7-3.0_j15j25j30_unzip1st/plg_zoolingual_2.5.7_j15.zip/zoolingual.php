<?php
/**
* @package		ZOOlingual
* @author    	ZOOlanders http://www.zoolanders.com
* @copyright 	Copyright (C) JOOlanders SL
* @license   	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class plgSystemZoolingual extends JPlugin { 
	
	/**
	 * onAfterInitialise handler
	 *
	 * Adds ZOO event listeners
	 *
	 * @access	public
	 * @return null
	 */
	function onAfterInitialise() {
	
		// make sure ZOO exist
		jimport('joomla.filesystem.file');
		if (!JFile::exists(JPATH_ADMINISTRATOR.'/components/com_zoo/config.php')
				|| !JComponentHelper::getComponent('com_zoo', true)->enabled) {
			return;
		}
		
		// load zoo
		require_once(JPATH_ADMINISTRATOR.'/components/com_zoo/config.php');
		
		// check if Zoo > 2.4 is loaded
		if (!class_exists('App')) {
			return;
		}
		
		// Get the ZOO App instance
		$zoo = App::getInstance('zoo');
		
		// register plugin path
		$plg_path = $zoo->joomla->isVersion('1.5') ? 'plugins/system/zoolingual/' : 'plugins/system/zoolingual/zoolingual/';
		if ( $path = $zoo->path->path( 'root:'.$plg_path ) ) {
			$zoo->path->register($path, 'zoolingual');
		}
		
		// load default and current language
		$zoo->system->language->load('plg_system_zoolingual', JPATH_ADMINISTRATOR, 'en-GB', true);
		$zoo->system->language->load('plg_system_zoolingual', JPATH_ADMINISTRATOR, null, true);
		
		if( !$this->checkInstallation() ){
			// keep it after language was loaded
			return;	
		}
		
		// register helper
		if ( $path = $zoo->path->path( 'zoolingual:helpers/' ) ) {
			$zoo->path->register($path, 'helpers');
			$zoo->loader->register('LangHelper', 'helpers:lang.php');
			
			// overide AliasHelper for Alias purposes
			$zoo->loader->register('AliasHelper', 'helpers:alias.php');
		}
		
		// register fields
		if ( $path = $zoo->path->path( 'zoolingual:fields/' ) ) {
			$zoo->path->register($path, 'fields');
		}
		
		// Register Events
		$zoo->event->dispatcher->connect('element:beforedisplay', array($this, 'beforeElementDisplay'));
		$zoo->event->dispatcher->connect('element:afteredit', array($this, 'afterEdit'));
		$zoo->event->dispatcher->connect('element:configparams', array($this, 'addElementConfig'));
		$zoo->event->dispatcher->connect('element:configform', array($this, 'configForm'));
		if(!strstr(JRequest::getVar('controller'), 'submission')) // only if not submission
			$zoo->event->dispatcher->connect('application:init', array($this, 'appXml'));
		$zoo->event->dispatcher->connect('category:init', array($this, 'categoryInit'));
		$zoo->event->dispatcher->connect('item:init', array($this, 'itemInit'));
		//$zoo->event->dispatcher->connect('submission:init', array($this, 'submissionInit'));
		
	}
	
	/**
	 *  checkInstallation
	 */
	public function checkInstallation()
	{
		// Get the ZOO App instance
		$zoo = App::getInstance('zoo');
		
		$fw = JPluginHelper::isEnabled('system', 'zlframework');
		if( !$fw )
		{
			$app = JFactory::getApplication();
			if($app->isAdmin())
			{
				$app->enqueueMessage(JText::_('PLG_ZOOLINGUAL_ZLFW_MISSING'), 'notice');
			}
			return false;
		} 
		else 
		{
			// Fix ordering of the plugins
			$fw_path = $zoo->joomla->isVersion('1.5') ? 'plugins/system/zlframework/helpers' : 'plugins/system/zlframework/zlframework/helpers';
			$zoo->loader->register('ZlfwHelper', 'root:'.$fw_path.'/zlfwhelper.php');
			$zoo->zlfw->checkPluginOrder('zoolingual');
		}
		
		// Check for dependencies
		if(!class_exists('ZldependencyHelper'))
		{
			$zoo->error->raiseNotice(0, "ZL Framework minimum version required: 2.5.1");
			return false;
		}
		
		// Run only if we have the minimum versions installed
		if(!$zoo->zldependency->check("zoolingual:dependencies.config", 'ZOOlingual'))
		{
			return false;
		}
		
		// if all ok
		return true;
	}
	
	/**
	 * Change the element name when displayed for editing
	 */
	public function afterEdit($event) {

		$element = $event->getSubject();

		if ($languages = $element->config->find('zoolingual._languages', 0)) {
			$element->app->document->addStylesheet('zoolingual:assets/lang.css');

			$lang_html = '';
			foreach ($languages as $lang) {
				$lang_html .= '<br /><span class="element-lang '.$lang.'"></span>';
			}
			
			$html = $event['html'];
			$html[1] = '<strong'.$event['description'].'>'.$event['name'].$lang_html.'</strong>';
			
			// set the $vent after modifying the html
			$event['html'] = $html;
		}
	}
	
	/**
	 * Check the language before displaying the element
	 */
	public function beforeElementDisplay($event) {

		$zoo 	 = App::getInstance( 'zoo' );
		$item 	 = $event->getSubject();
		$element = $event['element'];
		$config  = $element->config;
		$params	 = $zoo->data->create($event['params']);
		$isCore  = $element->getGroup() == 'Core';
		
/* 		if ($zoo->lang->checkGroup($item, $config->get('group_elms', ''))){
			// any of the group should be render with current lang but has no value?
			$event['render'] = true; // then render our default element
		} else {
		 */
			// values
			$languages = $config->find('zoolingual._languages', array());
			$overide = $params->find('zoolingual._overided', 0);
			
			// overide values if is the case
			if ($overide || $isCore){
				$languages = $params->find('zoolingual._languages', array());
			}

			// avoid rendering if result is false
			if(!$element->app->lang->checkLang($languages)){
				$event['render'] = false;
			}
		
		//}
	}
	
	/**
	 * Add language parameter to the form
	 */
	public function configForm( $event, $arguments = array( ) )
	{
		// Get the ZOO App instance
		$zoo = App::getInstance( 'zoo' );
		
		$config = $event['form'];
		
		// add XML params path
		$config->addElementPath($zoo->path->path('zoolingual:fields'));
	}
	
	/**
	 * Add Application Parameters on the fly
	 */
	public function appXml( $event, $arguments = array( ) )
	{
		// Get the ZOO App instance
		$zoo = App::getInstance( 'zoo' );
		$app = $event->getSubject( );
		
		// Call the helper method
		$file = '';
		if ($zoo->joomla->isVersion('1.5')) {
			$file = $zoo->path->path('zoolingual:').DS.'application-15.xml';
		} else {
			$file = $zoo->path->path('zoolingual:').DS.'application.xml';
		}
		
		$zoo->xmlparams->addApplicationParams( $app, $file );
		$params = $app->getParams();
		
		// Current Language
		$lang = $zoo->lang->getCurrentLanguage();
	
		// only on site
		if(JFactory::getApplication()->isSite()){
		
			// Name Translation
			$name_translations = $params->get('content.title_translation', array());
			if( count( $name_translations ) )
			{
				if( array_key_exists($lang, $name_translations))
				{
					if( strlen($name_translations[$lang]) )
					{
						$params->set('content.title', $name_translations[$lang]);
					}
				}
			}
			
			// Subtitle Translation
			$sub_translations = $params->get('content.subtitle_translation', array());
			if( count( $sub_translations ) )
			{
				if( array_key_exists($lang, $sub_translations))
				{
					if( strlen($sub_translations[$lang]) )
					{
						$params->set('content.subtitle', $sub_translations[$lang]);
					}
				}
			}
			
			// Description Translation
			$desc_translations = $params->get('content.desc_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$app->description = $desc_translations[$lang];
					}
				}
			}
			
			// Image Translation
			$image_translations = $params->get('content.image_translation', array());
			if( count( $image_translations ) )
			{
				if( array_key_exists($lang, $image_translations))
				{
					if( strlen($image_translations[$lang]) )
					{
						$params->set('content.image', $image_translations[$lang]);
					}
				}
			}
			
			// Image width Translation
			$image_width_translations = $params->get('content.image_translation_width', array());
			if( count( $image_width_translations ) )
			{
				if( array_key_exists($lang, $image_width_translations))
				{
					if( strlen($image_width_translations[$lang]) )
					{
						$params->set('content.image_width', $image_width_translations[$lang]);
					}
				}
			}

			// Image height Translation
			$image_height_translations = $params->get('content.image_translation_height', array());
			if( count( $image_height_translations ) )
			{
				if( array_key_exists($lang, $image_height_translations))
				{
					if( strlen($image_height_translations[$lang]) )
					{
						$params->set('content.image_height', $image_height_translations[$lang]);
					}
				}
			}
			
			// Items Titles Translation
			$items_title_translation = (array)$params->get('content.items_title_translation', array());
			if( count( $items_title_translation ) )
			{
				if( array_key_exists($lang, $items_title_translation))
				{
					if( strlen($items_title_translation[$lang]) )
					{
						$params->set('content.items_title', $items_title_translation[$lang]);
					}
				}
			}
			
			// Categories Titles Translation
			$categories_title_translation = (array)$params->get('content.categories_title_translation', array());
			if( count( $categories_title_translation ) )
			{
				if( array_key_exists($lang, $categories_title_translation))
				{
					if( strlen($categories_title_translation[$lang]) )
					{
						$params->set('content.categories_title', $categories_title_translation[$lang]);
					}
				}
			}
			
			// Application name translation
			$name_translations = $params->get('config.name_translation', array());
			if( count( $name_translations ) )
			{
				if( array_key_exists($lang, $name_translations))
				{
					if( strlen($name_translations[$lang]) )
					{
						$app->name = $name_translations[$lang];
					}
				}
			}
			
			// Application slug translation
			$alias_translations = $params->get('config.alias_translation', array());
			if( count( $alias_translations ) )
			{
				if( array_key_exists($lang, $alias_translations))
				{
					if( strlen($alias_translations[$lang]) )
					{
						$app->alias = $alias_translations[$lang];
					}
				}
			}
		}
	}
	
	/**
	 * Check the language before displaying the category, and translate it if necessary
	 */
	public function categoryInit($event, $arguments = array()) {

		// Only on site side
		if( JFactory::getApplication()->isSite() )
		{
			$category = $event->getSubject();
			
			// Parameters
			$params = $category->getParams();
			
			// Current Language
			$lang = $category->app->lang->getCurrentLanguage();
			
			// Name Translation
			$name_translations = $params->get('content.name_translation', array());
			if( count( $name_translations ) )
			{
				if( array_key_exists($lang, $name_translations))
				{
					if( strlen($name_translations[$lang]) )
					{
						$category->name = $name_translations[$lang];
					}
				}
			}
			
			// Alias Translation
			$alias_translations = $params->get('content.alias_translation', array());
			if( count( $alias_translations ) )
			{
				if( array_key_exists($lang, $alias_translations))
				{
					if( strlen($alias_translations[$lang]) )
					{
						$category->alias = $alias_translations[$lang];
					}
				}
			}
			
			// Description
			$desc_translations = $params->get('content.desc_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$category->description = $desc_translations[$lang];
					}
				}
			}
			
			// Teaser Description
			$desc_translations = $params->get('content.teaser_desc_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$category->getParams()->set('content.teaser_description', $desc_translations[$lang] );
					}
				}
			}
			
			// Categories Title
			$desc_translations = $params->get('content.cat_title_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$category->getParams()->set('content.categories_title', $desc_translations[$lang] );
					}
				}
			}
			
			// Items Title
			$desc_translations = $params->get('content.item_title_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$category->getParams()->set('content.items_title', $desc_translations[$lang] );
					}
				}
			}
			
			// Sub Headline Title
			$sub_translations = $params->get('content.sub_headline_translation', array());
			if( count( $sub_translations ) )
			{
				if( array_key_exists($lang, $sub_translations))
				{
					if( strlen($sub_translations[$lang]) )
					{
						$category->getParams()->set('content.sub_headline', $sub_translations[$lang] );
					}
				}
			}
			
			// Teaser Image 
			$timage_translations = $params->get('content.teaser_image_translation', array());
			if( count( $timage_translations ) )
			{
				if( array_key_exists($lang, $timage_translations))
				{
					if( strlen($timage_translations[$lang]) )
					{
						$category->getParams()->set('content.teaser_image', $timage_translations[$lang] );
					}
				}
			}
			
			// Teaser Image Width
			$timagew_translations = $params->get('content.teaser_image_translation_width', array());
			if( count( $timagew_translations ) )
			{
				if( array_key_exists($lang, $timagew_translations))
				{
					if( strlen($timagew_translations[$lang]) )
					{
						$category->getParams()->set('content.teaser_image_width', $timagew_translations[$lang] );
					}
				}
			}
			
			// Teaser Image Height
			$timageh_translations = $params->get('content.teaser_image_translation_height', array());
			if( count( $timageh_translations ) )
			{
				if( array_key_exists($lang, $timageh_translations))
				{
					if( strlen($timageh_translations[$lang]) )
					{
						$category->getParams()->set('content.teaser_image_height', $timageh_translations[$lang] );
					}
				}
			}
			
			
			// Image 
			$image_translations = $params->get('content.image_translation', array());
			if( count( $image_translations ) )
			{
				if( array_key_exists($lang, $image_translations))
				{
					if( strlen($image_translations[$lang]) )
					{
						$category->getParams()->set('content.image', $image_translations[$lang] );
					}
				}
			}
			
			// Image Width
			$imagew_translations = $params->get('content.image_translation_width', array());
			if( count( $imagew_translations ) )
			{
				if( array_key_exists($lang, $imagew_translations))
				{
					if( strlen($imagew_translations[$lang]) )
					{
						$category->getParams()->set('content.image_width', $imagew_translations[$lang] );
					}
				}
			}
			
			// Image Height
			$imageh_translations = $params->get('content.image_translation_height', array());
			if( count( $imageh_translations ) )
			{
				if( array_key_exists($lang, $imageh_translations))
				{
					if( strlen($imageh_translations[$lang]) )
					{
						$category->getParams()->set('content.image_height', $imageh_translations[$lang] );
					}
				}
			}
		}		
	}

	/**
	 * Check the language before displaying the item, and translate it if necessary
	 */
	public function itemInit($event, $arguments = array()) {

		$task = JRequest::getVar('task', '');
		$method = JRequest::getVar('method', '');
		
		// Only on site side
		if( JFactory::getApplication()->isSite())
		{
			// NOT ON SUBMISSION / COMMENT SAVE AND UNSUBSCRIBE TO AVOID SWITCHING NAME ISSUE
			// ALSO NOT IN DOWNLOAD - DOWNLOAD PRO - RATING TO AVOID NAME SWITCHING ISSUE
			$methods_not_allowed = array('reset', 'vote', 'download');
			$tasks_not_allowed = array('submission', 'unsubscribe', 'save');
			if( in_array($task, $tasks_not_allowed) ||   ($task == 'callelement' && in_array($method, $methods_not_allowed)) ) 
			{
				return;
			}
			
			$item = $event->getSubject();
			
			// Parameters
			$params = $item->getParams();
			
			// Current Language
			$lang = $item->app->lang->getCurrentLanguage();
			
			// Name Translation
			$name_translations = $params->get('content.name_translation', array());
			if( count( $name_translations ) )
			{
				if( array_key_exists($lang, $name_translations))
				{
					if( strlen($name_translations[$lang]) )
					{
						$item->name = $name_translations[$lang];
					}
				}
			}
			
			// Alias
			$desc_translations = $params->get('content.alias_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$item->alias = $desc_translations[$lang];
					}
				}
			}

			// Meta Title
			$desc_translations = $params->get('content.metatitle_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$item->getParams()->set('metadata.title', $desc_translations[$lang] );
					}
				}
			}

			// Meta Desc
			$desc_translations = $params->get('content.metadesc_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$item->getParams()->set('metadata.description', $desc_translations[$lang] );
					}
				}
			}
			
			// Meta Keys
			$desc_translations = $params->get('content.metakeywords_translation', array());
			if( count( $desc_translations ) )
			{
				if( array_key_exists($lang, $desc_translations))
				{
					if( strlen($desc_translations[$lang]) )
					{
						$item->getParams()->set('metadata.keywords', $desc_translations[$lang] );
					}
				}
			}
		}
	}

	/**
	 * Check the language before displaying the submission, and translate it if necessary
	 */
	public function submissionInit($event, $arguments = array()) {

		// Only on site side
		if( JFactory::getApplication()->isSite() )
		{
			$submission = $event->getSubject();
			
			// Parameters
			$params = $submission->getParams();
			
			// Current Language
			$lang = $submission->app->lang->getCurrentLanguage();
			
			// Name Translation
			$name_translations = $params->get('config.name_translation', array());
			if( count( $name_translations ) )
			{
				if( array_key_exists($lang, $name_translations))
				{
					if( strlen($name_translations[$lang]) )
					{
						$submission->name = $name_translations[$lang];
					}
				}
			}
		}
	}
	
	/** 
	 * New method for adding params to the element
	 * @since 2.5
	 */
	public static function addElementConfig($event) {

		$element = $event->getSubject();
		
		// Zoo App Instance
		$zoo = App::getInstance('zoo');
		
		// Custom Params File
		$file = $zoo->path->path( 'zoolingual:') . DS . 'element.xml';
		$xml = simplexml_load_file( $file );

		// Old params
		$params = $event->getReturnValue();
		// add new params from custom params file
		$params[] = $xml->asXML();

		$event->setReturnValue($params);
	}
}