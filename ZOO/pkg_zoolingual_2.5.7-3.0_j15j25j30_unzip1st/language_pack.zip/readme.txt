
 Unpack and copy the necesary languages into "administrator/languages" appropiate folder.

 English translation is allready installed.



 ======

 Thanks Pavel Ivanov for the ru-RU translation