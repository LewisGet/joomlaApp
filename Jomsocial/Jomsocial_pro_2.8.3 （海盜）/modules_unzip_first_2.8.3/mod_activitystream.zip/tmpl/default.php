<?php
/**
 * @category	Modules
 * @package		JomSocial
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license		GNU/GPL, see LICENSE.php
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div id="cModule-ActivityStream" class="cMods cMods-ActivityStream<?php echo $params->get('moduleclass_sfx'); ?>">
	<div id="activity-stream-container">
	<?php echo $stream; ?>
	</div>
</div>
