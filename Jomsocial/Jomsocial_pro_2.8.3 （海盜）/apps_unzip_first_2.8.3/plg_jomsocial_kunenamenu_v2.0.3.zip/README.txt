Kunena README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING plg_jomsocial_kunenamenu 2.0.3!

OVERVIEW
============

The plg_jomsocial_kunenamenu plugin for jomSocial adds further integration between Kunena and jomSocial. 
Install the package through the Joomla backend plugin installer. Once successfully installed, make sure 
to enable and publish the plugin in the backend. 
In addition it is recommended to set the backend parameter of this plugin to Core Application = Yes.
That way all Kunena forum users will see the menu on the community pages toolbar.

For feedback and support please visit the forums at http://www.kunena.com

END OF README
=============
