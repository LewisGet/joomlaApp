<?php
/**
 * Extension Install File
 * Does the stuff for the specific extensions
 *
 * @package			Cache Cleaner
 * @version			1.11.3
 *
 * @author			Peter van Westen <peter@nonumber.nl>
 * @link			http://www.nonumber.nl
 * @copyright		Copyright © 2011 NoNumber! All Rights Reserved
 * @license			http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die();

$name = 'Cache Cleaner';
$alias = 'cachecleaner';
$ext = $name.' (admin module & system plugin)';

// SYSTEM PLUGIN
$states[] = installExtension( $alias, 'System - '.$name, 'plugin', array( 'folder' => 'system' ) );

// MODULE
$states[] = installExtension( $alias, $name, 'module', array( 'client_id' => '1' ), 1 );

// Stuff to do after installation / update
function afterInstall( &$db )
{
	$query = "UPDATE `#__modules`
		SET	`position` = 'status',
			`published` = 1,
			`access` = 3
		WHERE `module` = 'mod_cachecleaner'";

	$db->setQuery( $query );
	$db->query();
}

// Stuff to do after installation / update
// For Joomla 1.5
function afterInstall_15( &$db )
{
	afterInstall( $db );

	$query = "UPDATE `#__modules`
		SET	`access` = 2
		WHERE `module` = 'mod_cachecleaner'";

	$db->setQuery( $query );
	$db->query();
}