<?php
/**
 * Extension Install File
 * Does the stuff for the specific extensions
 *
 * @package			Cache Cleaner
 * @version			2.2.0
 *
 * @author			Peter van Westen <peter@nonumber.nl>
 * @link			http://www.nonumber.nl
 * @copyright		Copyright © 2012 NoNumber All Rights Reserved
 * @license			http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined('_JEXEC') or die;

$name = 'Cache Cleaner';
$alias = 'cachecleaner';
$ext = $name.' (administrator module & system plugin)';

// SYSTEM PLUGIN
$states[] = installExtension($states, $alias, 'System - '.$name, 'plugin', array('folder' => 'system'));

// MODULE
$states[] = installExtension($states, $alias, $name, 'module', array('access' => '3'), 1);

// Stuff to do after installation / update
// For Joomla 1.5
function afterInstall_j1(&$db)
{
	$query = "UPDATE `#__modules`
		SET	`access` = 2
		WHERE `module` = 'mod_cachecleaner'";

	$db->setQuery($query);
	$db->query();
}