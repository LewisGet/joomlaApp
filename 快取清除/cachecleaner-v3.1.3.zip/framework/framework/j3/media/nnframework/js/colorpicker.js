/**
 * JavaScript file for Element: ColorPicker
 *
 * @package         NoNumber Framework
 * @version         13.3.4
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2012 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

/**
 * BASED ON:
 * Very simple jQuery Color Picker CSS.
 * Copyright (C) 2012 Tanguy Krotoff
 * Licensed under the MIT license.
 *
 * Inspired by Bootstrap Twitter.
 * See https://github.com/twitter/bootstrap/blob/master/less/dropdowns.less
 * See http://twitter.github.com/bootstrap/assets/css/bootstrap.css
 */


(function($)
{
	var NNColorPicker = function(element, options)
	{
		this.select = $(element);
		this.options = $.extend({}, $.fn.nncolorpicker.defaults, options);

		this.select.hide();

		// Trick: fix span alignment
		// When a span does not contain any text, its alignment is not correct
		var fakeText = '&nbsp;&nbsp;&nbsp;&nbsp;';

		// Build the list of colors
		// <div class="selected" title="Green" style="background-color: #7bd148;" role="button"></div>
		var colorList = '';
		$('option', this.select).each(function()
		{
			var option = $(this);
			var color = option.val();
			var title = option.text();
			if (color == '' && title == '') {
				colorList += '<br />';
			} else {
				if (color == '') {
					color = 'FFFFFF';
				}
				var clss = 'label nncolorpicker-label';
				if (option.attr('selected')) {
					clss += ' active';
				}
				colorList += '<span class="' + clss + '" title="' + title + '" style="background-color: #' + color + ';" role="button" tabindex="0">'
					+ fakeText
					+ '</span>';
			}
		});

		if (this.options.picker) {
			var selectText = this.select.find('option:selected').text();
			var selectValue = this.select.val();
			if (selectValue == '') {
				selectValue = 'FFFFFF';
			}
			this.icon = $('<span class="label nncolorpicker-label" title="' + selectText + '" style="background-color: #' + selectValue + ';" role="button" tabindex="0">'
				+ fakeText
				+ '</span>').insertAfter(this.select);
			this.icon.on('click', $.proxy(this.show, this));

			this.picker = $('<span class="nncolorpicker-picker"></span>').appendTo(document.body);
			this.picker.html(colorList);
			this.picker.on('click', $.proxy(this.click, this));

			// Hide picker when clicking outside
			$(document).on('mousedown', $.proxy(this.hide, this));
			this.picker.on('mousedown', $.proxy(this.mousedown, this));
		} else {
			this.inline = $('<span class="nncolorpicker-inline"></span>').insertAfter(this.select);
			this.inline.html(colorList);
			this.inline.on('click', $.proxy(this.click, this));
		}
	};

	/**
	 * NNColorPicker class.
	 */
	NNColorPicker.prototype = {
		constructor: NNColorPicker,

		show: function()
		{
			var bootstrapArrowWidth = 16; // Empirical value
			var pos = this.icon.offset();
			this.picker.css({
				left: pos.left + this.icon.width() / 2 - bootstrapArrowWidth, // Middle of the icon
				top: pos.top + this.icon.outerHeight()
			});

			this.picker.show(this.options.delay);
		},

		hide: function()
		{
			this.picker.hide(this.options.delay);
		},

		click: function(e)
		{
			var target = $(e.target);
			if (target.length === 1) {
				if (target[0].nodeName.toLowerCase() === 'span') {
					// When you click on a color

					var color = target.css('background-color');
					var title = target.attr('title');

					// Mark this div as the selected one
					target.siblings().removeClass('active');
					target.addClass('active');

					if (this.options.picker) {
						this.icon.css('background-color', color);
						this.icon.attr('title', title);

						// Hide the picker
						this.hide();
					}

					// Change select value
					this.select.val(this.rgb2hex(color)).change();
				}
			}
		},

		/**
		 * Prevents the mousedown event from "eating" the click event.
		 */
		mousedown: function(e)
		{
			e.stopPropagation();
			e.preventDefault();
		},

		/**
		 * Converts a RGB color to its hexadecimal value.
		 *
		 * See http://stackoverflow.com/questions/1740700/get-hex-value-rather-than-rgb-value-using-$
		 */
		rgb2hex: function(rgb)
		{
			function hex(x)
			{
				return ("0" + parseInt(x, 10).toString(16)).slice(-2);
			}

			var matches = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
			if (matches === null) {
				// Fix for Internet Explorer < 9
				// Variable rgb is already a hexadecimal value
				return rgb;
			} else {
				return hex(matches[1]) + hex(matches[2]) + hex(matches[3]);
			}
		}
	};

	/**
	 * Plugin definition.
	 */
	$.fn.nncolorpicker = function(option)
	{
		// For HTML element passed to the plugin
		return this.each(function()
		{
			var $this = $(this),
				data = $this.data('nncolorpicker'),
				options = typeof option === 'object' && option;
			if (!data) {
				$this.data('nncolorpicker', (data = new NNColorPicker(this, options)));
			}
			if (typeof option === 'string') {
				data[option]();
			}
		});
	};

	$.fn.nncolorpicker.Constructor = NNColorPicker;

	/**
	 * Default options.
	 */
	$.fn.nncolorpicker.defaults = {
		// Animation delay
		delay: 0,

		// Show the picker or make it inline
		picker: false
	};

	$(document).ready(function()
	{
		$('select.nncolorpicker').nncolorpicker({
			picker: true
		});
	});
})(jQuery);
