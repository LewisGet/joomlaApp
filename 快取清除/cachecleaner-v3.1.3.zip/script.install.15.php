<?php
/**
 * Installer File
 * Performs an install / update of NoNumber extensions
 *
 * @package         NoNumber Installer
 * @version         13.3.4
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2012 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

define('ROOT', dirname(__FILE__));

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

// Load language for messaging
$lang = JFactory::getLanguage();
if ($lang->getTag() != 'en-GB') {
	// Loads English language file as fallback (for undefined stuff in other language file)
	$lang->load('com_nonumberinstaller', ROOT, 'en-GB');
}
$lang->load('com_nonumberinstaller', ROOT, null, 1);

JFactory::getApplication()->enqueueMessage(JText::sprintf('NNI_NOT_COMPATIBLE_OLD', implode('.', array_slice(explode('.', JVERSION), 0, 2))), 'error');
cleanupInstall();
uninstallInstaller();

/**
 * Cleanup install files/folders
 */
function cleanupInstall()
{
	$installer = JInstaller::getInstance();
	$source = str_replace('\\', '/', $installer->getPath('source'));
	$config = JFactory::getConfig();
	$tmp = dirname(str_replace('\\', '/', $config->getValue('config.tmp_path') . '/x'));

	if (strpos($source, $tmp) === false || $source == $tmp) {
		return;
	}

	$package_folder = dirname($source);
	if ($package_folder == $tmp) {
		$package_folder = $source;
	}

	$package_file = '';
	switch (JFactory::getApplication()->input->getString('installtype')) {
		case 'url':
			$package_file = JFactory::getApplication()->input->getString('install_url');
			$package_file = str_replace(dirname($package_file), '', $package_file);
			break;
		case 'upload':
		default:
			if (isset($_FILES) && isset($_FILES['install_package']) && isset($_FILES['install_package']['name'])) {
				$package_file = $_FILES['install_package']['name'];
			}
			break;
	}
	if (!$package_file && $package_folder != $source) {
		$package_file = str_replace($package_folder . '/', '', $source) . '.zip';
	}

	$package_file = $tmp . '/' . $package_file;

	JInstallerHelper::cleanupInstall($package_file, $package_folder);
}

function uninstallInstaller($alias = 'nonumberinstaller')
{
	$app = JFactory::getApplication();
	$db = JFactory::getDBO();

	$query = 'SELECT `id` FROM `#__components`'
		. ' WHERE `option` = ' . $db->quote('com_' . $alias)
		. ' AND `parent` = 0'
		. ' LIMIT 1';
	$db->setQuery($query);
	$id = (int) $db->loadResult();
	if ($id > 1) {
		$installer = JInstaller::getInstance();
		$installer->uninstall('component', $id);
	}
	$query = 'ALTER TABLE `#__components` AUTO_INCREMENT = 1';
	$db->setQuery($query);
	$db->query();

	// Delete language files
	$lang_folder = JPATH_ADMINISTRATOR . '/language';
	$languages = JFolder::folders($lang_folder);
	foreach ($languages as $lang) {
		$file = $lang_folder . '/' . $lang . '/' . $lang . '.com_' . $alias . '.ini';
		if (JFile::exists($file)) {
			JFile::delete($file);
		}
	}

	// Delete old language files
	$files = JFolder::files(JPATH_SITE . '/language', 'com_nonumberinstaller.ini');
	foreach ($files as $file) {
		JFile::delete(JPATH_SITE . '/language/' . $file);
	}

	// Redirect with message
	$app->redirect('index.php?option=com_installer');
}
