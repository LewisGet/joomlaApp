<?php
/**
 * Extension Install File
 * Does the stuff for the specific extensions
 *
 * @package         Cache Cleaner
 * @version         3.1.5
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2012 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

function install(&$states, &$ext)
{
	$name = 'Cache Cleaner';
	$alias = 'cachecleaner';
	$ext = $name . ' (administrator module & system plugin)';

	// SYSTEM PLUGIN
	$states[] = installExtension($states, $alias, 'System - ' . $name, 'plugin', array('folder' => 'system'));

	// ADMIN MODULE
	$states[] = installExtension($states, $alias, $name, 'module', array('access' => '3'), 1);
}

