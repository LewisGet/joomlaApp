<?php
/*
Plugin Name: PHP Image Editor Pro
Plugin URI: http://www.phpimageeditor.se/wordpress.php
Description: Nice image editing directly in WordPress.
Author: Patrik Hultgren
Author URI: http://www.phpimageeditor.se
Version: 0.6
Stable tag: 0.6
License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/

/**
 * PHP Image Editor
 *
 * @package WordPress
 *
 * Nice image editing directly in WordPress.
 *
 * @since 2012-06-02
 */
 
define('PIE_SERVICE_URL', 'http://www.phpimageeditor.se/service');
define('PIE_VERSION', '0.6');
define('PIE_USER_CAPABILITY_DEFAULT', 'upload_files');

global $phpimageeditor_db_version;
$phpimageeditor_db_version = "1.0";

function phpimageeditor_install() {
	global $wpdb;
	global $phpimageeditor_db_version;

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

	$sql = "CREATE TABLE IF NOT EXISTS ".$wpdb->prefix."pie_code (
			  id int(11) NOT NULL AUTO_INCREMENT,
			  code text NOT NULL,
			  created int(11) NOT NULL DEFAULT '0',
			  PRIMARY KEY (id)
			);";
	
	dbDelta($sql);

	add_option("phpimageeditor_db_version", $phpimageeditor_db_version);
}

register_activation_hook(__FILE__,'phpimageeditor_install');

 function phpimageeditor_init(){
    
 	if (is_admin() && current_user_can(get_option('phpimageeditor_user_capability', PIE_USER_CAPABILITY_DEFAULT))) {

 		$uploads = wp_upload_dir();
 		$is_multisite = (substr_count($uploads['path'],'/blogs.dir/'));
		$upload_path = get_option('upload_path'); 

		wp_enqueue_script('jquery');
	    wp_enqueue_script('thickbox',null,array('jquery'));
	    wp_enqueue_style('thickbox.css', '/'.WPINC.'/js/thickbox/thickbox.css', null, '1.0');
	    wp_enqueue_script('php-image-editor-script', plugins_url().'/php-image-editor/editimage.js', array('jquery', 'thickbox'));
	    
		$params = array(
		  'host' => site_url(),
		  'language' => get_bloginfo("language"),
		  'wordpressversion' => get_bloginfo("version"),
		  'serviceurl' => PIE_SERVICE_URL,
		  'version' => PIE_VERSION,
		  'is_multisite' => $is_multisite,
		  'upload_path' => $upload_path
		);    
	
	 	wp_localize_script('php-image-editor-script', 'PieParams', $params);
 	}
}

add_action('init','phpimageeditor_init');
	
function phpimageeditor_parse_request($wp) {
	
	if (current_user_can(get_option('phpimageeditor_user_capability', PIE_USER_CAPABILITY_DEFAULT))) {
		if (array_key_exists('pie-ajax-save-code', $wp->query_vars))
			phpimageeditor_ajax_save_code();
		else if (array_key_exists('pie-ajax-file-info', $wp->query_vars))
			phpimageeditor_ajax_file_info();
	}
	
	if (array_key_exists('pie-download-image', $wp->query_vars))
		phpimageeditor_download_image();
}
	
add_action('parse_request', 'phpimageeditor_parse_request');

function phpimageeditor_query_vars($vars) {

	if (current_user_can(get_option('phpimageeditor_user_capability', PIE_USER_CAPABILITY_DEFAULT))) {
		$vars[] = 'pie-ajax-save-code';
		$vars[] = 'pie-ajax-file-info';
	}
	
	$vars[] = 'pie-download-image';
	return $vars;
}

add_filter('query_vars', 'phpimageeditor_query_vars');

function phpimageeditor_ajax_save_code() {
	
	header("Cache-Control: no-store"); 
	header('Content-Type: text/xml');

	print '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
	print '<response>';

	$code = '';
	$filepath = '';

	if (isset($_POST['filepath']) && isset($_POST['host'])) {

		$filepath = urldecode($_POST['filepath']);
		
		if (file_exists($filepath) && getimagesize($filepath)) {

			$host = urldecode($_POST['host']);

			global $current_user;
      		get_currentuserinfo();
			$code = base64_encode($filepath.'##'.$host.'##'.$_SERVER['REMOTE_ADDR'].'##'.microtime().'##'.$current_user->ID);

			global $wpdb;
			$wpdb->insert($wpdb->prefix.'pie_code', array('id' => null, 'code' => $code, 'created' => time()), array('%d', '%s', '%d'));
		}
		else
			$filepath = '';
	}

	print '<code>'.$code.'</code>';
	print '<filepath>'.$filepath.'</filepath>';
	
	print '</response>';

	die;
}

function phpimageeditor_ajax_file_info() {

	header("Cache-Control: no-store"); 
	header('Content-Type: text/xml');
	print '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
	print '<response>';
	
	$image = '';
	$imagechanged = '';
	
	if (isset($_POST['filepath'])) {
		$filepath = urldecode($_POST['filepath']);
		
		if (file_exists($filepath)) {
			$image = $filepath;
			$imagechanged = filemtime($filepath);
		}
	}
	
	print '<image>'.$image.'</image>';
	print '<imagechanged>'.$imagechanged.'</imagechanged>';
	
	print '</response>';

	die;
}

function phpimageeditor_download_image()
{
	error_reporting(0);
	
	global $wpdb;
	
	$wpdb->query($wpdb->prepare("DELETE FROM ".$wpdb->prefix."pie_code WHERE (created + ".(60*60*2).") < %d", time()));
	
	$THUMBNAIL_SETTING_ALL = 1;
	$THUMBNAIL_SETTING_THUMBNAIL = 2;
	$THUMBNAIL_SETTING_EXCEPT_THUMBNAIL = 3;
	
	//Download and copy image file to where it belongs.
	if (isset($_GET['code'])) {
		$code = urldecode($_GET['code']);

		if (isset($_GET['saveas'])) {
			$saveas = urldecode($_GET['saveas']);

			if (isset($_GET['thumbnailsetting'])) {
				$thumbnailsetting = (int)urldecode($_GET['thumbnailsetting']);
			
				$result = $wpdb->get_results($wpdb->prepare("SELECT * FROM ".$wpdb->prefix."pie_code WHERE code = %s", $code));
				
				if (count($result) > 0) {
					$from = PIE_SERVICE_URL.'/editimagesedit/'.$code.'.txt';
					
					$tmpCode = base64_decode($code);
					$arr = explode('##', $tmpCode);
					$to = $arr[0];
					$user_id = (int)$arr[4];
					$to_org = $to;
					
					$arr = explode("/", $to);
					$to_filename_org = $arr[count($arr)-1];
		
					$pos_dot = strrpos($to_filename_org, ".");
					
					$file_and_type = array();
					$file_and_type[0] = substr($to_filename_org, 0, $pos_dot);
					$file_and_type[1] = strtolower(substr($to_filename_org, $pos_dot+1, strlen($to_filename_org) - $pos_dot));
					
					$to_filename = $saveas.'.'.$file_and_type[1];
					$to_save_as = str_replace($file_and_type[0], $saveas, $to);
					
					if ($file_and_type[1] == 'jpg' || $file_and_type[1] == 'jpeg' || $file_and_type[1] == 'png' || $file_and_type[1] == 'gif') {
	
						if ($file_content = phpimageeditor_file_get_contents($from)) {
	
							$download = plugin_dir_path(__FILE__).'download/'.$to_filename;
	
							if (file_put_contents($download, $file_content) !== false) {
	
								if ($imagesize = getimagesize($download)) {
									//It's an image.
	
									$uploads = wp_upload_dir();
									
									if ($is_multisite = (substr_count($uploads['path'],'/blogs.dir/'))) {
										$upload_base = get_option('upload_path'); //Only set on multisite?
										// Multisite = wp-content/blogs.dir/2/files
										// Normal site = wp-content/uploads 
									}
									else {
										//site_url() = 	http://www.example.com or http://www.example.com/wordpress
										//baseurl = http://example.com/wp-content/uploads
										$upload_base = str_replace(site_url().'/', '', $uploads['baseurl']);
									}

									$saveas_is_active = false;
									$save_as_postmeta = false;
									
									if ($to != $to_save_as) {
										
										//Save as is active.
										
										$to = $to_save_as;	
										$saveas_is_active = true;
	
										if (!file_exists($to)) {
											
											$imagetype_str = '';
											if ($imagesize[2] == IMAGETYPE_JPEG) 
												$imagetype_str = 'jpeg';
											else if ($imagesize[2] == IMAGETYPE_PNG) 
												$imagetype_str = 'png';
											else if ($imagesize[2] == IMAGETYPE_GIF) 
												$imagetype_str = 'gif';
												
											$post_date = time();
											$post = array(
											  'menu_order' => 0,
											  'comment_status' => 'open', 
											  'ping_status' => 'open',
											  'pinged' => '',
											  'guid' => site_url().'/'.$to,
											  'post_author' => $user_id,
											  'post_content' => '',
											  'post_date' => date('Y-m-d H:i:s', $post_date),
											  'post_date_gmt' => date('Y-m-d H:i:s', $post_date), 
											  'post_parent' => 0,
											  'post_status' => 'inherit',  
											  'post_title' => $saveas, 
											  'post_type' => 'attachment', 
											  'post_mime_type' => 'image/'.$imagetype_str, 
											);  
											$post_id = wp_insert_post($post);
											
											add_post_meta($post_id, '_wp_attached_file', str_replace($upload_base.'/', '', $to));
											
											list($hw_width, $hw_height) = wp_constrain_dimensions($imagesize[0], $imagesize[1], 128, 96);
											
											$save_as_postmeta = new stdClass;
											$save_as_postmeta->post_id = $post_id;
											$save_as_postmeta->metadata = array();
											$save_as_postmeta->metadata['width'] = 0;
											$save_as_postmeta->metadata['height'] = 0;
											$save_as_postmeta->metadata['hwstring_small'] = "height='".$hw_height."' width='".$hw_width."'";
											$save_as_postmeta->metadata['file'] = str_replace($upload_base.'/', '', $to);
											$save_as_postmeta->metadata['sizes'] = array();
											$save_as_postmeta->metadata['image_meta'] = array();
											$save_as_postmeta->metadata['image_meta']['aperture'] = 0;
											$save_as_postmeta->metadata['image_meta']['credit'] = '';
											$save_as_postmeta->metadata['image_meta']['camera'] = '';
											$save_as_postmeta->metadata['image_meta']['caption'] = '';
											$save_as_postmeta->metadata['image_meta']['created_timestamp'] = 0;
											$save_as_postmeta->metadata['image_meta']['copyright'] = '';
											$save_as_postmeta->metadata['image_meta']['focal_length'] = 0;
											$save_as_postmeta->metadata['image_meta']['iso'] = 0;
											$save_as_postmeta->metadata['image_meta']['shutter_speed'] = 0;
											$save_as_postmeta->metadata['image_meta']['title'] = '';
										}
									}
	
									$post_meta = phpimageeditor_attachment_post_meta(str_replace($upload_base.'/', '', $to));
									
									if ($saveas_is_active && file_exists($to) && !$post_meta) {
										//Maybe someone tries to use save as for replacing a thumbnail. That's not okey.
										$output = '11';
									}
									else
									{
										if ($save_as_postmeta)
											$post_meta = $save_as_postmeta; //Save as image doesnt't already exists. We need to create our won post_meta.

										if ($saveas_is_active && !file_exists($to))	
											$thumbnailsetting = $THUMBNAIL_SETTING_ALL; //We can't just replace thumbnail when original image doesn't exists.

										if (!$post_meta) {
											//Found no post meta for file. Maybe file has been deleted during image editing?
											$output = '12 ';
										}	
										else if ((($thumbnailsetting == $THUMBNAIL_SETTING_ALL || $thumbnailsetting == $THUMBNAIL_SETTING_EXCEPT_THUMBNAIL) && copy($download, $to)) || 
												   $thumbnailsetting == $THUMBNAIL_SETTING_THUMBNAIL) {
		
											//Generate thumbnails.
											require_once(ABSPATH.'/wp-admin/includes/image.php');
											
											$dest_path = null;
											
											if ($thumbnailsetting == $THUMBNAIL_SETTING_THUMBNAIL) {
												$dest_path = substr($to, 0, strrpos($to, "/")); //Get path to where the thumb should be generated.
												$to = $download; //The original image hasn't been replaced. We must work with the downloaded instead.
											}
												
											if ($post_meta)
											{
												if ($thumbnailsetting == $THUMBNAIL_SETTING_ALL || $thumbnailsetting == $THUMBNAIL_SETTING_EXCEPT_THUMBNAIL)
												{
													//Only update width and height when the original image is replaced.
													$post_meta->metadata['width'] = $imagesize[0];
													$post_meta->metadata['height'] = $imagesize[1];
												}

												$image_sizes = array();
										 	
										 		// make thumbnails and other intermediate sizes
												global $_wp_additional_image_sizes;
												
												foreach (get_intermediate_image_sizes() as $s ) {
													$image_sizes[$s] = array('width' => '', 'height' => '', 'crop' => FALSE);
													if (isset($_wp_additional_image_sizes[$s]['width']))
														$image_sizes[$s]['width'] = intval($_wp_additional_image_sizes[$s]['width']); // For theme-added sizes
													else
														$image_sizes[$s]['width'] = get_option( "{$s}_size_w" ); // For default sizes set in options
													if (isset($_wp_additional_image_sizes[$s]['height']))
														$image_sizes[$s]['height'] = intval($_wp_additional_image_sizes[$s]['height']); // For theme-added sizes
													else
														$image_sizes[$s]['height'] = get_option("{$s}_size_h"); // For default sizes set in options
													if (isset($_wp_additional_image_sizes[$s]['crop']))
														$image_sizes[$s]['crop'] = intval($_wp_additional_image_sizes[$s]['crop']); // For theme-added sizes
													else
														$image_sizes[$s]['crop'] = get_option("{$s}_crop"); // For default sizes set in options
												}
										
												$image_sizes = apply_filters('intermediate_image_sizes_advanced', $image_sizes);
												
												foreach ($image_sizes as $size_name => $size_attributes) {

													if ($thumbnailsetting == $THUMBNAIL_SETTING_ALL || 
														($thumbnailsetting == $THUMBNAIL_SETTING_THUMBNAIL && $size_name == 'thumbnail') ||
														($thumbnailsetting == $THUMBNAIL_SETTING_EXCEPT_THUMBNAIL && $size_name != 'thumbnail')) {
													
														$thumb = image_resize($to, $size_attributes['width'], $size_attributes['height'], $size_attributes['crop'], null, $dest_path);
														
														if (is_wp_error($thumb)) {
															//Thumb is probably larger the original and couldn't be generated.
															//print $key.' '.$thumb->get_error_message().'<br/>';
															unset($post_meta->metadata['sizes'][$size_name]);
														}
														else {	
															$arr = explode("/", $thumb);
															$filename = $arr[count($arr)-1];
															$tmp = substr($filename, 0, strripos($filename, "."));
															$tmp = substr($tmp, strripos($tmp, "-")+1);
															$thumb_sizes = explode('x', $tmp);
															
															$post_meta->metadata['sizes'][$size_name]['width'] = $thumb_sizes[0];
															$post_meta->metadata['sizes'][$size_name]['height'] = $thumb_sizes[1];
															$post_meta->metadata['sizes'][$size_name]['file'] = $filename;
														}
													}
												}
			
												if ($save_as_postmeta)
													add_post_meta($post_meta->post_id, '_wp_attachment_metadata', $post_meta->metadata);
												else
													update_post_meta($post_meta->post_id, '_wp_attachment_metadata', $post_meta->metadata);	
												
												$output = '1';	
					
												$wpdb->query($wpdb->prepare("DELETE FROM ".$wpdb->prefix."pie_code WHERE code = %s", $code));
												
												if ($saveas_is_active || $thumbnailsetting == $THUMBNAIL_SETTING_THUMBNAIL)
													touch($to_org); //Otherwise the lightbox won't be closed.
											}
										}
										else {
											if ($saveas_is_active)
												$output = '10';
											else
												$output = '2';
										}
									}
								}
								else
									$output = '3';
		
								unlink($download);
							}
							else
								$output = '8';
						}
						else
							$output = '4';
					}
					else
						$output = '5';
				}
				else
					$output = '6';
			}
			else
				$output = '13';
		}
		else
			$output = '9';
	}
	else
		$output = '7';

	print $output;
	die;
}

function phpimageeditor_file_get_contents($url)
{
	if (ini_get('safe_mode') || !ini_get('allow_url_fopen')) {
		if ($url_parts = parse_url($url))
			return phpimageeditor_http_request('GET', $url_parts['host'], 80, $url_parts['path']);
	}
	else
		return file_get_contents($url);

	return false;
}

function phpimageeditor_http_request(
    $verb = 'GET',             /* HTTP Request Method (GET and POST supported) */
    $ip,                       /* Target IP/Hostname */
    $port = 80,                /* Target TCP port */
    $uri = '/',                /* Target URI */
    $getdata = array(),        /* HTTP GET Data ie. array('var1' => 'val1', 'var2' => 'val2') */
    $postdata = array(),       /* HTTP POST Data ie. array('var1' => 'val1', 'var2' => 'val2') */
    $cookie = array(),         /* HTTP Cookie Data ie. array('var1' => 'val1', 'var2' => 'val2') */
    $custom_headers = array(), /* Custom HTTP headers ie. array('Referer: http://localhost/ */
    $timeout = 1000,           /* Socket timeout in milliseconds */
    $req_hdr = false,          /* Include HTTP request headers */
    $res_hdr = false           /* Include HTTP response headers */
    ) {
    $ret = '';
    $verb = strtoupper($verb);
    $cookie_str = '';
    $getdata_str = count($getdata) ? '?' : '';
    $postdata_str = '';

    foreach ($getdata as $k => $v)
        $getdata_str .= urlencode($k) .'='. urlencode($v);

    foreach ($postdata as $k => $v)
        $postdata_str .= urlencode($k) .'='. urlencode($v) .'&';

    foreach ($cookie as $k => $v)
        $cookie_str .= urlencode($k) .'='. urlencode($v) .'; ';

    $crlf = "\r\n";
    $req = $verb .' '. $uri . $getdata_str .' HTTP/1.1' . $crlf;
    $req .= 'Host: '. $ip . $crlf;
    $req .= 'User-Agent: Mozilla/5.0 Firefox/3.6.12' . $crlf;
    $req .= 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' . $crlf;
    $req .= 'Accept-Language: en-us,en;q=0.5' . $crlf;
    $req .= 'Accept-Encoding: deflate' . $crlf;
    $req .= 'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7' . $crlf;
   
    foreach ($custom_headers as $k => $v)
        $req .= $k .': '. $v . $crlf;
       
    if (!empty($cookie_str))
        $req .= 'Cookie: '. substr($cookie_str, 0, -2) . $crlf;
       
    if ($verb == 'POST' && !empty($postdata_str)) {
        $postdata_str = substr($postdata_str, 0, -1);
        $req .= 'Content-Type: application/x-www-form-urlencoded' . $crlf;
        $req .= 'Content-Length: '. strlen($postdata_str) . $crlf . $crlf;
        $req .= $postdata_str;
    }
    else $req .= $crlf;
   
    if ($req_hdr)
        $ret .= $req;
   
    if (($fp = @fsockopen($ip, $port, $errno, $errstr)) == false)
        return false;
   
    stream_set_timeout($fp, 0, $timeout * 1000);
   
    fputs($fp, $req);
    while ($line = fgets($fp)) $ret .= $line;
    fclose($fp);
   
    if (!$res_hdr)
        $ret = substr($ret, strpos($ret, "\r\n\r\n") + 4);
   
    return $ret;
}

function phpimageeditor_attachment_post_meta($meta_value) {
	
	global $wpdb;
	$result1 = $wpdb->get_results($wpdb->prepare("SELECT * FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value = %s", $meta_value));
	
	if (count($result1)) {
		$postmeta = $result1[0];
		
		$result2 = $wpdb->get_results($wpdb->prepare("SELECT * FROM $wpdb->postmeta WHERE meta_key = '_wp_attachment_metadata' AND post_id = %d", $postmeta->post_id));
		if (count($result2)) {
			
			$postmeta2 = new stdClass;
			$postmeta2->post_id = $result2[0]->post_id;
			$postmeta2->metadata = unserialize($result2[0]->meta_value);

			return $postmeta2;
		}
	}
		
	return false;
}