=== PHP Image Editor Pro ===
Contributors: patrikhultgren-1
Tags: image,editing,editor,picture,resize,contrast,brightness
Tested up to: 3.3.2
Stable tag: 0.6
Requires at least: 3.0

Nice image editing directly in WordPress. Replaces the original image editor with more image editing features.

== Description ==
Image editing directly in WordPress with more features than the original image editor. 
The actual image editing is done on http://www.phpimageeditor.se
When "Edit Image" is pressed, the image is sent to http://www.phpimageeditor.se 
After you're done editing, the image is sent back to your server.
So it will only work on live sites. There is a free trial period of two weeks for each domain name.

== Installation instructions ==
Unzip the zip file to /yoursite/wp-content/plugins/
Set the directory /yoursite/wp-content/plugins/php-image-editor/download/ to read, write, and execute permissions.
If you already haven´t done it, set your own image directory, subdirectories to read, write, and execute permissions. For example /yoursite/wp-content/uploads/

Note: CHMOD 777 ain't secure. Read more at: http://www.phpimageeditor.se/installation.php

== Changelog ==

= 0.6 =
* Fixed bug when using multi sites.

= 0.5 =
* Initial release.