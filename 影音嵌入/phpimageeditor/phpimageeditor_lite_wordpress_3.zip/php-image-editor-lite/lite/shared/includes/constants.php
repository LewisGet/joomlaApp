<?php    
	/**
	* Protection
	*
	* This string of code will prevent hacks from accessing the file directly.
	*/
	defined('ABSPATH') or die("Cannot access pages directly.");
	
	define("PIE_PHP_VERSION_MINIMUM", "5");
	define("PIE_GD_VERSION_MINIMUM", "2.0.28");
	define("PIE_MENU_RESIZE", "0");
	define("PIE_MENU_ROTATE", "1");
	define("PIE_MENU_CROP", "2");
	define("PIE_MENU_EFFECTS", "3");
?>