<?php
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
	

	$is_admin = (isset($_GET['isadmin']) && $_GET['isadmin'] == 'true');	

	// Set flag that this is a parent file
	define('_JEXEC', 1);
	define('DS', DIRECTORY_SEPARATOR);
	
	if (file_exists(dirname(__FILE__) . '/defines.php')) {
		include_once dirname(__FILE__) . '/defines.php';
	}
	
	if (!defined('_JDEFINES')) {
		define('JPATH_BASE', dirname(__FILE__).DS."..".DS."..".DS."..".DS."..".DS.($is_admin ? "administrator" : ""));
		require_once JPATH_BASE.'/includes/defines.php';
	}
	
	require_once JPATH_BASE.'/includes/framework.php';
	
	$is_admin = (isset($_GET['isadmin']) && $_GET['isadmin'] == 'true');	
	
	if ($is_admin)
	{
		require_once JPATH_BASE.'/includes/helper.php';
		require_once JPATH_BASE.'/includes/toolbar.php';
	}
	
	// Mark afterLoad in the profiler.
	JDEBUG ? $_PROFILER->mark('afterLoad') : null;
	
	// Instantiate the application.
	$app = JFactory::getApplication($is_admin ? 'administrator' : 'site');
	
	// Initialise the application.
	$app->initialise(array(
		'language' => $app->getUserState('application.lang', 'lang')
	));
	
	// Mark afterIntialise in the profiler.
	JDEBUG ? $_PROFILER->mark('afterInitialise') : null;
	
	// Route the application.
	$app->route();

	$user =& JFactory::getUser();
	
	include_once '../pro/shared/includes/acl_functions.php';

	if (!PIE_Access($user))
		die;
	
	include_once '../pro/shared/includes/ajax_save_code_xml.php';
?>