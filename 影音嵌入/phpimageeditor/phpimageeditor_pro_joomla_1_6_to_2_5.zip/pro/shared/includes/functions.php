<?php
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
		

    function PIE_GetTexts($filePath)
	{
		$texts = array();
		$lines = file($filePath);
		
		foreach($lines as $line_num => $line)
		{
			if (substr_count($line, "#") == 0)
			{
				$keyAndText = explode("=", trim($line));
				$texts[$keyAndText[0]] = $keyAndText[1];
			}
		}
		
		return $texts;
	}
	
	function PIE_HttpRequest(
	    $verb = 'GET',             /* HTTP Request Method (GET and POST supported) */
	    $ip,                       /* Target IP/Hostname */
	    $port = 80,                /* Target TCP port */
	    $uri = '/',                /* Target URI */
	    $getdata = array(),        /* HTTP GET Data ie. array('var1' => 'val1', 'var2' => 'val2') */
	    $postdata = array(),       /* HTTP POST Data ie. array('var1' => 'val1', 'var2' => 'val2') */
	    $cookie = array(),         /* HTTP Cookie Data ie. array('var1' => 'val1', 'var2' => 'val2') */
	    $custom_headers = array(), /* Custom HTTP headers ie. array('Referer: http://localhost/ */
	    $timeout = 1000,           /* Socket timeout in milliseconds */
	    $req_hdr = false,          /* Include HTTP request headers */
	    $res_hdr = false           /* Include HTTP response headers */
	    )
	{
	    $ret = '';
	    $verb = strtoupper($verb);
	    $cookie_str = '';
	    $getdata_str = count($getdata) ? '?' : '';
	    $postdata_str = '';
	
	    foreach ($getdata as $k => $v)
	        $getdata_str .= urlencode($k) .'='. urlencode($v);
	
	    foreach ($postdata as $k => $v)
	        $postdata_str .= urlencode($k) .'='. urlencode($v) .'&';
	
	    foreach ($cookie as $k => $v)
	        $cookie_str .= urlencode($k) .'='. urlencode($v) .'; ';
	
	    $crlf = "\r\n";
	    $req = $verb .' '. $uri . $getdata_str .' HTTP/1.1' . $crlf;
	    $req .= 'Host: '. $ip . $crlf;
	    $req .= 'User-Agent: Mozilla/5.0 Firefox/3.6.12' . $crlf;
	    $req .= 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' . $crlf;
	    $req .= 'Accept-Language: en-us,en;q=0.5' . $crlf;
	    $req .= 'Accept-Encoding: deflate' . $crlf;
	    $req .= 'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7' . $crlf;
	   
	    foreach ($custom_headers as $k => $v)
	        $req .= $k .': '. $v . $crlf;
	       
	    if (!empty($cookie_str))
	        $req .= 'Cookie: '. substr($cookie_str, 0, -2) . $crlf;
	       
	    if ($verb == 'POST' && !empty($postdata_str))
	    {
	        $postdata_str = substr($postdata_str, 0, -1);
	        $req .= 'Content-Type: application/x-www-form-urlencoded' . $crlf;
	        $req .= 'Content-Length: '. strlen($postdata_str) . $crlf . $crlf;
	        $req .= $postdata_str;
	    }
	    else $req .= $crlf;
	   
	    if ($req_hdr)
	        $ret .= $req;
	   
	    if (($fp = @fsockopen($ip, $port, $errno, $errstr)) == false)
	        return false;
	   
	    stream_set_timeout($fp, 0, $timeout * 1000);
	   
	    fputs($fp, $req);
	    while ($line = fgets($fp)) $ret .= $line;
	    fclose($fp);
	   
	    if (!$res_hdr)
	        $ret = substr($ret, strpos($ret, "\r\n\r\n") + 4);
	   
	    return $ret;
	}
	
	function PIE_FileGetContents($url)
	{
		if (ini_get('safe_mode') || !ini_get('allow_url_fopen'))
		{
			if ($url_parts = parse_url($url))
				return PIE_HttpRequest('GET', $url_parts['host'], 80, $url_parts['path']);
		}
		else
			return file_get_contents($url);
	
		return false;
	}
	
	function PIE_IsJoomla16() 
	{
		global $mainframe;

		if ($mainframe)
			return false;
		
		return true;
	}

	function PIE_IsAdmin() 
	{
		global $mainframe;

		if ($mainframe)
		{
			//Joomla 1.5
			return $mainframe->isAdmin();
		}
		else
		{
			//Joomla 1.6
			$app = JFactory::getApplication();
			return $app->isAdmin();
		}
	}

	function PIE_AddEditJavascript() 
	{
		$admin_path = PIE_IsAdmin() ? '../' : '';
		
		$config =& JFactory::getConfig();
		
        $languagePathCurrent = $admin_path.'plugins/system/phpimageeditor/language/'.$config->getValue('config.language').'.ini';
        $languagePathEnglish = $admin_path.'plugins/system/phpimageeditor/language/en-GB.ini';

        $texts = array();

        if (file_exists($languagePathCurrent))
            $texts = PIE_GetTexts($languagePathCurrent);
        else if (file_exists($languagePathEnglish))
            $texts = PIE_GetTexts($languagePathEnglish);
            
        if (count($texts) > 0)          
        {
            $hostPath = str_replace("administrator/", "", JURI::base());
            $hostUrl = parse_url($hostPath);

			$version = new JVersion();

            if (!PIE_IsAdmin() && PIE_IsJoomla16())
            {
            	//In Joomla 1.6 frontend, the domain contains an extra /, like http://www.example.com//
            	//We need to add a slash, which will result in correct image paths without leading slashes.
            	$hostPath .= '/';
            }

            $document = &JFactory::getDocument();
            $document->addScript($admin_path.'plugins/system/phpimageeditor/pro/shared/javascript/joomla_editimagelink.js?a=3');
            $document->addScriptDeclaration("var PIE_IS_ADMIN = ".(PIE_IsAdmin() ? "true" : "false")."; var PIE_SYSTEM_VERSION = '".$version->getShortVersion()."'; var PIE_VERSION = '".PIE_VERSION."'; var PIE_SERVICE_URL = '".PIE_SERVICE_URL."'; var PIE_BASE_PATH = '".$hostUrl['path']."';");
            $document->addScriptDeclaration("window.addEvent('domready', function(){pie_add_editlink('".PIE_SERVICE_URL."/index.php?imagesrc=', '".$admin_path."plugins/system/phpimageeditor/','".$hostPath."',\"".htmlspecialchars($texts["EDIT IMAGE"], ENT_QUOTES)."\",'".$config->getValue('config.language')."','');});");
        }
	}

	function PIE_LoadSqueezeBox() 
	{
		$admin_path = PIE_IsAdmin() ? '../' : '';
    	$is_media_manager = (isset($_GET['option']) && ($_GET['option'] == 'com_media' && !isset($_GET['view'])));	//Media manager
        
        $document = &JFactory::getDocument();
    	$document->addScriptDeclaration("var PIE_IS_MEDIA_MANAGER = ".($is_media_manager ? "true" : "false").";");
	    $document->addScript($admin_path.'plugins/system/phpimageeditor/pro/javascript/load_squeeze_box.js?a=2');
    }

	function PIE_DownloadImage()
	{
		$db =& JFactory::getDBO();
		$db->setQuery("DELETE FROM #__pie_code WHERE (created + ".(60*60*2).") < ".time());
		$db->query();
		
		$output = '';
		
		//Download and copy image file to where it belongs.
		if (isset($_GET['code']))
		{
			$code = urldecode($_GET['code']);
	
			if (isset($_GET['saveas']))
			{
				$saveas = urldecode($_GET['saveas']);
	
				$db->setQuery("SELECT * FROM #__pie_code WHERE code = '".$code."'");
				
				if (($result = $db->query()) && $db->getNumRows($result) > 0)
				{
					$from = PIE_SERVICE_URL.'/editimagesedit/'.$code.'.txt';
					
					$tmpCode = base64_decode($code);
					$arr = explode('##', $tmpCode);
					$to = '../../../'.$arr[0];
					$to_org = $to;
					
					$arr = explode("/", $to);
					$to_filename_org = $arr[count($arr)-1];
		
					$pos_dot = strrpos($to_filename_org, ".");
					
					$file_and_type = array();
					$file_and_type[0] = substr($to_filename_org, 0, $pos_dot);
					$file_and_type[1] = strtolower(substr($to_filename_org, $pos_dot+1, strlen($to_filename_org) - $pos_dot));
					
					$to_filename = $saveas.'.'.$file_and_type[1];
					$to_save_as = str_replace($file_and_type[0], $saveas, $to);
					
					if ($file_and_type[1] == 'jpg' || $file_and_type[1] == 'jpeg' || $file_and_type[1] == 'png' || $file_and_type[1] == 'gif')
					{
						if ($file_content = PIE_FileGetContents($from))
						{
							$download = 'download/'.$to_filename;
							if (file_put_contents($download, $file_content) !== false)
							{
								if (getimagesize($download))
								{
									$saveas_is_active = false;
									
									if ($to != $to_save_as)
									{
										$to = $to_save_as;	
										$saveas_is_active = true;
									}
	
									//It´s an image.
									if (copy($download, $to))
									{
										$output = '1';	
			
										$db->setQuery("DELETE FROM #__pie_code WHERE code = '".$code."'");
										$db->query();
	
										if ($saveas_is_active)
											touch($to_org); //Otherwise the lightbox won´t be closed.
									}
									else
									{
										if ($saveas_is_active)
											$output = '10';
										else
											$output = '2';
									}
								}
								else
									$output = '3';
		
								unlink($download);
							}
							else
								$output = '8';
						}
						else
							$output = '4';
					}
					else
						$output = '5';
				}
				else
					$output = '6';
			}
			else
				$output = '9';
		}
		else
			$output = '7';

		return $output;
	}	

?>