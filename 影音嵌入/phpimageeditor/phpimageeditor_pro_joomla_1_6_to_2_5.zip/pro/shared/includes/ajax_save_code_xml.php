<?php
	header("Cache-Control: no-store"); 
	header('Content-Type: text/xml');

	print '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
	print '<response>';

	$code = '';
	$filepath = '';
	$language = '';

	if (isset($_GET['filepath']) && isset($_GET['language']))
	{
		$filepath = urldecode($_GET['filepath']);
		
		if (file_exists('../../../../'.$filepath) && getimagesize('../../../../'.$filepath))
		{
			$language = urldecode($_GET['language']);
			$hostPath = JURI::base();

			if (isset($_GET['isadmin']) && $_GET['isadmin'] == 'true')
			{
				$config =& JFactory::getConfig();
	            $live_site = $config->getValue('config.live_site');
	            if(trim($live_site) != '')
					$hostPath = str_replace("/administrator/", "", $hostPath); //To avoid bug returning wrong path when live_site is set in configuration.
			}
			
			//I suspect this replace is needed even sometimes when live_site is set.
			$hostPath = str_replace("/plugins/system/phpimageeditor/includes/", "", $hostPath);
			
			//Sometimes we get an extra trailing / slash, remove it.
			$hostPath = rtrim($hostPath, '/');
			
			$code = base64_encode($filepath.'##'.$hostPath.'##'.$_SERVER['REMOTE_ADDR'].'##'.microtime());
			
			$db =& JFactory::getDBO();
			$db->setQuery("INSERT INTO #__pie_code (id, code, created) VALUES (NULL , '$code', ".time().")");
			$db->query();
		}
		else
			$filepath = '';
	}

	print '<code>'.$code.'</code>';
	print '<filepath>'.$filepath.'</filepath>';
	print '<language>'.$language.'</language>';
	
	print '</response>';
?>