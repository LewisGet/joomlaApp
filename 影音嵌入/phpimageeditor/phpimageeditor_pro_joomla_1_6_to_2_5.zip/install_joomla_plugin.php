<?php
	
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
	
    
	// Set flag that this is a parent file
	define('_JEXEC', 1);
	define('DS', DIRECTORY_SEPARATOR);
	
	if (file_exists(dirname(__FILE__) . '/defines.php')) {
		include_once dirname(__FILE__) . '/defines.php';
	}
	
	if (!defined('_JDEFINES')) {
		define('JPATH_BASE', dirname(__FILE__).DS."..".DS."..".DS."..".DS."administrator");
		require_once JPATH_BASE.'/includes/defines.php';
	}
	
	require_once JPATH_BASE.'/includes/framework.php';
	require_once JPATH_BASE.'/includes/helper.php';
	require_once JPATH_BASE.'/includes/toolbar.php';
	
	// Mark afterLoad in the profiler.
	JDEBUG ? $_PROFILER->mark('afterLoad') : null;
	
	// Instantiate the application.
	$app = JFactory::getApplication('administrator');
	
	// Initialise the application.
	$app->initialise(array(
		'language' => $app->getUserState('application.lang', 'lang')
	));
	
	// Mark afterIntialise in the profiler.
	JDEBUG ? $_PROFILER->mark('afterInitialise') : null;
	
	// Route the application.
	$app->route();

	$db =& JFactory::getDBO();
	
	$dbTablePrefix = $app->getCfg('dbprefix');
	
	$user =& JFactory::getUser();
	
	//Array ( [Manager] => 6 [Administrator] => 7 [Super Users] => 8 ) 
	if (!in_array(7, $user->groups) && !in_array(8, $user->groups))
		header('Location: ../../../administrator/index.php');
?>
<html>
	<head>
		<title>Installation PHP Image Editor as a plugin in Joomla</title>
	</head>
	<h1>Install PHP Image Editor as a plugin in Joomla</h1>
	<?php
		$db->setQuery('show tables like "'.$dbTablePrefix.'pie_code"');
		$result = $db->query();
		
		if (!$result) 
		{
			echo '<p style="color: red;">'.$db->stderr().'</p>';
		}
		else
		{
			if ($db->getNumRows($result) > 0)
			{
				echo '<p style="color: green;">The '.$dbTablePrefix.'pie_code database table is already created.</p>';
			}
			else
			{
				$db->setQuery("CREATE TABLE `#__pie_code` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `code` TEXT CHARACTER SET utf8 NOT NULL,
				  `created` int(11) NOT NULL DEFAULT '0',
				  PRIMARY KEY (`id`)
				) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8");
				$result = $db->query();
				
				if (!$result) 
				{
					echo '<p style="color: red;">An error occurred during trying to create '.$dbTablePrefix.'pie_code table: '.$db->stderr().'</p>';
				}
				else 
				{
					echo '<p style="color: green;">Successfull created '.$dbTablePrefix.'pie_code table.</p>';
				}
			}
		}
		
		$db->setQuery("SELECT * FROM #__extensions WHERE element = 'phpimageeditor'");
		$result = $db->query();
		
		if (!$result) 
		{
			echo '<p style="color: red;">'.$db->stderr().'</p>';
		}
		else
		{
			if ($db->getNumRows($result) > 0)
			{
				echo '<p style="color: green;">The plugin is already installed.</p>';

				$db->setQuery("SELECT * FROM #__extensions WHERE element = 'phpimageeditor' AND enabled = 0");
				$result = $db->query();

				if ($db->getNumRows($result) > 0)
				{
					//Make sure its published.
					$db->setQuery("UPDATE #__extensions SET enabled = 1 WHERE element = 'phpimageeditor'");
					$result = $db->query();

					echo '<p style="color: green;">The plugin has been enabled.</p>';
				}
			}
			else
			{
				$db->setQuery("INSERT INTO #__extensions (
								extension_id,
								name,
								type,
								element,
								folder,
								client_id,
								enabled,
								access,
								protected,
								manifest_cache,
								params,
								custom_data,
								system_data,
								checked_out,
								checked_out_time,
								ordering,
								state)
								VALUES (
									NULL , 'PHP Image Editor - Edit your images directly in Joomla!', 'plugin', 'phpimageeditor', 'system', '0', '1', '1', '0', '', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'
								)");
				
				$result = $db->query();
				if (!$result) 
				{
					echo '<p style="color: red;">An error occurred during the installation: '.$db->stderr().'</p>';
				}
				else 
				{
					echo '<p style="color: green;">Successfull installation</p>';
				}
			}
		}
	?>
</html>