<?php

	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    YOUR PROJECT MUST ALSO BE OPEN SOURCE IN ORDER TO USE THIS VERSION OF PHP IMAGE EDITOR.
	    BUT YOU CAN USE PHP IMAGE EDITOR JOOMLA PRO IF YOUR CODE NOT IS OPEN SOURCE.
	    
	    This file is part of PHP Image Editor Joomla.
	
	    PHP Image Editor Joomla is free software: you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation, either version 3 of the License, or
	    (at your option) any later version.
	
	    PHP Image Editor Joomla is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.
	
	    You should have received a copy of the GNU General Public License
	    along with PHP Image Editor Joomla. If not, see <http://www.gnu.org/licenses/>.
	    */
	
    
	// Set flag that this is a parent file
	define('_JEXEC', 1);
	define('DS', DIRECTORY_SEPARATOR);
	
	if (file_exists(dirname(__FILE__) . '/defines.php')) {
		include_once dirname(__FILE__) . '/defines.php';
	}
	
	if (!defined('_JDEFINES')) {
		define('JPATH_BASE', dirname(__FILE__).DS."..".DS."..".DS."..".DS."administrator");
		require_once JPATH_BASE.'/includes/defines.php';
	}
	
	require_once JPATH_BASE.'/includes/framework.php';
	require_once JPATH_BASE.'/includes/helper.php';
	require_once JPATH_BASE.'/includes/toolbar.php';
	
	// Mark afterLoad in the profiler.
	JDEBUG ? $_PROFILER->mark('afterLoad') : null;
	
	// Instantiate the application.
	$app = JFactory::getApplication('administrator');
	
	// Initialise the application.
	$app->initialise(array(
		'language' => $app->getUserState('application.lang', 'lang')
	));
	
	// Mark afterIntialise in the profiler.
	JDEBUG ? $_PROFILER->mark('afterInitialise') : null;
	
	// Route the application.
	$app->route();

	$db =& JFactory::getDBO();
	
	$dbTablePrefix = $app->getCfg('dbprefix');
	
	$user =& JFactory::getUser();
	
	//Array ( [Manager] => 6 [Administrator] => 7 [Super Users] => 8 ) 
	if (!in_array(7, $user->groups) && !in_array(8, $user->groups))
		header('Location: ../../../administrator/index.php');
?>
<html>
	<head>
		<title>Installation PHP Image Editor as a plugin in Joomla</title>
	</head>
	<h1>Install PHP Image Editor as a plugin in Joomla</h1>
	<?php
		$db->setQuery("SELECT * FROM #__extensions WHERE element = 'phpimageeditor'");
		$result = $db->query();
		
		if (!$result) 
		{
			echo '<p style="color: red;">'.$db->stderr().'</p>';
		}
		else
		{
			if ($db->getNumRows($result) > 0)
			{
				echo '<p style="color: green;">The plugin is already installed.</p>';

				$db->setQuery("SELECT * FROM #__extensions WHERE element = 'phpimageeditor' AND enabled = 0");
				$result = $db->query();

				if ($db->getNumRows($result) > 0)
				{
					//Make sure its published.
					$db->setQuery("UPDATE #__extensions SET enabled = 1 WHERE element = 'phpimageeditor'");
					$result = $db->query();

					echo '<p style="color: green;">The plugin has been enabled.</p>';
				}
			}
			else
			{
				$db->setQuery("INSERT INTO #__extensions (
								extension_id,
								name,
								type,
								element,
								folder,
								client_id,
								enabled,
								access,
								protected,
								manifest_cache,
								params,
								custom_data,
								system_data,
								checked_out,
								checked_out_time,
								ordering,
								state)
								VALUES (
									NULL , 'PHP Image Editor - Edit your images directly in Joomla!', 'plugin', 'phpimageeditor', 'system', '0', '1', '1', '0', '', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'
								)");
				
				$result = $db->query();
				if (!$result) 
				{
					echo '<p style="color: red;">An error occurred during the installation: '.$db->stderr().'</p>';
				}
				else 
				{
					echo '<p style="color: green;">Successfull installation</p>';
				}
			}
		}
	?>
</html>