<?php
    
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
	

	global $mainframe;
	$admin_path = $mainframe->isAdmin() ? '../' : '';

	include_once JPATH_BASE.'/'.$admin_path.'plugins/system/phpimageeditor/pro/shared/includes/plugin.php';