<?php
    
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
	
    
    define( '_JEXEC', 1 );
	define('DS', DIRECTORY_SEPARATOR);
	define('JPATH_BASE', dirname(__FILE__).DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..");
	require_once( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once( JPATH_BASE .DS.'includes'.DS.'framework.php' );
	
	$mainframe =& JFactory::getApplication('administrator');	
	$mainframe->initialise();
	$mainframe->route();
	
	$db =& JFactory::getDBO();
	$dbTablePrefix = $mainframe->getCfg('dbprefix');
	
	$user =& JFactory::getUser();
	
	if ($user->usertype != 'Administrator' && $user->usertype != 'Super Administrator')
		header('Location: ../../../administrator/index.php');
?>
<html>
	<head>
		<title>Installation PHP Image Editor as a plugin in Joomla</title>
	</head>
	<h1>Install PHP Image Editor as a plugin in Joomla</h1>
	<?php
		$db->setQuery('show tables like "'.$dbTablePrefix.'pie_code"');
		$result = $db->query();
		
		if (!$result) 
		{
			echo '<p style="color: red;">'.$db->stderr().'</p>';
		}
		else
		{
			if ($db->getNumRows($result) > 0)
			{
				echo '<p style="color: green;">The '.$dbTablePrefix.'pie_code database table is already created.</p>';
			}
			else
			{
				$db->setQuery("CREATE TABLE `#__pie_code` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `code` TEXT CHARACTER SET utf8 NOT NULL,
				  `created` int(11) NOT NULL DEFAULT '0',
				  PRIMARY KEY (`id`)
				) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8");
				$result = $db->query();
				
				if (!$result) 
				{
					echo '<p style="color: red;">An error occurred during trying to create '.$dbTablePrefix.'pie_code table: '.$db->stderr().'</p>';
				}
				else 
				{
					echo '<p style="color: green;">Successfull created '.$dbTablePrefix.'pie_code table.</p>';
				}
			}
		}
		
		$db->setQuery("SELECT * FROM ".$dbTablePrefix."plugins WHERE element = 'joomla_phpimageeditor'");
		$result = $db->query();
		
		if (!$result) 
		{
			echo '<p style="color: red;">'.$db->stderr().'</p>';
		}
		else
		{
			if ($db->getNumRows($result) > 0)
			{
				echo '<p style="color: green;">The plugin is already installed.</p>';

				$db->setQuery("SELECT * FROM ".$dbTablePrefix."plugins WHERE element = 'joomla_phpimageeditor' AND published = 0");
				$result = $db->query();

				if ($db->getNumRows($result) > 0)
				{
					//Make sure its published.
					$db->setQuery("UPDATE ".$dbTablePrefix."plugins SET published = 1 WHERE element = 'joomla_phpimageeditor'");
					$result = $db->query();

					echo '<p style="color: green;">The plugin has been enabled.</p>';
				}
			}
			else
			{
				$db->setQuery("INSERT INTO ".$dbTablePrefix."plugins (id ,name ,element ,folder ,access ,ordering ,published ,iscore ,client_id ,checked_out ,checked_out_time ,params )VALUES (NULL , 'PHP Image Editor - Edit your images directly in Joomla!', 'joomla_phpimageeditor', 'system', '0', '0', '1', '0', '0', '0', '0000-00-00 00:00:00', '')");
				$result = $db->query();
				if (!$result) 
				{
					echo '<p style="color: red;">An error occurred during the installation: '.$db->stderr().'</p>';
				}
				else 
				{
					echo '<p style="color: green;">Successfull installation</p>';
				}
			}
		}
	?>
</html>