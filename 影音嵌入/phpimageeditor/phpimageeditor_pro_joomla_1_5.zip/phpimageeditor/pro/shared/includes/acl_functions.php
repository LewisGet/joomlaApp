<?php
	
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
	
	
	function PIE_Access($user)
	{
		global $mainframe;
		
		if ($mainframe)
		{
			//In Joomla 1.5, change this code if you wan´t to adjust which users who can edit images.
			return ($user->usertype == 'Manager' || $user->usertype == 'Administrator' || $user->usertype == 'Super Administrator');
		}
		else
		{
			//In Joomla 1.6 and 1.7, change this code if you wan´t to adjust which users who can edit images.
			//Group 8 = Super Users
			return (JAccess::check($user->id, 'core.edit') || in_array(8, $user->groups));
		}
	}		
?>