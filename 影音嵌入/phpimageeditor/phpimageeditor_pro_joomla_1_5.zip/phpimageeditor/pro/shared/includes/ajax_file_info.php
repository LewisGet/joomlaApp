<?php
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
	
	
	header("Cache-Control: no-store"); 
	header('Content-Type: text/xml');
	print '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
	print '<response>';
	
	$image = '';
	$imagechanged = '';
	
	if (isset($_GET['filepath']))
	{
		$filepath = urldecode($_GET['filepath']);
		
		if (file_exists('../../../../../../'.$filepath))
		{
			$image = $filepath;
			$imagechanged = filemtime('../../../../../../'.$filepath);
		}
	}
	
	print '<image>'.$image.'</image>';
	print '<imagechanged>'.$imagechanged.'</imagechanged>';
	
	print '</response>';
?>
