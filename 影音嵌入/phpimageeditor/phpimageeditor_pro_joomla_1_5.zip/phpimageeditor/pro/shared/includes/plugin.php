<?php
    
	
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/
	

	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' );
	
	function PIE_ShowEditLinks() 
	{
		$show_edit_link = ((isset($_GET['view']) && isset($_GET['option']) && $_GET['option'] == 'com_media' && (
			$_GET['view'] == 'images' || 							//Frontend article
			$_GET['view'] == 'mediaList' || 						//Backend Media Manager
			$_GET['view'] == 'imagesList')) ||						//Backend article 
			(isset($_GET['view']) && $_GET['view'] == 'imagesList')	//Frontend folder click
			); 	
		
		//print 'show_edit_link: '.$show_edit_link.'<br/>';
		return $show_edit_link;
	}

	global $mainframe;

	$admin_path = '';

	if ($mainframe)
		$admin_path = $mainframe->isAdmin() ? '../' : '';
	else
	{
		$app = JFactory::getApplication();
		$admin_path = $app->isAdmin() ? '../' : '';
	}

	include_once JPATH_BASE.'/'.$admin_path.'plugins/system/phpimageeditor/pro/shared/includes/acl_functions.php';

	$user =& JFactory::getUser();

	if (PIE_Access($user))
	{
		$url = parse_url(JURI::getInstance()->toString());
		
		$load_squeeze_box = ((isset($_GET['option']) && ($_GET['option'] == 'com_media' && !isset($_GET['view']))) ||	//Backend Media manager
							 (isset($_GET['option']) && ($_GET['option'] == 'com_content')) || 							//Backend add/edit article
							 (isset($url['path']) && (substr_count($url['path'], '/submit-an-article') == 1)) || 		//Frontend add article
							 (isset($_GET['task']) && $_GET['task'] == 'edit' && (!isset($_GET['option']) || (isset($_GET['option']) && $_GET['option'] != 'com_menus')))); //Frontend edit article. The second option check is used to avoid breaking select single article when creating new menu item in Joomla 1.5. 
	
		$show_edit_links = PIE_ShowEditLinks();	
	
		if ($load_squeeze_box || $show_edit_links)
		{
			include_once JPATH_BASE.'/'.$admin_path.'plugins/system/phpimageeditor/pro/shared/includes/functions.php';
			include_once JPATH_BASE.'/'.$admin_path.'plugins/system/phpimageeditor/includes/constants.php';
		}
	
		if ($load_squeeze_box)
		{
			JHTML::_('behavior.modal');
			
			if ($mainframe)
				$mainframe->registerEvent('onAfterInitialise', 'PIE_LoadSqueezeBox');
			else
			{
				$app = JFactory::getApplication();
				$app->registerEvent('onAfterInitialise', 'PIE_LoadSqueezeBox');
			}
				
			if (!$mainframe)
			{
	        	$document = &JFactory::getDocument();
	    		$document->addStyleSheet($admin_path.'plugins/system/phpimageeditor/pro/css/lightbox.css?a=1');
			}
		}
		else if ($show_edit_links)	
		{
			jimport('joomla.plugin.plugin');
			jimport('joomla.version');
	
			if ($mainframe)
				$mainframe->registerEvent('onAfterInitialise', 'PIE_AddEditJavascript');
			else
			{
				JHTML::_('behavior.modal'); //Needed to load mootools.
				$app = JFactory::getApplication();
				$app->registerEvent('onAfterInitialise', 'PIE_AddEditJavascript');
			}
		}
	}
?>