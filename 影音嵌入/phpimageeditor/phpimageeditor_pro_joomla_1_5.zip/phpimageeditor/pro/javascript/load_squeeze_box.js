var pie_squeeze_box = null;

window.addEvent('domready', function()
{ 
	if (PIE_IS_MEDIA_MANAGER || document.getElementById('editor-xtd-buttons'))
	{
		pie_squeeze_box = {
				   
			    loadModal: function(modalUrl,handler) {     
			       var options = $merge(options || {}, Json.evaluate("{handler: '" + handler + "', size: {x: 100, y: 100}}"));     
			       this.setOptions(this.presets, options);
			       this.assignOptions();
			       this.setContent(handler,modalUrl);
			   },

			   extend: $extend
			   
			}

			window.addEvent('domready', function() {
			    pie_squeeze_box.extend(SqueezeBox);
			    pie_squeeze_box.initialize({zIndex: 70000});
		});
	}
});