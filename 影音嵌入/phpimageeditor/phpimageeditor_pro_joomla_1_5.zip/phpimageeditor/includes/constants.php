<?php  
    
	    /*
	    Copyright 2008, 2009, 2010, 2011 Patrik Hultgren
	    
	    This file is part of PHP Image Editor Joomla Pro.
	
		This library is licensed with PHP Image Editor Joomla Pro Software License
		http://www.phpimageeditor.se/license-pro.php
		*/

	define('PIE_SERVICE_URL', 'http://www.phpimageeditor.se/service');
	define('PIE_VERSION', '2.31');
?>