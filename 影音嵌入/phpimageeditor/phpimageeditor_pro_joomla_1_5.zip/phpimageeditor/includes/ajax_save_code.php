<?php
    define( '_JEXEC', 1 );
	define('DS', DIRECTORY_SEPARATOR);
	define('JPATH_BASE', dirname(__FILE__).DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..");
	require_once( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once( JPATH_BASE .DS.'includes'.DS.'framework.php' );
	
	$mainframe =& JFactory::getApplication(isset($_GET['isadmin']) && $_GET['isadmin'] == 'true' ? 'administrator' : 'site');	
	$mainframe->initialise();
	$mainframe->route();

	$user =& JFactory::getUser();
	
	include_once '../pro/shared/includes/acl_functions.php';

	if (!PIE_Access($user))
		die;
	
	include_once '../pro/shared/includes/ajax_save_code_xml.php';
?>