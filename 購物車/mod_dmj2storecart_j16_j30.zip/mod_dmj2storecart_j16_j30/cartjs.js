var DMJ2Cart = {
	
	arg : '',
	
	init : function() {
		
	},
	
	refreshCart : function() {
		
		jQuery.post(
			document.URL,
			{ 
				'arg' : DMJ2Cart.arg,
				'dmj2storecart_task' : 'refresh'
			},
			function(data){
				var myTemp = jQuery('<div>'+data+'</div>').find('.dmj2cart_tablebody');
				jQuery('.dmj2storecart_cont table').html(myTemp);
			});
	}
	
}