<?php

	/**
	* @copyright		(C)2013 DM Digital S.r.l
	* @author 			DM Digital <support@dmjoomlaextensions.com>
	* @link				http://www.dmjoomlaextensions.com
	* @license 			GNU/LGPL http://www.gnu.org/copyleft/gpl.html
	**/
	
	defined('_JEXEC') or die('Direct Access to this location is not allowed.');
	
?>

<div class="dmj2storecart_cont">

	<?php 
	    if (!empty($cartItems) && is_array($cartItems)) { 
	    	require('table.php');
	    } else {
	    	echo '<table><tr><td class="empty_cart">' .JText::_('MOD_DMJ2STORECART_FRONT_EMPTYCART'). '</td></tr></table>';
	    }
	?>
	
	<a href="<?php echo JRoute::_('index.php?option=com_j2store&view=mycart'); ?>" class="view_cart_link"><?php echo $arg['link_text']; ?> &raquo;</a>
	
</div>

<script>
	
	DMJ2Cart.arg = encodeURI('<?php echo base64_encode( json_encode($arg) ); ?>');
	
	jQuery(document).ready(function(){
		
		DMJ2Cart.init();
		
		doMiniCart = (function(old) {
		    function extendsInit() {
		        old();
		        DMJ2Cart.refreshCart();
		    }
		    return extendsInit;
		})(doMiniCart);
		
		jQuery('.j2storeadminform .add_to_cart input.addcart').click(function(){
			DMJ2Cart.refreshCart();
		});
		
	});
	
</script>