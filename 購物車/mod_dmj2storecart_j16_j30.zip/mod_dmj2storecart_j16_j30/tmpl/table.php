<?php

	/**
	* @copyright		(C)2013 DM Digital S.r.l
	* @author 			DM Digital <support@dmjoomlaextensions.com>
	* @link				http://www.dmjoomlaextensions.com
	* @license 			GNU/LGPL http://www.gnu.org/copyleft/gpl.html
	**/
	
	defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>

<table class="dmj2cart_tablebody">
	<?php
	foreach ($cartItems as $item) {
	?>
    <tr>
    	<?php 
    		if ($arg['showthumb'] > 0) { 
    			echo '<td class="item_thumb">';
    			if (!empty($item->thumb)) {
	    			echo '<img src="'.$item->thumb.'" />';
    			}
    			echo '</td>';
	    	}
    	?>
    	<td class="product_name">
    		<a href="<?php echo $item->url; ?>"><?php echo $item->product_name; ?></a>
    	</td>
    	<td class="product_price">
    		<?php echo $item->price_out; ?> 
    		<span class="product_quantity">x <?php echo $item->product_qty; ?></span>
    	</td>
    </tr>
	<?php 
	} 
	?>
	<tr class="cart_total">
	    <td class="label" <?php if ($arg['showthumb']>0) echo 'colspan="2"'; ?>><?php echo JText::_('MOD_DMJ2STORECART_FRONT_TOTAL'); ?>:</td>
	    <td class="count"><?php echo $cartTotal; ?></td>
	</tr>
</table>