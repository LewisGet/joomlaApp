<?php

	/**
	* @copyright		(C)2013 DM Digital S.r.l
	* @author 			DM Digital <support@dmjoomlaextensions.com>
	* @link				http://www.dmjoomlaextensions.com
	* @license 			GNU/LGPL http://www.gnu.org/copyleft/gpl.html
	**/
	
	defined('_JEXEC') or die('Direct Access to this location is not allowed.');
	require_once(JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class DMHJ2Store {
	
	function getCartItems($arg) {
		
		$user =& JFactory::getUser();
		$cartList = DMHData::loadObjectList('SELECT * FROM #__j2store_mycart AS c WHERE c.session_id = "' .$arg['sessionId']. '" AND c.user_id = ' . $user->id);
		
		if (!empty($cartList)) {
			foreach ($cartList as $cart) {
				$itemData = DMHData::loadObject('SELECT * FROM #__content AS c WHERE c.id = ' . $cart->product_id);
				$cart->product_name = $itemData->title;
				$cart->price = self::getPrice($cart);
				$cart->price_out = self::formatPrice($cart->price,$arg);
				$cart->url = self::getItemUrl($cart->product_id,$itemData->catid);
				$cart->thumb = self::getImage($itemData,$arg);
			}
		}
		return $cartList;
	}
	
	function getCartTotal($cartList,$arg) {
		
		$total = 0;
		foreach ($cartList as $item) {
			$temp = $item->price * $item->product_qty;
			$total += $temp;
		}
		return self::formatPrice($total,$arg);
	}
	
	function getItemUrl($itemId, $categoryId) {
		
		$link = 'index.php?option=com_content&view=article&id='.$itemId;
        $link = ContentHelperRoute::getArticleRoute($itemId, $categoryId);
		return urldecode($link);
	}
	
	function getPrice($cart) {
		
		$price = DMHData::loadObject('SELECT p.* FROM #__j2store_prices AS p WHERE p.article_id = '.$cart->product_id);
		$totalPrice = $price->item_price;
		if (!empty($cart->product_attributes)) {
			$attributes = explode(',',$cart->product_attributes);
			foreach ($attributes as $attrId) {
				$attr = DMHData::loadObject('SELECT a.* FROM #__j2store_productattributeoptions AS a WHERE a.productattributeoption_id = '.$attrId);
				if (!empty($attr) && $attr->productattributeoption_prefix == '+') {
					$totalPrice += $attr->productattributeoption_price;
				} else if (!empty($attr) && $attr->productattributeoption_prefix == '-') {
					$totalPrice -= $attr->productattributeoption_price;
				} else if (!empty($attr) && $attr->productattributeoption_prefix == '=') {
					$totalPrice = $attr->productattributeoption_price;
				}
			}
		}
		if ($price->item_tax > 0) {
			$tax = DMHData::loadResult('SELECT t.tax_percent FROM #__j2store_taxprofiles AS t WHERE t.id = '.$price->item_tax);
			$totalPrice = $totalPrice*(1+$tax);
		}
		return $totalPrice;
	}
	
	function getImage($itemData,$arg) {
		
		if ($arg['show_thumb_cart'] == 'within_text') {
			$imageUrl = '';
			$output = preg_match( '/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $itemData->introtext, $matches);
			if ($output > 0) {
				$imageUrl = self::checkImgSrc($matches[1]);
			}
		} else if ($arg['show_thumb_cart'] == 'intro') {
			$imageUrl = '';
			$images = json_decode($itemData->images);
			if (!empty($images->image_intro)) {
				$imageUrl = self::checkImgSrc($images->image_intro);
			}
		} else if ($arg['show_thumb_cart'] == 'fulltext') {
			$imageUrl = '';
			$images = json_decode($itemData->images);
			if (!empty($images->image_fulltext)) {
				$imageUrl = self::checkImgSrc($images->image_fulltext);
			}
		} else {
			$imageUrl = '';
		}
		return $imageUrl;
	}
	
	function formatPrice($price, $arg) {
		
		$price = number_format($price,$arg['currency_num_decimals'],$arg['currency_decimal'],$arg['currency_thousands']);
		if ($arg['currency_position'] == 'pre') {
			$price = $arg['currency'].' '.$price;
		} else {
			$price = $price.' '.$arg['currency'];
		}
		return $price;
	}
	
	function checkImgSrc($imageUrl) {
		
		$parsedUrl = parse_url($imageUrl);
		if (empty($parsedUrl['scheme'])) {
			$imageUrl = JUri::base().$imageUrl;
		}
		return $imageUrl;
	}
	
}

?>