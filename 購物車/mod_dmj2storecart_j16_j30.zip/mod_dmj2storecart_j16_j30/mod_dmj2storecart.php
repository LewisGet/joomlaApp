<?php

	/**
	* @copyright		(C)2013 DM Digital S.r.l
	* @author 			DM Digital <support@dmjoomlaextensions.com>
	* @link				http://www.dmjoomlaextensions.com
	* @license 			GNU/LGPL http://www.gnu.org/copyleft/gpl.html
	**/
	
	defined('_JEXEC') or die('Direct Access to this location is not allowed.');
	if (!defined('DS')) define('DS',DIRECTORY_SEPARATOR);
	require_once(JPATH_SITE.DS.'modules'.DS.'mod_dmj2storecart'.DS.'helpers'.DS.'globalhelper.php');
	require_once(JPATH_SITE.DS.'modules'.DS.'mod_dmj2storecart'.DS.'helpers'.DS.'dbhelper.php');
	
	if (JRequest::getVar('dmj2storecart_task','') == 'refresh') {
	
		$arg = JRequest::getVar('arg','');
		$arg = base64_decode($arg);
		$arg = get_object_vars(json_decode($arg));
		
		$cartItems = DMHJ2Store::getCartItems($arg);
		$cartTotal = DMHJ2Store::getCartTotal($cartItems,$arg);
		
		if (!empty($cartItems) && is_array($cartItems)) {
			require(JPATH_SITE.DS.'modules'.DS.'mod_dmj2storecart'.DS.'tmpl'.DS.'table.php');
		}
		
		exit;
		
	} else {
	
		$mySession =& JFactory::getSession();
		$app = JFactory::getApplication('site');
		$j2sParams = $app->getParams('com_j2store');
		
		$arg = array();
		$arg['moduleclasss_sfx'] = 		$params->get('moduleclass_sfx','');
		$arg['link_text'] = 			$params->get('link_text', 'View Cart');
		$arg['showthumb'] = 			$params->get('showthumb', 1);
		$arg['sessionId'] = 			$mySession->getId();
		$arg['currency'] = 				$j2sParams->get('currency', '$');
		$arg['currency_position'] = 	$j2sParams->get('currency_position', 'pre');
		$arg['currency_num_decimals'] = $j2sParams->get('currency_num_decimals', '2');
		$arg['currency_decimal'] = 		$j2sParams->get('currency_decimal', '.');
		$arg['currency_thousands'] = 	$j2sParams->get('currency_thousands', ',');
		$arg['show_thumb_cart'] = 		$j2sParams->get('show_thumb_cart', 'intro');
		
		$cartItems = DMHJ2Store::getCartItems($arg);
		$cartTotal = DMHJ2Store::getCartTotal($cartItems,$arg);
		
		$document = JFactory::getDocument();
		$document->addStyleSheet('modules/mod_dmj2storecart/style.css');
		$document->addScript('modules/mod_dmj2storecart/cartjs.js');
		if ($params->get('include_jquery',1)>0) {
			$document->addScript('http://code.jquery.com/jquery-1.9.0.js');
		}
		
		require(JPATH_SITE.DS.'modules'.DS.'mod_dmj2storecart'.DS.'tmpl'.DS.'default.php');
		
	}

?>