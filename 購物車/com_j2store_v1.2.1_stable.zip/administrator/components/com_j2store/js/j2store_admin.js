function j2storeUpdate()
{
    location.reload(true);
}
