<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

//no direct access
defined('_JEXEC') or die('Restricted access'); 
require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_k2store'.DS.'library'.DS.'prices.php');
require_once (JPATH_SITE.DS.'components'.DS.'com_k2store'.DS.'helpers'.DS.'orders.php');
$row = @$this->row;
$order = @$this->order;
$items = @$order->getItems();
if(JFactory::getUser()->id && empty($row->billing_first_name)) {
	$recipient_name = JFactory::getUser()->name; 
}else {
	$recipient_name = $row->billing_first_name.'&nbsp;'.$row->billing_last_name;
}
$ourl = $this->siteurl.'index.php?option=com_k2store&view=orders&task=view&id='.$row->id;
?>

<div class="k2store_ordermail_header">
<?php echo JText::sprintf('ORDER PLACED_HEADER', $recipient_name, $this->sitename, $row->order_id); ?>
</div>

<div>
	<h3 style='text-align: center;'>
		<?php echo JText::_( "Order Detail" ); ?>
	</h3>
</div>
<div id="k2store_order_info">

	<table class="orders">
		<tr class="order_info">
			<td>
				<h3>
					<?php echo JText::_("Order Information"); ?>
				</h3>
			</td>
			<td>
				<div>
					<table class="orderInfoTable">
						<tr>
							<td style="width: 90px"></td>
							<td></td>
						</tr>
						<tr>
							<td><strong><?php echo JText::_("Order ID"); ?> </strong>
							</td>
							<td><?php echo @$row->order_id; ?>
							</td>
						</tr>
						<tr>
							<td><strong><?php echo JText::_("Invoice No"); ?> </strong>
							</td>
							<td><?php echo @$row->id; ?>
							</td>
						</tr>
						<tr>
							<td><strong><?php echo JText::_("Date"); ?> </strong>
							</td>
							<td><?php echo JHTML::_('date', $row->created_date, $this->params->get('date_format', '%a, %d %b %Y, %I:%M%p')); ?>
							</td>
						</tr>
						<tr>
							<td><strong><?php echo JText::_("Status"); ?> </strong>
							</td>
							<td><?php echo JText::_(@$row->order_state); ?>
							</td>
						</tr>

					</table>
				</div>
			</td>
		</tr>

		<tr class="payment_info" style="background-color: #CEE0E8;">
			<td>
				<h3>
					<?php echo JText::_("Payment Information"); ?>
				</h3>
			</td>
			<td>
				<div>
					<table class="paymentTable">
						<tr>
							<td></td>
						</tr>
						<tr>
							<td><strong><?php echo JText::_("Amount"); ?> </strong>
							</td>
							<td><?php echo K2StorePrices::number( $row->order_total ); ?>
							</td>
						</tr>
						
						<?php if($this->params->get('show_billing_address')): ?>
								<tr>
								<td valign="top"><strong><?php echo JText::_("K2STORE_BILLING_ADDRESS"); ?> </strong></td>
								<td>
						
						
							<?php //TODO: legacy mode compatability. Those who do not have the order info will see this
							if(empty($row->billing_first_name)) {
								$billAddr =  K2StoreOrdersHelper::getAddress($row->user_id);
								
								if($billAddr->first_name || $billAddr->last_name)
								echo $billAddr->first_name." ".$billAddr->last_name."<br/>";
								
								if($billAddr->address_1)
								echo $billAddr->address_1.", ";
								
								echo $billAddr->address_2 ? $billAddr->address_2.", " : "<br/>";
								
								if($billAddr->city)
								echo $billAddr->city.", ";
								
								echo $billAddr->state ? $billAddr->state." - " : "";
								
								if($billAddr->zip)
								echo $billAddr->zip." <br/>";
								
								if($billAddr->country)
								echo $billAddr->country." <br/> ".JText::_('K2STORE_TELEPHONE').":";
								
								if($billAddr->phone_1)
								echo $billAddr->phone_1." , ";

								echo $billAddr->phone_2 ? $billAddr->phone_2.", " : "<br/> ";
								echo '<br/> ';
								echo $row->email; 
								
							} else {
								
								if($row->billing_first_name ||$row->billing_last_name)
								echo $row->billing_first_name." ".$row->billing_last_name."<br/>";
								
								if($row->billing_address_1)
								echo $row->billing_address_1.", ";
								
								echo $row->billing_address_2 ? $row->billing_address_2.", " : "<br/>";
								
								if($row->billing_city)
								echo $row->billing_city.", ";
								
								echo $row->billing_zone_name ? $row->billing_zone_name." - " : "";
								
								if($row->billing_zip)
								echo $row->billing_zip." <br/>";
								
								if($row->billing_country_name)
								echo $row->billing_country_name." <br/> ";
								
								if($row->billing_phone_1 || $row->billing_phone_2) {
								echo JText::_('K2STORE_TELEPHONE').":";	
								
								if($row->billing_phone_1)
								echo $row->billing_phone_1." , ";
								echo $row->billing_phone_2 ? $row->billing_phone_2 : "<br/> ";
								}
								
								echo '<br/> ';
								
								echo $row->user_email;
								
							}							
							?>
							</td>
						</tr>
						<?php endif; ?>
						<?php if($this->params->get('show_shipping_address') ): ?>
						<tr>
							<td valign="top"><strong><?php echo JText::_("K2STORE_SHIPPING_ADDRESS"); ?> </strong> 							</td>
							<td>
							<?php //TODO: legacy mode compatability. Those who do not have the order info will see this
							if(empty($row->shipping_first_name)) {
								$shipAddr =  K2StoreOrdersHelper::getAddress($row->user_id);
								
								if($shipAddr->first_name ||$shipAddr->last_name)								
								echo $shipAddr->first_name." ".$shipAddr->last_name."<br/>";
								
								if($shipAddr->address_1)
								echo $shipAddr->address_1.", ";
								echo $shipAddr->address_2 ? $shipAddr->address_2.", " : "<br/>";
								
								if($shipAddr->city)
								echo $shipAddr->city.", ";
								echo $shipAddr->state ? $shipAddr->state." - " : "";
								
								if($shipAddr->zip)
								echo $shipAddr->zip." <br/>";
								
								if($shipAddr->country)
								echo $shipAddr->country." <br/> ".JText::_('K2STORE_TELEPHONE').":";
								
								if($shipAddr->phone_1)
								echo $shipAddr->phone_1." , ";
								echo $shipAddr->phone_2 ? $shipAddr->phone_2 : "<br/> ";
								
							} else {
								if($row->shipping_first_name||$row->shipping_last_name)
								echo $row->shipping_first_name." ".$row->shipping_last_name."<br/>";
								
								if($row->shipping_address_1)
								echo $row->shipping_address_1.", ";
								echo $row->shipping_address_2 ? $row->shipping_address_2.", " : "<br/>";
								
								if($row->shipping_city)
								echo $row->shipping_city.", ";
								echo $row->shipping_zone_name ? $row->shipping_zone_name." - " : "";
								
								if($row->shipping_zip)
								echo $row->shipping_zip." <br/>";
								
								if($row->shipping_country_name)
								echo $row->shipping_country_name." <br/> ";
								
								if($row->shipping_phone_1 || $row->shipping_phone_2) {
									echo JText::_('K2STORE_TELEPHONE').":";
									if($row->shipping_phone_1) {
									echo $row->shipping_phone_1." , ";
									}	
									echo $row->shipping_phone_2 ? $row->shipping_phone_2 : "<br/> ";
								}							
							}							
							?>
							</td>
						</tr>
					<?php endif; ?>
												
					</table>
				</div>
			</td>
		</tr>
		<tr>
			<td><strong><?php echo JText::_("Associated Payment Records"); ?> </strong><br />
			</td>
			<td>
				<div>
					<table class="paymentTable">

						<tr>
							<td><strong><?php echo JText::_('Payment Type'); ?> </strong></td>
							<td><?php echo JText::_($row->orderpayment_type); ?>
							</td>
						</tr>

						<?php if ($row->orderpayment_type == 'payment_offline') { ?>
						<tr>
							<td><strong><?php echo JText::_('Payment Mode'); ?> </strong></td>
							<td><?php echo JText::_($row->transaction_details); ?>
							</td>
						</tr>
						<?php } ?>

						<tr>
							<td><strong><?php echo JText::_('Transaction ID'); ?> </strong></td>
							<td><?php echo $row->transaction_id; ?>
							</td>
						</tr>

						<tr>
							<td><strong><?php echo JText::_('Payment Status'); ?> </strong></td>
							<td><?php echo JText::_($row->transaction_status); ?></td>
						</tr>
					</table>
				</div>
			</td>
		</tr>
		<tr>
			<td><strong><?php echo JText::_("Customer Note"); ?> </strong><br />
			</td>
			<td>
				<table class="paymentTable">
					<tr>
						<td colspan="2"><?php echo $row->customer_note; ?>
						</td>
					</tr>
				</table>
			</td>
		</tr>

	</table>
</div>

<div id="items_info">
	<h3 style='text-align: center;'>
		<?php echo JText::_("Items in Order"); ?>
	</h3>

	<table class="cart_order" style="clear: both;">
		<thead>
			<tr>
				<th style="text-align: left;"><?php echo JText::_("Item"); ?></th>
				<th style="width: 192px; text-align: center;"><?php echo JText::_("Quantity"); ?>
				</th>
				<th style="width: 192px; text-align: right;"><?php echo JText::_("Amount"); ?>
				</th>
			</tr>
		</thead>
		<tbody>
			<?php $i=0; $k=0; ?>
			<?php foreach (@$items as $item) : ?>

			<tr class='row<?php echo $k; ?>'>
				<td><strong> <?php echo JText::_( $item->orderitem_name ); ?> </strong>
					<br /> <?php if (!empty($item->orderitem_attribute_names)) : ?> <?php echo $item->orderitem_attribute_names; ?>
					<br /> <?php endif; ?> 
					<?php if (!empty($item->orderitem_sku)) : ?>
					<b><?php echo JText::_( "SKU" ); ?>:</b> <?php echo $item->orderitem_sku; ?>
					<br /> <?php endif; ?> 
					<b><?php echo JText::_( "Price" ); ?>:</b> <?php echo K2StorePrices::number( $item->orderitem_price); ?>

				</td>
				<td style="text-align: center;"><?php echo $item->orderitem_quantity; ?>
				</td>
				<td style="text-align: right;"><?php echo K2StorePrices::number( $item->orderitem_final_price ); ?>
				</td>
			</tr>
			<?php $i=$i+1; $k = (1 - $k); ?>
			<?php endforeach; ?>

			<?php if (empty($items)) : ?>
			<tr>
				<td colspan="10" align="center"><?php echo JText::_('No items found'); ?>
				</td>
			</tr>
			<?php endif; ?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="2" style="text-align: right;"><?php echo JText::_( "Subtotal" ); ?>
				</th>
				<th style="text-align: right;"><?php echo K2StorePrices::number($order->order_subtotal); ?>
				</th>
			</tr>

			<tr>
				<th colspan="2" style="text-align: right;"><?php
				if (!empty($this->show_tax)) {
					echo JText::_("Product Tax Included");
				}
				else { echo JText::_("Product Tax");
				}
				?>
				</th>
				<th style="text-align: right;"><?php echo K2StorePrices::number($row->order_tax); ?>
				</th>
			</tr>

			<tr>
				<th colspan="2" style="text-align: right;"><?php echo JText::_( "Shipping" ); ?>
				</th>
				<th style="text-align: right;"><?php echo K2StorePrices::number($row->order_shipping); ?>
				</th>
			</tr>

			<?php if ($row->order_discount > 0): ?>
				
			<tr>
				<th colspan="2" style="text-align: right;">
				<?php 
					echo "(-)";
					echo JText::_("Discount")." (".$this->params->get('global_discount')."%) :";
				?>
				</th>
				<th style="text-align: right;"><?php echo K2StorePrices::number($row->order_discount); ?>
				</th>
			</tr>
			<?php endif;?>

			<tr>
				<th colspan="2" style="font-size: 120%; text-align: right;"><?php echo JText::_( "Total" ); ?>
				</th>
				<th style="font-size: 120%; text-align: right;"><?php echo K2StorePrices::number($row->order_total); ?>
				</th>
			</tr>
		</tfoot>
	</table>
</div>

<?php if(!$this->isGuest): //show only if the buyer is not a guest. Because a guest cannot access the stored order information ?>
<div class="k2store_ordermail_footer">
 <?php JText::sprintf('ORDER PLACED_FOOTER', $ourl); ?>
</div>
<?php endif; ?>
