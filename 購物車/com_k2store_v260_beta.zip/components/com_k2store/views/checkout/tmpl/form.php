<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$url = JRoute::_( "index.php?option=com_k2store&view=mycart" );
$return_url = JRoute::_( "index.php?option=com_k2store&view=checkout&task=begin" );
$guest_url = JRoute::_( "index.php?option=com_k2store&view=checkout&&task=begin");
$register_action_url = JRoute::_( "index.php?option=com_k2store&view=checkout&task=register" );
?>
<table id="k2store_checkout_table">
	<tr>
		<td class="k2store_login_box" valign="top">
			<fieldset>
				<legend>
						<?php echo JText::_('K2STORE_LOGIN'); ?>
				</legend>
				<!-- LOGIN FORM -->

				<?php if (JPluginHelper::isEnabled('authentication', 'openid')) :
				$lang->load( 'plg_authentication_openid', JPATH_ADMINISTRATOR );
				$langScript =   'var JLanguage = {};'.
						' JLanguage.WHAT_IS_OPENID = \''.JText::_( 'WHAT_IS_OPENID' ).'\';'.
						' JLanguage.LOGIN_WITH_OPENID = \''.JText::_( 'LOGIN_WITH_OPENID' ).'\';'.
						' JLanguage.NORMAL_LOGIN = \''.JText::_( 'NORMAL_LOGIN' ).'\';'.
						' var modlogin = 1;';
				$document = &JFactory::getDocument();
				$document->addScriptDeclaration( $langScript );
				JHTML::_('script', 'openid.js');
        				endif; ?>

				<form
					action="<?php echo JRoute::_( 'index.php?option=com_users&task=user.login', true, $this->params->get('usesecure')); ?>"
					method="post" name="login" id="form-login">

					<label for="username" class="k2storeUserName"><?php echo JText::_('USERNAME'); ?>
					</label>
					<br />
					<input type="text" name="username" class="inputbox"	alt="username" />
					<br />
					<label for="password" class="k2storePassword"><?php echo JText::_('password'); ?> </label>
					<br />
					<input type="password" name="password" class="inputbox"	alt="password" />
					<br />
					<?php if (JPluginHelper::isEnabled('system', 'remember')) : ?>
					<?php echo JText::_('REMEMBER ME'); ?>
					<span style="float: left;"> <input type="checkbox" name="remember"
						class="inputbox" value="yes" />
					</span>
					<?php endif; ?>
					<div class="clr"></div>
					<input type="submit" name="submit" class="k2store_checkout_button"
						value="<?php echo JText::_('K2STORE_LOGIN') ?>" />
					<ul class="loginLinks">
						<li><?php // TODO Can we do this in a lightbox or something? Why does the user have to leave? ?>
							<a
							href="<?php echo JRoute::_( 'index.php?option=com_users&view=reset' ); ?>">
								<?php echo JText::_('FORGOT_YOUR_PASSWORD'); ?>
						</a>
						</li>
						<li><?php // TODO Can we do this in a lightbox or something? Why does the user have to leave? ?>
							<a
							href="<?php echo JRoute::_( 'index.php?option=com_users&view=remind' ); ?>">
								<?php echo JText::_('FORGOT_YOUR_USERNAME'); ?>
						</a>
						</li>
					</ul>
					<input type="hidden" name="option" value="com_users" /> <input
						type="hidden" name="task" value="user.login" /> <input
						type="hidden" name="return"
						value="<?php echo base64_encode( $return_url ); ?>" />
					<?php echo JHTML::_( 'form.token' ); ?>
				</form>
			</fieldset>
		</td>
		<td class="k2store_register_box" valign="top">
			<fieldset>
				<legend>
					
						<?php echo JText::_('K2STORE_REGISTER_NEWUSER'); ?>
				</legend>
				<!-- Registration form -->
				<form action="<?php echo $register_action_url;?>" method="post"
					class="adminform form-validate" name="adminForm" id="form-register">
					
					<div class="k2store_register_fields">
						<label for="email"> <?php echo JText::_( 'K2STORE_REGISTER_EMAIL' ); ?>
							*
						</label> <br /> <input name="email" id="email"
							class="required validate-email" type="text" />
					</div>

					<div class="k2store_register_fields">
						<label for="confirm_mail"> <?php echo JText::_( 'K2STORE_CONFIRM_EMAIL' ); ?>*
						</label> <br /> <input name="confirm_mail" id="confirm_mail"
							class="required validate-email" type="text" />
					</div>
					<div class="k2store_register_fields">

						<label for="password"> <?php echo JText::_( 'K2STORE_PASSWORD' ); ?>
							*
						</label> <br /> <input name="password" id="password"
							class="required" type="password" />
					</div>
					<div class="k2store_register_fields">

						<label for="first_name"> <?php echo JText::_( 'K2STORE_CONFIRM_PASSWORD' ); ?>*
						</label> <br /> <input name="password2" id="password2"
							class="required" type="password" /><br />
					</div>
					<div class="k2store_register_fields">

						<input type="submit" name="submit" class="k2store_checkout_button"
							value="<?php echo JText::_('K2STORE_REGISTER') ?>" />
					</div>
					<?php echo JHTML::_( 'form.token' ); ?>
				</form>

			</fieldset>
		</td>
	</tr>
	<tr>
		<td colspan="2"><?php if ($this->params->get('allow_guest_checkout')) : ?>
			<!--Guest -->
			<div class="k2storeGuests">
			<form action="<?php echo $guest_url;?>" method="post"
					class="guestform form-validate" name="guest" id="form-guest">
				<!-- REGISTRATION -->
					<?php echo JTEXT::_('K2STORE_CHECKOUT_AS_GUEST_DESC'); ?>
					<br />
						
						<label for="k2store_guest_mail"><strong> <?php echo JText::_( 'K2STORE_GUEST_EMAIL' ); ?></strong><em>*</em>
						</label> 
						<input name="k2store_guest_mail" id="k2store_guest_mail" class="required validate-email" type="email" />
						<input type="submit" name="submit" class="k2store_checkout_button"
							value="<?php echo JText::_('K2STORE_CHECKOUT_AS_GUEST') ?>" />
				</form>
			</div> <?php endif; ?>
		</td>
	</tr>
</table>
