<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.6
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
if ($this->bill_address) {
	$billAddr = @$this->bill_address;
}
$k2params = $this->params;
/*
 * 1 required
* 2 not required
* 3 disable
* */
?>

<div id="k2store_billing_section">
	<ul class="form-list">
		<li id="billing-new-address-form">
			<fieldset>

				<ul>
					<!-- First Name and last name fields-->

					<li class="fields">
						<div class="customer-name">
							<div class="field name-firstname">
								<label class="required" for="first_name"><em>*</em> <?php echo JText::_('K2STORE_FIRST_NAME'); ?>
								</label>
								<div class="input-box">
									<input type="text" class="input-text required"
										title="First Name"
										value="<?php echo $billAddr->first_name; ?>"
										name="billing[first_name]" id="billing:firstname">
								</div>
							</div>

							<?php if($k2params->get('bill_lname') != 3):?>
							<div class="field name-lastname">
								<label
									class="<?php echo ($k2params->get('bill_lname')==1)?'required':''; ?>"
									for="billing:lastname"><em>*</em> <?php echo JText::_('K2STORE_LAST_NAME')?>
								</label>
								<div class="input-box">

									<input type="text"
										class="input-text <?php echo ($k2params->get('bill_lname')==1)?'required':''; ?>"
										title="Last Name" value="<?php echo $billAddr->last_name; ?>"
										name="billing[last_name]" id="billing:lastname">
								</div>
							</div>
							<?php endif; // bill last name?>
						</div>
					</li>

					<?php if($k2params->get('bill_addr_line1') != 3):?>
					<li class="wide"><label
						class="<?php echo ($k2params->get('bill_addr_line1')==1)?'required':''; ?>"
						for="billing:address_1"><em>*</em> <?php echo JText::_('K2STORE_ADDRESS'); ?>
					</label>
						<div class="input-box">
							<input type="text"
								class="input-text <?php echo ($k2params->get('bill_addr_line1')==1)?'required':''; ?>"
								title="Street Address"
								value="<?php echo $billAddr->address_1; ?>"
								id="billing:address_1" name="billing[address_1]">
						</div>
					</li>
					<?php endif; // bill address line 1?>
					
					<?php if($k2params->get('bill_addr_line2') != 3):?>
					<li class="wide">
						<div class="input-box">
							<input type="text"
								class="input-text <?php echo ($k2params->get('bill_addr_line2')==1)?'required':''; ?>"
								title="Street Address 2"
								value="<?php echo $billAddr->address_2; ?>"
								id="billing:address_2" name="billing[address_2]">
						</div>
					</li>
					<?php endif; // bill address line 2?>


					<?php if(($k2params->get('bill_zip') != 3)||($k2params->get('bill_city') != 3)):?>
					<li class="fields">
					<?php if($k2params->get('bill_zip') != 3):?>
						<div class="field">
							<label class="<?php echo ($k2params->get('bill_zip')==1)?'required':''; ?>" for="billing:zip"><em>*</em> <?php echo JText::_('K2STORE_POSTCODE');?>
								Code</label>
							<div class="input-box">
								<input type="text" class="input-text <?php echo ($k2params->get('bill_zip')==1)?'required':''; ?>"
									title="Zip/Postal Code" value="<?php echo $billAddr->zip; ?>"
									id="billing:zip" name="billing[zip]">
							</div>
						</div> 
						<?php endif; // end zip ?> 
						<?php if($k2params->get('bill_city') != 3):?>
						<div class="field">
							<label class="<?php echo ($k2params->get('bill_city')==1)?'required':''; ?>" for="billing:city"><em>*</em> <?php echo JText::_('K2STORE_CITY'); ?>
							</label>
							<div class="input-box">
								<input type="text" class="input-text <?php echo ($k2params->get('bill_city')==1)?'required':''; ?>" title="City"
									value="<?php echo $billAddr->city; ?>" id="billing:city"
									name="billing[city]">
							</div>
						</div> 
						<?php endif; // end city ?>
					</li>
					<?php endif; // end both city and zip?>

					<?php if($k2params->get('bill_country_zone') != 3):?>
					<li class="fields">
						<div class="field">
							<label 
							class="required" 
							for="billing:country"><em>*</em> <?php echo JText::_('K2STORE_COUNTRY'); ?>
							</label>
							<div class="input-box">
								<?php echo $this->bill_country; ?>
							</div>

						</div>

						<div class="field">

							<label class="" for="billing:state"><?php echo JText::_('K2STORE_STATE_PROVINCE'); ?>
							</label>
							<div class="input-box">

								<span id="billZoneList"> </span>
							</div>

						</div>
					</li>
					<?php endif; // end country , zone ?>

					<?php if(($k2params->get('bill_phone1') != 3)||($k2params->get('bill_phone2') != 3)):?>

					<li class="fields">
						<?php if($k2params->get('bill_phone1') != 3):?>
						<div class="field">
							<label 
							class="<?php echo ($k2params->get('bill_phone1')==1)?'required':''; ?>" 
							for="billing:phone_1"><em>*</em> <?php echo JText::_('K2STORE_TELEPHONE')?>
							</label>
							<div class="input-box">
								<input type="text" 
								class="input-text <?php echo ($k2params->get('bill_phone1')==1)?'required':''; ?>" 
								title="Telephone" value="<?php echo $billAddr->phone_1; ?>" id="billing:phone_1"
									name="billing[phone_1]">
							</div>
						</div>
						<?php endif; // end phone1 ?> 
						<?php if($k2params->get('bill_phone2') != 3):?>
						<div class="field">
							<label 
							class="<?php echo ($k2params->get('bill_phone2')==1)?'required':''; ?>" 
							for="billing:phone_2"><em>*</em> <?php echo JText::_('K2STORE_MOBILE')?>
							</label>
							<div class="input-box">
								<input type="text" 
								class="input-text <?php echo ($k2params->get('bill_phone2')==1)?'required':''; ?>" 
								title="Mobile" value="<?php echo $billAddr->phone_2; ?>" id="billing:phone_2"
									name="billing[phone_2]">
							</div>
						</div>
						<?php endif; // end phone2 ?>
					</li>
					<?php endif; // end mobile , phone1 phone2?>
					<input type="hidden" name="bill_id"
						value="<?php echo @$billAddr->id; ?>" />
				</ul>
			</fieldset>
		</li>
	</ul>

</div>
