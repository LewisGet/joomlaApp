<?php 
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/
// no direct access
defined('_JEXEC') or die('Restricted access');
$edit_link = JRoute::_('index.php?option=com_k2store&view=checkout&task=begin');

$order = @$this->order;
if(count($this->bill_address))
	$billAddr = (object) $this->bill_address;
if(count($this->ship_address))
	$shipAddr = (object) $this->ship_address;

$plugin_html = @$this->plugin_html;
?>
<div class="k2store_order_review">

<div class='componentheading'>
	<span><?php echo JText::_( "K2STORE_REVIEW_CHECKOUT" ); ?>
	</span>
</div>

<!--    ORDER SUMMARY   -->
<h3>
	<?php echo JText::_("Order Summary") ?>
</h3>
<div class="k2storeOrderSummary">
	<?php echo @$this->orderSummary; ?>
</div>

<table class="billing_shipping" width="100%">
	<tr>
		<td width="50%"><?php
		if(($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout') ) && $billAddr){
			echo '<h3>'. JText::_('K2STORE_BILLING_ADDRESS') .'</h3>';
			echo $billAddr->first_name." ".$billAddr->last_name."<br/>";
			echo $billAddr->address_1.", ";
			echo $billAddr->address_2 ? $billAddr->address_2.", " : "<br/>";
			echo $billAddr->city.", ";
			echo $billAddr->zone_name ? $billAddr->zone_name." - " : "";
			echo $billAddr->zip." <br/>";
			echo $billAddr->country_name." <br/> ".JText::_('ph').":";
			echo $billAddr->phone_1." , ";
			echo $billAddr->phone_2 ? $billAddr->phone_2.", " : "<br/> ";
			//echo $billAddr->email ? JText::_('email').": ".$billAddr->email."<br/>" : "";
			
		}
		?>
		</td>
		
		<td><?php
		if($this->params->get('show_shipping_address') && $shipAddr){
			echo '<h3>'. JText::_('K2STORE_SHIPPING_ADDRESS') .'</h3>';
			echo $shipAddr->first_name." ".$shipAddr->last_name."<br/>";
			echo $shipAddr->address_1.", ";
			echo $shipAddr->address_2 ? $shipAddr->address_2.", " : "<br/>";
			echo $shipAddr->city.", ";
			echo $shipAddr->zone_name ? $shipAddr->zone_name." - " : "";
			echo $shipAddr->zip." <br/>";
			echo $shipAddr->country_name." <br/> ".JText::_('ph').":";
			echo $shipAddr->phone_1." , ";
			echo $shipAddr->phone_2 ? $shipAddr->phone_2.", " : "";			
		}
		?>
		</td>
				
</tr>
<tr><td colspan="2"><div class="edit_address_link" style="text-align:right;padding:3px;">
				<a href="<?php echo $edit_link; ?>" >
				  <?php echo JText::_('K2STORE_EDIT_ADDRESS'); ?>
				  </a>
				  </div></td></tr>
				  </table>

<div class="reset"></div>

<!--    PAYMENT METHOD   -->
<h3>
	<?php echo JText::_("K2STORE_PAYMENT_METHOD"); ?>
</h3>

<?php echo $plugin_html; ?>

</div>