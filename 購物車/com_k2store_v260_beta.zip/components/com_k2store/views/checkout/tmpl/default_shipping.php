<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.6
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

if ($this->ship_address) {
	$shipAddr = @$this->ship_address;
}
$k2params = $this->params;

?>

<div id="k2store_shipping_section" >
<h3><?php echo JText::_('K2STORE_SHIPPING_ADDRESS'); ?></h3>
	<ul class="form-list">
		<li id="shipping-new-address-form">
			<fieldset>
				
				<ul>
					<li class="fields">

						<div class="customer-name">
							<div class="field name-firstname">
								<label class="input-label" for="first_name"><em>*</em><?php echo JText::_('K2STORE_FIRST_NAME'); ?></label>
								<div class="input-box">
									<input type="text" class="input-text"
										title="First Name" value="<?php echo $shipAddr->first_name; ?>" name="shipping[first_name]"
										id="shipping:firstname">
								</div>
							</div>
							
							<?php if($k2params->get('ship_lname') != 3):?>
							<div class="field name-lastname">
								<label class="input-label" for="shipping:lastname"><em>*</em><?php echo JText::_('K2STORE_LAST_NAME')?></label>
								<div class="input-box">
									<input type="text" class="input-text"
										title="Last Name" value="<?php echo $shipAddr->last_name; ?>" name="shipping[last_name]"
										id="shipping:lastname">
								</div>
							</div>
							<?php endif; // ship last name?>
						</div>


					</li>

					<li class="wide"><label class="input-label" for="shipping:address_1"><em>*</em><?php echo JText::_('K2STORE_ADDRESS'); ?></label>
						<div class="input-box">
							<input type="text" class="input-text"
								title="Street Address" value="<?php echo $shipAddr->address_1; ?>" id="shipping:address_1"
								name="shipping[address_1]">
						</div>
					</li>
					
					<?php if($k2params->get('ship_addr_line2') != 3):?>
					<li class="wide">
						<div class="input-box">
							<input type="text" class="input-text1" value="<?php echo $shipAddr->address_2; ?>"
								id="shipping:address_2" name="shipping[address_2]"
								title="Street Address 2">
						</div>

					</li>
					<?php endif; // ship address line 2?>


					<?php if(($k2params->get('ship_zip') != 3)||($k2params->get('ship_city') != 3)):?>
					<li class="fields">
					<?php if($k2params->get('ship_zip') != 3):?>
						<div class="field">

							<label class="input-label" for="shipping:zip"><em>*</em><?php echo JText::_('K2STORE_POSTCODE');?>
								Code</label>
							<div class="input-box">
								<input type="text"
									class="input-text"
									title="Zip/Postal Code" value="<?php echo $shipAddr->zip; ?>" id="shipping:zip"
									name="shipping[zip]">
							</div>

						</div>
						<?php endif; // end zip ?>
						<?php if($k2params->get('ship_city') != 3):?>

						<div class="field">

							<label class="input-label" for="shipping:city"><em>*</em><?php echo JText::_('K2STORE_CITY'); ?></label>
							<div class="input-box">
								<input type="text" class="input-text"
									title="City" value="<?php echo $shipAddr->city; ?>" id="shipping:city" name="shipping[city]">
							</div>

						</div>
						<?php endif; // end city ?>
					</li>
					<?php endif; // end both city and zip?>
					
					<?php if($k2params->get('ship_country_zone') != 3):?>
					<li class="fields">

						<div class="field">

							<label class="input-label required" for="shipping:country"><em>*</em><?php echo JText::_('K2STORE_COUNTRY'); ?></label>
							<div class="input-box">
							<?php echo $this->ship_country; ?>
							</div>

						</div>

						<div class="field">

							<label class="" for="shipping:state"><?php echo JText::_('K2STORE_STATE_PROVINCE'); ?></label>
							<div class="input-box">
									<span id="shipZoneList"> </span>
							</div>

						</div>
					</li>
					<?php endif; // end country , zone ?>
					
					<?php if(($k2params->get('ship_phone1') != 3)||($k2params->get('ship_phone2') != 3)):?>
					
					<li class="fields">
					
					<?php if($k2params->get('ship_phone1') != 3):?>

						<div class="field">

							<label class="input-label" for="shipping:phone_1"><em>*</em><?php echo JText::_('K2STORE_TELEPHONE')?></label>
							<div class="input-box">
								<input type="text" class="input-text"
									title="Telephone" value="<?php echo $shipAddr->phone_1; ?>" id="shipping:phone_1"
									name="shipping[phone_1]">
							</div>

						</div>
						<?php endif; // end phone1 ?> 
						<?php if($k2params->get('ship_phone2') != 3):?>
						<div class="field">

							<label class="input-label" for="shipping:phone_2"><em>*</em><?php echo JText::_('K2STORE_MOBILE')?></label>
							<div class="input-box">
								<input type="text" class="input-text"
									title="Mobile" value="<?php echo $shipAddr->phone_2; ?>" id="shipping:phone_2"
									name="shipping[phone_2]">
							</div>

						</div>
						<?php endif; // end phone1 ?>

					</li>
					<?php endif; // end mobile , phone1 phone2?>
				</ul>
			</fieldset>
		</li>
	</ul>
	
			<input type="hidden" name="ship_id"	value="<?php echo @$shipAddr->id; ?>" /> 
				 
</div>