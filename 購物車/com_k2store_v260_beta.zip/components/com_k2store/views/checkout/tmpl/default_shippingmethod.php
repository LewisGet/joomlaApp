<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.6
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

	<h3>
		<?php echo JText::_('K2STORE_SHIPPING_INFORMATION'); ?>
	</h3>
	<?php echo $this->order->shipping->shipping_name; ?>
