<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.6
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_k2store'.DS.'library'.DS.'popup.php');
?>

<h3>
	<?php echo JText::_('K2STORE_CUSTOMER_NOTE'); ?>
</h3>
<textarea name="customer_note" rows="3" cols="40"><?php echo $this->order->customer_note; ?></textarea>
<div id="checkbox_tos">
	<input type="checkbox" class="required" id="k2store_tos"
		name="k2store_tos" value="1" /> <label for="k2store_tos"> <?php 
		if(! $this->tos_link==null){
			echo K2StorePopup::popup($this->tos_link,JText::_('K2STORE_TERMS_AND_CONDITIONS'));
		} else{ echo JText::_('K2STORE_TERMS_AND_CONDITIONS');
} ?>
	</label>	
</div>