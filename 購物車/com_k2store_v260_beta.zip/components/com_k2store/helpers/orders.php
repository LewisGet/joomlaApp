<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class K2StoreOrdersHelper {
	
	
	  function sendUserEmail($user_id, $order_id, $payment_status, $order_status, $order_state_id)
    {
        $mainframe =& JFactory::getApplication();
                
        // grab config settings for sender name and email
        $config     = &JComponentHelper::getParams('com_k2store');
        $k2params = &JComponentHelper::getParams('com_k2');
        $mailfrom   = $config->get( 'emails_defaultemail', $mainframe->getCfg('mailfrom') );
        $fromname   = $config->get( 'emails_defaultname', $mainframe->getCfg('fromname') );
       
        $sitename   = $config->get( 'sitename', $mainframe->getCfg('sitename') );
        $siteurl    = $config->get( 'siteurl', JURI::root() );
        
        //now get the order table's id based on order id
        $id = K2StoreOrdersHelper::_getOrderKey($order_id);
        //now get the receipient
        $recipient = K2StoreOrdersHelper::_getRecipient($id);
        
        if($user_id && empty($recipient->billing_first_name)) {
        	$recipient->name = JFactory::getUser()->name;
        } else {
        	$recipient->name = $recipient->billing_first_name.' '.$recipient->billing_last_name;
        }
        
        $html = K2StoreOrdersHelper::_getHtmlFormatedOrder($id, $user_id);   
        
        $ourl = $siteurl.'index.php?option=com_k2store&view=orders&task=view&id='.$id;
   
        $mailer =& JFactory::getMailer();
        $mode = 1;
        
        $subject = JText::sprintf('ORDER USER EMAIL SUB', $recipient->name, $sitename);
        
        $msg = '';
        $msg .= $html;
       //send attachments as well
        
        //allow_attachment_downloads
        
        //attachements
        
        //send attachments, only when the order state is confirmed and attachments are allowed
        if ($config->get('allow_attachment_downloads'))  {      
	        if ($order_state_id == 1) {
			
	        $attachments = K2StoreOrdersHelper::getAttachments($order_id);
	        
	        $path = $k2params->get('attachmentsFolder', NULL);
			if (is_null($path)) {
            $savepath = JPATH_ROOT.DS.'media'.DS.'k2'.DS.'attachments';
			} else {
            $savepath = $path;
			}
			
	        
			if (count($attachments)>0) {
				$msg .='<br />----------------------------------------------------------------------------------------------------------- <br />';
				$msg .= JText::_('The attached file(s) to this email').': <br />';
				foreach($attachments as $attachment) {
					$myfile = trim($attachment->titleAttribute);
					$msg .= 'File: '.$myfile.'<br />';
					$att = $savepath.DS.$myfile;
					$mailer->addAttachment($att);
				}//foreach
			}//if count
	        
			}
		} 

		$admin_emails = $config->get('admin_email') ;
		$admin_emails = explode(',',$admin_emails ) ;
      
        if ($recipient) 
        {           
            
            $mailer->addRecipient($recipient->email);
       	    $mailer->addCC( $admin_emails );
            $mailer->setSubject( $subject );
            $mailer->setBody($msg);
            $mailer->IsHTML($mode);          
            $mailer->setSender(array( $mailfrom, $fromname ));
         	$mailer->send();
       }

        return true;
    }
    
    
    
    function _getUser($uid)
    {
	
        $db =& JFactory::getDBO();
        $q = "SELECT name, email FROM #__users "
           . "WHERE id = {$uid}"
           ;
       
        $db->setQuery($q);
        $user_email = $db->loadObject();
            
        if ($error = $db->getErrorMsg()) {
            JError::raiseError(500, $error);
            return false;
        }

        return $user_email;               
    }
    
    function _getRecipient($orderpayment_id) {
    		
    		
    	$db =& JFactory::getDBO();
    	$q = "SELECT user_email,user_id,billing_first_name,billing_last_name FROM #__k2store_orderinfo"
    	. " WHERE orderpayment_id = {$orderpayment_id}"
    	;
    	$db->setQuery($q);
    	$user_email = $db->loadObject();
    		
    	if ($error = $db->getErrorMsg()) {
    	JError::raiseError(500, $error);
    	return false;
    }
    	
    return $user_email;
    }
    
    
    function getAttachments($order) {

		global $mainframe;
		$db =& JFactory::getDBO();
 		$all_attachments = Array(); 

		//get all the items for this order
		$query = "SELECT * FROM #__k2store_orderitems WHERE order_id=".$order;
		$db->setQuery( $query );
		$items = $db->loadObjectList();
		//if no items found then exit now!
		if ($items==0) {
		  return $all_attachments;  //return empty array
		}

		//loop through items, generating a list of attachments
		foreach($items as $item) {
			$sql = "SELECT * FROM #__k2_attachments WHERE itemID =".$item->product_id;
			$db->setQuery( $sql );
			$attachments = $db->loadObjectList();
			//accumulate all attachments into one big array
		  $all_attachments = array_merge($all_attachments, (array)$attachments);
		}//foreach
		
		//ok, all done - return the resulting array of attachments
		return $all_attachments;		
	}//function getOrderAttachments
   
   
   function _getOrderKey($order_id) {
	   
	   $db = &JFactory::getDBO();
	   $query = 'SELECT id FROM #__k2store_orders WHERE order_id='.$db->Quote($order_id);
	   $db->setQuery($query);
	   return $db->loadResult();   	   
   }
   
   
   function _getHtmlFormatedOrder($id, $user_id) {
	   
		$app = &JFactory::getApplication();
		$html = ' ';
		
		$k2storeparams   = &JComponentHelper::getParams('com_k2store');
		$sitename   = $k2storeparams->get( 'sitename', $app->getCfg('sitename') );
		$siteurl    = $k2storeparams->get( 'siteurl', JURI::root() );
		
		
	    JLoader::register( "K2StoreViewOrders", JPATH_SITE."/components/com_k2store/views/orders/view.html.php" );
	    
	     $config = array();
		 $config['base_path'] = JPATH_SITE."/components/com_k2store";  
        if ($app->isAdmin())
        {
            // finds the default Site template
            $db = JFactory::getDBO();
            $query = "SELECT template FROM #__templates_menu WHERE `client_id` = '0' AND `menuid` = '0';";
            $db->setQuery( $query );
            $template = $db->loadResult();
            
            jimport('joomla.filesystem.file');
            if (JFile::exists(JPATH_SITE.'/templates/'.$template.'/html/com_k2store/orders/orderemail.php'))
            {
                // (have to do this because we load the same view from the admin-side Orders view, and conflicts arise)            
                $config['template_path'] = JPATH_SITE.'/templates/'.$template.'/html/com_k2store/orders';                
            }
        }
        
        $view = new K2StoreViewOrders( $config );
		
		require_once(JPATH_SITE.DS.'components'.DS.'com_k2store'.DS.'models'.DS.'orders.php');		
		$model =  new K2StoreModelOrders();
	    //lets set the id first
        $model->setId($id);

        $order = $model->getTable( 'orders' );
        $order->load( $model->getId() );
        $orderitems = &$order->getItems();
        $row = $model->getItem();
        
        if(!$user_id) {
        	$isGuest = true;
        }
        
	    $view->set( '_controller', 'orders' );
        $view->set( '_view', 'orders' );
        $view->set( '_doTask', true);
        $view->set( 'hidemenu', false);
        $view->setModel( $model, true );
        $view->assign( 'row', $row );
		$show_tax = $k2storeparams->get('show_tax_total');
        $view->assign( 'show_tax', $show_tax );
        foreach ($orderitems as &$item)
        {
        	$item->orderitem_price = $item->orderitem_price + floatval( $item->orderitem_attributes_price );
        	$taxtotal = 0;
        	if($show_tax)
        	{
        		$taxtotal = ($item->orderitem_tax / $item->orderitem_quantity);
        	}
        	$item->orderitem_price = $item->orderitem_price + $taxtotal;
        	$item->orderitem_final_price = $item->orderitem_price * $item->orderitem_quantity;
        	$order->order_subtotal += ($taxtotal * $item->orderitem_quantity);
        }
        
        $view->assign( 'order', $order );
        $view->assign( 'isGuest', $isGuest);
        $view->assign( 'sitename', $sitename);
        $view->assign( 'siteurl', $siteurl);
        $view->assign( 'params', $k2storeparams );
        $view->setLayout( 'orderemail' );
       
        //$this->_setModelState();
        ob_start();
        $view->display();      
        $html .= ob_get_contents();
        ob_end_clean();   
        return $html;	   
   }
   
   
   function getAddress($user_id) {
   
   	$db = &JFactory::getDBO();
   	$query = 'SELECT tbl.*,c.country_name,z.zone_name'
   	.' FROM #__k2store_address AS tbl'
   	.' LEFT JOIN #__k2store_countries AS c ON tbl.country_id=c.country_id'
   	.' LEFT JOIN #__k2store_zones AS z ON tbl.zone_id=z.zone_id'
   	.' WHERE tbl.user_id='.(int) $user_id;
   	$db->setQuery($query);
   	return $db->loadObject();
   }
   
}