<?php
/*
 * --------------------------------------------------------------------------------
Weblogicx India  - K2 Store v 2.6
* --------------------------------------------------------------------------------
* @package		Joomla! 2.5x
* @subpackage	K2 Store
* @author    	Weblogicx India http://www.weblogicxindia.com
* @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
* @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
* @link		http://weblogicxindia.com
* --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport('joomla.html.parameter');

class plgSystemK2Store extends JPlugin {

	function plgSystemK2Store( &$subject, $config ){
		parent::__construct( $subject, $config );
		$this->_plugin = JPluginHelper::getPlugin( 'system', 'k2store' );
		$this->_params = new JParameter( $this->_plugin->params );
		//if($this->_mainframe->isAdmin())return;
			
	}

	function onAfterRoute() {

		$mainframe = &JFactory::getApplication();
		JHtml::_('behavior.framework');
		JHtml::_('behavior.modal');
		$baseURL = JURI::root();
		$document =& JFactory::getDocument();
		$k2storeparams = &JComponentHelper::getParams('com_k2store');
		if($mainframe->isAdmin()) {
			$document->addScript($baseURL.'administrator/components/com_k2store/js/k2store_admin.js');
		} else {

			$document->addScriptDeclaration("var k2storeURL = '$baseURL';");
			$document->addScript($baseURL.'components/com_k2store/js/k2store.js');

			// Add related CSS to the <head>
			if ($document->getType() == 'html' && $k2storeparams->get('k2store_enable_css', 1)) {

				jimport('joomla.filesystem.file');

				// k2store.css
				if(JFile::exists(JPATH_SITE.DS.'templates'.DS.$mainframe->getTemplate().DS.'css'.DS.'k2store.css'))
					$document->addStyleSheet(JURI::root(true).'/templates/'.$mainframe->getTemplate().'/css/k2store.css');
				else
					$document->addStyleSheet(JURI::root(true).'/components/com_k2store/css/k2store.css');
			} else {
					$document->addStyleSheet(JURI::root(true).'/components/com_k2store/css/k2store.css');
			}

		}

	}

}
