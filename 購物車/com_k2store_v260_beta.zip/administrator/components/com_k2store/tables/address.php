<?php
/*
 * --------------------------------------------------------------------------------
Weblogicx India  - K2 Store v 2.4
* --------------------------------------------------------------------------------
* @package		Joomla! 1.5x
* @subpackage	K2 Store
* @author    	Weblogicx India http://www.weblogicxindia.com
* @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
* @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
* @link		http://weblogicxindia.com
* --------------------------------------------------------------------------------
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );
JLoader::register( 'K2StoreTable', JPATH_ADMINISTRATOR.DS.'components'.DS.'com_k2store'.DS.'tables'.DS.'_base.php' );

class TableAddress  extends K2StoreTable
{
	/**
	 * @param database A database connector object
	 */

	function __construct(&$db)
	{
		parent::__construct('#__k2store_address', 'id', $db );
	}

	/**
	 * Checks the entry to maintain DB integrity
	 * @return unknown_type
	 */
	function check()
	{
		$params = &JComponentHelper::getParams('com_k2store');
		/*if (empty($this->user_id))
		 {
		$this->setError( "User Required" );
		return false;
		}
		*/
	
		if($this->type=='billing') {
			if (empty($this->first_name))
			{
				$this->setError( "First Name Required" );
				return false;
			}

			if($params->get('bill_lname')==1)
				if (empty($this->last_name))
				{
					$this->setError( "Last Name Required" );
					return false;
				}

				if($params->get('bill_addr_line1')==1)
				{
					if (empty($this->address_1))
					{
						$this->setError( "At Least One Address Line is Required" );
						return false;
					}
				}
				if($params->get('bill_city')==1)
				{
					if (empty($this->city))
					{
						$this->setError( "City Required" );
						return false;
					}
				}
				if($params->get('bill_zip')==1)
				{
					if (empty($this->zip))
					{
						$this->setError( "Zip/Postal code Required" );
						return false;
					}
				}
				if($params->get('bill_country_zone')==1)
				{
					if (empty($this->country_id))
					{
						$this->setError( "Country Required" );
						return false;
					}
				}
				
				if($params->get('bill_phone1')==1)
				{
					if (empty($this->phone_1))
					{
						$this->setError( "At least one phone number required" );
						return false;
					}
				}
				
				if($params->get('bill_phone2')==1)
				{
					if (empty($this->phone_2))
					{
						$this->setError( "At least one phone number required" );
						return false;
					}
				}

				return true;
		}

		if($this->type=='shipping') {
			if (empty($this->first_name))
			{
				$this->setError( "First Name Required" );
				return false;
			}

			if($params->get('ship_lname')==1)
				if (empty($this->last_name))
				{
					$this->setError( "Last Name Required" );
					return false;
				}

				if($params->get('ship_addr_line1')==1)
				{
					if (empty($this->address_1))
					{
						$this->setError( "At Least One Address Line is Required" );
						return false;
					}
				}
				if($params->get('ship_city')==1)
				{
					if (empty($this->city))
					{
						$this->setError( "City Required" );
						return false;
					}
				}
				if($params->get('ship_zip')==1)
				{
					if (empty($this->zip))
					{
						$this->setError( "Zip/Postal code Required" );
						return false;
					}
				}
				if($params->get('ship_country_zone')==1)
				{
					if (empty($this->country_id))
					{
						$this->setError( "Country Required" );
						return false;
					}
				}
				if($params->get('ship_phone1')==1)
				{
					if (empty($this->phone_1))
					{
						$this->setError( "At least one phone number required" );
						return false;
					}
				}
				
				if($params->get('ship_phone2')==1)
				{
					if (empty($this->phone_2))
					{
						$this->setError( "At least one phone number required" );
						return false;
					}
				}

				return true;
		}



	}

}

