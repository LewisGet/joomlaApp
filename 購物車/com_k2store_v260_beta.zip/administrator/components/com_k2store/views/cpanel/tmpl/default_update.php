<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/
// no direct access
defined('_JEXEC') or die('Restricted access');

$version = $this->row->version;
$doc = &JFactory::getDocument();


?>
 
<div style="padding: 4px 8px; border: 6px solid #becae4;">
<table>
	
<?php if(!empty($this->wiupdate->version)):?>
	<tr>
		<td><h1>
		<?php echo JText::_('Update Check'); ?> </h1>
		</td>
		<td id="checkUpdate"> 
			<?php
			if($this->wiupdate->version != $this->row->version ) { ?>
				<span class='updateyes'><?php echo JText::_('K2STORE_NEW_VERSION_AVAILABLE'); ?> : <?php echo $this->wiupdate->version; ?>
				<br/>
				<a href="<?php echo JRoute::_('index.php?option=com_installer&view=update')?>"><?php echo JText::_('K2STORE_GOTO_UPDATE_MANAGER');?></a>
				</span>
			<?php } else { ?>
				<span class='updateno'><?php echo JText::_('K2STORE_IS_UPTODATE'); ?></span>
			<?php } ?>
		
		 </td>
	</tr>
	<?php endif; ?>
	
	<tr>
		<td><h1>
		<?php echo JText::_('Current Version'); ?> </h1>
		</td>
		<td id="currentVersion"><?php echo $this->row->version; ?></td>
	</tr>
	
	
	<tr>
		<td colspan="2">
			<h1> K2 Store</h1>
			<p>
			K2Store is a simple shopping cart extension for Joomla 2.5.x and K2 
			The extension is created by <a target="_blank" href="http://weblogicxindia.com">Weblogicx India</a>, professional Joomla extension
			developers.
			</p>
			
			<div> 
			<h2>Key features: </h2> 
			<ul>
			<li>Ajax shopping cart </li>
			<li>Product options, tax, shipping, global discount.</li>
			<li>Payment plugins - Paypal, Authorize.Net, SagePay and OGone </li>
			<li>Enhanced order management </li>
			<li>Guest checkout </li>
			<li>Professional Support from developers</li>
			</ul>
			</div>
	
			<div>
			<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
			<input type="hidden" name="cmd" value="_donations">
			<input type="hidden" name="business" value="rameshelamathi@gmail.com">
			<input type="hidden" name="lc" value="US">
			<input type="hidden" name="item_name" value="J2Store">
			<input type="hidden" name="no_note" value="0">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="bn" value="PP-DonationsBF:btn_donate_SM.gif:NonHostedGuest">
			<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
			</form>
			</div>
			<div>
			<strong> Visit : <a target="_blank" href="http://k2store.org">K2Store.Org</a> to know more. <br /> 
			Use our <a target="_blank" href="http://k2store.org/support/forum.html"> support forum</a> to post your queries <br /> 
			</strong>
			</div>
			
		 </td>
	</tr>	
	
</table>
</div>
