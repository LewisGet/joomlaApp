<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/
// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<div class="k2store_quicktips">
<h3><?php echo JText::_('K2STORE_QUICK_TIPS'); ?>
</h3>
<ol>
	<li><?php echo JText::_('K2STORE_QUICK_TIPS_SET_UP_STORE'); ?></li>
	<li><?php echo JText::_('K2STORE_QUICK_TIPS_SET_UP_CURRENCY'); ?></li>
	<li><?php echo JText::_('K2STORE_QUICK_TIPS_SET_UP_ADMIN_EMAIL'); ?></li>
	<li><?php echo JText::_('K2STORE_QUICK_TIPS_SET_UP_PRICE_DISPLAY'); ?></li>
	<li><?php echo JText::_('K2STORE_QUICK_TIPS_SET_UP_PRICE_TIPS'); ?></li>
	<li><?php echo JText::_('K2STORE_QUICK_TIPS_SET_UP_DONE'); ?></li>
	
</ol>
<span class="learn_more"><a href="http://k2store.org" target="_blank"><?php echo JText::_('K2STORE_QUICK_TIPS_READ_MORE'); ?></a> </span>

</div>