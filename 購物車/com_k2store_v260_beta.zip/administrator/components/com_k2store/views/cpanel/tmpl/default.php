<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/
// no direct access
defined('_JEXEC') or die('Restricted access');

?>

<div id="cpanel" class="k2storeAdminCpanel">
  	
	<table class="adminTable">
	<?php if($this->params->get('show_quicktips', 1)):?>
		<tr>
		<td colspan="2" valign="top" width="100%">	<?php echo $this->loadTemplate('info'); ?></td>
		</tr>
	<?php endif; ?>
		<tr>
			<td valign="top" width="50%"><?php echo $this->loadTemplate('quickicons'); ?> </td>
			<td valign="top" width="50%"><?php echo $this->loadTemplate('update'); ?> </td>
		</tr>
	  </table>		
	
	<div class="clr"></div>
	
</div>


<div class="clr"></div>