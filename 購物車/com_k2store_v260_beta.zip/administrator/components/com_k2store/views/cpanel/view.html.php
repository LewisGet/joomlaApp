<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.6
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/
// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class K2StoreViewCpanel extends JView
{

	function display($tpl = null) {
		
		$model = &$this->getModel();

		$params = &JComponentHelper::getParams('com_k2store');
		
		$xmlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_k2store'.DS.'manifest.xml';
		
		
		$data = JApplicationHelper::parseXMLInstallFile($xmlfile);
			foreach($data as $key => $value) {
						$row->$key = $value;
				}
		$output=null;		
		
		$db = &JFactory::getDbo();
		$query = 'SELECT * FROM #__updates WHERE element='.$db->quote('com_j2store');
		$db->setQuery($query);
		$wiupdate = $db->loadObject();
        
        $this->assignRef('params', $params);
        $this->assignRef('row', $row);
		$this->assignRef('wiupdate', $wiupdate);
		
		$user = & JFactory::getUser();
		
		$this->addToolBar();
		K2StoreSubmenuHelper::addSubmenu($vName = 'cpanel');		
		parent::display($tpl);
	}
	
	function addToolBar() {
		JToolBarHelper::title(JText::_('Dashboard'),'k2store-logo');
		JToolBarHelper::preferences('com_k2store', '500', '850');	
	}

}
