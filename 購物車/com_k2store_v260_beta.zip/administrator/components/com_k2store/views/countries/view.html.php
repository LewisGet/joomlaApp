<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - K2 Store v 2.0
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	K2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

// import Joomla view library
jimport('joomla.application.component.view');

class K2StoreViewCountries extends JView
{
   	protected $items;
	protected $pagination;
	protected $state;
     function display($tpl = null) 
        {
       
                // Get data from the model
                $this->items = $this->get('Items');
				 // inturn calls getState in parent class and populateState() in model
               $this->state = $this->get('State');
				$this->pagination = $this->get('Pagination');
                // Check for errors.
                if (count($errors = $this->get('Errors'))) 
                {
                        JError::raiseError(500, implode('<br />', $errors));
                        return false;
                }
            	//add toolbar
				$this->addToolBar();
				K2StoreSubmenuHelper::addSubmenu($vName = 'countries');
				// Display the template
				parent::display($tpl);
				$this->setDocument();	
        }
        
         protected function addToolBar() {
			 // setting the title for the toolbar string as an argument
			    JToolBarHelper::title(JText::_('K2STORE_COUNTRIES'),'k2store-logo');
				$state	= $this->state->get('filter.state');
 		        JToolBarHelper::back();
			 	JToolBarHelper::divider();
				JToolBarHelper::addNew('country.add','JTOOLBAR_NEW');
				JToolBarHelper::divider();
				// check permissions for the users
			 	JToolBarHelper::editList('country.edit','JTOOLBAR_EDIT');
			    JToolBarHelper::divider();	 	
				JToolBarHelper::custom('countries.publish', 'publish.png', 'publish_f2.png','JTOOLBAR_PUBLISH', true);
				JToolBarHelper::divider();
				JToolBarHelper::custom('countries.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);
			    JToolBarHelper::divider();		
			 	if($state == '-2' ) {
					JToolBarHelper::deleteList('', 'countries.delete','JTOOLBAR_EMPTY_TRASH');
			 	} else {
					JToolBarHelper::trash('countries.trash', 'JTOOLBAR_TRASH');	
				}
			 	
		 }
		 
		 protected function setDocument() {
			 // get the document instance
			  $document = JFactory::getDocument();
			// setting the title of the document
              $document->setTitle(JText::_('K2STORE_COUNTRIES'));
  	 
		 }
}
