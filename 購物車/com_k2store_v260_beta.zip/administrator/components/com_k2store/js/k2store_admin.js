function k2storeUpdate()
{
    location.reload(true);
}
