<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

$item = @$this->item;
$formName = 'j2storeadminForm_'.$item->product_id;
require_once (JPATH_SITE.'/components/com_j2store/helpers/cart.php');
require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/select.php');
$action = JRoute::_('index.php?option=com_j2store&view=mycart');
?>

<div class="j2store">
<div class="j2storeAddtocart">
<div class="">
<?php if(count(JModuleHelper::getModules('j2store-addtocart-top')) > 0 ): ?> 
	<div class="j2store_modules">
		<?php echo J2StoreHelperModules::loadposition('j2store-addtocart-top'); ?>
	</div>
<?php endif; ?>

<form action="<?php echo $action; ?>" method="post" class="j2storeCartForm" id="<?php echo $formName; ?>" name="<?php echo $formName; ?>" enctype="multipart/form-data" >

<?php if($this->params->get('show_price_field', 1)):?>
	
		<div class="">
			<!--base price-->
		    <span id="product_price_<?php echo $item->product_id; ?>" class="product_price">
		    	<?php  echo J2StoreHelperCart::dispayPriceWithTax($item->price, $item->tax, $this->params->get('price_display_options', 1)); ?>
		    </span>
		</div>
	
<?php endif; ?>
		
<?php $default = J2StoreHelperCart::getDefaultAttributeOptions($this->attributes);
		if(!empty($default)):?>
  <!--attribute options-->
			    <div id='product_attributeoptions_<?php echo $item->product_id; ?>' class="product_attributeoptions">
			    <?php
			  //  $default = J2StoreHelperCart::getDefaultAttributeOptions($this->attributes);
			  
			    foreach ($this->attributes as $attribute)
			    {
			    	$attribs = array('class' => 'inputbox', 'size' => '1');
			        ?>
			        <div class="pao" id='productattributeoption_<?php echo $attribute->productattribute_id; ?>'>
			        <?php
			        echo "<span class='attribute_title'>".$attribute->productattribute_name."&nbsp;";
			        $required = J2StoreSelect::getAttributeRequired($attribute->productattribute_id);
			        if($required) {
			        	$attribs = array('class' => 'inputbox required', 'size' => '1');
			        	echo '*';
			        }
					echo "</span>";
					
			        $key = 'attribute_'.$attribute->productattribute_id;
			        $selected = (!empty($values[$key])) ? $values[$key] : $default[$attribute->productattribute_id];
			
			         // Selected attribute options (for child attributes)
					$selected_opts = (!empty($this->selected_opts)) ? json_decode($this->selected_opts) : 0;
			
					if(!count($selected_opts))
					{
						$selected_opts = 0;
					}
			        			        
			        //now choose the format: select or radio
			        $format = J2StoreSelect::getAttributeDisplayFormat($attribute->productattribute_id);
			        if($format == 'radio') {
			        	//echo J2StoreSelect::productattributeoptions( $attribute->productattribute_id, $selected, $key, $attribs, null, $selected_opts  );
			        	echo J2StoreSelect::radio_productattributeoptions( $attribute->productattribute_id, $selected, $key, $attribs,  $idtag = null, $required, $selected_opts  );
			        } else {
			        	echo J2StoreSelect::productattributeoptions( $attribute->productattribute_id, $selected, $key, $attribs,  $idtag = null, $required, $selected_opts  );
			        }
			        
			        ?>
			
			        </div>
			        <?php
			    }
			    ?>
			
			    </div> <!-- end of attribute options -->
			  <?php endif; ?>
    
    <!-- product quantity block-->
   <div class="">
   <?php if($this->params->get('show_qty_field', 1)):?>
     		<div id='product_quantity_input_<?php echo $item->product_id; ?>' class="product_quantity_input">
				<span class="title"><?php echo JText::_( "J2STORE_ADDTOCART_QUANTITY" ); ?>:</span>
				<input type="text" name="product_qty" value="<?php echo $item->product_quantity; ?>" size="2" />
     		</div>
	<?php else: ?>
		<input type="hidden" name="product_qty" value="<?php echo $item->product_quantity; ?>" size="2" />
	<?php endif;?>	
	
		      <!-- Add to cart button -->
		      <div>
		    <div id='add_to_cart_<?php echo $item->product_id; ?>' class="add_to_cart" style="display: block;">
		        <input type="hidden" name="product_id" value="<?php echo $item->product_id; ?>" />
		         <input type="hidden" name="return" value="<?php echo base64_encode( JUri::getInstance()->toString() ); ?>" />
		        <input type="hidden" id="task" name="task" value="" />
		        <?php echo JHTML::_( 'form.token' ); ?>
		       <input value="<?php echo JText::_('J2STORE_ADD_TO_CART'); ?>" type="submit" class="j2store_cart_button btn btn-primary" />
		    </div>
		    </div>
	</div>
</form>
	<?php if(count(JModuleHelper::getModules('j2store-addtocart-bottom')) > 0 ): ?> 
	<div class="j2store_modules">
		<?php echo J2StoreHelperModules::loadposition('j2store-addtocart-bottom'); ?>
	</div>
	<?php endif; ?>
</div>
</div>
</div>
