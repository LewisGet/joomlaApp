<?php

/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/



// no direct access
defined('_JEXEC') or die('Restricted access');
require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/select.php');
	//$required = J2StoreSelect::getAttributeRequired($this->productattribute_id);
    	
    	
?>
<div class="j2store_attribute_<?php echo $this->productattribute_id; ?>">
	<?php foreach (@$this->items as $item): 
	
	if($item->productattributeoption_prefix != '=')
	{
		$display_suffix = ($item->productattributeoption_price > '0') ? ": ".$item->productattributeoption_prefix.J2StorePrices::number($item->productattributeoption_price) : '';
	}
	else
	{
		$display_suffix = ($item->productattributeoption_price > '0') ? ": ".J2StorePrices::number($item->productattributeoption_price) : '';
	}
	
	?>
	<label for="<?php echo $this->name; ?>"
			id="<?php echo $this->name; ?>-lbl"
			 class="radiobtn radio inline">
	
	<input type="radio"
	name="<?php echo $this->name; ?>"
	id="<?php echo $this->idTag; ?>"
	value="<?php echo $item->productattributeoption_id; ?>"
	class="<?php echo $this->attribs['class'];?>"
	<?php if($this->required): ?>
	title="<?php echo JText::_('J2STORE_SELECT_AN_OPTION'); ?>"
	<?php endif; ?>
	/>
			 <span class="j2store_radio_option_text">
			 	<span class="j2store_radio_option_header"><?php echo $item->productattributeoption_name ?></span>
			 	<?php if($item->productattributeoption_short_desc):?>
			 		<span class="j2store_radio_option_short_desc"><?php echo $item->productattributeoption_short_desc ?></span>
			 	<?php endif;?>
			 	
			 	<?php if($item->productattributeoption_long_desc || $item->productattributeoption_ref):?>
			 	<span class="j2store_radio_option_readon">
			 	<a class="modal readon3" href="#j2store_<?php echo $item->productattributeoption_id; ?>"><?php echo JText::_('J2STORE_PAO_EXTRA_DETAILS')?></a>
			 	</span>
			 	<div id="j2store_<?php echo $item->productattributeoption_id; ?>" class="k2modal">
			 		<?php echo $item->productattributeoption_long_desc ?>
			 		<br />
			 		<?php echo $item->productattributeoption_ref; ?>
			 	</div>
			 	<?php endif; ?>
			 </span>
			 
		</label>
	<?php endforeach;?>	
</div> 
<div class="j2error"></div>
	