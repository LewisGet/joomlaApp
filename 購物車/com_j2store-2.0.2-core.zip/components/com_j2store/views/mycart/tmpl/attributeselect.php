<?php

/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/



// no direct access
defined('_JEXEC') or die('Restricted access');
require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/select.php');
?>
<?php if(count($this->items)) : ?>
	<div class="j2store_attribute_<?php echo $this->productattribute_id; ?>">
		<div class="j2store_wrapper">
	<?php 	
	$list[] =  J2StoreSelect::option( '', JText::_('J2STORE_SELECT'));
        foreach ($this->items as $item)
        {
        	if($item->productattributeoption_prefix != '=')
        	{
        		$display_suffix = ($item->productattributeoption_price > '0') ? ": ".$item->productattributeoption_prefix.J2StorePrices::number($item->productattributeoption_price) : '';
        	}
        	else
        	{
        		$display_suffix = ($item->productattributeoption_price > '0') ? ": ".J2StorePrices::number($item->productattributeoption_price) : '';
        	}
        	$display_name = JText::_($item->productattributeoption_name).$display_suffix;
            $list[] =  J2StoreSelect::option( $item->productattributeoption_id, $display_name );
          
        }
        sort($list);
        $attribs = array();
       
        if($this->required) $attribs = array('class' => 'inputbox required ', 'size'=>'1', 'title'=>JText::_('J2STORE_SELECT_AN_OPTION'));
     	echo  J2StoreSelect::genericlist($list, $this->name, $attribs, 'value', 'text', $this->selected=null, $this->idTag  );
   ?>
   	</div>
   </div>
   <div class="j2error"></div>
   <?php endif; ?>