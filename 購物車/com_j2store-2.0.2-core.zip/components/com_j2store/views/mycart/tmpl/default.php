<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once(JPATH_ADMINISTRATOR.'/components/com_j2store/library/j2item.php');
$items = @$this->cartobj->items;
$subtotal = @$this->cartobj->subtotal;
$state = @$this->state;
$quantities = array();
$action = JRoute::_('index.php?option=com_j2store&view=mycart');
$checkout_url = JRoute::_('index.php?option=com_j2store&view=checkout');
?>

<div class="row-fluid"><div class="span12">


	<?php if(count(JModuleHelper::getModules('j2store-mycart-top')) > 0 ): ?> 
		<div class="j2store_modules">
			<?php echo J2StoreHelperModules::loadposition('j2store-mycart-top'); ?>
		</div>
	<?php endif; ?>


<?php if(!isset($this->remove)):?>
	<div id="j2storeCartPopup">
<?php endif; ?>

<div class='componentheading'>
    <span><?php echo JText::_( "J2STORE_MY_SHOPPING_CART" ); ?></span>
</div>

<div class="j2store_cartitems">
    <?php if (!empty($items)) { ?>
    <form action="<?php echo $action; ?>" method="post" name="adminForm" enctype="multipart/form-data">

        <table id="cart" class="adminlist table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <?php if($this->params->get('show_thumb_cart')) : ?>
					<th style="text-align: left;"><?php echo JText::_( "J2STORE_CART_ITEM" ); ?></th>
                    <?php endif; ?>
                    <th style="text-align: left;"><?php echo JText::_( "J2STORE_CART_ITEM_DESC" ); ?></th>
                    <th style="width: 50px;"><?php echo JText::_( "J2STORE_CART_ITEM_QUANTITY" ); ?></th>
                    <th style="width: 50px;"><?php echo JText::_( "J2STORE_CART_ITEM_TOTAL" ); ?></th>
                    <th style="width: 50px;"><?php echo JText::_( "J2STORE_CART_ITEM_REMOVE" ); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php $i=0; $k=0; $subtotal = 0;?>
            <?php foreach ($items as $item) : ?>

            	<?php
            		$link = JRoute::_("index.php?option=com_content&view=article&id=".$item->product_id);
            		$link = JRoute::_($link);
            		$image = J2StoreItem::getJ2Image($item->product_id, $this->params);
            	?>

                <tr class="row<?php echo $k; ?>">
                   <?php if($this->params->get('show_thumb_cart')) : ?>
                    <td style="text-align: center;">
                        <?php if(!empty($image)) {echo $image; }?>
                    </td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo $link; ?>">
                            <?php echo $item->product_name; ?>
                        </a>
                        <br/>

                        <?php if (!empty($item->attributes_names)) : ?>
	                        <?php echo $item->attributes_names; ?>
	                        <br/>
	                    <?php endif; ?>
	                    <input name="product_attributes[<?php echo $item->cart_id; ?>]" value="<?php echo $item->product_attributes; ?>" type="hidden" />

                         <?php echo JText::_( "J2STORE_ITEM_PRICE" ); ?>: <?php echo J2StorePrices::number($item->product_price); ?>

                    </td>
                    <td style="width: 50px; text-align: center;">
                        <?php $type = 'text';
                       ?>

                        <input class="productqty" name="quantities[<?php echo $item->cart_id; ?>]" type="<?php echo $type; ?>" size="3" maxlength="3" value="<?php echo $item->product_qty; ?>" />

                        <!-- Keep Original quantity to check any update to it when going to checkout -->
                        <input name="original_quantities[<?php echo $item->cart_id; ?>]" type="hidden" value="<?php echo $item->product_qty; ?>" />
                    </td>
                    <td style="text-align: right;">
                        <?php $subtotal = $subtotal + $item->subtotal; ?>
                        <?php echo J2StorePrices::number($item->subtotal); ?>
                    </td>
                    <td> 
                    <div onclick="j2storeCartRemove(<?php echo $item->cart_id; ?>, <?php echo $item->product_id; ?>, 2)" class="j2storeCartRemove"> X </div> 
                    
                     </td>
                </tr>
            <?php ++$i; $k = (1 - $k); ?>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
               	<tr class="cart_subtotal">
                    <td colspan="<?php echo $colspan=($this->params->get('show_thumb_cart'))? 3:2 ?>" style="font-weight: bold;">
                        <?php echo JText::_( "J2STORE_CART_SUBTOTAL" ); ?>
                    </td>
                    <td colspan="1" style="text-align: right;">
                        <?php echo J2StorePrices::number($subtotal); ?>
                    </td>
                    <td>&nbsp;</td>
                </tr>
            </tfoot>
        </table>
        <table id="cart_actions" class="table">

               <tr>
                    <td colspan="5">
                        <input style="float: right;" type="submit" class="j2store_cart_button btn btn-warning" value="<?php echo JText::_('J2STORE_UPDATE_QUANTITIES'); ?>" name="update" />
                    </td>
                </tr>

                <tr>
                	<td colspan="5" style="white-space: nowrap;">
                        <b><?php echo JText::_( "J2STORE_CART_TAX_SHIPPING_TOTALS" ); ?></b>
                        <br/>
                        <?php
                            echo JText::_( "J2STORE_CALCULATED_DURING_CHECKOUT_PROCESS" );
                    	?>
              	 	</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <?php if (!empty($this->return)) { ?>
                        <a class="btn btn-primary" href="<?php echo base64_decode($this->return); ?>">
                            <?php echo JText::_( "J2STORE_CONTINUE_SHOPPING" ); ?>
                        </a>
                        <?php } ?>
                    </td>
                    <td style="text-align: right;" nowrap>
				        <div style="float: right;">
				        <a class="btn btn-primary begin_checkout" href="<?php echo $checkout_url; ?>">
				            <?php echo JText::_( "J2STORE_BEGIN_CHECKOUT" ); ?>
				        </a>
				        </div>
                    </td>
                </tr>

        </table>
		<input type="hidden" name="task" value="update" />
        <input type="hidden" name="boxchecked" value="" />
    </form>
    <?php } else { ?>
    <p><?php echo JText::_( "J2STORE_NO_ITEMS" ); ?></p>
    <?php } ?>
</div>
</div>

	<?php if(count(JModuleHelper::getModules('j2store-mycart-bottom')) > 0 ): ?> 
		<div class="j2store_modules">
			<?php echo J2StoreHelperModules::loadposition('j2store-mycart-bottom'); ?>
		</div>
	<?php endif; ?>
</div>
</div>
