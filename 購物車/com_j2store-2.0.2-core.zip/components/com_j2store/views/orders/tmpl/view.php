<?php
/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/


//no direct access
defined('_JEXEC') or die('Restricted access');

$row = @$this->row;
$order = @$this->order;
$items = @$order->getItems();
require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2store'.DS.'library'.DS.'popup.php');
require_once (JPATH_SITE.DS.'components'.DS.'com_j2store'.DS.'helpers'.DS.'orders.php');

?>
<script type="text/javascript">
function j2storeOpenModal(url) {
	<?php if(JBrowser::getInstance()->getBrowser() =='msie') :?>
	var options = {size:{x:document.documentElement.­clientWidth-80, y: document.documentElement.­clientHeight-80}};
	<?php else: ?>
	var options = {size:{x: window.innerWidth-80, y: window.innerHeight-80}};
	<?php endif; ?>
	SqueezeBox.initialize();
	SqueezeBox.setOptions(options);
	SqueezeBox.setContent('iframe',url); 
}
</script>
<div class="container-fluid j2store">
	<?php if(count(JModuleHelper::getModules('j2store-orders-view-top')) > 0 ): ?> 
		<div class="j2store_modules">
			<?php echo J2StoreHelperModules::loadposition('j2store-orders-view-top'); ?>
		</div>
	<?php endif; ?>

<div class='row-fluid'>
<?php if(!isset($this->guest)): ?>
	<div class="span6 pull-left">
		<a class="btn" href="<?php echo JRoute::_("index.php?option=com_j2store&view=orders"); ?>"><?php echo JText::_( 'J2STORE_ORDER_RETURN_TO_LIST' ); ?></a>
	</div>
	
<?php endif; ?>

<div class="span6 pull-right">
	<?php
	$url = JRoute::_( "index.php?option=com_j2store&view=orders&task=printOrder&tmpl=component&id=".@$row->id);
//	$text = JText::_( "J2STORE_PRINT_INVOICE" );
//	echo '<span class="btn">';
//	echo J2StorePopup::popup( $url, $text );
//	echo '</span>';
	?>
	<input type="button" class="btn btn-primary" onclick="j2storeOpenModal('<?php echo $url; ?>')" value="<?php echo JText::_( "J2STORE_PRINT_INVOICE" ); ?>" />
	</div>

</div>

<div class='row-fluid'>
	<div class="span12">
		<h3><?php echo JText::_( "J2STORE_ORDER_DETAIL" ); ?></h3>
	</div>
</div>

<div class='row-fluid'>
	<div class="span6">
		<h3><?php echo JText::_("J2STORE_ORDER_INFORMATION"); ?></h3>
		<dl class="dl-horizontal">
			<dt><?php echo JText::_("J2STORE_ORDER_ID"); ?> </dt>
			<dd><?php echo @$row->order_id; ?></dd>
		
			<dt><?php echo JText::_("J2STORE_INVOICE_NO"); ?></dt>
			<dd><?php echo @$row->id; ?></dd>
			
			<dt><?php echo JText::_("J2STORE_ORDER_PAYMENT_AMOUNT"); ?></dt>
			<dd><?php echo J2StorePrices::number( $row->order_total ); ?></dd>
			
			<dt><?php echo JText::_("J2STORE_ORDER_DATE"); ?></dt>
			<dd><?php echo JHTML::_('date', $row->created_date, $this->params->get('date_format', '%a, %d %b %Y, %I:%M%p')); ?></dd>
		
			<dt><?php echo JText::_("J2STORE_ORDER_STATUS"); ?></dt>
			<dd><?php echo JText::_((@$row->order_state=='')?'':@$row->order_state); ?></dd>
				
		</dl>
		
		<h3><?php echo JText::_("J2STORE_ORDER_PAYMENT_INFORMATION"); ?></h3>
		<dl class="dl-horizontal">
			<dt><?php echo JText::_('J2STORE_ORDER_PAYMENT_TYPE'); ?></dt>
			<dd><?php echo JText::_($row->orderpayment_type); ?></dd>
			
			<?php if ($row->orderpayment_type == 'payment_offline') : ?>
							<dt><?php echo JText::_('J2STORE_ORDER_PAYMENT_MODE'); ?></dt>
							<dd><?php echo JText::_($row->transaction_details); ?>
							</dd>
			<?php endif; ?>
			<?php if(!empty($row->transaction_id)): ?>		
							<dt><?php echo JText::_('J2STORE_ORDER_TRANSACTION_ID'); ?></dt>
							<dd><?php echo $row->transaction_id; ?></dd>
			<?php endif; ?>	
						<!-- 			
							<dt><?php echo JText::_('J2STORE_ORDER_PAYMENT_STATUS'); ?> </dt>
							<dd><?php echo JText::_($row->transaction_status); ?></dd>
							 -->
		</dl>
		 
	</div>
	
	<?php if($this->params->get('show_billing_address') || $this->params->get('show_shipping_address') || $this->params->get('allow_guest_checkout') ): ?>
	<div class="span6">
		<h3><?php echo JText::_("J2STORE_ORDER_CUSTOMER_INFORMATION"); ?></h3>
		<dl class="dl-horizontal">
	<?php if($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout')): ?>
		
				<dt><?php echo JText::_("J2STORE_BILLING_ADDRESS"); ?></dt>
				<dd>
				<address>
			
							<?php //TODO: legacy mode compatability. Those who do not have the order info will see this
							if(empty($row->billing_first_name)) {
								$billAddr =  J2StoreOrdersHelper::getAddress($row->user_id);
								if(!empty($billAddr)) {
								echo '<strong>'.$billAddr->first_name." ".$billAddr->last_name."</strong><br/>";
								echo $billAddr->address_1.", ";
								echo $billAddr->address_2 ? $billAddr->address_2.", " : "<br/>";
								echo $billAddr->city.", ";
								echo $billAddr->state ? $billAddr->state." - " : "";
								echo $billAddr->zip." <br/>";
								echo $billAddr->country." <br/> ".JText::_('J2STORE_TELEPHONE').":";
								echo $billAddr->phone_1." , ";
								echo $billAddr->phone_2 ? $billAddr->phone_2.", " : "<br/> ";
								echo '<br/> ';
								echo $row->email;
								}
							} else {
								echo '<strong>'.$row->billing_first_name." ".$row->billing_last_name."</strong><br/>";
								echo $row->billing_address_1.", ";
								echo $row->billing_address_2 ? $row->billing_address_2.", " : "<br/>";
								echo $row->billing_city.", ";
								echo $row->billing_zone_name ? $row->billing_zone_name." - " : "";
								echo $row->billing_zip." <br/>";
								echo $row->billing_country_name." <br/> ".JText::_('J2STORE_TELEPHONE').":";
								echo $row->billing_phone_1." , ";
								echo $row->billing_phone_2 ? $row->billing_phone_2.", " : "<br/> ";
								echo '<br/> ';
								echo $row->user_email;
							}
							?>
					</address>
					</dd>		
		 <?php endif; ?>
		 <?php if($this->params->get('show_shipping_address') ): ?>
						<dt><?php echo JText::_("J2STORE_SHIPPING_ADDRESS"); ?></dt>
							<dd>
							<address>
							<?php //TODO: legacy mode compatability. Those who do not have the order info will see this
							if(empty($row->shipping_first_name)) {
								$shipAddr =  J2StoreOrdersHelper::getAddress($row->user_id);
								if(!empty($shipAddr)) {
								echo '<strong>'.$shipAddr->first_name." ".$shipAddr->last_name."</strong><br/>";
								echo $shipAddr->address_1.", ";
								echo $shipAddr->address_2 ? $shipAddr->address_2.", " : "<br/>";
								echo $shipAddr->city.", ";
								echo $shipAddr->state ? $shipAddr->state." - " : "";
								echo $shipAddr->zip." <br/>";
								echo $shipAddr->country." <br/> ".JText::_('J2STORE_TELEPHONE').":";
								echo $shipAddr->phone_1." , ";
								echo $shipAddr->phone_2 ? $shipAddr->phone_2.", " : "<br/> ";
								}

							} else {
								echo '<strong>'.$row->shipping_first_name." ".$row->shipping_last_name."</strong><br/>";
								echo $row->shipping_address_1.", ";
								echo $row->shipping_address_2 ? $row->shipping_address_2.", " : "<br/>";
								echo $row->shipping_city.", ";
								echo $row->shipping_zone_name ? $row->shipping_zone_name." - " : "";
								echo $row->shipping_zip." <br/>";
								echo $row->shipping_country_name;

								echo $row->shipping_phone_1." , ";
								echo $row->shipping_phone_2 ? $row->shipping_phone_2.", " : "<br/> ";
							}
							?>
							</address>
							</dd>
					<?php endif; ?>
			
		</dl>	 
	</div>
	<?php endif; ?>
	 <?php if(!empty($row->customer_note)): ?>
	 <dl class="dl-horizontal">
			 <dt><?php echo JText::_("J2STORE_ORDER_CUSTOMER_NOTE"); ?></dt>
			 <dd><?php echo $row->customer_note; ?></dd>
	 </dl>
	 <?php endif; ?>
</div>
<div class="row-fluid">
<div class="span12">
	<h3>
		<?php echo JText::_("J2STORE_ITEMS_IN_ORDER"); ?>
	</h3>

	<table class="cart_order table table-striped table-bordered" style="clear: both;">
		<thead>
			<tr>
				<th style="text-align: left;"><?php echo JText::_("J2STORE_CART_ITEM"); ?></th>
				<th style="width: 150px; text-align: center;"><?php echo JText::_("J2STORE_CART_ITEM_QUANTITY"); ?>
				</th>
				<th style="width: 150px; text-align: right;"><?php echo JText::_("J2STORE_ITEM_PRICE"); ?>
				</th>
			</tr>
		</thead>
		<tbody>
			<?php $i=0; $k=0; ?>
			<?php foreach (@$items as $item) : ?>

			<tr class='row<?php echo $k; ?>'>
				<td><a
					href="<?php echo JRoute::_('index.php?option=com_content&view=article&id='.$item->product_id); ?>">
						<?php echo JText::_( $item->orderitem_name ); ?> </a> <br /> <?php if (!empty($item->orderitem_attribute_names)) : ?>
					<?php echo $item->orderitem_attribute_names; ?> <br /> <?php endif; ?>

					<?php if (!empty($item->orderitem_sku)) : ?> <b><?php echo JText::_( "J2STORE_SKU" ); ?>:</b>
					<?php echo $item->orderitem_sku; ?> <br /> <?php endif; ?> <b><?php echo JText::_( "J2STORE_CART_ITEM_UNIT_PRICE" ); ?>:</b>
					<?php echo J2StorePrices::number( $item->orderitem_price); ?>
				</td>
				<td style="text-align: center;"><?php echo $item->orderitem_quantity; ?>
				</td>
				<td style="text-align: right;"><?php echo J2StorePrices::number( $item->orderitem_final_price ); ?>
				</td>
			</tr>
			<?php $i=$i+1; $k = (1 - $k); ?>
			<?php endforeach; ?>

			<?php if (empty($items)) : ?>
			<tr>
				<td colspan="10" align="center"><?php echo JText::_('J2STORE_NO_ITEMS'); ?>
				</td>
			</tr>
			<?php endif; ?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="2" style="text-align: right;"><?php echo JText::_( "J2STORE_CART_SUBTOTAL" ); ?>
				</th>
				<th style="text-align: right;"><?php echo J2StorePrices::number($order->order_subtotal); ?>
				</th>
			</tr>

			<tr>
				<th colspan="2" style="text-align: right;"><?php
				if (!empty($this->show_tax)) {
					echo JText::_("J2STORE_CART_PRODUCT_TAX_INCLUDED");
				}
				else { echo JText::_("J2STORE_CART_PRODUCT_TAX");
				}
				?>
				</th>
				<th style="text-align: right;"><?php echo J2StorePrices::number($row->order_tax); ?>
				</th>
			</tr>

			<tr>
				<th colspan="2" style="text-align: right;"><?php echo JText::_( "J2STORE_SHIPPING" ); ?>
				</th>
				<th style="text-align: right;"><?php echo J2StorePrices::number($row->order_shipping); ?>
				</th>
			</tr>
			<?php if ($row->order_discount > 0): ?>

			<tr>
				<th colspan="2" style="text-align: right;">
				<?php
					echo "(-)";
					echo JText::_("J2STORE_CART_DISCOUNT")." (".$this->params->get('global_discount')."%) :";
				?>
				</th>
				<th style="text-align: right;"><?php echo J2StorePrices::number($row->order_discount); ?>
				</th>
			</tr>
			<?php endif;?>
			<tr>
				<th colspan="2" style="text-align: right;"><?php echo JText::_( "J2STORE_CART_GRANDTOTAL" ); ?>
				</th>
				<th style="text-align: right;"><?php echo J2StorePrices::number($row->order_total); ?>
				</th>

			</tr>
		</tfoot>
	</table>
</div>
</div>

<?php if(count(JModuleHelper::getModules('j2store-orders-view-bottom')) > 0 ): ?> 
		<div class="j2store_modules">
			<?php echo J2StoreHelperModules::loadposition('j2store-orders-view-bottom'); ?>
		</div>
	<?php endif; ?>

</div>