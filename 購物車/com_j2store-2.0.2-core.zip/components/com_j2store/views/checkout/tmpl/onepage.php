<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - J2 Store v 2.4
 * --------------------------------------------------------------------------------
 * @package		Joomla! 1.5x
 * @subpackage	J2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$action = JRoute::_('index.php?option=com_j2store&view=checkout');

//calculate span
if( $this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout') || $this->params->get('show_shipping_address')) {
	$span = 'span5';
	$align="";
} else {
	$span = 'span11';
	$align="";
}

$k2params = $this->params;

$doc = &JFactory::getDocument();
JHtml::_('behavior.tooltip');
JHtml::_('behavior.keepalive');
if($this->params->get('show_billing_address') && $this->params->get('show_shipping_address') ) {
	$script = "
	J2Store(document).ready(function(){
	//check for billing address
	var sameAsBilling = '#j2store_shipping_make_same';
	if (J2Store(sameAsBilling).is(':checked')) {
	J2Store('#j2store_shipping_section').css({'visible' : 'visible', 'display' : 'none'});
}
});
";
	$doc->addScriptDeclaration($script);
}

//shipping address form check
if(isset($this->ship_address)) {
	$checked ='';
} else {
	$checked ='checked="checked"';
}
?>

<script type="text/javascript">
<!--

J2Store(document).ready(function(){
	var j2store_billing_zone_id; 
	var j2store_shipping_zone_id;
	
	<?php if(isset($this->bill_address->zone_id)) { ?>
		j2store_billing_zone_id = <?php echo $bzone_id=($this->bill_address->zone_id)?$this->bill_address->zone_id:0; ?>;
	<?php } else { ?>
		j2store_billing_zone_id=0;
	<?php } ?>
				
	if(J2Store('#billing_country')) {
		j2storeGetAjaxZone('billing[zone_id]','billing_zone', J2Store('#billing_country').val(), j2store_billing_zone_id);

		J2Store("#billing_country").bind('change load', function(){
			
			  // validate
			j2storeGetAjaxZone('billing[zone_id]','billing_zone', J2Store('#billing_country').val(), j2store_billing_zone_id);
		});
	}

	<?php if(isset($this->ship_address->zone_id)) { ?>
	j2store_shipping_zone_id = <?php echo $szone_id = ($this->ship_address->zone_id)?$this->ship_address->zone_id:0; ?>;
	<?php } else { ?>
	j2store_shipping_zone_id=0;
	<?php } ?>

	 	if(J2Store('#shipping_country')) {
	 		j2storeGetAjaxZone('shipping[zone_id]','shipping_zone', J2Store('#shipping_country').val(), j2store_shipping_zone_id);		

	 		J2Store("#shipping_country").bind('change load', function(){
	 			j2storeGetAjaxZone('shipping[zone_id]','shipping_zone', J2Store('#shipping_country').val(), j2store_shipping_zone_id);
	 		});
		}


	 	var j2storeErrorcontainer = J2Store('div.j2storeErrorcontainer');
		
	 	J2Store("#onepageCheckoutForm").validate({
	 		debug: true,
	 		errorElement: "em",
	 		//errorContainer: $("#warning, #summary"),
	 		errorPlacement: function(error, element) {
	 			if ( element.is(":radio") )
	 				error.appendTo( element.parent().next('div') );
	 			else
	 			error.appendTo( element.next("div") );
	 		},
	 		success: function(label) {
	 			///label.text("<?php echo JText::_('J2STORE_VALIDATION_OK');?>").addClass("success");
	 		},
	 	   submitHandler: function(form) {
	 	       // now validate the shipping fields if same as billing not checked
	 	    	form.submit();
	 	   },
	 	   rules: {
	 		   <?php if($k2params->get('ship_fname') == 1):?>
	 		   'shipping[first_name]': {
	 			   required: J2Store('#j2store_shipping_make_same').is(':checked')
	 		   },
	 		   <?php endif;?>
	 		  payment_plugin:"required"
	 		},
	 		messages: {
	 			payment_plugin: "<?php echo JText::_('J2STORE_SELECT_A_PAYMENT_METHOD'); ?>",
	 		}
	 	});	 		 	

		
		
	});
	
function j2storeToggleShipping(el){
	    if(el.checked) {
	    	J2Store('#j2store_shipping_section').css({
				    // the 'styles' property passes the object to Element:setStyles.
				        'visible': 'hidden',
				        'display': 'none'
			  });
			 J2Store('#j2store_shipping_make_same').val(1);
			 J2Store('#j2store_shipping_make_same').attr('checked', true);
			
		  } else {
			  J2Store('#j2store_shipping_section').css({
				    // the 'styles' property passes the object to Element:setStyles.
				        'visible': 'visible',
				        'display': 'block'
			  });

			var j2store_shipping_zone_id;
			 <?php if(isset($this->ship_address->zone_id)) { ?>
			 j2store_shipping_zone_id = <?php echo $szone_id = ($this->ship_address->zone_id)?$this->ship_address->zone_id:0; ?>;
			<?php } else { ?>
			j2store_shipping_zone_id=0;
			<?php } ?>
			  
			  j2storeGetAjaxZone('shipping[zone_id]','shipping_zone', J2Store('#shipping_country').val(), j2store_shipping_zone_id);
			  J2Store('#j2store_shipping_make_same').val(2);
			  J2Store('#j2store_shipping_make_same').attr('checked', false);			  		 
		  }
	  }

  
-->
</script>
<form action="<?php echo $action; ?>" method="post" id="onepageCheckoutForm" class="" name="onepageCheckoutForm" enctype="multipart/form-data">			
<div class="j2storeOnePageCheckout j2storeCheckout j2store container-fluid">
	<div class="row-fluid">
			
			<?php if($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout') || $this->params->get('show_shipping_address')): ?>
			<!-- billing/shipping address fields -->
			<div class="<?php echo $s=$span=='span5'?'span6':$span;?>">
					
					<?php //TODO:: seems only when all three are checked no, the fields disappear. Need to correct this 
						if($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout')): ?>
						<div class="j2storeBillingAddress">
							<h3><?php echo JText::_('J2STORE_BILLING_ADDRESS'); ?></h3>
							<?php echo $this->loadTemplate('billing'); ?>
						</div>
						<?php endif; ?>
			
						<?php if($this->params->get('show_shipping_address')): ?>
						<div class="j2storeShippingAddress">
							<?php if(($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout'))  && $this->params->get('show_shipping_address')):?>
							<br />
							<input id="j2store_shipping_make_same" value='1' name="j2store_shipping_make_same" type="checkbox"
								<?php echo $checked; ?> onClick="j2storeToggleShipping(this)" />
							<?php echo JText::_('J2STORE_MAKE_SHIPPING_SAME'); ?>
							<?php endif; ?>
			
							<?php echo $this->loadTemplate('shipping'); ?>
						</div>
			
						<?php endif; ?>
			
			</div>
			<?php endif;?>
			
			<!-- shipping/payment methods -->
			<div class="<?php echo $span;?> <?php echo $align;?>">
			
				<?php if($this->showShipping): ?>
				<div class="shipping_info">
					<?php echo $this->loadTemplate('shippingmethod'); ?>					
				</div>
				<?php endif; ?>
				
				<?php if($this->showPayment): ?>
				<div class="payment_info">
					<?php echo $this->loadTemplate('payment'); ?>
				</div>
				<?php endif; ?>

				<div class="order_comment">
					<?php echo $this->orderSummary; ?>
					<?php echo $this->loadTemplate('comment'); ?>
						<input class="j2store_checkout_button btn btn-primary" type="submit"
						value="<?php echo JText::_('J2STORE_PLACE_ORDER');?>" />
				</div>
			
			</div>
	
	</div>
	
	
</div>	

			<input type="hidden" name="option" value="com_j2store" />
			<input type="hidden" name="controller" value="checkout" />
			<input type="hidden" name="task" value="preparePayment" />				
			<?php echo JHTML::_( 'form.token' ); ?>
</form>
