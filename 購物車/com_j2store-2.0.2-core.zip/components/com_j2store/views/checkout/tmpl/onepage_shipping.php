<?php
/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.6
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
if (isset($this->ship_address)) {
	$shipAddr = @$this->ship_address;
}
$j2params = $this->params;

?>

<div id="j2store_shipping_section">
<h3><?php echo JText::_('J2STORE_SHIPPING_ADDRESS'); ?></h3>
	<table class="table table-condensed">
						<tr>
							<td>
								<label class="input-label" for="first_name"><?php echo JText::_('J2STORE_FIRST_NAME'); ?>
								<em class="">*</em>
								</label>
								
									<input type="text" class="input-text required"
										title="<?php echo JText::_('J2STORE_FIRST_NAME_REQUIRED');?>" 
										value="<?php if(isset($shipAddr->first_name)) echo $shipAddr->first_name; ?>" name="shipping[first_name]"
										id="shipping_firstname" />
									<div class="j2error"></div>	
							</td>
							
							<?php if($j2params->get('ship_lname') != 3):?>
							<td>
								<label class="input-label" for="shipping_lastname">
								
								<?php echo JText::_('J2STORE_LAST_NAME')?>
								<?php echo ($j2params->get('ship_lname')==1)?'<em class="">*</em>':''; ?>
								</label>
									<input type="text" class="input-text <?php echo ($j2params->get('ship_lname')==1)?'required':''; ?>"
										title="<?php echo JText::_('J2STORE_LAST_NAME_REQUIRED');?>"
										value="<?php if(isset($shipAddr->last_name)) echo $shipAddr->last_name; ?>" name="shipping[last_name]"
										id="shipping_lastname">
									<div class="j2error"></div>	
							</td>
							<?php endif; // ship last name?>
						</tr>

					<?php if($j2params->get('ship_addr_line1')!=3 || $j2params->get('ship_addr_line2')!=3 ): ?>	
					<tr>
						<td colspan="2">
						<?php if($j2params->get('ship_addr_line1') != 3):?>
						
							<label class="input-label" for="shipping_address_1">
							<?php echo JText::_('J2STORE_ADDRESS'); ?>
							<?php echo ($j2params->get('ship_addr_line1')==1)?'<em class="">*</em>':''; ?>
							</label>
							<input type="text" class="input-text <?php echo ($j2params->get('ship_addr_line1')==1)?'required':''; ?>"
								title="<?php echo JText::_('J2STORE_ADDRESS_REQUIRED');?>"
								value="<?php if(isset($shipAddr->address_1)) echo $shipAddr->address_1; ?>" id="shipping_address_1"
								name="shipping[address_1]" />
								<div class="j2error"></div>	
						
					<?php endif; ?>
						<?php if($j2params->get('ship_addr_line2') != 3):?>
						
								<label>&nbsp;</label>
								<input type="text"
								class="input-text1 <?php echo ($j2params->get('ship_addr_line2')==1)?'required':''; ?>"
								 value="<?php if(isset($shipAddr->address_2)) echo $shipAddr->address_2; ?>"
									id="shipping_address_2" name="shipping[address_2]"
									title="<?php echo JText::_('J2STORE_ADDRESS_REQUIRED');?>"
									/>
									<div class="j2error"></div>	
							
						<?php endif; // ship address line 2?>
						</td>
					</tr>
				<?php endif; ?>
				
					<?php if(($j2params->get('ship_zip') != 3)||($j2params->get('ship_city') != 3)):?>
					<tr>
					<?php if($j2params->get('ship_zip') != 3):?>
						<td>
							<label class="input-label" for="shipping_zip">
							<?php echo JText::_('J2STORE_POSTCODE');?>
							<?php echo ($j2params->get('ship_zip')==1)?'<em class="">*</em>':''; ?>
								</label>
								<input type="text"
									class="input-text <?php echo ($j2params->get('ship_zip')==1)?'required':''; ?>"
									title="<?php echo JText::_('J2STORE_ZIP_REQUIRED');?>"
									value="<?php if(isset($shipAddr->zip)) echo $shipAddr->zip; ?>" id="shipping_zip"
									name="shipping[zip]">
									<div class="j2error"></div>	
						</td>
						<?php endif; // end zip ?>
						
						<?php if($j2params->get('ship_city') != 3):?>
						<td>

							<label class="input-label" for="shipping_city">
							<?php echo JText::_('J2STORE_CITY'); ?>
							<?php echo ($j2params->get('ship_city')==1)?'<em class="">*</em>':''; ?>
							</label>
								<input type="text" class="input-text <?php echo ($j2params->get('ship_city')==1)?'required':''; ?>"
									title="<?php echo JText::_('J2STORE_CITY_REQUIRED');?>"
									value="<?php if(isset($shipAddr->city)) echo $shipAddr->city; ?>" id="shipping_city" 
									name="shipping[city]" />
									<div class="j2error"></div>	
						</td>
						<?php endif; // end city ?>
					</tr>
					<?php endif; // end both city and zip?>
					
					<?php if($j2params->get('ship_country_zone') != 3):?>
					<tr>

						<td>

							<label class="input-label" for="shipping_country">
							<?php echo JText::_('J2STORE_COUNTRY'); ?>
							<em class="">*</em>
							</label>
							<?php echo $this->ship_country; ?>
							<div class="j2error"></div>
						</td>

						<td>
							<label class="" for="shipping_state"><?php echo JText::_('J2STORE_STATE_PROVINCE'); ?></label>
									<span id="shipZoneList"> </span>

						</td>
					</tr>
					<?php endif; // end country , zone ?>
					
					<?php if(($j2params->get('ship_phone1') != 3)||($j2params->get('ship_phone2') != 3)):?>
					
					<tr>
					
					<?php if($j2params->get('ship_phone1') != 3):?>

						<td>
							<label class="input-label" for="shipping_phone_1">
							<?php echo JText::_('J2STORE_TELEPHONE')?>
							<?php echo ($j2params->get('ship_phone1')==1)?'<em class="">*</em>':''; ?>
							</label>
								<input type="text" class="input-text <?php echo ($j2params->get('ship_phone1')==1)?'required':''; ?>"
									title="<?php echo JText::_('J2STORE_PHONE_REQUIRED');?>"
									value="<?php if(isset($shipAddr->phone_1)) echo $shipAddr->phone_1; ?>" id="shipping_phone_1"
									name="shipping[phone_1]" />
									<div class="j2error"></div>	
						</td>
						<?php endif; // end phone1 ?> 
						<?php if($j2params->get('ship_phone2') != 3):?>
						<td>
							<label class="input-label" for="shipping_phone_2">
								<?php echo JText::_('J2STORE_MOBILE')?>
								<?php echo ($j2params->get('ship_phone2')==1)?'<em class="">*</em>':''; ?>
							 </label>
								<input type="text" class="input-text <?php echo ($j2params->get('ship_phone2')==1)?'required':''; ?>"
									title="<?php echo JText::_('J2STORE_MOBILE_REQUIRED');?>"
									value="<?php if(isset($shipAddr->phone_2)) echo $shipAddr->phone_2; ?>" id="shipping_phone_2"
									name="shipping[phone_2]" />
									<div class="j2error"></div>	

						</td>
						<?php endif; // end phone1 ?>

					</tr>
					<?php endif; // end mobile , phone1 phone2?>
				</table>	
			<input type="hidden" name="ship_id"	value="<?php echo @$shipAddr->id; ?>" />
</div>
