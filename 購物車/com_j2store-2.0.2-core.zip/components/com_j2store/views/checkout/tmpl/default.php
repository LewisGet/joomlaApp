<?php
/*
 * --------------------------------------------------------------------------------
   com_j2store J2 Store v 2.0
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	j2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://j2store.org
 * --------------------------------------------------------------------------------
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$action = JRoute::_('index.php?option=com_j2store&view=checkout');

//calculate span
if( ($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout') ) && $this->params->get('show_shipping_address')) {
	$span = 'span6';
} else {
	$span = 'span12';
}

$j2params = $this->params;

$doc = &JFactory::getDocument();
JHtml::_('behavior.tooltip');
JHtml::_('behavior.keepalive');
if($this->params->get('show_billing_address') && $this->params->get('show_shipping_address') ) {
		$script = "
		
		J2Store(document).ready(function(){
		//check for billing address
		var sameAsBilling = '#j2store_shipping_make_same';
		if (J2Store(sameAsBilling).is(':checked')) {
		J2Store('#j2store_shipping_section').css({'visible' : 'visible', 'display' : 'none'});
		}
		});
		";
	$doc->addScriptDeclaration($script);
}

//shipping address form check
if(isset($this->ship_address)) {
	$checked ='';
} else {
	$checked ='checked="checked"';
}
?>

<script type="text/javascript">
<!--

J2Store(document).ready(function(){
	var j2store_billing_zone_id; 
	var j2store_shipping_zone_id;
	
	<?php if(isset($this->bill_address->zone_id)) { ?>
		j2store_billing_zone_id = <?php echo $bzone_id=($this->bill_address->zone_id)?$this->bill_address->zone_id:0; ?>;
	<?php } else { ?>
		j2store_billing_zone_id=0;
	<?php } ?>
				
	if(J2Store('#billing_country')) {
		j2storeGetAjaxZone('billing[zone_id]','billing_zone', J2Store('#billing_country').val(), j2store_billing_zone_id);

		J2Store("#billing_country").bind('change load', function(){
			
			  // validate
			j2storeGetAjaxZone('billing[zone_id]','billing_zone', J2Store('#billing_country').val(), j2store_billing_zone_id);
		});
	}

	<?php if(isset($this->ship_address->zone_id)) { ?>
	j2store_shipping_zone_id = <?php echo $szone_id = ($this->ship_address->zone_id)?$this->ship_address->zone_id:0; ?>;
	<?php } else { ?>
	j2store_shipping_zone_id=0;
	<?php } ?>

	 	if(J2Store('#shipping_country')) {
	 		j2storeGetAjaxZone('shipping[zone_id]','shipping_zone', J2Store('#shipping_country').val(), j2store_shipping_zone_id);		

	 		J2Store("#shipping_country").bind('change load', function(){
	 			j2storeGetAjaxZone('shipping[zone_id]','shipping_zone', J2Store('#shipping_country').val(), j2store_shipping_zone_id);
	 		});
		}


	 	var j2storeErrorcontainer = J2Store('div.j2storeErrorcontainer');
		
	 	J2Store("#addressForm").validate({
	 		debug: true,
	 		errorElement: "em",
	 		//errorContainer: $("#warning, #summary"),
	 		errorPlacement: function(error, element) {
	 			error.appendTo( element.next("div") );
	 		},
	 		success: function(label) {
	 		//	label.text("<?php echo JText::_('J2STORE_VALIDATION_OK');?>").addClass("success");
	 		},
	 	   submitHandler: function(form) {
	 	       // now validate the shipping fields if same as billing not checked
	 	    	form.submit();
	 	   },
	 	   rules: {
	 		   <?php if($j2params->get('ship_fname') == 1):?>
	 		   'shipping[first_name]': {
	 			   required: J2Store('#j2store_shipping_make_same').is(':checked')
	 		   }
	 		   <?php endif;?>
	 		}
	 	});	 		 	

		
		
	});


function j2storeToggleShipping(el){
	    if(el.checked) {
	    	J2Store('#j2store_shipping_section').css({
				    // the 'styles' property passes the object to Element:setStyles.
				        'visible': 'hidden',
				        'display': 'none'
			  });
			 J2Store('#j2store_shipping_make_same').val(1);
			 J2Store('#j2store_shipping_make_same').attr('checked', true);
			
		  } else {
			  J2Store('#j2store_shipping_section').css({
				    // the 'styles' property passes the object to Element:setStyles.
				        'visible': 'visible',
				        'display': 'block'
			  });

			var j2store_shipping_zone_id;
			 <?php if(isset($this->ship_address->zone_id)) { ?>
			 j2store_shipping_zone_id = <?php echo $szone_id = ($this->ship_address->zone_id)?$this->ship_address->zone_id:0; ?>;
			<?php } else { ?>
			j2store_shipping_zone_id=0;
			<?php } ?>
			  
			  j2storeGetAjaxZone('shipping[zone_id]','shipping_zone', J2Store('#shipping_country').val(), j2store_shipping_zone_id);
			  J2Store('#j2store_shipping_make_same').val(2);
			  J2Store('#j2store_shipping_make_same').attr('checked', false);			  		 
		  }
	  }
-->
</script>

<div class="j2storeCheckoutAddress container-fluid">
<div class="row-fluid">
	<form action="<?php echo $action; ?>" method="post" id="addressForm"
		class="form-inline" name="addressForm" enctype="multipart/form-data">
	
		<?php if($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout') || $this->params->get('show_shipping_address')): ?>
		<div class="j2store">

			<?php //TODO:: seems only when all three are checked no, the fields disappear. Need to correct this 
			
			if($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout')): ?>

			<div class="j2storeBillingAddressDefault">
				<h3>
					<?php echo JText::_('J2STORE_BILLING_ADDRESS'); ?>
				</h3>
				<?php echo $this->loadTemplate('billing'); ?>

			</div>
			<?php endif; ?>

			<?php if($this->params->get('show_shipping_address')): ?>

			<div class="j2storeShippingAddressDefault">
			
				<?php if(($this->params->get('show_billing_address') || $this->params->get('allow_guest_checkout'))  && $this->params->get('show_shipping_address')):?>
				<br />
				<input id="j2store_shipping_make_same" value='1' name="j2store_shipping_make_same" type="checkbox"
					<?php echo $checked; ?> onClick="j2storeToggleShipping(this)" />
				<?php echo JText::_('J2STORE_MAKE_SHIPPING_SAME'); ?>
				<?php endif; ?>
				
				<?php echo $this->loadTemplate('shipping'); ?>
			</div>

			<?php endif; ?>
		</div>
		<?php endif; ?>
			<br />
			<input class="j2store_cart_button btn btn-primary pull-right ignore" type="submit" name="mysubmit" value="<?php echo JText::_('J2STORE_CHOOSE_PAYMENT'); ?>" />

				<input type="hidden" name="option" value="com_j2store" />
				<input type="hidden" name="controller" value="checkout" />
				<input type="hidden" name="task" value="selectpayment" />				
			<?php echo JHTML::_( 'form.token' ); ?>
		
	</form>
</div>

</div>
