<?php
/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$action = JRoute::_('index.php?option=com_j2store&view=checkout');
$doc = &JFactory::getDocument();
$doc->addScript(JURI::root(true).'/media/j2store/js/jquery.validate.min.js');
?>

<script id="demo" type="text/javascript">
J2Store(document).ready(function() {
	// validate payment form on submit
	var validator = J2Store("#j2storePaymentForm").validate({
		rules: {
			payment_plugin:"required"
		},
		messages: {
			payment_plugin: "<?php echo JText::_('J2STORE_SELECT_A_PAYMENT_METHOD'); ?>",
		},	
		debug: true,
 		errorElement: "em",
 		//errorContainer: $("#warning, #summary"),
 		errorPlacement: function(error, element) {
 			if ( element.is(":radio") )
				error.appendTo( element.parent().next('div') );
 			else
 			error.appendTo(element.next("div") );
 		},
 		success: function(label) {
 		//	label.text("<?php echo JText::_('J2STORE_VALIDATION_OK');?>").addClass("success");
 		},
 	   submitHandler: function(form) {
 	       // now validate the shipping fields if same as billing not checked
 	      form.submit();
 	   }
	});

});	

</script>
<div class="j2store">		
<form action="<?php echo $action; ?>" 
		method="post" 
		id="j2storePaymentForm"
		class="j2storePaymentForm form-inline"
		name="j2storePaymentForm"
		enctype="multipart/form-data">

	<div class="row-fluid">
		
			<div class="span7">	
	 			<?php if($this->showShipping): ?>
				<div class="shipping_info">
					<?php echo $this->loadTemplate('shippingmethod'); ?>			
				</div>
				<?php endif; ?>
	
			
				<?php if($this->showPayment): ?>
				<div class="payment_info">
					<?php echo $this->loadTemplate('payment'); ?>
				</div>
				<?php endif; ?>
	
				<div class="order_comment">
					<?php echo $this->loadTemplate('comment'); ?>
				</div>
			</div>
			<div class="span5">	
				<div class="order_summary">
					<?php echo $this->orderSummary; ?>
				</div>
			</div>
			<div class="span12">
				<input class="j2store_checkout_button btn btn-primary" type="submit"
						value="<?php echo JText::_('J2STORE_PROCEED_TO_PAYMENT');?>" />
						</div>
		</div>
		
		<?php if(isset($this->billing_address_id)): ?>
			<input type="hidden" name="billing_address_id" value="<?php echo $this->billing_address_id; ?>" />
		<?php endif; ?>
		<?php if(isset($this->shipping_address_id)): ?>
			<input type="hidden" name="shipping_address_id" value="<?php echo $this->shipping_address_id; ?>" />
		<?php endif; ?>
		
			
				<input type="hidden" name="option" value="com_j2store" />
				<input type="hidden" name="controller" value="checkout" />
				<input type="hidden" name="task" value="preparePayment" />				
			<?php echo JHTML::_( 'form.token' ); ?>
		
	</form>
	</div>