<?php
/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.6
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
if (isset($this->bill_address)) {
	$billAddr = @$this->bill_address;
}
$j2params = $this->params;
/*
 * 1 required
* 2 not required
* 3 disable
* */
?>

<div id="j2store_billing_section" class="row-fluid">
	<table class="table table-condensed">
		<tr>

			<td>
				<label class="" for="billing[first_name]"> 
				<?php echo JText::_('J2STORE_FIRST_NAME'); ?>
				<em class="">*</em>
				</label>
				<input type="text" class="input-text required"
				value="<?php if(isset($billAddr->first_name)) echo $billAddr->first_name; ?>"
				name="billing[first_name]" id="billing_firstname" title="<?php echo JText::_('J2STORE_FIRST_NAME_REQUIRED');?>">
				<div class="j2error"></div>
			</td>

			<?php if($j2params->get('bill_lname') != 3):?>
			<td>
				<label
				class=""
				for="billing_lastname"> 
				<?php echo JText::_('J2STORE_LAST_NAME')?>
				<?php echo ($j2params->get('bill_lname')==1)?'<em class="">*</em>':''; ?>
				</label>
					<input type="text"
					class="input-text <?php echo ($j2params->get('bill_lname')==1)?'required':''; ?>"
					title="<?php echo JText::_('J2STORE_LAST_NAME_REQUIRED');?>"
					value="<?php if(isset($billAddr->last_name)) echo $billAddr->last_name; ?>"
					name="billing[last_name]" id="billing_lastname">
					<div class="j2error"></div>
			</td>
			<?php endif; // bill last name?>
		</tr>
		
		<?php if($j2params->get('bill_addr_line1') != 3 || $j2params->get('bill_addr_line2') != 3):?>
		<tr>
		<?php if($j2params->get('bill_addr_line1') != 3):?>
			<td>
					<label
						class=""
						for="billing_address_1"> <?php echo JText::_('J2STORE_ADDRESS'); ?>
						<?php echo ($j2params->get('bill_addr_line1')==1)?'<em class="">*</em>':''; ?>
					</label>
					<input type="text"
					class="input-text <?php echo ($j2params->get('bill_addr_line1')==1)?'required':''; ?>"
					title="<?php echo JText::_('J2STORE_ADDRESS_REQUIRED');?>"
					value="<?php if(isset($billAddr->address_1)) echo $billAddr->address_1; ?>"
					id="billing_address_1" name="billing[address_1]" />
					<div class="j2error"></div>
			</td>
	  <?php endif; // bill address line 1?>
		
		<?php if($j2params->get('bill_addr_line2') != 3):?>
				<td>
				<label>&nbsp;</label>
					<input type="text"
					class="input-text <?php echo ($j2params->get('bill_addr_line2')==1)?'required':''; ?>"
					title="<?php echo JText::_('J2STORE_ADDRESS_REQUIRED');?>"
					value="<?php if(isset($billAddr->address_2)) echo $billAddr->address_2; ?>"
					id="billing_address_2" name="billing[address_2]">
					<div class="j2error"></div>
				</td>
	    <?php endif; // bill address line 2?>
    </tr>
	<?php endif; ?>
    		<?php if(($j2params->get('bill_zip') != 3)||($j2params->get('bill_city') != 3)):?>
    			<tr>
					<?php if($j2params->get('bill_zip') != 3):?>
						<td>
							<label for="billing_zip">
							<?php echo JText::_('J2STORE_POSTCODE');?>
							<?php echo ($j2params->get('bill_zip')==1)?'<em class="">*</em>':''; ?>
								</label>
								<input type="text" class="input-text <?php echo ($j2params->get('bill_zip')==1)?'required':''; ?>"
									title="<?php echo JText::_('J2STORE_ZIP_REQUIRED');?>" 
									value="<?php if(isset($billAddr->zip)) echo $billAddr->zip; ?>"
									id="billing_zip" name="billing[zip]">
									<div class="j2error"></div>
						</td>
						<?php endif; // end zip ?>
						<?php if($j2params->get('bill_city') != 3):?>
						<td>
							<label class="" for="billing_city">
							<?php echo JText::_('J2STORE_CITY'); ?>
							<?php echo ($j2params->get('bill_city')==1)?'<em class="">*</em>':''; ?>
							</label>
								<input type="text" class="input-text <?php echo ($j2params->get('bill_city')==1)?'required':''; ?>" 
								title="<?php echo JText::_('J2STORE_CITY_REQUIRED');?>"
									value="<?php if(isset($billAddr->city)) echo $billAddr->city; ?>" id="billing_city"
									name="billing[city]" />
									<div class="j2error"></div>
						</td>
						<?php endif; // end city ?>
			</tr>	
		 <?php endif; // end both city and zip?>

		 <?php if($j2params->get('bill_country_zone') != 3):?>
		  <tr>
		  				<td>	
							<label
							class="required"
							for="billing_country"> <?php echo JText::_('J2STORE_COUNTRY'); ?>
							<em class="">*</em>
							</label>
								<?php echo $this->bill_country; ?>
								<div class="j2error"></div>
						</td>
						<td>
						
							<label class="" for="billing_state"><?php echo JText::_('J2STORE_STATE_PROVINCE'); ?>
							</label>
								<span id="billZoneList"> </span>
							
						</td>
			</tr>			
		   <?php endif; // end country , zone ?>

           <?php if(($j2params->get('bill_phone1') != 3)||($j2params->get('bill_phone2') != 3)):?>
			<tr>
						<?php if($j2params->get('bill_phone1') != 3):?>
						<td>
							<label
							class=""
							for="billing_phone_1">
							<?php echo JText::_('J2STORE_TELEPHONE')?>
							<?php echo ($j2params->get('bill_phone1')==1)?'<em class="">*</em>':''; ?>
							</label>
								<input type="text"
								class="input-text <?php echo ($j2params->get('bill_phone1')==1)?'required':''; ?>"
								title="<?php echo JText::_('J2STORE_PHONE_REQUIRED');?>"
								value="<?php if(isset($billAddr->phone_1)) echo $billAddr->phone_1; ?>" id="billing_phone_1"
									name="billing[phone_1]" />
									<div class="j2error"></div>
						</td>
						<?php endif; // end phone1 ?>
						<?php if($j2params->get('bill_phone2') != 3):?>
						<td>
							<label
							class=""
							for="billing_phone_2">
							<?php echo JText::_('J2STORE_MOBILE')?>
							<?php echo ($j2params->get('bill_phone2')==1)?'<em class="">*</em>':''; ?> 
							</label>
								<input type="text"
								class="input-text <?php echo ($j2params->get('bill_phone2')==1)?'required':''; ?>"
								title="<?php echo JText::_('J2STORE_MOBILE_REQUIRED');?>"
								 value="<?php if(isset($billAddr->phone_2)) echo $billAddr->phone_2; ?>" id="billing_phone_2"
									name="billing[phone_2]" />
									<div class="j2error"></div>
						</td>
						<?php endif; // end phone2 ?>
			</tr>	
			<?php endif; // end mobile , phone1 phone2?>
		</table>
		<input type="hidden" name="bill_id" value="<?php echo @$billAddr->id; ?>" />	
</div>