<?php
/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$url = JRoute::_( "index.php?option=com_j2store&view=mycart" );
$return_url = JRoute::_( "index.php?option=com_j2store&view=checkout" );
$guest_url = JRoute::_( "index.php?option=com_j2store&view=checkout");
$register_action_url = JRoute::_( "index.php?option=com_j2store&view=checkout" );

//calculat span
if($this->params->get('show_login_form', 1) && $this->params->get('allow_registration', 1)) {
	
	$span = 'span5';
} else {
	$span = 'span12';
}

?>
<div class="j2store">
<?php if($this->params->get('show_login_form', 1) || $this->params->get('allow_registration', 1)): ?>
<div class="row-fluid">
	<?php if($this->params->get('show_login_form', 1)): ?>
	
	 <script type="text/javascript">
			<!--
			J2Store(document).ready(function(){
				J2Store('#j2store_login_form').validate(); 
			});
			-->
		 </script>
	
		<div class="j2store_login_form <?php echo $span; ?>">
				<h3><?php echo JText::_('J2STORE_LOGIN'); ?></h3>
				
				<!-- LOGIN FORM -->

				<?php if (JPluginHelper::isEnabled('authentication', 'openid')) :
				$lang->load( 'plg_authentication_openid', JPATH_ADMINISTRATOR );
				$langScript =   'var JLanguage = {};'.
						' JLanguage.WHAT_IS_OPENID = \''.JText::_( 'WHAT_IS_OPENID' ).'\';'.
						' JLanguage.LOGIN_WITH_OPENID = \''.JText::_( 'LOGIN_WITH_OPENID' ).'\';'.
						' JLanguage.NORMAL_LOGIN = \''.JText::_( 'NORMAL_LOGIN' ).'\';'.
						' var modlogin = 1;';
				$document = &JFactory::getDocument();
				$document->addScriptDeclaration( $langScript );
				JHTML::_('script', 'openid.js');
        				endif; ?>

				<form
					action="<?php echo JRoute::_( 'index.php?option=com_users&task=user.login', true, $this->params->get('usesecure')); ?>"
					method="post" name="login" class="j2store_login_form" id="j2store_login_form">

					<label for="username" class="j2storeUserName"><?php echo JText::_('J2STORE_USERNAME'); ?>
					</label>
					<input type="text" name="username" class="inputbox required" alt="username" title="<?php echo JText::_('J2STORE_LOGIN_FORM_ENTER_USERNAME');?>" />
					
					<label for="password" class="j2storePassword"><?php echo JText::_('J2STORE_PASSWORD'); ?> </label>
				
					<input type="password" name="password" class="inputbox required" alt="password" title="<?php echo JText::_('J2STORE_LOGIN_FORM_ENTER_PASSWORD');?>" />
				
					<?php if (JPluginHelper::isEnabled('system', 'remember')) : ?>
					<label for="remember"> 
					<span> <input type="checkbox" name="remember"
						class="inputbox" value="yes" />
					</span>
					<?php echo JText::_('J2STORE_REMEMBER_ME'); ?>
					</label>
					<?php endif; ?>
					<div class="clr"></div>
					<input type="submit" name="submit" class="j2store_checkout_button btn btn-primary"
						value="<?php echo JText::_('J2STORE_LOGIN') ?>" />
					<ul class="loginLinks">
						<li><?php // TODO Can we do this in a lightbox or something? Why does the user have to leave? ?>
							<a
							href="<?php echo JRoute::_( 'index.php?option=com_users&view=reset' ); ?>">
								<?php echo JText::_('J2STORE_FORGOT_YOUR_PASSWORD'); ?>
						</a>
						</li>
						<li><?php // TODO Can we do this in a lightbox or something? Why does the user have to leave? ?>
							<a
							href="<?php echo JRoute::_( 'index.php?option=com_users&view=remind' ); ?>">
								<?php echo JText::_('J2STORE_FORGOT_YOUR_USERNAME'); ?>
						</a>
						</li>
					</ul>
					<input type="hidden" name="option" value="com_users" /> <input
						type="hidden" name="task" value="user.login" /> <input
						type="hidden" name="return"
						value="<?php echo base64_encode( $return_url ); ?>" />
					<?php echo JHTML::_( 'form.token' ); ?>
				</form>
				</div>
		<?php endif; ?>
		
		<?php if($this->params->get('allow_registration', 1)): ?>
		 <script type="text/javascript">
			<!--
			J2Store(document).ready(function(){
				J2Store('#j2storeRegistrationForm').validate({
					  rules: {
						    email: {
							    required: true,
							    email: true
						    },
						    confirm_mail: {
						     required: true,
							  email: true,
						      equalTo: '#email'
						    },
						    password: 'required',
						    password2: {
						    	 equalTo: '#password'
						    }
					  } 
				}); 
			});
			-->
		 </script>
		<div class="j2store_registration_form <?php echo $span; ?>">
					
					<h3><?php echo JText::_('J2STORE_REGISTER_NEWUSER'); ?></h3>
				<!-- Registration form -->
				<form action="<?php echo $register_action_url;?>" method="post"
					name="adminForm" id="j2storeRegistrationForm">
					
						<label for="email"> <?php echo JText::_( 'J2STORE_REGISTER_EMAIL' ); ?>
							*
						</label>  <input name="email" id="email"
							class="required email" type="text" title="<?php echo JText::_('J2STORE_VALIDATION_ENTER_VALID_EMAIL'); ?>" />
			
						<label for="confirm_mail"> <?php echo JText::_( 'J2STORE_CONFIRM_EMAIL' ); ?>*
						</label>  <input name="confirm_mail" id="confirm_mail"
							class="required email" type="text" title="<?php echo JText::_('J2STORE_EMAIL_DOES_NOT_MATCH'); ?>" />
			
						<label for="password"> <?php echo JText::_( 'J2STORE_PASSWORD' ); ?>
							*
						</label>  <input name="password" id="password"
							class="required" type="password" title="<?php echo JText::_('J2STORE_VALIDATION_PASSWORD_REQUIRED'); ?>" />
			
						<label for="first_name"> <?php echo JText::_( 'J2STORE_CONFIRM_PASSWORD' ); ?>*
						</label>  <input name="password2" id="password2"
							class="required" type="password" title="<?php echo JText::_('J2STORE_PASSWORD_DOES_NOT_MATCH'); ?>" />
						<input type="hidden" name="task" value="register" />
						<label></label>
						<input type="submit" name="submit" class="j2store_checkout_button btn btn-primary"
							value="<?php echo JText::_('J2STORE_REGISTER') ?>" />
					<?php echo JHTML::_( 'form.token' ); ?>
				</form>

			</div>
		<?php endif; ?>
		</div>
	<?php endif; ?>
	
		<?php if ($this->params->get('allow_guest_checkout')) : ?>
		 <script type="text/javascript">
			<!--
			J2Store(document).ready(function(){
				J2Store('#guestform').validate(); 
			});
			-->
		 </script>
		<div class="row-fluid">
			<!--Guest -->
			<div class="j2store_guest_form span12">
			<form action="<?php echo $guest_url;?>" method="post"
					class="guestform" name="guest" id="guestform">
				<!-- REGISTRATION -->
					<h3><?php echo JTEXT::_('J2STORE_CHECKOUT_AS_GUEST_DESC'); ?></h3>
					<br />
						
						<label for="guest_mail"><strong> <?php echo JText::_( 'J2STORE_GUEST_EMAIL' ); ?></strong><em>*</em>
						</label> 
						<input name="guest_mail" id="guest_mail" class="required email" type="email" title="<?php echo JText::_('J2STORE_ERROR_GUEST_EMAIL_REQUIRED'); ?>" />
						<input type="submit" name="submit" class="j2store_checkout_button btn btn-primary"
							value="<?php echo JText::_('J2STORE_CHECKOUT_AS_GUEST') ?>" />
				</form>
			</div> 
			</div>
		<?php endif; ?>
	</div>