<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/



// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class J2StoreControllerMyCart extends J2StoreController
{
	public function __construct($config = array())
		{
			parent::__construct($config);
		}

	function display() {

		//initialist system objects
		$app = &JFactory::getApplication();
		$params = &JComponentHelper::getParams('com_j2store');

		//get post vars
		$post = JRequest::get('post');
		if(!empty($post)) {
			
			//first validate attributes
			$errors = $this->validateAttributes($post);
			if(count($errors->attr_notfound)) {
				require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/select.php');
				//validation failed. Echo the relevant message and close the app
				$msg = '';
				foreach($errors->attr_notfound as $attr_id) {
					$msg .= JText::_('J2STORE_ATTRIBUTE_SELECTION_REQUIRED').J2StoreSelect::getAttributeName($attr_id);
				}
				$return_url = (isset($post['return']))?base64_decode($post['return']):JRoute::_('index.php');
					
				$app->redirect($return_url, $msg);
			}
			
			//add to cart
			$this->addtocart($post);
		}

		$model = $this->getModel('Mycart');

		//set the state

		// limitstart isn't working for some reason when using getUserStateFromRequest -- cannot go back to page 1
		$limit  = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', '0', 'request', 'int');
		// If limit has been changed, adjust offset accordingly
		$state['limitstart'] = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
        $state['limit']  	= $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');


        $session =& JFactory::getSession();
        $user =& JFactory::getUser();

        $state['filter_user'] = $user->id;
        if (empty($user->id))
        {
            $state['filter_session'] = $session->getId();
        }

        foreach (@$state as $key=>$value)
        {
			$model->setState( $key, $value );
        }

		//load the cart data
		$items = $model->getData();

		$cartobject = $this->checkItems($items, $params->get('show_tax_total'));

		$view = $this->getView( 'mycart', 'html' );
		$view->set( '_view', 'mycart' );
		$view->assign( 'cartobj', $cartobject);
		$view->assign( 'state', $model->getState());
		$view->assign( 'params', $params );
		if(isset($post['return'])) {
			$view->assign( 'return', $post['return']);
		}
		$view->set( '_doTask', true);
		$view->set( 'hidemenu', true);
		$view->setModel( $model, true );
		$view->setLayout( 'default');
		$view->display();

	}

	function ajax() {
		//initialise system objects
		$app = &JFactory::getApplication();
		$params = &JComponentHelper::getParams('com_j2store');

		//$elements = json_decode( preg_replace('/[\n\r]+/', '\n', JRequest::getVar( 'elements', '', 'post', 'string' ) ) );

		$values = $app->input->get('elements', array(0), 'ARRAY');
		
		//first validate the attribute
		$errors = $this->validateAttributes($values);
		if(count($errors->attr_notfound)) {
			require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/select.php');
			//validation failed. Echo the relevant message and close the app
			$msg = '';
			foreach($errors->attr_notfound as $attr_id) {
				$msg .= JText::_('J2STORE_ATTRIBUTE_SELECTION_REQUIRED').J2StoreSelect::getAttributeName($attr_id);
			}
			echo $msg;
			$app->close();
		}
		
		//lets add things to the cart
		$this->addtocart($values);

		$model = $this->getModel('mycart');


		// limitstart isn't working for some reason when using getUserStateFromRequest -- cannot go back to page 1
		$limit  = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', '0', 'request', 'int');
		// If limit has been changed, adjust offset accordingly
		$state['limitstart'] = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
        $state['limit']  	= $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');


        $session =& JFactory::getSession();
        $user =& JFactory::getUser();

        $state['filter_user'] = $user->id;
        if (empty($user->id))
        {
            $state['filter_session'] = $session->getId();
        }

        foreach (@$state as $key=>$value)
        {
			$model->setState( $key, $value );
        }


		$items = $model->getData();

		$cartobject = $this->checkItems($items, $params->get('show_tax_total'));

		$view = $this->getView( 'mycart', 'html' );
		$view->set( '_view', 'mycart' );
		$view->set( '_doTask', true);
		$view->set( 'hidemenu', true);
		$view->setModel( $model, true );
		$view->assign( 'cartobj', $cartobject);
		$view->assign( 'params', $params );
		//popup layout options
		switch($params->get('popup_style', 1)) {
			case 1:
			default:
				$view->setLayout( 'ajax');
			break;

			case 2:
				$view->setLayout( 'ajaxstatic');
			break;

		}

		ob_start();
		$view->display();
		$html = ob_get_contents();
		ob_end_clean();
		echo $html;
		$app->close();
	}


	function ajaxmini() {
			//initialise system objects
		$app = &JFactory::getApplication();
		$params = &JComponentHelper::getParams('com_j2store');

		$model = $this->getModel('mycart');

        $session =& JFactory::getSession();
        $user =& JFactory::getUser();

        $state['filter_user'] = $user->id;
        if (empty($user->id))
        {
            $state['filter_session'] = $session->getId();
        }

        foreach (@$state as $key=>$value)
        {
			$model->setState( $key, $value );
        }

		$items = $model->getData();

		$cartobject = $this->checkItems($items, $params->get('show_tax_total'));

		$view = $this->getView( 'mycart', 'html' );
		$view->set( '_view', 'mycart' );
		$view->set( '_doTask', true);
		$view->set( 'hidemenu', true);
		$view->setLayout( 'ajaxmini');
		$view->setModel( $model, true );
		$view->assign( 'cartobj', $cartobject);
		$view->assign( 'params', $params );

		ob_start();
		$view->display();
		$html = ob_get_contents();
		ob_end_clean();
		echo $html;
		$app->close();
	}

	public function addtocart($values) {

		if(empty($values)) {
			return;
		}

		//initialise system objects
		$app = &JFactory::getApplication();
		$config = &JComponentHelper::getParams('com_j2store');
		// After login, session_id is changed by Joomla, so store this for reference
		$session = &JFactory::getSession( );
		$session->set( 'old_sessionid', $session->getId( ) );

			$product_id = !empty( $values['product_id'] ) ? ( int ) $values['product_id'] : JRequest::getInt( 'product_id' );
			$product_qty = !empty( $values['product_qty'] ) ? ( int ) $values['product_qty'] : '1';

			//get attributes

			$attributes = array( );
			foreach ( $values as $key => $value )
			{
				if ( substr( $key, 0, 10 ) == 'attribute_' )
				{
					$attributes[] = $value;
				}
			}
			sort( $attributes );
			$attributes_csv = implode( ',', $attributes );


			// Integrity checks on quantity being added
			if ( $product_qty <= 0 )
			{
				$product_qty = '1';
			}

			$user = JFactory::getUser( );
			$cart_id = $user->id;
			$id_type = "user_id";
			if ( empty( $user->id ) )
			{
				$cart_id = $session->getId( );
				$id_type = "session";
			}

			// create cart object out of item properties
			$item = new JObject;
			$item->user_id = JFactory::getUser( )->id;
			$item->product_id = ( int ) $product_id;
			$item->product_qty = ( int ) $product_qty;
			$item->product_attributes = $attributes_csv;
			$item->vendor_id = '0'; // TODO: May be useful to create market place site
	
			// add the item to the cart
			JLoader::register( 'J2StoreHelperCart', JPATH_SITE.DS.'components'.DS.'com_j2store'.DS.'helpers'.DS.'cart.php');
			$cart_helper = new J2StoreHelperCart();
			$cartitem = $cart_helper->addItem( $item );

			return $cartitem;
	}


	 /**
     *
     * @return unknown_type
     */
    function update()
    {
        $app = &JFactory::getApplication();
        $params = &JComponentHelper::getParams('com_j2store');
        $model 	= $this->getModel('mycart');

        // limitstart isn't working for some reason when using getUserStateFromRequest -- cannot go back to page 1
		$limit  = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', '0', 'request', 'int');
		// If limit has been changed, adjust offset accordingly
		$state['limitstart'] = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
        $state['limit']  	= $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');


        $session =& JFactory::getSession();
        $user =& JFactory::getUser();

        $state['filter_user'] = $user->id;
        if (empty($user->id))
        {
            $state['filter_session'] = $session->getId();
        }

        foreach (@$state as $key=>$value)
        {
			$model->setState( $key, $value );
        }

        $cids = $app->input->get('cid', array(0), 'ARRAY');
        $product_attributes = $app->input->get('product_attributes', array(0), 'ARRAY');
        $quantities = $app->input->get('quantities', array(0), 'ARRAY');
        $post = JRequest::get('post');

        $msg = JText::_('J2STORE_CART_UPDATED');

        $remove = $app->input->get('remove');
        if ($remove)
        {
            foreach ($cids as $cart_id=>$product_id)
            {
//            	$keynames = explode('.', $key);
//            	$attributekey = $keynames[0].'.'.$keynames[1];
//            	$index = $keynames[2];
                $row = $model->getTable();

                //main cartitem keys
                $ids = array('user_id'=>$user->id, 'cart_id'=>$cart_id);

				        if (empty($user->id))
		                {
		                    $ids['session_id'] = $session->getId();
		                }

		                if ($return = $row->delete(array('cart_id'=>$cart_id)))
		                {

		                }
            }
        }
        else
        {
            foreach ($quantities as $cart_id=>$value)
            {
                $carts = JTable::getInstance( 'Mycart', 'Table' );
                $carts->load( array( 'cart_id'=>$cart_id) );
                $product_id = $carts->product_id;
                $value = (int) $value;

            	$vals = array();
                $vals['user_id'] = $user->id;
                $vals['session_id'] = $session->getId();
                $vals['product_id'] = $product_id;


              $row = $model->getTable();
              $vals['product_attributes'] = $product_attributes[$cart_id];
              $vals['product_qty'] = $value;
              if (empty($vals['product_qty']) || $vals['product_qty'] < 1)
              {
              	// remove it
              	if ($return = $row->delete($cart_id))
              	{

              	}
              }
              else
              {
                $row->load($cart_id);
              	$row->product_qty = $vals['product_qty'];
              	$row->save();
              }
            }
        }

        JLoader::register( 'J2StoreHelperCart', JPATH_SITE.'/components/com_j2store/helpers/cart.php');
		$cart_helper = new J2StoreHelperCart();

        if (empty($user->id))
        {
        	$cart_helper->checkIntegrity($session->getId(), 'session_id');
        }
        else
        {
        	$cart_helper->checkIntegrity($user->id);
        }

        $popup = $app->input->get('popup');
        if($popup && $remove) {
			$items = $model->getData();

			$cartobject = $this->checkItems($items, $params->get('show_tax_total'));

			$view = $this->getView( 'mycart', 'html' );
			$view->set( '_view', 'mycart' );
			$view->set( '_doTask', true);
			$view->set( 'hidemenu', true);

			if($popup==1) {
				$view->setLayout( 'ajax');
			} else {
				$view->setLayout( 'default');
			}
			$view->setModel( $model, true );
			$view->assign( 'cartobj', $cartobject);
			$view->assign( 'params', $params );
			$view->assign( 'popup', $popup );
			$view->assign( 'remove', $remove);

			ob_start();
			$view->display();
			$html = ob_get_contents();
			ob_end_clean();
			echo $html;
			$app->close();
		}

        $redirect = JRoute::_( "index.php?option=com_j2store&view=mycart", false );
       	$this->setRedirect( $redirect, $msg);
    }



	 function _setModelState()
    {
        $app = JFactory::getApplication();

        $model = $this->getModel('Mycart');
		$ns = 'com_j2store.mycart';
		$state = array();

		// limitstart isn't working for some reason when using getUserStateFromRequest -- cannot go back to page 1
		$limit  = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', '0', 'request', 'int');
		// If limit has been changed, adjust offset accordingly
		$state['limitstart'] = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
        $state['limit']  	= $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');


        $session =& JFactory::getSession();
        $user =& JFactory::getUser();

        $state['filter_user'] = $user->id;
        if (empty($user->id))
        {
            $state['filter_session'] = $session->getId();
        }

        foreach (@$state as $key=>$value)
        {
            $result = $model->setState( $key, $value );
        }
        return $state;
    }


    /**
     *
     * Method to check config, user group and product state (if recurs).
     * Then get right values accordingly
     * @param array $items - cart items
     * @param boolean - config to show tax or not
     * @return object
     */
    function checkItems( &$items, $show_tax=false)
    {
    	if (empty($items)) { return array(); }


      	$subtotal = 0;
        foreach ($items as $item)
        {

        	if($show_tax)
        	{
        		$cartitem_tax = 0;

		       $product_tax_rate = J2StorePrices::getItemTax($item->product_id);
		       //$product_tax_rate = $taxrate->tax_rate;

		         // track the total tax for this item
		        $cartitem_tax = $product_tax_rate * $item->product_price;

           	 	$item->product_price = $item->product_price + $cartitem_tax;
            	$item->taxtotal = $cartitem_tax;
        	}

        	$item->subtotal = $item->product_price * $item->product_qty;
        	$subtotal = $subtotal + $item->subtotal;
        }
        $cartObj = new JObject();
        $cartObj->items = $items;
    	$cartObj->subtotal = $subtotal;
        return $cartObj;
    }
    
    function validateAttributes($values, $ajax=false) {
    	 
    	$errors = new JObject();
    	$errors->attr_notfound=array();
    	$db = &JFactory::getDbo();
    
    	$product_id = $values['product_id'];
    	if(!$product_id) {
    		$errors->msg = JText::_('J2STORE_PRODUCT_ID_REQUIRED');
    	}
    	 
    	//get attributes
    	 
    	//	$attributes = array( );
    	$attributes_key = array( );
    	foreach ( $values as $key => $value )
    	{
    		//	echo $key;
    		 
    		if ( substr( $key, 0, 10 ) == 'attribute_' )
    		{
    			list($text,$attr_id) = explode('_',$key);
    			 
    			//	$attributes[] = $value;
    			$attributes_key[] = $attr_id;
    		}
    	}
    	//sort( $attributes );
    	sort( $attributes_key );
    	 
    	//now get the attributes assigned for this product
    	$query = $db->getQuery(true);
    	$query->select('*');
    	$query->from('#__j2store_productattributes');
    	$query->where('product_id='.(int)$product_id);
    	$query->where('productattribute_required=1');
    	 
    	$db->setQuery($query);
    	$rows = $db->loadObjectList();
    	 
    	if(count($rows)) {
    		foreach($rows as $row){
    			if(!in_array($row->productattribute_id, $attributes_key)) {
    				$errors->attr_notfound[]= $row->productattribute_id;
    			}
    			 
    		}
    	}
    	return $errors;
    }
}