<?php
/*------------------------------------------------------------------------
 # com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
JHTML::_('behavior.tooltip');
jimport('joomla.application.component.controller');
$app = &JFactory::getApplication();

//j3 compatibility
if(!defined('DS')){
	define('DS',DIRECTORY_SEPARATOR);
}
JLoader::register('J2StoreController', JPATH_COMPONENT.'/controllers/controller.php');
JLoader::register('J2StoreView', JPATH_COMPONENT.'/views/view.php');
JLoader::register('J2StoreModel', JPATH_COMPONENT.'/models/model.php');
require_once (JPATH_SITE.'/components/com_j2store/helpers/utilities.php');
require_once (JPATH_COMPONENT.'/helpers/submenu.php');

/*
 * Make sure the user is authorized to view this page
*/
$controller = $app->input->getWord('view', 'cpanel');
if (JFile::exists(JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php')
		&& $controller !='countries' && $controller !='zones'
		&& $controller !='country' && $controller !='zone'
)

{
	require_once (JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');
	$classname = 'J2StoreController'.$controller;
	$controller = new $classname();

} else {
	$controller = JControllerLegacy::getInstance('J2Store');
}
$controller->execute($app->input->getWord('task'));
$controller->redirect();