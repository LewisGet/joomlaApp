<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/


// no direct access
defined('_JEXEC') or die('Restricted access');

?>

<div id="cpanel" class="j2storeAdminCpanel j2store row-fluid">
  	
	<?php if($this->params->get('show_quicktips', 1)):?>
		<div class="row-fluid">
			<div class="span12">
			<?php echo $this->loadTemplate('info'); ?>
			</div>
		</div>
	<?php endif; ?>
		<div class="row-fluid">
			<div class="span8">
				<div id="j2storeQuickIcons">
			<?php echo $this->loadTemplate('quickicons'); ?>
				</div>
			</div>	
			<div class="span4">
			<?php echo $this->loadTemplate('update'); ?>
			</div>
			
		</div>
</div>
<div class="clr"></div>