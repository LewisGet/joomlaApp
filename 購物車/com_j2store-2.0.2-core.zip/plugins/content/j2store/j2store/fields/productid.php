<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die;
 
// import the list field type
jimport('joomla.form.helper'); 
/**
 * Product ID Field class for the J2Store component
 */
class JFormFieldProductID extends JFormFieldText
{
	/**
	 * The field type.
	 *
	 * @var		string
	 */
	protected $type = 'ProductID';
	
	protected function getInput()
	 {
	 	$app = JFactory::getApplication();
	 	$product_id = $app->input->get('id');
	 	$html = '';
	 	if(isset($product_id)){ 
	 		$html .= '<label class="j2store_product_id">';
	 		$html .= $product_id;
	 		$html .= '</label>';
	 	} else {
	 		$html .= '<div class="alert alert-info">';
	 		$html .= JText::_('PLG_J2STORE_PRODUCT_ID_DESC');
	 		$html .= '</div>';
	 	}
		return $html;
	}
}
