<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 2.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport('joomla.html.parameter');

class plgSystemJ2Store extends JPlugin {

	function plgSystemJ2Store( &$subject, $config ){
		parent::__construct( $subject, $config );
		$this->_plugin = JPluginHelper::getPlugin( 'system', 'j2store' );
     	$params = new JRegistry;
		$params->loadString($this->_plugin->params );
		$this->_params = $params;
		
		//load language
		$this->loadLanguage('com_j2store', JPATH_SITE);
		//if($this->_mainframe->isAdmin())return;

	}

	function onAfterRoute() {

		$mainframe = JFactory::getApplication();
		require_once (JPATH_SITE.'/components/com_j2store/helpers/modules.php');
		JHtml::_('behavior.framework');
		JHtml::_('behavior.modal');
		$baseURL = JURI::root();
		$j2storeparams = JComponentHelper::getParams('com_j2store');
		$document = JFactory::getDocument();
		if($mainframe->isAdmin()) {
			$document->addScriptDeclaration("var j2storeURL = '$baseURL';");
			$document->addScript($baseURL.'media/j2store/js/j2store_admin.js');
			$document->addStyleSheet($baseURL.'media/j2store/css/j2store_admin.css');

			//add additional css if it is version 2.5
			if (version_compare(JVERSION, '3.0', 'lt'))
			{
				$document->addStyleSheet($baseURL.'media/j2store/css/j2store_admin_no_bootstrap.css');
			}
		}
		else {
			if(version_compare(JVERSION, '3.0', 'ge')) {
				//load jquery if version is 3.0
				// Joomla! 3.0 and later, use Joomla! code to load the library
				JHtml::_('jquery.framework');				
			}else {
				//load jquery for joomla 2.5/ local/remote
				if($j2storeparams->get('j2store_load_jquery', 1) == 1)
					//load from local 
					$document->addScript($baseURL.'media/j2store/js/jquery.min.js');
				elseif($j2storeparams->get('j2store_load_jquery', 1) == 2)
					//load from remote
					$document->addScript('https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js');
			}
			$document->addScript(JURI::root(true).'/media/j2store/js/jquery.validate.min.js');
			$document->addScriptDeclaration("var j2storeURL = '$baseURL';");
			$script = "
				if(typeof(J2Store) == 'undefined') {
				var J2Store = jQuery.noConflict();
				}
				";
				$document->addScriptDeclaration($script);
		
			//now add j2store js	
			$document->addScript($baseURL.'media/j2store/js/j2store.js');
		
		// Add related CSS to the <head>
			if ($document->getType() == 'html' && $j2storeparams->get('j2store_enable_css')) {

				jimport('joomla.filesystem.file');

				// j2store.css
				if(JFile::exists(JPATH_SITE.'/templates/'.$mainframe->getTemplate().'/css/j2store.css'))
					$document->addStyleSheet($baseURL.'templates/'.$mainframe->getTemplate().'/css/j2store.css');
				else
					$document->addStyleSheet($baseURL.'media/j2store/css/j2store.css');
				if (version_compare(JVERSION, '3.0', 'lt'))
				{
					$document->addStyleSheet($baseURL.'media/j2store/css/j2store_no_bootstrap.css');
				}

			} else {
				$document->addStyleSheet($baseURL.'media/j2store/css/j2store.css');
					
				if (version_compare(JVERSION, '3.0', 'lt'))
				{
					$document->addStyleSheet($baseURL.'media/j2store/css/j2store_no_bootstrap.css');
				}
			}
			
			$this->_addCartJS();
		}
	}
	
	function _addCartJS() {
		
		$valid_ok = JText::_('J2STORE_VALIDATION_OK');
		$processing = JText::_('J2STORE_PROCESSING');
		$script ='';
		$script .="
		J2Store(document).ready(function(){
			J2Store('.j2storeCartForm').each(function(){
				J2Store(this).validate({
					errorElement: 'em',
					errorPlacement: function(error, element) {
						error.appendTo( element.parent().parent().next('div'));
					},
					success: function(label) {
						//label.text('$valid_ok').addClass('success');
					},
					submitHandler: function(form) {
					";
					$j2storeparams = JComponentHelper::getParams('com_j2store');
				       if($j2storeparams->get('popup_style') == 3) { 
			 	    	$script .="form.submit();";
				       }else {
				       	$script .="
				       		j2storeAddToCart( 'addtocart', form);
				       	";
				       }

				      $script .="
					 	   }
						});	
						});
					});	";
				      $document = JFactory::getDocument();
				      $document->addScriptDeclaration($script);
	}
}