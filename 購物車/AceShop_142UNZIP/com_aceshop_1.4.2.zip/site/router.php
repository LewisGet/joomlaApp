<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

function AceshopBuildRoute(&$query) {
	return AceShop::get('router')->buildRoute($query);
}

function AceshopParseRoute($segments) {
	return AceShop::get('router')->parseRoute($segments);
}