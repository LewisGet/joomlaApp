<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::get('base')->is15()) {
    jimport('joomla.html.parameter.element');

    class JElementAceshopLayout extends JElement {

        var $_name = 'AceshopLayout';

        function fetchElement($name, $value, &$node, $control_name) {
            $db = JFactory::getDbo();
            $db->setQuery("SELECT layout_id, name FROM #__aceshop_layout");
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No layouts created.';
            }
			
			$options = array();
			foreach ($rows as $row){
				$options[] = array('value' => $row->layout_id, 'text' => $row->name);
			}

            return JHTML::_('select.genericlist', $options, ''.$control_name.'['.$name.']', 'class="inputbox" style="width:150px !important;"', 'value', 'text', $value, $control_name.$name);
        }
    }
}
else {
    jimport('joomla.form.formfield');

    class JFormFieldAceshopLayout extends JFormField {

        protected $type = 'AceshopLayout';

        protected function getInput() {
            $db = JFactory::getDbo();
            $db->setQuery("SELECT layout_id, name FROM #__aceshop_layout");
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No layouts created.';
            }
			
			$options = array();
			foreach ($rows as $row){
				$options[] = array('value' => $row->layout_id, 'text' => $row->name);
			}

            return JHTML::_('select.genericlist', $options, $this->name, 'class="inputbox" style="width:150px !important;"', 'value', 'text', $this->value, $this->name);
        }
    }
}