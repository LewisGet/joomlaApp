<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::get('base')->is15()) {
    jimport('joomla.html.parameter.element');

    class JElementAceshopManufacturer extends JElement {

        var $_name = 'AceshopManufacturer';

        function fetchElement($name, $value, &$node, $control_name) {
            $db = JFactory::getDbo();
            $query = "SELECT DISTINCT manufacturer_id, name FROM #__aceshop_manufacturer ORDER BY name";
            $db->setQuery($query);
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No manufacturers created.';
            }
			
			foreach ($rows as $row){
				$options[] = array('manufacturer_id' => $row->manufacturer_id, 'name' => $row->name);
			}

            return JHTML::_('select.genericlist', $options, ''.$control_name.'['.$name.']', 'class="inputbox"', 'manufacturer_id', 'name', $value, $control_name.$name);
        }
    }
}
else {
    jimport('joomla.form.formfield');

    class JFormFieldAceshopManufacturer extends JFormField {

        protected $type = 'AceshopManufacturer';

        protected function getInput() {
            $db = JFactory::getDbo();
            $query = "SELECT DISTINCT manufacturer_id, name FROM #__aceshop_manufacturer ORDER BY name";
            $db->setQuery($query);
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No manufacturers created.';
            }
			
			foreach ($rows as $row){
				$options[] = array('manufacturer_id' => $row->manufacturer_id, 'name' => $row->name);
			}

            return JHTML::_('select.genericlist', $options, $this->name, 'class="inputbox"', 'manufacturer_id', 'name', $this->value, $this->name);
        }
    }
}