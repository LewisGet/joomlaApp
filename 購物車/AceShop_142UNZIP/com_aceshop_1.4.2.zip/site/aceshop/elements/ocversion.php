<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::get('base')->is15()) {
    jimport('joomla.html.parameter.element');

    class JElementOcVersion extends JElement {

        var $_name = 'OcVersion';

        function fetchElement($name, $value, &$node, $control_name) {
            return AceShop::get('base')->getOcVersion();
        }
    }
}
else {
    jimport('joomla.form.formfield');

    class JFormFieldOcVersion extends JFormField {

        protected $type = 'OcVersion';

        protected function getInput() {
            return AceShop::get('base')->getOcVersion();
        }
    }
}