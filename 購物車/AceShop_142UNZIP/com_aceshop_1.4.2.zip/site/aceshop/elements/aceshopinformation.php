<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::get('base')->is15()) {
    jimport('joomla.html.parameter.element');

    class JElementAceshopInformation extends JElement {

        var $_name = 'AceshopInformation';

        function fetchElement($name, $value, &$node, $control_name) {
            $db = JFactory::getDbo();
			
            $query = "SELECT DISTINCT id.information_id AS id, id.title AS name "
                    ."FROM #__aceshop_information AS i, #__aceshop_information_description AS id "
                    ."WHERE i.status = '1' "
                    //."AND id.language_id = '1' "
                    ."ORDER BY i.sort_order, id.title";
					
            $db->setQuery($query);
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No information pages created.';
            }
			
			foreach ($rows as $row){
				$options[] = array('id' => $row->id, 'name' => $row->name);
			}

            return JHTML::_('select.genericlist', $options, ''.$control_name.'['.$name.']', 'class="inputbox"', 'id', 'name', $value, $control_name.$name);
        }
    }
}
else {
    jimport('joomla.form.formfield');

    class JFormFieldAceshopInformation extends JFormField {

        protected $type = 'AceshopInformation';

        protected function getInput() {
            $db = JFactory::getDbo();
			
			$query = "SELECT DISTINCT id.information_id AS id, id.title AS name "
                    ."FROM #__aceshop_information AS i, #__aceshop_information_description AS id "
                    ."WHERE i.status = '1' "
                    //."AND id.language_id = '1' "
                    ."ORDER BY i.sort_order, id.title";
			
            $db->setQuery($query);
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No information pages created.';
            }
			
			foreach ($rows as $row){
				$options[] = array('id' => $row->id, 'name' => $row->name);
			}

            return JHTML::_('select.genericlist', $options, $this->name, 'class="inputbox"', 'id', 'name', $this->value, $this->name);
        }
    }
}