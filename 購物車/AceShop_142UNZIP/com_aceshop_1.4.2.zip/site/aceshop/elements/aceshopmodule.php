<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::get('base')->is15()) {
    jimport('joomla.html.parameter.element');

    class JElementAceshopModule extends JElement {

        var $_name = 'AceshopModule';

        function fetchElement($name, $value, &$node, $control_name) {
			$files = JFolder::files(JPATH_ROOT.'/components/com_aceshop/opencart/catalog/controller/module', '', false, false, array('index.html'));
			
			if (empty($files) || !is_array($files)) {
                return 'No modules created.';
            }
			
			$options = array();

			foreach ($files as $file) {
				$_title = '';
				$_value = JFile::stripExt($file);
				
				$_file = JPATH_ROOT.'/components/com_aceshop/opencart/admin/language/english/module/'.$file;
				if (JFile::exists($_file)) {
					require_once($_file);
					
					if (isset($_['heading_title'])) {
						$_title = $_['heading_title'];
					}
				}
				
				if (empty($_title)) {
					$_title = ucwords(str_replace('_', ' ', $_value));
				}
				
				$_title .= " ({$_value})";
				
				$options[] = array('value' => $_value, 'text' => $_title);
			}

            return JHTML::_('select.genericlist', $options, ''.$control_name.'['.$name.']', 'class="inputbox" style="width:200px !important;"', 'value', 'text', $value, $control_name.$name);
        }
    }
}
else {
    jimport('joomla.form.formfield');

    class JFormFieldAceshopModule extends JFormField {

        protected $type = 'AceshopModule';

        protected function getInput() {
            $files = JFolder::files(JPATH_ROOT.'/components/com_aceshop/opencart/catalog/controller/module', '');
			
			if (empty($files) || !is_array($files)) {
                return 'No modules created.';
            }
			
			$options = array();

			foreach ($files as $file) {
				$_title = '';
				$_value = JFile::stripExt($file);
				
				$_file = JPATH_ROOT.'/components/com_aceshop/opencart/catalog/language/english/module/'.$file;
				if (JFile::exists($_file)) {
					require_once($_file);
					
					if (isset($_['heading_title'])) {
						$_title = $_['heading_title'];
					}
				}
				
				if (empty($_title)) {
					$_title = ucwords(str_replace('_', ' ', $_value));
				}
				
				$_title .= " ({$_value})";
				
				$options[] = array('value' => $_value, 'text' => $_title);
			}

            return JHTML::_('select.genericlist', $options, $this->name, 'class="inputbox" style="width:200px !important;"', 'value', 'text', $this->value, $this->name);
        }
    }
}