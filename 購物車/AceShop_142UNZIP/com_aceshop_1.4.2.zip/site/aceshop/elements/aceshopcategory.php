<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::getClass('base')->is15()) {
    jimport('joomla.html.parameter.element');

    class JElementAceshopCategory extends JElement {

        var $_name = 'AceshopCategory';

        function fetchElement($name, $value, &$node, $control_name) {
            $db = JFactory::getDbo();

            $query = "SELECT DISTINCT cd.category_id AS id, cd.name, c.parent_id AS parent "
                    ."FROM #__aceshop_category AS c, #__aceshop_category_description AS cd "
                    ."WHERE c.category_id = cd.category_id "
                    ."AND c.status = '1' "
                    //."AND cd.language_id = '1' "
                    ."ORDER BY c.parent_id, c.sort_order, cd.name";

            $db->setQuery($query);
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No categories created.';
            }
			
			// Collect childrens
			$children = array();
			foreach ($rows as $row) {
				// Not subcategories
				if (empty($row->parent)) {
					$row->parent = 0;
				}
				
				$pt = $row->parent;
				$list = @$children[$pt] ? $children[$pt] : array();
				array_push($list, $row);
				$children[$pt] = $list;
			}
			
			// Not subcategories
			if (empty($rows[0]->parent)) {
				$rows[0]->parent = 0;
			}
			
			// Build Tree
			$tree = AceShop::get('base')->buildIndentTree(intval($rows[0]->parent), '', array(), $children);
			
			foreach ($tree as $item){
				$options[] = array('path' => $item->id, 'name' => $item->name);
			}

            return JHTML::_('select.genericlist', $options, ''.$control_name.'['.$name.']', 'class="inputbox"', 'path', 'name', $value, $control_name.$name);
        }
    }
}
else {
    jimport('joomla.form.formfield');

    class JFormFieldAceshopCategory extends JFormField {

        protected $type = 'AceshopCategory';

        protected function getInput() {
            $db = JFactory::getDbo();

            $query = "SELECT DISTINCT cd.category_id AS id, cd.name, c.parent_id AS parent "
                    ."FROM #__aceshop_category AS c, #__aceshop_category_description AS cd "
                    ."WHERE c.category_id = cd.category_id "
                    ."AND c.status = '1' "
                    //."AND cd.language_id = '1' "
                    ."ORDER BY c.parent_id, c.sort_order, cd.name";

            $db->setQuery($query);
            $rows = $db->loadObjectList();

            if (empty($rows)) {
                return 'No categories created.';
            }
			
			// Collect childrens
			$children = array();
			foreach ($rows as $row) {
				// Not subcategories
				if (empty($row->parent)) {
					$row->parent = 0;
				}
				
				$pt = $row->parent;
				$list = @$children[$pt] ? $children[$pt] : array();
				array_push($list, $row);
				$children[$pt] = $list;
			}
			
			// Not subcategories
			if (empty($rows[0]->parent)) {
				$rows[0]->parent = 0;
			}
			
			// Build Tree
			$tree = AceShop::get('base')->buildIndentTree(intval($rows[0]->parent), '', array(), $children);
			
			foreach ($tree as $item){
				$options[] = array('path' => $item->id, 'name' => $item->name);
			}

            return JHTML::_('select.genericlist', $options, $this->name, 'class="inputbox"', 'path', 'name', $this->value, $this->name);
        }
    }
}