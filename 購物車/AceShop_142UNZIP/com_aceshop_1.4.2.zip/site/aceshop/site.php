<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::get('base')->plgEnabled('system', 'legacy')) {
    return JError::raiseWarning(404, JText::_('COM_ACESHOP_LEGACY_PLUGIN'));
}

$view = JRequest::getCmd('view');
$route = JRequest::getString('route');

if (empty($route)) {
    $_route = AceShop::get('router')->getRoute($view);
	
	JRequest::setVar('route', $_route);
}

$replace_output = array(
'$.' => 'jQuery.',
'$(' => 'jQuery(',
'<div class="breadcrumb">' => '<div class="breadcrumb" style="display: none;">',
'<div id="container">' => '<div id="container_oc">',
'"header"' => '"header_oc"',
'"content"' => '"content_oc"',
'class="box"' => 'class="box_oc"',
'class="button_oc"' => 'class="'.AceShop::getButton().'"',
'class="button"' => 'class="'.AceShop::getButton().'"',
'id="button"' => 'id="button_oc"',
'"search"' => '"search_oc"',
'"menu"' => '"menu_oc"',
'"breadcrumb"' => '"breadcrumb_oc"',
//'"logo"' => '"logo_oc"',
'"banner"' => '"banner_oc"',
'"footer"' => '"footer_oc"',
'#header' => '#header_oc',
'#content' => '#content_oc',
'.button ' => '.button_oc ',
'.button:' => '.button_oc:',
'#content' => '#content_oc',
'#container' => '#container_oc',
'#menu' => '#menu_oc',
'<img src="catalog/' => '<img src="components/com_aceshop/opencart/catalog/',
'<img src="image/' => '<img src="components/com_aceshop/opencart/image/',
/*'<h1><?php echo $heading_title; ?></h1>' => '<div class="box">
  <div class="box-heading"><?php echo $heading_title; ?></div>
  <div class="box-content">',
'<?php echo $content_bottom; ?>' => '  </div>
  </div>',*/
"index.php?route=common/filemanager" => "index.php?option=com_aceshop&tmpl=component&format=raw&route=common/filemanager",
".load('index.php?route=" => ".load('index.php?option=com_aceshop&format=raw&tmpl=component&route=",
": 'index.php?route=" => ": 'index.php?option=com_aceshop&format=raw&tmpl=component&route=",
"index.php?route=" => "index.php?option=com_aceshop".AceShop::get('router')->getItemid('home', 0, true)."&route="
);

ob_start();

require_once(JPATH_ACESHOP_OC.'/index.php');

$output = ob_get_contents();

ob_end_clean();

foreach($replace_output as $key => $value){
	$output = str_replace($key, $value, $output);
}

echo $output;

$is_ajax = false;

if (AceShop::get('base')->isAjax()) {
    $is_ajax = true;
}
else if (substr($output, 0, 11) == '{"success":' ||
    substr($output, 0, 12) == '{"redirect":' ||
    substr($output, 0, 9) == '{"error":' ||
    substr($output, 0, 11) == '{"warning":' ||
    substr($output, 0, 15) == '{"information":' ||
    substr($output, 0, 13) == '{"attention":') {
    $is_ajax = true;
    JRequest::setVar('format', 'raw');
    JRequest::setVar('tmpl', 'component');
}

if ($is_ajax == true) {
	jexit();
}

AceShop::get('base')->loadPathway();