<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

class AceShopDb {

    public function getRecord($id, $type = 'product') {
        $id = intval($id);

        if (empty($id)) {
            return '';
        }

        static $rows = array('product' => array(), 'category' => array(), 'manufacturer' => array(), 'information' => array());

        if (!isset($rows[$type][$id])) {
            $rows[$type][$id] = AceShop::get('opencart')->loadModelFunction('catalog/'.$type.'/get'.ucfirst($type), $id);
        }

        return $rows[$type][$id];
   	}

	public function getRecordName($id, $type = 'product') {
        $field = 'name';
        if ($type == 'information') {
            $field = 'title';
        }

        $record = $this->getRecord($id, $type);

        if (!empty($record) && is_array($record)) {
            return $record[$field];
        }
        else {
            return '';
        }
	}

	public function getRecordAlias($id, $type = 'product') {
        $id = intval($id);

        if (empty($id)) {
            return '';
        }

        static $rows = array('product' => array(), 'category' => array(), 'manufacturer' => array(), 'information' => array());

        if (!isset($rows[$type][$id])) {
            $query = $type.'_id='.$id;

            $_name = $this->run("SELECT keyword FROM #__aceshop_url_alias WHERE query = '{$query}'", 'loadResult');

            if (empty($_name)) {
                $_name = $this->getRecordName($id, $type);
            }

            $rows[$type][$id] = JFilterOutput::stringURLSafe(html_entity_decode($_name, ENT_QUOTES, 'UTF-8'));
        }

        return $rows[$type][$id];
	}

    public function getProductCategoryId($id) {
        $id = intval($id);

        static $cache = array();

        if (!isset($cache[$id])) {
            $cache[$id] = $this->run("SELECT category_id FROM #__aceshop_product_to_category WHERE product_id = ". (int) $id." LIMIT 1", 'loadResult');
        }

        return $cache[$id];
    }

    public function getParentCategoryId($id) {
        $id = intval($id);

        static $cache = array();

        if (!isset($cache[$id])) {
            $cache[$id] = $this->run("SELECT parent_id FROM #__aceshop_category WHERE category_id = ". (int) $id." LIMIT 1", 'loadResult');
        }

        return $cache[$id];
    }

    public function getCategoryNames($id) {
        $id = intval($id);

        static $cache = array();

        if (!isset($cache[$id])) {
            $p_id = $id;
            $categories = array();

            $config = AceShop::get('opencart')->get('config');
            if (is_object($config)) {
                $lang = ' AND cd.language_id = '.$config->get('config_language_id');
            }
            else {
                $lang = '';
            }

            while ($p_id > 0) {
                $row = $this->run("SELECT cd.name, c.parent_id, c.category_id AS id "
                    ."FROM #__aceshop_category AS c, #__aceshop_category_description AS cd "
                    ."WHERE c.category_id = cd.category_id "
                    ."AND c.category_id = {$p_id} "
                    ."{$lang}", 'loadObject');

                array_unshift($categories, $row);
                $p_id = $row->parent_id;
            }

            $cache[$id] = $categories;
        }

        return $cache[$id];
    }

    public function getLanguageList() {
        static $cache;

        if (!isset($cache)) {
            $cache = $this->run("SELECT * FROM #__aceshop_language", 'loadAssocList');
        }

        return $cache;
    }

    public function getLanguage($var, $is_code = false) {
        $lang = null;
        $rows = $this->getLanguageList();

        foreach ($rows as $row) {
            if ($is_code == true) {
                $v = 'code';
            }
            else {
                $v = 'language_id';
            }

            if ($row[$v] == $var) {
                $lang = $row;
                break;
            }
        }

        return $lang;
    }

    public function run($q, $f = 'loadAssoc', $p = null) {
   		$db = $this->getDbo();

   		switch($f) {
   			case 'escape':
   				$result = $db->getEscaped($q);
   				break;
   			case 'Quote':
   			case 'getEscaped':
   				$result = $db->$f($q);
   				break;
   			case 'getLastId':
   				$result = $db->insertid();
   				break;
   			default:
   				$db->setQuery($q);

   				if (empty($p)) {
   					$result = $db->$f();
   				}
   				else {
   					$result = $db->$f($p);
   				}
   				break;
   		}

   		return $result;
   	}

    public function getDbo() {
        static $db;

        if (!isset($db)) {
            $config = AceShop::getClass('base')->getConfig();

            if ($config->get('multistore', 0) == 0) {
                $db = JFactory::getDbo();
            }
            else {
                jimport('joomla.database.database');

                $j_config = self::getJConfig();

                $options = array();
                $options['website']   	= AceShop::get()->getFullUrl();
                $options['driver']   	= $config->get('multistore_driver', $j_config->dbtype);
                $options['host']     	= $config->get('multistore_host', $j_config->host);
                $options['user']     	= $config->get('multistore_user', $j_config->user);
                $options['password'] 	= $config->get('multistore_password', $j_config->password);
                $options['database'] 	= $config->get('multistore_database', $j_config->db);
                $options['prefix']   	= $config->get('multistore_prefix', $j_config->dbprefix);

                $db	= JDatabase::getInstance($options);
            }
        }

        return $db;
    }

    public function getDbAttribs($name) {
        static $db;

        if (!isset($db)) {
            $db = array();

            $config = AceShop::get()->getConfig();
            $j_config = AceShop::get()->getJConfig();

            if ($config->get('multistore', 0) == 0) {
                $db['driver']   	= $j_config->dbtype;
                $db['host']     	= $j_config->host;
                $db['user']     	= $j_config->user;
                $db['password'] 	= $j_config->password;
                $db['database'] 	= $j_config->db;
                $db['prefix']   	= $j_config->dbprefix;
            }
            else {
                $db['driver']   	= $config->get('multistore_driver', $j_config->dbtype);
                $db['host']     	= $config->get('multistore_host', $j_config->host);
                $db['user']     	= $config->get('multistore_user', $j_config->user);
                $db['password'] 	= $config->get('multistore_password', $j_config->password);
                $db['database'] 	= $config->get('multistore_database', $j_config->db);
                $db['prefix']   	= $config->get('multistore_prefix', $j_config->dbprefix);
            }
        }

        return $db[$name];
    }
}