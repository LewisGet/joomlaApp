<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

class AceShopAcesef {

    public function get($var, $type, $id, $lang_id) {
        static $cache = array();

        if (!isset($cache[$type][$id][$lang_id])) {
            $field = $type.'_id';
            if ($type == 'category') {
                $field = 'path';
            }

            $lang = '';
            if (count(AceShop::get('db')->getLanguageList()) > 1) {
                require_once(JPATH_ADMINISTRATOR.'/components/com_acesef/library/factory.php');

                $_l = AceShop::get('db')->getLanguage($lang_id);

                if ((AcesefFactory::getConfig()->joomfish_main_lang != $_l['code']) || (AcesefFactory::getConfig()->joomfish_main_lang_del == 0)) {
                    $lang = '&lang='.$_l['code'];
                }
            }

            $route = str_replace('/', '%2F', AceShop::get('router')->getRoute($type, false));

            $url_1 = "index.php?option=com_aceshop";
            $url_2 = "{$field}={$id}{$lang}&route={$route}";

            $cache[$type][$id][$lang_id] = AceShop::get('db')->run("SELECT u.id AS url_id, u.url_sef, m.id AS meta_id, m.title, m.description, m.keywords, m.lang, m.robots, m.googlebot, m.canonical "
                                    ."FROM #__acesef_urls AS u "
                                    ."LEFT JOIN #__acesef_metadata AS m ON u.url_sef = m.url_sef "
                                    ."WHERE u.url_real LIKE '{$url_1}%' AND u.url_real LIKE '%{$url_2}%' "
                                    ."ORDER BY u.used, u.cdate "
                                    ."LIMIT 1");

            if (empty($cache[$type][$id][$lang_id])) {
                $cache[$type][$id][$lang_id] = array();
                $cache[$type][$id][$lang_id]['url_id'] = 0;
                $cache[$type][$id][$lang_id]['url_sef'] = '';
                $cache[$type][$id][$lang_id]['meta_id'] = 0;
                $cache[$type][$id][$lang_id]['title'] = '';
                $cache[$type][$id][$lang_id]['description'] = '';
                $cache[$type][$id][$lang_id]['keywords'] = '';
                $cache[$type][$id][$lang_id]['lang'] = '';
                $cache[$type][$id][$lang_id]['robots'] = '';
                $cache[$type][$id][$lang_id]['googlebot'] = '';
                $cache[$type][$id][$lang_id]['canonical'] = '';
            }
        }

        return $cache[$type][$id][$lang_id][$var];
    }

    public function store($posts, $rec_id = 0) {
        if (!AceShop::get('base')->isAcesefInstalled() || empty($posts)) {
            return;
        }

        $db = AceShop::get('db');

        foreach ($posts as $lang_id => $post) {
            if (empty($post['url_sef'])) {
                continue;
            }

            if ($post['url_id'] == 0) {
                $this->_saveNewSefUrl($post, $lang_id, $rec_id);
            }
            else {
                $db->run("UPDATE #__acesef_urls SET url_sef = '{$post['url_sef']}' WHERE id = {$post['url_id']}", 'query');
            }

            if ($post['meta_id'] == 0) {
                $db->run("INSERT IGNORE INTO #__acesef_metadata (url_sef, title, description, keywords, lang, robots, googlebot, canonical) ".
                                    "VALUES('{$post['url_sef']}', ".$db->run($post['title'], 'Quote').", ".$db->run($post['description'], 'Quote').", ".$db->run($post['keywords'], 'Quote').", '{$post['lang']}', '{$post['robots']}', '{$post['googlebot']}', '{$post['canonical']}')", 'query');
            }
            else {
                $db->run("UPDATE #__acesef_metadata SET title = ".$db->run($post['title'], 'Quote').", description = ".$db->run($post['description'], 'Quote').", keywords = ".$db->run($post['keywords'], 'Quote').", lang = '{$post['lang']}', robots = '{$post['robots']}', googlebot = '{$post['googlebot']}', canonical = '{$post['canonical']}' WHERE id = {$post['meta_id']}", 'query');
            }
        }
    }

    function _saveNewSefUrl($post, $lang_id, $rec_id) {
        $db = AceShop::get('db');

        require_once(JPATH_ADMINISTRATOR.'/components/com_acesef/library/loader.php');

        $component = 'com_aceshop';
        $route = end(explode('=', $post['route_var']));
        $record_id = end(explode('=', $post['route_id']));

        if ($record_id == 0) {
            $record_id = $rec_id;

            $_a = explode('=', $post['route_id']);
            $post['route_id'] = $_a[0].'='.$record_id;
        }

        $lang = '';
        if (count($db->getLanguageList()) > 1) {
            $_l = $db->getLanguage($lang_id);

            if ((AcesefFactory::getConfig()->joomfish_main_lang != $_l['code']) || (AcesefFactory::getConfig()->joomfish_main_lang_del == 0)) {
                $lang = '&lang='.$_l['code'];
            }
        }

        $sef_url = $post['url_sef'];
        $real_url = 'index.php?option=com_aceshop'.AceShop::get('router')->getItemid(AceShop::get('router')->getView($route), $record_id, true).$lang.'&'.$post['route_id'].'&'.$post['route_var'];

        $uri = new JURI($real_url);
        $acesef_ext = AcesefFactory::getExtension($component);
        $ext_params = AcesefFactory::getCache()->getExtensionParams($component);

        // Override menu item id if set to
        if ($ext_params->get('override', '1') != '1' && $ext_params->get('override_id', '') != '') {
            $uri->setVar('Itemid', $ext_params->get('override_id'));
        }

        // Make changes on URI before building route
        $acesef_ext->beforeBuild($uri);

        // Category status
        $real_url = AcesefURI::sortURItoString($uri);
        $acesef_ext->catParam($uri->getQuery(true), $real_url);

        // Check if we should track the URL source
        $source = "";

        // Cat statuses
        $tags = $this->_paramValue('tags', $component, $ext_params);
        $ilinks = $this->_paramValue('ilinks', $component, $ext_params);
        $bookmarks = $this->_paramValue('bookmarks', $component, $ext_params);

        // Params
        $params = "custom=0";
        $params .= "\npublished=1";
        $params .= "\nlocked=0";
        $params .= "\nblocked=0";
        $params .= "\ntrashed=0";
        $params .= "\nnotfound=0";
        $params .= "\ntags={$tags}";
        $params .= "\nilinks={$ilinks}";
        $params .= "\nbookmarks={$bookmarks}";
        $params .= "\nvisited=0";
        $params .= "\nnotes=";

        // Finally, save record in DB
        $values = "(".$db->run($sef_url, 'Quote').", ".$db->run($real_url, 'Quote').", '0', '".date('Y-m-d H:i:s')."', '{$source}', '{$params}')";

        $db->run("INSERT IGNORE INTO #__acesef_urls (url_sef, url_real, used, cdate, source, params) VALUES {$values}", 'query');
    }

    function _paramValue($section, $component, $params) {
        $AcesefConfig = AcesefFactory::getConfig();

   		$_components = $section."_components";
   		$_cats = $section."_cats";
   		$_enable_cats = $section."_enable_cats";
   		$_in_cats = $section."_in_cats";
   		$cat = AcesefUtility::get('category.param');

   		if (!in_array($component, $AcesefConfig->$_components)) {
   			return 0;
   		}

   		if (AcesefUtility::getConfigState($params, $_enable_cats) && ($cat[$_cats.'_status'] == 0 && $cat['_flag'] == 1)) {
   			return 0;
   		}

   		if (!AcesefUtility::getConfigState($params, $_in_cats) && $cat['_is_cat'] == 1) {
   			return 0;
   		}

   		return 1;
   	}
}