<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

class AceShopBase {

	private static $data = array();
	
	public function get($name, $default = null) {
        if (!is_array(self::$data) || !isset(self::$data[$name])) {
            return $default;
        }
        
        return self::$data[$name];
    }
    
    public function set($name, $value) {
        if (!is_array(self::$data)) {
            self::$data = array();
        }
        
        $previous = self::get($name);
		
        self::$data[$name] = $value;
        
        return $previous;
    }
	
	public function getAceshopVersion() {
        static $version;

        if (!isset($version)) {
            $version = $this->getXmlText(JPATH_ACESHOP_ADMIN.'/aceshop.xml', 'version');
        }

		return $version;
	}

	public function getOcVersion() {
        $version = '1.5.1.3';

		return $version;
	}
	
	public function is15() {
		static $status;
		
		if (!isset($status)) {
			if (version_compare(JVERSION,'1.6.0','ge')) {
				$status = false;
			}
			else {
				$status = true;
			}
		}
		
		return $status;
	}

	public function getConfig() {
		static $config;
		
		if (!isset($config)) {
            jimport('joomla.application.component.helper');
            $config = JComponentHelper::getParams('com_aceshop');
		}
		
		return $config;
	}

	public function getJConfig() {
		static $config;

		if (!isset($config)) {
			require_once(JPATH_SITE.'/configuration.php');

			$config = new JConfig();
		}

		return $config;
	}

    public function route($url) {
        return AceShop::get('router')->route($url);
    }
	
	public function editor() {
		static $editor;
		
		if (!isset($editor)) {
			$editor =& JFactory::getEditor();
		}
		
		return $editor;
	}

	public function getFullUrl($path_only = false) {
        $url = JURI::root($path_only);

        if (substr($url, -1) != '/') {
            $url .= '/';
        }
		
		return $url;
	}

	public function getSubdomain() {
		static $sub_domain;
		
		if (!isset($sub_domain)) {
            $sub_domain = $this->getFullUrl(true);
		}
		
		return $sub_domain;
	}
	
	public function getXmlText($file, $variable) {
        jimport('joomla.filesystem.file');
        
		$value = '';
		
		if (JFile::exists($file)) {
			if (self::is15()) {
				$xml =& JFactory::getXMLParser('Simple');
				if ($xml->loadFile($file)) {
					$root =& $xml->document;
					$element =& $root->getElementByPath($variable);
					$value = $element ? $element->data() : '';
				}
			}
			else {
				$xml = JFactory::getXML($file);
				$value = $xml->$variable;
			}
		}
		
		return $value;
    }

    public function trigger($function, $args = array(), $folder = 'aceshop') {
        jimport('joomla.plugin.helper');

        JPluginHelper::importPlugin($folder);
        $dispatcher =& JDispatcher::getInstance();
        $result = $dispatcher->trigger($function, $args);

        return $result;
    }

    public function triggerContentPlg($text) {
        $config = $this->getConfig();

        if ($config->get('trigger_content_plg', 0) == 0) {
            return $text;
        }

        $item = new stdClass();
        $item->id = null;
        $item->rating = null;
        $item->rating_count = null;
        $item->text = $text;

        $params = $config;
        $limitstart = JRequest::getInt('limitstart');

        if ($this->is15()) {
            $this->trigger('onPrepareContent', array(&$item, &$params, $limitstart), 'content');
        }
        else {
            $this->trigger('onContentPrepare', array('com_aceshop.product', &$item, &$params, $limitstart), 'content');
        }

        return $item->text;
    }

    public function loadPathway() {
        $view = JRequest::getWord('view');
        if (!empty($view)) {
            return;
        }

        $route = JRequest::getString('route');
        if (empty($route)) {
            return;
        }

        $a_menu = JSite::getMenu()->getActive();
        $pathway = JFactory::getApplication()->getPathway();

        switch($route) {
            case 'product/product':
                $c_id = JRequest::getCmd('path');
                $p_id = JRequest::getInt('product_id');

                if (is_object($a_menu) && $a_menu->query['view'] == 'product' && $a_menu->query['product_id'] == $p_id){
                    break;
                }

                if (empty($c_id)) {
                    $c_id = AceShop::get('db')->getProductCategoryId($p_id);
                }

                $cats = AceShop::get('db')->getCategoryNames($c_id);
                if (!empty($cats)) {
                    foreach ($cats as $cat) {
                        if (is_object($a_menu) && $a_menu->query['view'] == 'category' && $a_menu->query['path'] == $cat->id){
                            continue;
                        }

                        $pathway->addItem($cat->name, AceShop::get('router')->route('index.php?route=product/category&path='.$cat->id));
                    }
                }

                $pathway->addItem(AceShop::get('db')->getRecordName($p_id));

                break;
            case 'product/category':
                $c_id = JRequest::getCmd('path');
                if (empty($c_id)) {
                    break;
                }

                if (is_object($a_menu) && $a_menu->query['view'] == 'category' && $a_menu->query['path'] == $c_id){
                    break;
                }

                if (strpos($c_id, '_')) {
                    $c_id = end(explode('_', $c_id));
                }

                $cats = AceShop::get('db')->getCategoryNames($c_id);

                if (!empty($cats)) {
                    foreach ($cats as $cat) {
                        if (is_object($a_menu) && $a_menu->query['view'] == 'category' && $a_menu->query['path'] == $cat->id){
                            continue;
                        }

                        if ($cat->id == $c_id) {
                            $pathway->addItem($cat->name);
                        }
                        else {
                            $pathway->addItem($cat->name, AceShop::get('router')->route('index.php?route=product/category&path='.$cat->id));
                        }
                    }
                }

                break;
            case 'product/manufacturer':
                $pathway->addItem('Brand');

                break;
            case 'product/manufacturer/product':
                $m_id = JRequest::getInt('manufacturer_id');
                if (empty($m_id)) {
                    break;
                }

                if (is_object($a_menu) && $a_menu->query['view'] == 'manufacturer' && $a_menu->query['manufacturer_id'] == $m_id){
                    break;
                }

                $pathway->addItem('Brand', AceShop::get('router')->route('index.php?route=product/manufacturer'));
                $pathway->addItem(AceShop::get('db')->getRecordName($m_id, 'manufacturer'));

                break;
            case 'information/information':
                $i_id = JRequest::getInt('information_id');
                if (empty($i_id)) {
                    break;
                }

                if (is_object($a_menu) && $a_menu->query['view'] == 'information' && $a_menu->query['information_id'] == $i_id){
                    break;
                }

                $pathway->addItem(AceShop::get('db')->getRecordName($i_id, 'information'));

                break;
            default:
                if ($route == 'common/home') {
                    break;
                }

                if ($route == 'product/search') {
                    $route = 'search';
                }

                if (is_object($a_menu) && $a_menu->query['view'] == 'cart') {
                    break;
                }

                $names = explode('/', $route);
                if (isset($names[0]) && isset($names[1]) && ($names[0] == $names[1])) {
                    unset($names[1]);
                }

                foreach ($names as $name) {
                    $name = ucwords(strtolower($name));

                    if ($name == 'Insert') {
                        continue;
                    }

                    $pathway->addItem($name);
                }

                break;
        }
    }
	
	public function addHeader($path, $css = true, $only_ie = false) {
		static $headers = array();
		
		if (isset($headers[$path])) {
			return;
		}
		
		jimport('joomla.environment.browser');
		$browser = JBrowser::getInstance();

		if ($only_ie == true || strpos($path, 'ie6.css') || strpos($path, 'ie7.css') || strpos($path, 'ie8.css')) {
            if ($browser->getBrowser() != 'msie') {
                return;
            }

            if (strpos($path, 'ie6.css') && ($browser->getMajor() != '6')) {
                return;
            }

            if (strpos($path, 'ie7.css') && ($browser->getMajor() != '7')) {
                return;
            }

            if (strpos($path, 'ie8.css') && ($browser->getMajor() != '8')) {
                return;
            }
		}
		
		global $vqmod;
		
		if (empty($vqmod)) {
			require_once(JPATH_ACESHOP_OC.'/vqmod/vqmod.php');
			$vqmod = new VQMod();
		}
		
		$doc = JFactory::getDocument();
		
		$f = 'addStylesheet';
		if ($css == false) {
			$f = 'addScript';
		}
		
		$doc->$f(self::clearPath($vqmod->modCheck($path)));
		
		$headers[$path] = 'added';
	}
	
	public function clearPath($path) {
		$clear_path = str_replace(JPATH_ROOT, $this->getSubdomain(), $path);
		$clear_path = str_replace('/\\', '/', $clear_path);
		$clear_path = str_replace('\\', '/', $clear_path);
		$clear_path = str_replace('//', '/', $clear_path);

		return $clear_path;
	}

    public function buildIndentTree($id, $indent, $list, &$children) {
        if (@$children[$id]) {
            foreach ($children[$id] as $ch) {
                $id = $ch->id;

                $pre 	= '|_&nbsp;';
                $spacer = '.&nbsp;&nbsp;&nbsp;';

                if ($ch->parent == 0) {
                    $txt = $ch->name;
                } else {
                    $txt = $pre . $ch->name;
                }

                $list[$id] = $ch;
                $list[$id]->name = "$indent$txt";
                $list[$id]->children = count(@$children[$id]);
                $list = self::buildIndentTree($id, $indent . $spacer, $list, $children);
            }
        }

        return $list;
    }

    public function getStoreId() {
        static $store_id;

   		if (!isset($store_id)) {
   			$db = AceShop::get('db')->getDbo();

   			if (isset($_SERVER['HTTPS']) && (($_SERVER['HTTPS'] == 'on') || ($_SERVER['HTTPS'] == '1'))) {
   				$field = 'ssl';
   			}
   			else {
   				$field = 'url';
   			}

   			$db->setQuery("SELECT store_id FROM #__aceshop_store WHERE REPLACE(`{$field}`, 'www.', '') = ".$db->Quote(str_replace('www.', '', $this->getFullUrl())));
            $store_id = $db->loadResult();

   			if (empty($store_id)) {
                $store_id = 0;
   			}
   		}

   		return $store_id;
   	}

    public function plgEnabled($folder, $name) {
        static $status = array();

        if (!isset($status[$folder][$name])) {
            jimport('joomla.plugin.helper');
            $status[$folder][$name] = JPluginHelper::isEnabled($folder, $name);
        }

        return $status[$folder][$name];
    }

    public function isAdmin($type = 'aceshop') {
        static $is_admin = array();

        if (!isset($is_admin[$type])) {
            if ($type == 'aceshop') {
                $state = (JRequest::getCmd('view') == 'admin');
            }
            else {
                $state = JFactory::getApplication()->isAdmin();
            }

            if ($state) {
                $is_admin[$type] = true;
            }
            else {
                $is_admin[$type] = false;
            }
        }

        return $is_admin[$type];
   	}

    public function isExternal() {
        static $is_external;

        if (!isset($is_external)) {
            $is_external = false;

            $view = JRequest::getString('view');

            if (substr($view, 0, 7) == 'install' || substr($view, 0, 8) == 'external') {
                $is_external = true;
            }
        }

        return $is_external;
   	}

    public function isAjax() {
        $is_ajax = false;

        $tmpl = JRequest::getWord('tmpl');
        $format = JRequest::getWord('format');

        if ($tmpl == 'component' || $format == 'raw') {
            $is_ajax = true;
        }

        return $is_ajax;
    }

    public function isAcesefInstalled() {
        static $status;

        if (!isset($status)) {
            $status = true;

            $file = JPATH_ADMINISTRATOR.'/components/com_acesef/library/factory.php';
            if (!file_exists($file)) {
                $status = false;

                return $status;
            }

            require_once($file);

            if (AcesefFactory::getConfig()->mode == 0) {
                $status = false;
            }
        }

        return $status;
    }

    public function isSh404sefInstalled() {
        static $status;

        if (!isset($status)) {
            $status = true;

            $file = JPATH_ADMINISTRATOR.'/components/com_sh404sef/sh404sef.class.php';
            if (!file_exists($file)) {
                $status = false;

                return $status;
            }

            require_once($file);

            if (Sh404sefFactory::getConfig()->Enabled == 0) {
                $status = false;
            }
        }

        return $status;
    }

    public function isJoomsefInstalled() {
        static $status;

        if (!isset($status)) {
            $status = true;

            $file = JPATH_ADMINISTRATOR.'/components/com_sh404sef/classes/config.php';
            if (!file_exists($file)) {
                $status = false;

                return $status;
            }

            require_once($file);

            if (!SEFConfig::getConfig()->enabled) {
                $status = false;
            }
        }

        return $status;
    }

    //------------------------------------------
    //------------------------------------------
    public function db($q, $f = 'loadAssoc', $p = null) {
   		return AceShop::get('db')->run($q, $f, $p);
   	}

    public function getDbo() {
       return AceShop::get('db')->getDbo();
    }

    public function getDbAttribs($name) {
       return AceShop::get('db')->getDbAttribs($name);
    }

    public function getRecordName($id, $type = 'product') {
       return AceShop::get('db')->getRecordName($id, $type);
    }

    public function getProductCategory($id) {
       return AceShop::get('db')->getProductCategory($id);
    }

    public function getCategoryNames($id) {
       return AceShop::get('db')->getCategoryNames($id);
    }
}