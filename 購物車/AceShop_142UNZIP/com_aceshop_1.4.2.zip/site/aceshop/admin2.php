<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

// Access check.
if (!AceShop::get('base')->is15() && !JFactory::getUser()->authorise('core.manage', 'com_aceshop')) {
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

if (AceShop::get('base')->plgEnabled('system', 'legacy')) {
    return JError::raiseWarning(404, JText::_('COM_ACESHOP_LEGACY_PLUGIN'));
}

JRequest::setVar('view', 'admin');

if (isset($_GET['token'])) {
	$_SESSION['token'] = $_GET['token'];
}

if (isset($_SESSION['token']) && !isset($_GET['token'])) {
	$_GET['token'] = $_SESSION['token'];
}

$replace_output = array(
"index.php?route=common/filemanager" => "index.php?option=com_aceshop&view=admin&tmpl=component&format=raw&route=common/filemanager",
"index.php?route=" => "index.php?option=com_aceshop&view=admin&route=",
"index.php?token=" => "index.php?option=com_aceshop&view=admin&token=",
'admin/view' => 'components/com_aceshop/opencart/admin/view',
'view/image' => 'components/com_aceshop/opencart/admin/view/image',
'view/javascript/jquery/' => AceShop::get('base')->is15() ? 'plugins/system/aceshopjquery/' : 'plugins/system/aceshopjquery/aceshopjquery/',
'view/javascript' => 'components/com_aceshop/opencart/admin/view/javascript',
'$.' => 'jQuery.',
'$(' => 'jQuery(',
'<div id="container">' => '<div id="container_oc">',
'"header"' => '"header_oc"',
'"content"' => '"content_oc"',
'class="button"' => 'class="button_oc"',
'id="button"' => 'id="button_oc"',
'"search"' => '"search_oc"',
'"menu"' => '"menu_oc"',
'"breadcrumb"' => '"breadcrumb_oc"',
//'"logo"' => '"logo_oc"',
'"banner"' => '"banner_oc"',
'"footer"' => '"footer_oc"',
'#header' => '#header_oc',
'#content' => '#content_oc',
'.button ' => '.button_oc ',
'.button:' => '.button_oc:',
'#content' => '#content_oc',
'#container' => '#container_oc',
'#menu' => '#menu_oc',
'<select name="filter_category" style="width: 18em;" >' => '<select name="filter_category" style="width: 120px;" >',
'<input type="text" name="filter_model" value="" />' => '<input type="text" name="filter_model" value="" style="width: 60px;" />',
'<input type="text" name="filter_price" value="" size="8"/>' => '<input type="text" name="filter_price" value="" size="8" style="width: 50px;" />',
'<input type="text" name="filter_quantity" value="" style="text-align: right;" />' => '<input type="text" name="filter_quantity" value="" style="text-align: right; width: 40px;" />',
"load('index.php?option=com_aceshop&" => "load('index.php?option=com_aceshop&format=raw&tmpl=component&",
": 'index.php?option=com_aceshop&" => ": 'index.php?option=com_aceshop&format=raw&tmpl=component&",
"index.php?option=com_aceshop&route=sale/order/invoice&" => "index.php?option=com_aceshop&route=sale/order/invoice&format=raw&tmpl=component&",
'<link rel="stylesheet" type="text/css" href="index.php?option=com_aceshop&' => '<link rel="stylesheet" type="text/css" href="index.php?option=com_aceshop&format=raw&tmpl=component&',
'index.php?option=com_aceshop&route=tool/backup/backup&' => 'index.php?option=com_aceshop&format=raw&tmpl=component&route=tool/backup/backup&'
);

ob_start();

require_once(JPATH_ACESHOP_OC.'/admin/index.php');

$output = ob_get_contents();

ob_end_clean();

foreach($replace_output as $key => $value){
	$output = str_replace($key, $value, $output);
}

echo $output;

$is_ajax = false;

if (AceShop::get('base')->isAjax()) {
    $is_ajax = true;
}
else if (substr($output, 0, 11) == '{"success":' ||
    substr($output, 0, 12) == '{"redirect":' ||
    substr($output, 0, 9) == '{"error":' ||
    substr($output, 0, 11) == '{"warning":' ||
    substr($output, 0, 15) == '{"information":' ||
    substr($output, 0, 13) == '{"attention":') {
    $is_ajax = true;
    JRequest::setVar('format', 'raw');
    JRequest::setVar('tmpl', 'component');
}

if ($is_ajax == true) {
	jexit();
}