<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

jimport("joomla.user.user");
jimport("joomla.user.helper");
require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

class AceShopUser {

    public function createOAccountFromJ($user, $is_login = false) {
        $db = AceShop::get('db');
        $base = AceShop::get('base');

        $name = explode(' ', $user['name']);
        $fname = $db->run($name[0], 'escape');
        $lname = $db->run(self::getLastName($name), 'escape');
        $username = $db->run($user['username'], 'escape');
        $email = $db->run($user['email'], 'escape');

        if (!empty($user['password'])) {
            $password = $db->run($this->getCleanPassword($user['password']), 'escape');
        }
        else {
            $password = $db->run(md5($user['password_clear']), 'escape');
        }

        $status = empty($user['block']) ? 1 : 0;

        $customer_id = $this->getOCustomerIdFromJUser($user['id'], $email);
        $customer_exists = $this->getOCustomerById($customer_id);

        if (!empty($customer_exists) && $is_login == true) {
            return true;
        }

        if ($base->isAdmin('joomla')) {
            $user_id = $this->getOUserIdFromJUser($user['id'], $username, $email);
            $user_exists = $this->getOUserById($user_id);

            if (!empty($user_exists) && $is_login == true) {
                return true;
            }
        }

        if (AceShop::get('base')->is15()) {
            $customer_group_id = $this->getOCustomerGroupIdByJGroup($user['gid']);
        }
        else {
            $_id = null;

            foreach ($user['groups'] as $group_id) {
                $_id = $this->getOCustomerGroupIdByJGroup($group_id);

                if (!empty($_id)) {
                    $customer_group_id = $_id;
                    break;
                }
            }
        }

        if (empty($customer_group_id)) {
            $customer_group_id = 8;
        }

        if (!empty($customer_exists)) {
            $db->run("UPDATE #__aceshop_customer SET firstname = '".$fname."', lastname = '".$lname."', email = '".$email."', password = '".$password."', customer_group_id = '".$customer_group_id."', status = ".$status.", approved = ".$status." WHERE customer_id = '".$customer_id."'", 'query');
        }
        else {
            $db->run("INSERT INTO #__aceshop_customer SET firstname = '".$fname."', lastname = '".$lname."', email = '".$email."', telephone = '', fax = '', password = '".$password."', newsletter = '0', customer_group_id = '".$customer_group_id."', status = '".$status."', approved = '".$status."', date_added = NOW()", 'query');
            $customer_id = $db->run('', 'getLastId');

            $db->run("INSERT IGNORE INTO #__aceshop_juser_ocustomer_map SET juser_id = '{$user['id']}', ocustomer_id = '".$customer_id."'", 'query');
        }

        if (!$base->isAdmin('joomla')) {
            return true;
        }

        if (AceShop::get('base')->is15()) {
            $user_group_id = $this->getOUserGroupIdByJGroup($user['gid']);
        }
        else {
            $_id = null;

            foreach ($user['groups'] as $group_id) {
                $_id = $this->getOUserGroupIdByJGroup($group_id);

                if (!empty($_id)) {
                    $user_group_id = $_id;
                    break;
                }
            }
        }

        if (empty($user_group_id)) {
            return true;
        }

        if (!empty($user_exists)){
            $db->run("UPDATE #__aceshop_user SET username = '".$username."', password = '".$password."', email = '".$email."', firstname = '".$fname."', lastname = '".$lname."', user_group_id = '".$user_group_id."' WHERE user_id = '".$user_id."'", 'query');
        }
        else {
            $db->run("INSERT INTO #__aceshop_user SET firstname = '".$fname."', lastname = '".$lname."', email = '".$email."', username = '".$username."', password = '".$password."', user_group_id = '".$user_group_id."', status = '".$status."', date_added = NOW()", 'query');
            $user_id = $db->run('', 'getLastId');

            $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$user['id']}', ouser_id = '".$user_id."'", 'query');
        }

        return true;
    }

    public function deleteOAccountFromJ($user) {
        $db = AceShop::get('db');

        $ouser_id = $this->getOUserIdFromJUser((int)$user['id']);
        if (!empty($ouser_id)) {
            $db->run("DELETE FROM #__aceshop_user WHERE user_id = '".(int)$ouser_id."'", 'query');
            $db->run("DELETE FROM #__aceshop_juser_ouser_map WHERE ouser_id = '".(int)$ouser_id."'", 'query');
        }

        $customer_id = $this->getOCustomerIdFromJUser((int)$user['id']);

        if (empty($customer_id)) {
            return true;
        }

        $db->run("DELETE FROM #__aceshop_juser_ocustomer_map WHERE ocustomer_id = '".(int)$customer_id."'", 'query');

        $db->run("DELETE FROM #__aceshop_customer WHERE customer_id = '".(int)$customer_id."'", 'query');
        $db->run("DELETE FROM #__aceshop_customer_reward WHERE customer_id = '" . (int)$customer_id . "'", 'query');
        $db->run("DELETE FROM #__aceshop_customer_transaction WHERE customer_id = '" . (int)$customer_id . "'", 'query');
        $db->run("DELETE FROM #__aceshop_customer_ip WHERE customer_id = '" . (int)$customer_id . "'", 'query');
        $db->run("DELETE FROM #__aceshop_address WHERE customer_id = '".(int)$customer_id."'", 'query');

        return true;
    }

    public function loginOFromJ($_class, $user = null, $is_backend = false) {
        $j_user = JFactory::getUser();

        if ($j_user->get('id') <= 0 || ($is_backend == false && isset($_class->session->data['customer_id'])) || ($is_backend == true && isset($_class->session->data['user_id']))) {
            return;
        }

        if (empty($user)) {
            $user = array();
            $user['id'] = $j_user->get('id');
            $user['name'] = $j_user->get('name');
            $user['username'] = $j_user->get('username');
            $user['email'] = $j_user->get('email');
            $user['password'] = $this->getCleanPassword($j_user->get('password'));
            $user['block'] = 0;

            $this->createOAccountFromJ($user, true);
        }

        if ($is_backend == true) {
            $_class->login($user['username'], $user['password']);
        }
        else {
            $_class->login($user['email'], $user['password']);
        }
    }

    public function getEncryptedOPassword($var, $password, $func_suffix = 'Email') {
        $function = 'getJUserBy'.$func_suffix;
        $j_user = $this->$function($var);

        if (empty($j_user)) {
            return;
        }

        $new_user = $j_user;
        $new_user['password'] = $this->getCleanPassword($new_user['password']);
        $this->createOAccountFromJ($new_user, true);

        $parts	= explode(':', $j_user['password']);
        $crypt	= $parts[0];
        $salt	= @$parts[1];
        $new_password = JUserHelper::getCryptedPassword($password, $salt);

        if ($crypt == $new_password) {
            return $new_password;
        }
        else {
            return $password;
        }
    }

    public function logoutOFromJ() {
        unset($_SESSION);
        return;

        $customer = AceShop::get('opencart')->get('customer');

        if (!is_object($customer)) {
            return;
        }

        $customer->logout();
    }

    public function redirectOAfterLoginFromJ($_class) {
        $token = md5(mt_rand());
        $_class->session->data['token'] = $token;
        $_class->request->set['token'] = $token;

        $option = JRequest::getCmd('option');
        if ($option != 'com_aceshop') {
            return;
        }

        $link = 'index.php?option=com_aceshop';

        $view = JRequest::getWord('view');
        if (!empty($view)) {
            $link .= '&view='.$view;
        }

        $Itemid = JRequest::getInt('Itemid');
        if (!empty($Itemid)) {
            $link .= '&Itemid='.$Itemid;
        }

        $route = JRequest::getString('route');
        if (!empty($route)) {
            $link .= '&route='.$route;
        }

        JFactory::getApplication()->redirect($link);
    }

    //-------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------

	public function createJUserFromO($data, $o_id) {
        $db = AceShop::get('db');

        if (empty($data['email'])) {
            return;
        }

		$ex_user = $this->getJUserByEmail($data['email']);
		
		if (is_array($ex_user) && !empty($ex_user['id'])) {
            $this->updateJUserFromO($ex_user['id'], $data, $o_id);

			return array($ex_user['id'], $this->encryptPassword($ex_user['password']), true);
		}

        if (!empty($data['username'])) {
            $ex_user = $this->getJUserByUsername($data['username']);

            if (is_array($ex_user) && !empty($ex_user['id'])) {
                $this->updateJUserFromO($ex_user['id'], $data, $o_id);

                return array($ex_user['id'], $this->encryptPassword($ex_user['password']), true);
            }
        }

        $post = array();
        $post['name'] = $data['firstname'] . " " . $data['lastname'];
        if (!empty($data['username'])) {
            $post['username'] = $data['username'];
        }
        else {
            $post['username'] = $data['email'];
        }
        $post['email'] = $data['email'];
        $post['password'] = JUserHelper::getCryptedPassword($db->run($data['password'], 'escape'));
        $post['block'] = $this->getBlockStatus($data);

        $j_user_group_id = $this->getJGroupId($data);
        if (AceShop::get('base')->is15()) {
            $post['gid'] = $j_user_group_id;
        }
        else {
            $post['groups'] = array($j_user_group_id);
        }

        $post['from_aceshop'] = 'yes';

        $j_user = new JUser();
        $j_user->setProperties($post);
        $j_user->save();

        $j_user_id = $j_user->get('id');

        if (isset($data['user_group_id'])) {
            $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$j_user_id}', ouser_id = '".$o_id."'", 'query');
        }
        else {
            $db->run("INSERT IGNORE INTO #__aceshop_juser_ocustomer_map SET juser_id = '{$j_user_id}', ocustomer_id = '".$o_id."'", 'query');
        }

		return array($j_user_id, self::encryptPassword($data['password']), false);
	}

    public function updateJUserFromO($j_user_id, $data, $o_id = 0) {
        $db = AceShop::get('db');
        $j_user = new JUser((int)$j_user_id);

        $post = array();

        $post['name'] = $data['firstname'] . " " . $data['lastname'];
        $post['email'] = $data['email'];
        $post['block'] = $this->getBlockStatus($data);
        $post['from_aceshop'] = 'yes';

        if (!empty($data['username'])) {
            $post['username'] = $data['username'];
        }
        else {
            $post['username'] = $j_user->get('username');
        }

        if (!empty($data['password'])) {
            $post['password'] = JUserHelper::getCryptedPassword(AceShop::get('db')->run($data['password'], 'escape'));
        }

        if (AceShop::get('base')->isAdmin('aceshop') || AceShop::get('base')->isAdmin('joomla')) {
            $j_user_group_id = $this->getJGroupId($data);

            if (AceShop::get('base')->is15()) {
                $ouser_id = $this->getOUserIdFromJUser($j_user_id, $data['username'], $data['email']);

                if (empty($ouser_id)) {
                    $post['gid'] = $j_user_group_id;
                }
            }
            else {
                $u_groups = JUserHelper::getUserGroups($j_user_id);

                if (!isset($u_groups[$j_user_group_id])) {
                    $u_groups[$j_user_group_id] = $j_user_group_id;
                }

                $post['groups'] = $u_groups;
            }
        }

        $j_user->setProperties($post);
        $j_user->save();

        if (isset($data['user_group_id'])) {
            $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$j_user_id}', ouser_id = '".$o_id."'", 'query');
        }
        else {
            $db->run("INSERT IGNORE INTO #__aceshop_juser_ocustomer_map SET juser_id = '{$j_user_id}', ocustomer_id = '".$o_id."'", 'query');
        }
    }

    public function updateJUserPasswordFromO($email, $password) {
        $encrypted_password = self::encryptPassword($password);

        AceShop::get('db')->run("UPDATE #__users SET password = '".$encrypted_password."' WHERE email = '".AceShop::get('db')->run($email, 'escape')."'", 'query');
    }

    public function approveJUserFromO($cust_id) {
        $user_id = $this->getJUserIdFromOCustomer($cust_id);

        if (empty($user_id)) {
            return;
        }

        $j_user = new JUser($user_id);
        $j_user->set('block', '0');
        $j_user->set('activation', '');
        $j_user->set('from_aceshop', 'yes');
        $j_user->save();
    }

	public function deleteJUserFromO($id, $is_user = false) {
        if ($is_user == false) {
            $user_id = $this->getJUserIdFromOCustomer($id);
        }
        else {
            $user_id = $this->getJUserIdFromOUser($id);

            $ocustomer_id = $this->getOCustomerIdFromJUser($user_id);
            if (!empty($ocustomer_id)) {
                return;
            }
        }

        if (empty($user_id)) {
            return;
        }

        $j_user = new JUser($user_id);
        $j_user->set('from_aceshop', 'yes');
        $j_user->delete();

        AceShop::get('db')->run("DELETE FROM #__aceshop_juser_ocustomer_map WHERE juser_id = {$user_id}", 'query');
	}
	
	public function loginJFromO($var, $password, $func_suffix = 'Email') {
        $db = AceShop::get('db');

		$user_id = JFactory::getUser()->get('id');
		if (!empty($user_id)) {
			return;
		}

        $function = 'getJUserBy'.$func_suffix;
        $j_user = $this->$function($var);

        if (empty($j_user)) {
            return;
        }

        if (!AceShop::get('base')->isAdmin('joomla') && !AceShop::get('base')->isAdmin('aceshop')) {
            $this->getOCustomerIdFromJUser($j_user['id'], $j_user['email']);
        }
        else {
            $this->getOUserIdFromJUser($j_user['id'], $j_user['username'], $j_user['email']);
        }
		
		$options = array();
        $options['return'] = '';
		$options['remember'] = true;

        $credentials = array();
		$credentials['username'] = $db->run($j_user['username'], 'escape');
		$credentials['password'] = $db->run($password, 'escape');
		
		JFactory::getApplication()->login($credentials, $options);
	}
	
	public function logoutJFromO() {
		$user_id = JFactory::getUser()->get('id');

		if (empty($user_id)) {
			return;
		}
		
		JFactory::getApplication()->logout();
	}

    //-------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------

    public function getOCustomerById($id) {
        $id = (int)$id;
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$id])) {
            $cache[$id] = $db->run("SELECT * FROM #__aceshop_customer WHERE customer_id = {$id}");
        }

        return $cache[$id];
    }

    public function getOCustomerByEmail($email) {
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$email])) {
            $_email = $db->run($email, 'Quote');

            $cache[$email] = $db->run("SELECT * FROM #__aceshop_customer WHERE email = {$_email}");
        }

        return $cache[$email];
    }

    public function getOCustomerIdFromJUser($juser_id, $email = '') {
        $juser_id = (int)$juser_id;
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$juser_id])) {
            $cache[$juser_id] = AceShop::get('db')->run("SELECT ocustomer_id FROM #__aceshop_juser_ocustomer_map WHERE juser_id = {$juser_id}", 'loadResult');

            if (empty($cache[$juser_id])) {
                if (!empty($email)) {
                    $o_customer = $this->getOCustomerByEmail($email);

                    if (!empty($o_customer['customer_id'])) {
                        $db->run("INSERT IGNORE INTO #__aceshop_juser_ocustomer_map SET juser_id = '{$juser_id}', ocustomer_id = '".$o_customer['customer_id']."'", 'query');

                        $cache[$juser_id] = $o_customer['customer_id'];
                    }
                }
            }
        }

        return $cache[$juser_id];
    }

    public function getOCustomerGroupIdByJGroup($jgroup_id) {
        $jgroup_id = (int)$jgroup_id;
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$jgroup_id])) {
            $cache[$jgroup_id] = $db->run("SELECT cgroup_id FROM #__aceshop_jgroup_cgroup_map WHERE jgroup_id = {$jgroup_id}", 'loadResult');
        }

        return $cache[$jgroup_id];
    }

    public function getOUserIdFromJUser($juser_id, $username = '', $email = '') {
        $juser_id = (int)$juser_id;
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$juser_id])) {
            $cache[$juser_id] = $db->run("SELECT ouser_id FROM #__aceshop_juser_ouser_map WHERE juser_id = {$juser_id}", 'loadResult');

            if (empty($cache[$juser_id])) {
                if (!empty($email)) {
                    $o_user = $this->getOUserByEmail($email);

                    if (!empty($o_user['user_id'])) {
                        $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$juser_id}', ouser_id = '".$o_user['user_id']."'", 'query');

                        $cache[$juser_id] = $o_user['id'];
                    }
                }

                if (empty($cache[$juser_id]) && !empty($username)) {
                    $o_user = $this->getOUserByUsername($username);

                    if (!empty($o_user['user_id'])) {
                        $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$juser_id}', ouser_id = '".$o_user['user_id']."'", 'query');

                        $cache[$juser_id] = $o_user['id'];
                    }
                }
            }
        }

        return $cache[$juser_id];
    }

    public function getOUserById($id) {
        $id = (int)$id;
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$id])) {
            $cache[$id] = $db->run("SELECT * FROM #__aceshop_user WHERE user_id = {$id}");
        }

        return $cache[$id];
    }

    public function getOUserByEmail($email) {
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$email])) {
            $_email = $db->run($email, 'Quote');

            $cache[$email] = $db->run("SELECT * FROM #__aceshop_user WHERE email = {$_email}");
        }

        return $cache[$email];
    }

    public function getOUserByUsername($username) {
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$username])) {
            $_username = $db->run($username, 'Quote');

            $cache[$username] = $db->run("SELECT * FROM #__aceshop_user WHERE username = {$_username}");
        }

        return $cache[$username];
    }

    public function getOUserGroupIdByJGroup($jgroup_id) {
        static $cache;

        $jgroup_id = (int)$jgroup_id;

        if (!isset($cache[$jgroup_id])) {
            $cache[$jgroup_id] = AceShop::get('db')->run("SELECT ugroup_id FROM #__aceshop_jgroup_ugroup_map WHERE jgroup_id = {$jgroup_id}", 'loadResult');
        }

        return $cache[$jgroup_id];
    }

    //-------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------

    public function getJUserByEmail($email) {
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$email])) {
            $cache[$email] = $db->run("SELECT * FROM #__users WHERE email = '".$db->run($email, 'escape')."'");
        }

        return $cache[$email];
    }

    public function getJUserByUsername($username) {
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$username])) {
            $cache[$username] = $db->run("SELECT * FROM #__users WHERE username = '".$db->run($username, 'escape')."'");
        }

        return $cache[$username];
    }

    public function getJUserIdFromOCustomer($customer_id, $email = '') {
        $customer_id = (int)$customer_id;
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$customer_id])) {
            $cache[$customer_id] = $db->run("SELECT juser_id FROM #__aceshop_juser_ocustomer_map WHERE ocustomer_id = {$customer_id}", 'loadResult');

            if (empty($cache[$customer_id])) {
                if (!empty($email)) {
                    $j_user = $this->getJUserByEmail($email);

                    if (!empty($j_user['id'])) {
                        $db->run("INSERT IGNORE INTO #__aceshop_juser_ocustomer_map SET juser_id = '{$j_user['id']}', ocustomer_id = '".$customer_id."'", 'query');

                        $cache[$customer_id] = $j_user['id'];
                    }
                }
            }
        }

        return $cache[$customer_id];
    }

    public function getJUserIdFromOUser($ouser_id, $username = '', $email = '') {
        $ouser_id = (int)$ouser_id;
        $db = AceShop::get('db');

        static $cache;

        if (!isset($cache[$ouser_id])) {
            $cache[$ouser_id] = $db->run("SELECT juser_id FROM #__aceshop_juser_ouser_map WHERE ouser_id = {$ouser_id}", 'loadResult');

            if (empty($cache[$ouser_id])) {
                if (!empty($email)) {
                    $j_user = $this->getJUserByEmail($email);
                    
                    if (!empty($j_user['id'])) {
                        $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$j_user['id']}', ouser_id = '".$ouser_id."'", 'query');

                        $cache[$ouser_id] = $j_user['id'];
                    }
                }
                
                if (empty($cache[$ouser_id]) && !empty($username)) {
                    $j_user = $this->getJUserByUsername($username);

                    if (!empty($j_user['id'])) {
                        $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$j_user['id']}', ouser_id = '".$ouser_id."'", 'query');

                        $cache[$ouser_id] = $j_user['id'];
                    }
                }
            }
        }

        return $cache[$ouser_id];
    }

    public function getJGroupId($data) {
        if (isset($data['user_group_id'])) {
            $j_user_group_id = $this->getJGroupIdOfUGroup((int)$data['user_group_id']);
        }
        else {
            $o_customer_group_id = (int)AceShop::get('opencart')->get('config')->get('config_customer_group_id');

            if (AceShop::get('base')->isAdmin() || AceShop::get('base')->isAdmin('joomla')) {
                $o_customer_group_id = (int)$data['customer_group_id'];
            }

            $j_user_group_id = $this->getJGroupIdOfCGroup((int)$o_customer_group_id);
        }

        return $j_user_group_id;
    }

    public function getJGroupIdOfCGroup($customer_group_id) {
        static $cache;

        $customer_group_id = (int)$customer_group_id;

        if (!isset($cache[$customer_group_id])) {
            $cache[$customer_group_id] = AceShop::get('db')->run("SELECT jgroup_id FROM #__aceshop_jgroup_cgroup_map WHERE cgroup_id = {$customer_group_id}", 'loadResult');
        }

        if (empty($cache[$customer_group_id])) {
            if (AceShop::get('base')->is15()){
                $cache[$customer_group_id] = 18;
            }
            else {
                $cache[$customer_group_id] = 2;
            }
        }

        return $cache[$customer_group_id];
    }

    public function getJGroupIdOfUGroup($user_group_id) {
        static $cache;

        $user_group_id = (int)$user_group_id;

        if (!isset($cache[$user_group_id])) {
            $cache[$user_group_id] = AceShop::get('db')->run("SELECT jgroup_id FROM #__aceshop_jgroup_ugroup_map WHERE ugroup_id = {$user_group_id}", 'loadResult');
        }

        if (empty($cache[$user_group_id])) {
            if (AceShop::get('base')->is15()){
                $cache[$user_group_id] = 23;
            }
            else {
                $cache[$user_group_id] = 6;
            }
        }

        return $cache[$user_group_id];
    }

    public function getJoomlaUserGroups() {
        if (AceShop::get('base')->is15()) {
            return JFactory::getACL()->get_group_children_tree(null, 'USERS', false);
        }
        else {
            return JHtml::_('user.groups');
        }
    }

    //-------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------

    public function encryptPassword($password) {
        $salt = JUserHelper::genRandomPassword(32);
        $crypt = JUserHelper::getCryptedPassword(AceShop::get('db')->run($password, 'escape'), $salt);
        $encrypted_password = $crypt.":".$salt;

        return $encrypted_password;
    }

    public function getCleanPassword($password) {
        if (strpos($password, ':')) {
            $a = explode(':', $password);
            $password = $a[0];
        }

        return $password;
    }

    public function getBlockStatus($data) {
        $block = '1';

        $oc_config =  AceShop::get('opencart')->get('config');

        if (isset($data['status'])) {
            if ($data['status'] == '1') {
                $block = '0';
            }
        }
        else if (!$oc_config->get("config_customer_approval")) {
            $block = '0';
        }

        return $block;
    }

    public function getLastName($name) {
        $lname = '';

        if (!is_array($name)) {
            $name = explode(' ', $name);
        }

        if (count($name) > 1) {
            for($i = 1; $i <= count($name); $i++){
                if (!isset($name[$i])) {
                    continue;
                }

                if ($i == 1) {
                    $lname = $name[$i];
                }
                else {
                    $lname = $lname." ".$name[$i];
                }
            }
        }

        return $lname;
    }

    public function addJUsersToO() {
        AceShop::get('install')->createUserTables();
    }

    public function synchronizeAccountsManually() {
        $db = AceShop::get('db');

        if (AceShop::get('base')->is15()) {
            $users = $db->run('SELECT DISTINCT u.id AS juser_id, au.user_id AS ouser_id FROM #__users AS u, #__aceshop_user AS au WHERE u.username = au.username AND u.block = 0 AND gid IN (24, 25)', 'loadObjectList');
        }
        else {
            $users = $db->run('SELECT DISTINCT u.id AS juser_id, au.user_id AS ouser_id FROM #__users AS u, #__aceshop_user AS au, #__user_usergroup_map AS uum WHERE u.id = uum.user_id AND u.username = au.username AND u.block = 0 AND uum.group_id IN (7, 8)', 'loadObjectList');
        }

        if (!empty($users)) {
            foreach ($users as $user) {
                $db->run("INSERT IGNORE INTO #__aceshop_juser_ouser_map SET juser_id = '{$user->juser_id}', ouser_id = '{$user->ouser_id}'", 'query');
            }
        }

        $customers = $db->run('SELECT * FROM #__aceshop_customer LIMIT 1');
		if (!empty($customers)) {
			$users = $db->run('SELECT DISTINCT u.id AS juser_id, ac.customer_id AS ocustomer_id FROM #__users AS u, #__aceshop_customer AS ac WHERE u.email = ac.email AND u.block = 0', 'loadObjectList');
		
			if (!empty($users)) {
				foreach ($users as $user) {
					$db->run("INSERT IGNORE INTO #__aceshop_juser_ocustomer_map SET juser_id = '{$user->juser_id}', ocustomer_id = '{$user->ocustomer_id}'", 'query');
				}
			}
		}
		else {
			$users = $db->run('SELECT id, name, username, email, password FROM #__users', 'loadAssocList');
			
			if (!empty($users)) {
				foreach ($users as $user) {
					$name = explode(' ', $user['name']);
					$fname = $db->run($name[0], 'escape');
					$lname = $db->run(self::getLastName($name), 'escape');
					$password = $db->run($this->getCleanPassword($user['password']), 'escape');
					$email = $db->run($user['email'], 'escape');
					$status = empty($user['block']) ? 1 : 0;
		
					$db->run("INSERT INTO #__aceshop_customer SET firstname = '".$fname."', lastname = '".$lname."', email = '".$email."', telephone = '', fax = '', password = '".$password."', newsletter = '0', customer_group_id = '8', status = '".$status."', approved = '".$status."', date_added = NOW()", 'query');
					$customer_id = $db->run('', 'getLastId');
					
					$db->run("INSERT IGNORE INTO #__aceshop_juser_ocustomer_map SET juser_id = '{$user['id']}', ocustomer_id = '".$customer_id."'", 'query');
				}
			}
		}

        $mainframe = JFactory::getApplication();
        $mainframe->set('_messageQueue', array());

        if (AceShop::get('base')->is15()) {
            $table = JTable::getInstance('component');
            $table->loadByOption('com_aceshop');
            $table->set('option', 'com_aceshop');
            $params = new JParameter($table->get('params', ''));
        }
        else {
            $table = JTable::getInstance('extension');
            $ext_id = $table->find(array('element' => 'com_aceshop', 'type' => 'component'));
            $table->load($ext_id);
            $params = new JRegistry($table->get('params', ''));
        }

        $params->set('account_sync_done', '1');

        $table->set('params', $params->toString());

        $table->check();
        $table->store();

        $mainframe->redirect('index.php?option=com_aceshop', JText::_('COM_ACESHOP_ACCOUNT_SYNC_DONE'));
    }
}