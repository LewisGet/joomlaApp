<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

class AceShopInstall {

	public function createTables() {
		$db = AceShop::getClass('db')->getDbo();
		
		$tables	= $db->getTableList();
		$aceshop_address = $db->getPrefix().'aceshop_address';
		if (!is_array($tables) || in_array($aceshop_address, $tables)) {
			return;
		}
		
		$sql_file = JPATH_ACESHOP_ADMIN.'/install.sql';
		
		if (!file_exists($sql_file)) {
			return;
		}
		
		$buffer = file_get_contents($sql_file);
		
		if ($buffer === false) {
			return;
		}
		
		jimport('joomla.installer.helper');
		
		$queries = JInstallerHelper::splitSql($buffer);

		if (count($queries) == 0) {
			return;
		}
		
		foreach ($queries as $query) {
			$query = trim($query);

			if ($query != '' && $query{0} != '#') {
				$db->setQuery($query);

				if (!$db->query()) {
					JError::raiseWarning(1, 'JInstaller::install: '.JText::_('SQL Error')." ".$db->stderr(true));
					return;
				}
			}
		}
	}

	public function createUserTables() {
        $this->_createUserMapTables();

		$db = AceShop::getClass('db')->getDbo();

		$tables	= $db->getTableList();
		$aceshop_user = $db->getPrefix().'aceshop_user';
		if (!is_array($tables) || in_array($aceshop_user, $tables)) {
			return;
		}

		$db->setQuery("CREATE TABLE IF NOT EXISTS `#__aceshop_user` (
		  `user_id` int(11) NOT NULL AUTO_INCREMENT,
		  `user_group_id` int(11) NOT NULL,
		  `username` varchar(20) COLLATE utf8_bin NOT NULL DEFAULT '',
		  `password` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
		  `firstname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
		  `lastname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
		  `email` varchar(96) COLLATE utf8_bin NOT NULL DEFAULT '',
		  `code` varchar(32) COLLATE utf8_bin NOT NULL,
		  `ip` varchar(15) COLLATE utf8_bin NOT NULL DEFAULT '',
		  `status` tinyint(1) NOT NULL,
		  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		  PRIMARY KEY (`user_id`)
		) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;");
		$db->query();

		if (AceShop::getClass('base')->is15()) {
			$users = AceShop::getClass('db')->run('SELECT * FROM #__users WHERE block = 0 AND gid IN (24, 25)', 'loadObjectList');
		}
		else {
			$users = AceShop::getClass('db')->run('SELECT u.* FROM #__users AS u, #__user_usergroup_map AS uum WHERE uum.group_id IN (7, 8) AND u.id = uum.user_id AND u.block = 0', 'loadObjectList');
		}

		if (empty($users)) {
			return;
		}

		foreach ($users as $user) {
			$name = explode(' ', $user->name);

			$firstname = $name[0];
			$lastname = AceShop::getClass('user')->getLastName($name);

			$password = $user->password;
			if (strpos($password, ':')) {
				$a = explode(':', $password);
				$password = $a[0];
			}

			AceShop::getClass('db')->run("INSERT IGNORE INTO #__aceshop_user SET ".
							"username = '" . $user->username . "', ".
							"password = '" . $password . "', ".
							"firstname = '" . $firstname . "', ".
							"lastname = '" . $lastname . "', ".
							"email = '" . $user->email . "', ".
							"user_group_id = '1', ".
							"status = '1', ".
							"date_added = NOW()"
						, 'query'
						);
		}
	}

    public function _createUserMapTables() {
        $db = AceShop::getClass('db')->getDbo();

        $tables	= $db->getTableList();
        $aceshop_juser_ocustomer_map = $db->getPrefix().'aceshop_juser_ocustomer_map';
        if (!is_array($tables) || in_array($aceshop_juser_ocustomer_map, $tables)) {
            return;
        }

        $db->setQuery("CREATE TABLE IF NOT EXISTS `#__aceshop_juser_ocustomer_map` (
          `juser_id` INT(11) NOT NULL,
          `ocustomer_id` INT(11) NOT NULL,
          PRIMARY KEY (`juser_id`),
          UNIQUE (`ocustomer_id`)
        ) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;");
        $db->query();

        $db->setQuery("CREATE TABLE IF NOT EXISTS `#__aceshop_juser_ouser_map` (
          `juser_id` INT(11) NOT NULL,
          `ouser_id` INT(11) NOT NULL,
          PRIMARY KEY (`juser_id`),
          UNIQUE (`ouser_id`)
        ) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;");
        $db->query();

        $db->setQuery("SHOW COLUMNS FROM `#__aceshop_customer` LIKE 'user_id'");
        $result = $db->loadRow();

        if (empty($result)) {
            return;
        }

        $db->setQuery("ALTER TABLE `#__aceshop_customer` DROP `user_id`");
        $db->query();
    }

	public function createGroupTables() {
		$db = AceShop::getClass('db')->getDbo();

		$tables	= $db->getTableList();
		$aceshop_jgroup_cgroup_map = $db->getPrefix().'aceshop_jgroup_cgroup_map';
		if (!is_array($tables) || in_array($aceshop_jgroup_cgroup_map, $tables)) {
			return;
		}

        if (AceShop::getClass('base')->is15()) {
            $registered = 18;
            $publisher = 21;
            $administrator = 25;
        }
        else {
            $registered = 2;
            $publisher = 5;
            $administrator = 8;
        }

		$db->setQuery("CREATE TABLE IF NOT EXISTS `#__aceshop_jgroup_cgroup_map` (
		  `jgroup_id` INT(11) NOT NULL,
		  `cgroup_id` INT(11) NOT NULL,
		  PRIMARY KEY (`cgroup_id`)
		) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;");
		$db->query();

		$customer_groups = AceShop::getClass('db')->run('SELECT customer_group_id FROM #__aceshop_customer_group', 'loadResultArray');
		if (!empty($customer_groups)) {
            foreach ($customer_groups as $customer_group) {
                $j_group = $registered;
                if ($customer_group == 6) {
                    $j_group = $publisher;
                }

                AceShop::getClass('db')->run("INSERT INTO #__aceshop_jgroup_cgroup_map SET jgroup_id = '{$j_group}', cgroup_id = '{$customer_group}'", 'query');
            }
        }

        $db->setQuery("CREATE TABLE IF NOT EXISTS `#__aceshop_jgroup_ugroup_map` (
      		  `jgroup_id` INT(11) NOT NULL,
      		  `ugroup_id` INT(11) NOT NULL,
      		  PRIMARY KEY (`ugroup_id`)
      		) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;");
      	$db->query();

        $user_groups = AceShop::getClass('db')->run('SELECT user_group_id FROM #__aceshop_user_group', 'loadResultArray');
		if (!empty($user_groups)) {
            foreach ($user_groups as $user_group) {
                AceShop::getClass('db')->run("INSERT INTO #__aceshop_jgroup_ugroup_map SET jgroup_id = '{$administrator}', ugroup_id = '{$user_group}'", 'query');
            }
        }
	}
}