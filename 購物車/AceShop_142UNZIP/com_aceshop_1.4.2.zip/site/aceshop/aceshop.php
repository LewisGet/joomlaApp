<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

define('JPATH_ACESHOP_OC', JPATH_SITE.'/components/com_aceshop/opencart');
define('JPATH_ACESHOP_LIB', JPATH_SITE.'/components/com_aceshop/aceshop');
define('JPATH_ACESHOP_SITE', JPATH_SITE.'/components/com_aceshop');
define('JPATH_ACESHOP_ADMIN', JPATH_SITE.'/administrator/components/com_aceshop');

$_lang = JFactory::getLanguage();
$_lang->load('com_aceshop', JPATH_ADMINISTRATOR, 'en-GB', true);
$_lang->load('com_aceshop', JPATH_ADMINISTRATOR, $_lang->getDefault(), true);
$_lang->load('com_aceshop', JPATH_ADMINISTRATOR, null, true);

abstract class AceShop {

    public static function &get($class = 'base', $options = null) {
        static $instances = array();

		$class = empty($class) ? 'base' : $class;
			
		if (!isset($instances[$class])) {			
			require_once(JPATH_ACESHOP_LIB.'/'.$class.'.php');

            $class_name = 'AceShop'.ucfirst($class);
			
			$instances[$class] = new $class_name($options);
		}

		return $instances[$class];
    }

    public static function getButton() {
        return AceShop::get('base')->getConfig()->get('button_class', 'button_oc');
    }

    public static function is15() {
        return AceShop::get('base')->is15();
    }

    public static function &getClass($class = 'base', $options = null) {
		return self::get($class, $options);
    }
}

if (!AceShop::get('base')->plgEnabled('system', 'aceshopjquery')) {
    JError::raiseWarning(404, JText::_('COM_ACESHOP_JQUERY_PLUGIN'));
}