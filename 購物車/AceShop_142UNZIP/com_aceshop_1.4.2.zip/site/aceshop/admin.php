<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');

// Access check.
if (!AceShop::get('base')->is15() && !JFactory::getUser()->authorise('core.manage', 'com_aceshop')) {
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

if (AceShop::get('base')->plgEnabled('system', 'legacy')) {
    return JError::raiseWarning(404, JText::_('COM_ACESHOP_LEGACY_PLUGIN'));
}

JFactory::getDocument()->addStyleSheet('components/com_aceshop/assets/css/aceshop.css');
JToolBarHelper::title(JText::_('AceShop'), 'aceshop');

$margin_info = "margin-top:12px;";
if (AceShop::get('base')->is15()) {
    $margin_info = "margin-top:2px;";
}
$version_info = '<span style="width:200px;text-align:left;float:left;vertical-align:middle;'.$margin_info.'"><strong>AceShop</strong>: '.AceShop::get('base')->getAceshopVersion().'<br /><strong>OpenCart</strong>: '.AceShop::get('base')->getOcVersion().'</span>';

$toolbar = JToolBar::getInstance();
$toolbar->appendButton('Custom', $version_info);

if (AceShop::get('base')->is15()) {
	JToolBarHelper::preferences('com_aceshop', '550');
}
elseif (JFactory::getUser()->authorise('core.admin', 'com_aceshop')) {
	JToolBarHelper::preferences('com_aceshop', '550');
}

JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_DASHBOARD'), 'index.php?option=com_aceshop', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_SETTINGS'), 'index.php?option=com_aceshop&route=setting/store', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_CATEGORIES'), 'index.php?option=com_aceshop&route=catalog/category', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_PRODUCTS'), 'index.php?option=com_aceshop&route=catalog/product', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_COUPONS'), 'index.php?option=com_aceshop&route=sale/coupon', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_CUSTOMERS'), 'index.php?option=com_aceshop&route=sale/customer', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_ORDERS'), 'index.php?option=com_aceshop&route=sale/order', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_AFFILIATES'), 'index.php?option=com_aceshop&route=sale/affiliate', false);
JSubMenuHelper::addEntry(JText::_('COM_ACESHOP_MAILING'), 'index.php?option=com_aceshop&route=sale/contact', false);

if (AceShop::get('base')->getConfig()->get('account_sync_done', 0) == 0) {
    JError::raiseWarning('100', JText::sprintf('COM_ACESHOP_ACCOUNT_SYNC_WARN', '<a href="index.php?option=com_aceshop&ctrl=sync">', '</a>'));
}

$ctrl = JRequest::getWord('ctrl');
$view = JRequest::getString('view');

if (!empty($ctrl)) {
    if ($ctrl == 'sync') {
        AceShop::get('user')->synchronizeAccountsManually();
    }
}

if (isset($_GET['token'])) {
	$_SESSION['token'] = $_GET['token'];
}

if (isset($_SESSION['token']) && !isset($_GET['token'])) {
	$_GET['token'] = $_SESSION['token'];
}

$replace_output = array(
"index.php?route=common/filemanager" => "index.php?option=com_aceshop&tmpl=component&format=raw&route=common/filemanager",
"index.php?route=" => "index.php?option=com_aceshop&route=",
"index.php?token=" => "index.php?option=com_aceshop&token=",
'admin/view' => '../components/com_aceshop/opencart/admin/view',
'view/image' => '../components/com_aceshop/opencart/admin/view/image',
'view/javascript/jquery/' => AceShop::get('base')->is15() ? '../plugins/system/aceshopjquery/' : '../plugins/system/aceshopjquery/aceshopjquery/',
'view/javascript' => '../components/com_aceshop/opencart/admin/view/javascript',
'$.' => 'jQuery.',
'$(' => 'jQuery(',
'<div id="container">' => '<div id="container_oc">',
'"header"' => '"header_oc"',
'"content"' => '"content_oc"',
'class="button"' => 'class="button_oc"',
'id="button"' => 'id="button_oc"',
'"search"' => '"search_oc"',
'"menu"' => '"menu_oc"',
'"breadcrumb"' => '"breadcrumb_oc"',
//'"logo"' => '"logo_oc"',
'"banner"' => '"banner_oc"',
'"footer"' => '"footer_oc"',
'#header' => '#header_oc',
'#content' => '#content_oc',
'.button ' => '.button_oc ',
'.button:' => '.button_oc:',
'#content' => '#content_oc',
'#container' => '#container_oc',
'#menu' => '#menu_oc',
"load('index.php?option=com_aceshop&" => "load('index.php?option=com_aceshop&format=raw&tmpl=component&",
": 'index.php?option=com_aceshop&" => ": 'index.php?option=com_aceshop&format=raw&tmpl=component&",
"index.php?option=com_aceshop&route=sale/order/invoice&" => "index.php?option=com_aceshop&route=sale/order/invoice&format=raw&tmpl=component&",
'<link rel="stylesheet" type="text/css" href="index.php?option=com_aceshop&' => '<link rel="stylesheet" type="text/css" href="index.php?option=com_aceshop&format=raw&tmpl=component&',
'index.php?option=com_aceshop&route=tool/backup/backup&' => 'index.php?option=com_aceshop&format=raw&tmpl=component&route=tool/backup/backup&'
);

$_file = JPATH_ACESHOP_OC.'/admin/index.php';

if (substr($view, 0, 7) == 'install') {
    $_file = JPATH_ACESHOP_OC.'/'.str_replace('install/', '', $view).'.php';
}
else if (substr($view, 0, 8) == 'external') {
    $_file = JPATH_ACESHOP_OC.'/'.str_replace('external/', '', $view).'.php';
}

if (AceShop::get('base')->isExternal()) {
    $_opencart = AceShop::get('opencart');
    $vqmod = $_opencart->get('vqmod');

    jimport('joomla.filesystem/file');
    jimport('joomla.filesystem/folder');

    $content = JFile::read($_file);

    $content = str_replace("require_once('config.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'startup.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'library/customer.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'library/affiliate.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'library/currency.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'library/tax.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'library/weight.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'library/length.php');", "", $content);
    $content = str_replace("require_once(DIR_SYSTEM . 'library/cart.php');", "", $content);

    $content = str_replace("define('VERSION','1.5.1.3');", "", $content);
    $content = str_replace("define('VERSION','1.5.2.1');", "", $content);
    $content = preg_replace('/require_once\(([^)]+)/', 'require_once($vqmod->modCheck($1)', $content);

    JFile::write($_file, $content);
}

ob_start();

require_once($_file);

$output = ob_get_contents();

ob_end_clean();

foreach($replace_output as $key => $value){
	$output = str_replace($key, $value, $output);
}

echo $output;

$is_ajax = false;

if (AceShop::get('base')->isAjax()) {
    $is_ajax = true;
}
else if (substr($output, 0, 11) == '{"success":' ||
    substr($output, 0, 12) == '{"redirect":' ||
    substr($output, 0, 9) == '{"error":' ||
    substr($output, 0, 11) == '{"warning":' ||
    substr($output, 0, 15) == '{"information":' ||
    substr($output, 0, 13) == '{"attention":') {
    $is_ajax = true;
    JRequest::setVar('format', 'raw');
    JRequest::setVar('tmpl', 'component');
}

if ($is_ajax == true) {
	jexit();
}