<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

require_once(JPATH_SITE.'/components/com_aceshop/aceshop/aceshop.php');

if (AceShop::get('base')->plgEnabled('system', 'legacy')) {
    return JError::raiseWarning(404, JText::_('COM_ACESHOP_LEGACY_PLUGIN'));
}

$output = AceShop::get('opencart')->loadModule($params->get('module', 'cart'), $params->get('layout_id', '12'));

if (is_object($output) || empty($output)) {
    return;
}

$output = preg_replace('#(<div class="box-heading">)(.*)(</div>)#e', "", $output);
$output = preg_replace('#(<div class="top">)(.*)(</div>)#e', "", $output);

$replace_output = array(
'$.' => 'jQuery.',
'$(' => 'jQuery(',
'<div class="breadcrumb">' => '<div class="breadcrumb" style="display: none;">',
'<div id="container">' => '<div id="container_oc">',
'"header"' => '"header_oc"',
'"content"' => '"content_oc"',
'class="box"' => 'class="box_oc"',
'class="button_oc"' => 'class="'.AceShop::getButton().'"',
'class="button"' => 'class="'.AceShop::getButton().'"',
'id="button"' => 'id="button_oc"',
'"search"' => '"search_oc"',
'"menu"' => '"menu_oc"',
'"breadcrumb"' => '"breadcrumb_oc"',
'"banner"' => '"banner_oc"',
'"footer"' => '"footer_oc"',
'#header' => '#header_oc',
'#content' => '#content_oc',
'.button ' => '.button_oc ',
'.button:' => '.button_oc:',
'#content' => '#content_oc',
'#container' => '#container_oc',
'#menu' => '#menu_oc',
'<img src="catalog/' => '<img src="components/com_aceshop/opencart/catalog/',
'<img src="image/' => '<img src="components/com_aceshop/opencart/image/',
"index.php?route=common/filemanager" => "index.php?option=com_aceshop&tmpl=component&format=raw&route=common/filemanager",
".load('index.php?route=" => ".load('index.php?option=com_aceshop&format=raw&tmpl=component&route=",
": 'index.php?route=" => ": 'index.php?option=com_aceshop&format=raw&tmpl=component&route=",
"index.php?route=" => "index.php?option=com_aceshop&route=",
'class="box-content"' => '',
'<div class="bottom">&nbsp;</div>' => '',
'class="box_oc"' => 'class="box_oc" style="margin-bottom: 0px !important;"'
);

foreach($replace_output as $key => $value){
	$output = str_replace($key, $value, $output);
}

echo $output;