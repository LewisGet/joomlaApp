<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

jimport('joomla.plugin.plugin');

class plgUserAceshop extends JPlugin {
	
	public function __construct(& $subject, $config) {
		parent::__construct($subject, $config);
		
		require_once(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php');
	}

	public function onLoginUser($user, $options = array()) {
		self::onUserLogin($user, $options);
	}

	public function onLogoutUser($user, $options = array()) {
		self::onUserLogout($user, $options);
	}

	public function onAfterStoreUser($user, $isnew, $succes, $msg) {
		self::onUserAfterSave($user, $isnew, $succes, $msg);
	}

	public function onAfterDeleteUser($user, $succes, $msg) {
		self::onUserAfterDelete($user, $succes, $msg);
	}
	
	public function onUserLogin($user, $options = array()) {
        $is_backend = false;
        $opencart = AceShop::get('opencart');
        $mainframe = JFactory::getApplication();

        if ($mainframe->isAdmin()){
            $is_backend = true;
            $o_user = $opencart->get('user');
        }
        else {
            $o_user = $opencart->get('customer');
        }

        AceShop::get('user')->loginOFromJ($o_user, $user, $is_backend);
	}

	public function onUserLogout($user, $options = array()){
		$mainframe = JFactory::getApplication();
		
		if ($mainframe->isAdmin()) {
			return true;
		}

        AceShop::get('user')->logoutOFromJ();
		
		return true;
	}

	public function onUserAfterSave($user, $isnew, $succes, $msg){
		if (!$succes) {
			return false;
		}

        if (!empty($user['from_aceshop'])) {
			return true;
		}
		
		$ret = AceShop::get('user')->createOAccountFromJ($user);
		
		return $ret;
	}
	
	public function onUserAfterDelete($user, $succes, $msg){
		if (!$succes) {
			return false;
		}

        if (!empty($user['from_aceshop'])) {
            return true;
        }
		
		$ret = AceShop::get('user')->deleteOAccountFromJ($user);
		
		return $ret;
	}
}