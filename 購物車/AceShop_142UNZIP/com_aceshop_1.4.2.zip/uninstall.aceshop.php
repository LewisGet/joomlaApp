<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import Libraries
jimport('joomla.application.helper');
jimport('joomla.filesystem.file');
jimport('joomla.installer.installer');

$db = JFactory::getDBO();

$status = new JObject();
$status->modules = array();
$status->plugins = array();


/***********************************************************************************************
 * ---------------------------------------------------------------------------------------------
 * MODULE REMOVAL SECTION
 * ---------------------------------------------------------------------------------------------
 ***********************************************************************************************/
$modules = array(
			array('title' => 'AceShop - All-in-One', 'element' => 'mod_aceshop', 'client' => 'Site', 'position' => 'left'),
			array('title' => 'AceShop - Quick Icons', 'element' => 'mod_aceshop_quickicons', 'client' => 'Administrator', 'position' => 'icon')
		);

if (!empty($modules)) {
	foreach ($modules as $module) {
		$mtitle		= $module['title'];
		$melement	= $module['element'];
		$mclient	= $module['client'];
		$mmclient 	= ($mclient == 'Site') ? 0 : 1;
		
		if (!version_compare(JVERSION,'1.6.0', 'ge')) {
			$db->setQuery("SELECT id FROM #__modules WHERE module = '{$melement}' AND client_id = '{$mmclient}' LIMIT 1");
			$id = $db->loadResult();
			if ($id) {
				$installer = new JInstaller();
				$installer->uninstall('module', $id);
			}
		}
		else {
			$db->setQuery("SELECT extension_id FROM #__extensions WHERE type = 'module' AND element = '{$melement}' AND client_id = '{$mmclient}' LIMIT 1");
			$id = $db->loadResult();
			if ($id) {
				$installer = new JInstaller();
				$installer->uninstall('module', $id);
			}
		}

		$status->modules[] = array('name' => $mtitle, 'client' => $mclient);
	}
}


/***********************************************************************************************
 * ---------------------------------------------------------------------------------------------
 * PLUGIN REMOVAL SECTION
 * ---------------------------------------------------------------------------------------------
 ***********************************************************************************************/
$plugins = array(
            array('title' => 'Content - AceShop', 'folder' => 'content', 'element' => 'aceshop'),
			array('title' => 'Search - AceShop', 'folder' => 'search', 'element' => 'aceshop'),
			array('title' => 'System - AceShop Redirect', 'folder' => 'system', 'element' => 'aceshopredirect'),
			array('title' => 'User - AceShop', 'folder' => 'user', 'element' => 'aceshop')
		);
		
if (!empty($plugins)) {
	foreach ($plugins as $plugin) {
		$ptitle		= $plugin['title'];
		$pfolder	= $plugin['folder'];
		$pelement	= $plugin['element'];
		
		if (!version_compare(JVERSION,'1.6.0', 'ge')) {
			$db->setQuery("SELECT id FROM #__plugins WHERE element = '{$pelement}' AND folder = '{$pfolder}' LIMIT 1");
			$id = $db->loadResult();
			if ($id) {
				$installer = new JInstaller();
				$installer->uninstall('plugin', $id);
			}
		}
		else {
			$db->setQuery("SELECT extension_id FROM #__extensions WHERE type = 'plugin' AND element = '{$pelement}' AND folder = '{$pfolder}' LIMIT 1");
			$id = $db->loadResult();
			if ($id) {
				$installer = new JInstaller();
				$installer->uninstall('plugin', $id);
			}
		}
		
		$status->plugins[] = array('name' => $ptitle, 'group' => $pfolder);
	}
}

/***********************************************************************************************
 * ---------------------------------------------------------------------------------------------
 * OUTPUT TO SCREEN
 * ---------------------------------------------------------------------------------------------
 ***********************************************************************************************/
 $rows = 0;
?>

<h2>AceShop Removal</h2>
<table class="adminlist">
	<thead>
		<tr>
			<th class="title" colspan="2"><?php echo JText::_('Extension'); ?></th>
			<th width="30%"><?php echo JText::_('Status'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="3"></td>
		</tr>
	</tfoot>
	<tbody>
		<tr class="row0">
			<td class="key" colspan="2"><?php echo 'AceShop '.JText::_('Component'); ?></td>
			<td><strong><?php echo JText::_('Removed'); ?></strong></td>
		</tr>
	<?php
if (count($status->modules)) : ?>
		<tr>
			<th><?php echo JText::_('Module'); ?></th>
			<th><?php echo JText::_('Client'); ?></th>
			<th></th>
		</tr>
	<?php foreach ($status->modules as $module) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo $module['name']; ?></td>
			<td class="key"><?php echo ucfirst($module['client']); ?></td>
			<td><strong><?php echo JText::_('Removed'); ?></strong></td>
		</tr>
	<?php endforeach;
endif;
if (count($status->plugins)) : ?>
		<tr>
			<th><?php echo JText::_('Plugin'); ?></th>
			<th><?php echo JText::_('Group'); ?></th>
			<th></th>
		</tr>
	<?php foreach ($status->plugins as $plugin) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo ucfirst($plugin['name']); ?></td>
			<td class="key"><?php echo ucfirst($plugin['group']); ?></td>
			<td><strong><?php echo JText::_('Removed'); ?></strong></td>
		</tr>
	<?php endforeach;
endif;
?>
	</tbody>
</table>