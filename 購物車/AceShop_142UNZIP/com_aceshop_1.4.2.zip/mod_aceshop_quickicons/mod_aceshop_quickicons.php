<?php
/*
* @package		AceShop
* @subpackage	Quick Icons
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

$file = JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php';
if (!file_exists($file)) {
	return;
}

require_once($file);

$j_lang = JFactory::getLanguage();
$j_lang->load('com_aceshop', JPATH_ADMINISTRATOR);

function getAceshopIcon($link, $image, $text) {
	$lang = JFactory::getLanguage();

	$div_class = '';
	if (!AceShop::get('base')->is15()) {
		$div_class = 'class="icon-wrapper"';
	}

	$img_path = '/components/com_aceshop/assets/images/';
	?>
	<div <?php echo $div_class; ?> style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
		<div class="icon">
			<a href="<?php echo $link; ?>">
				<?php echo JHtml::_('image.site', $image, $img_path, null, null, $text); ?>
				<span><?php echo $text; ?></span>
			</a>
		</div>
	</div>
	<?php
}

?>

<div id="cpanel">
	<?php
	if ($params->get('aceshop_dashboard', 1) == 1) {
		$link = 'index.php?option=com_aceshop';
		getAceshopIcon($link, 'icon-48-aceshop.png', JText::_('COM_ACESHOP_DASHBOARD'));
	}
	
	if ($params->get('aceshop_categories', 1) == 1) {
		$link = 'index.php?option=com_aceshop&amp;route=catalog/category';
		getAceshopIcon($link, 'icon-48-aceshop-categories.png', JText::_('COM_ACESHOP_CATEGORIES'));
	}
	
	if ($params->get('aceshop_products', 1) == 1) {
		$link = 'index.php?option=com_aceshop&amp;route=catalog/product';
		getAceshopIcon($link, 'icon-48-aceshop-products.png', JText::_('COM_ACESHOP_PRODUCTS'));
	}
	
	if ($params->get('aceshop_coupons', 0) == 1) {
		$link = 'index.php?option=com_aceshop&amp;route=sale/coupon';
		getAceshopIcon($link, 'icon-48-aceshop-coupons.png', JText::_('COM_ACESHOP_COUPONS'));
	}
	
	if ($params->get('aceshop_customers', 1) == 1) {
		$link = 'index.php?option=com_aceshop&amp;route=sale/customer';
		getAceshopIcon($link, 'icon-48-aceshop-customers.png', JText::_('COM_ACESHOP_CUSTOMERS'));
	}
	
	if ($params->get('aceshop_orders', 1) == 1) {
		$link = 'index.php?option=com_aceshop&amp;route=sale/order';
		getAceshopIcon($link, 'icon-48-aceshop-orders.png', JText::_('COM_ACESHOP_ORDERS'));
	}
	
	if ($params->get('aceshop_affiliates', 0) == 1) {
		$link = 'index.php?option=com_aceshop&amp;route=sale/affiliate';
		getAceshopIcon($link, 'icon-48-aceshop-affiliates.png', JText::_('COM_ACESHOP_AFFILIATES'));
	}
	?>
</div>