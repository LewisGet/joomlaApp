<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

// Import Libraries
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.archive');
jimport('joomla.filesystem.path');
jimport('joomla.installer.installer');
require_once(JPATH_SITE.'/components/com_aceshop/aceshop/aceshop.php');

$db = JFactory::getDBO();

$status = new JObject();
$status->modules = array();
$status->plugins = array();

/***********************************************************************************************
* ---------------------------------------------------------------------------------------------
* OPENCART INSTALLATION SECTION
* ---------------------------------------------------------------------------------------------
***********************************************************************************************/
$_oc_zip = $this->parent->getPath('source').'/site/opencart.zip';
$_oc_gzip = $this->parent->getPath('source').'/site/opencart.tar.gz';

$_dir = JPath::clean(JPATH_ROOT.'/components/com_aceshop');

if (JFile::exists($_oc_zip)) {
	$_file = JPath::clean($_oc_zip);
}
else if (JFile::exists($_oc_gzip)) {
	$_file = JPath::clean($_oc_gzip);
}

JArchive::extract($_file, $_dir);

$vqmm_menu_shortcut = JPATH_ROOT.'/components/com_aceshop/opencart/vqmod/xml/vqmm_menu_shortcut.xml';
if (JFile::exists($vqmm_menu_shortcut)) {
	JFile::delete($vqmm_menu_shortcut);
}

/***********************************************************************************************
* ---------------------------------------------------------------------------------------------
* DATABASE INSTALLATION SECTION
* ---------------------------------------------------------------------------------------------
***********************************************************************************************/
if (method_exists('AceShop', 'getClass')) {
	AceShop::getClass('install')->createTables();

	AceShop::getClass('install')->createUserTables();

	AceShop::getClass('install')->createGroupTables();
}

/***********************************************************************************************
* ---------------------------------------------------------------------------------------------
* MODULE INSTALLATION SECTION
* ---------------------------------------------------------------------------------------------
***********************************************************************************************/
$modules = array(
			array('title' => 'AceShop - All-in-One', 'element' => 'mod_aceshop', 'client' => 'Site', 'position' => 'left', 'update' => false),
			array('title' => 'AceShop - Quick Icons', 'element' => 'mod_aceshop_quickicons', 'client' => 'Administrator', 'position' => 'icon', 'update' => true)
		);
		
if (!empty($modules)) {
	foreach ($modules as $module) {
		$mtitle		= $module['title'];
		$melement	= $module['element'];
		$mclient	= $module['client'];
		$mposition	= $module['position'];
		$mupdate	= $module['update'];
		
		$installer = new JInstaller();
		$installer->install($this->parent->getPath('source').'/'.$melement);
		
		if ($mupdate == true) {
			$db->setQuery("UPDATE #__modules SET position = '{$mposition}', ordering = '0', published = '1' WHERE module = '{$melement}'");
			$db->query();

			$db->setQuery("SELECT `id` FROM `#__modules` WHERE `module` = '{$melement}'");
			$mod_id = $db->loadResult();

			$db->setQuery("REPLACE INTO `#__modules_menu` (`moduleid`, `menuid`) VALUES ({$mod_id}, 0)");
			$db->query();
		}
		
		$status->modules[] = array('name' => $mtitle, 'client' => $mclient);
	}
}

/***********************************************************************************************
* ---------------------------------------------------------------------------------------------
* PLUGIN INSTALLATION SECTION
* ---------------------------------------------------------------------------------------------
***********************************************************************************************/
$plugins = array(
			array('title' => 'Content - AceShop', 'folder' => 'content', 'element' => 'aceshop', 'ordering' => '0', 'update' => false),
			array('title' => 'Search - AceShop', 'folder' => 'search', 'element' => 'aceshop', 'ordering' => '0', 'update' => false),
			array('title' => 'System - AceShop Redirect', 'folder' => 'system', 'element' => 'aceshopredirect', 'ordering' => '0', 'update' => true),
			array('title' => 'User - AceShop', 'folder' => 'user', 'element' => 'aceshop', 'ordering' => '100', 'update' => true)
		);

if (!empty($plugins)) {
	foreach ($plugins as $plugin) {
		$ptitle		= $plugin['title'];
		$pfolder	= $plugin['folder'];
		$pelement	= $plugin['element'];
		$pordering	= $plugin['ordering'];
		$pupdate	= $plugin['update'];
		
		$installer = new JInstaller();
		$installer->install($this->parent->getPath('source').'/plg_'.$pfolder.'_'.$pelement);
		
		if ($pupdate == true) {
			if (AceShop::getClass('base')->is15()) {
				$db->setQuery("UPDATE #__plugins SET published = 1, ordering = '{$pordering}' WHERE element = '{$pelement}' AND folder = '{$pfolder}'");
				$db->query();
			}
			else {
				$db->setQuery("UPDATE #__extensions SET enabled = 1, ordering = '{$pordering}' WHERE type = 'plugin' AND element = '{$pelement}' AND folder = '{$pfolder}'");
				$db->query();
			}
		}

		$status->plugins[] = array('name' => $ptitle, 'group' => $pfolder);
	}
}

$rows = 0;
?>
<img src="components/com_aceshop/assets/images/icon-64-aceshop.png" alt="Joomla Shopping Cart" style="width:64px; height:64px; float: left; padding-right:15px;" />

<h2>AceShop Installation</h2>
<h2><a href="index.php?option=com_aceshop">Go to AceShop</a></h2>
<table class="adminlist">
	<thead>
		<tr>
			<th class="title" colspan="2"><?php echo JText::_('Extension'); ?></th>
			<th width="30%"><?php echo JText::_('Status'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="3"></td>
		</tr>
	</tfoot>
	<tbody>
		<tr class="row0">
			<td class="key" colspan="2"><?php echo 'AceShop '.JText::_('Component'); ?></td>
			<td><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>
	<?php
if (count($status->modules)) : ?>
		<tr>
			<th><?php echo JText::_('Module'); ?></th>
			<th><?php echo JText::_('Client'); ?></th>
			<th></th>
		</tr>
	<?php foreach ($status->modules as $module) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo $module['name']; ?></td>
			<td class="key"><?php echo ucfirst($module['client']); ?></td>
			<td><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>
	<?php endforeach;
endif;
if (count($status->plugins)) : ?>
		<tr>
			<th><?php echo JText::_('Plugin'); ?></th>
			<th><?php echo JText::_('Group'); ?></th>
			<th></th>
		</tr>
	<?php foreach ($status->plugins as $plugin) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo ucfirst($plugin['name']); ?></td>
			<td class="key"><?php echo ucfirst($plugin['group']); ?></td>
			<td><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>
	<?php endforeach;
endif;
 ?>

	</tbody>
</table>