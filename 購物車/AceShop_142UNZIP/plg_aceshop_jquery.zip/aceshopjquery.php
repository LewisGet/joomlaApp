<?php
/*
* @package		AceShop
* @copyright	2009-2012 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');
jimport('joomla.environment.browser');
jimport('joomla.application.module.helper');

class plgSystemAceshopJquery extends JPlugin {

	public $p_params = null;

	public function __construct(&$subject, $config) {
		parent::__construct($subject, $config);

        $file = JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php';
        if (!file_exists($file)) {
            return;
        }

        require_once($file);

        $plugin = JPluginHelper::getPlugin('system', 'aceshopjquery');
        if (AceShop::get('base')->is15()) {
            $this->p_params = new JParameter($plugin->params);
        }
        else {
            $this->p_params = new JRegistry($plugin->params);
        }
	}

	public function onAfterRoute() {
        if (!self::_checkUp()) {
            return;
        }

		$app = JFactory::getApplication();
		$document = JFactory::getDocument();

        JHTML::_('behavior.mootools');

		$route = JRequest::getString('route');

		$browser = JBrowser::getInstance()->getBrowser();

		$sys_folder = AceShop::get('base')->getFullUrl(true).'plugins/system';
		$lib_folder = AceShop::get('base')->is15() ? $sys_folder.'/aceshopjquery' : $sys_folder.'/aceshopjquery/aceshopjquery';

        $load_jquery = false;
        switch ($this->p_params->get('load_main', 1)) {
            case 1:
                $load_jquery = true;
                break;
            case 2:
                if ($app->isSite()) {
                    $load_jquery = true;
                }
                break;
            case 3:
                if (AceShop::get()->isAdmin() || AceShop::get()->isAdmin('joomla')) {
                    $load_jquery = true;
                }
                break;
        }

		if ($load_jquery == true) {
			$app->set('jquery', true);
            $app->set('jquery_loaded', true);

            if ($this->p_params->get('remove_other_jq', '0') == '0') {
                $document->addScript($lib_folder.'/jquery-1.6.1.min.js');
            }
            else {
                $document->addScript("ACESHOPJQLIB");
                $this->_jqpath = $lib_folder.'/jquery-1.6.1.min.js';
            }
		}

		if ($this->p_params->get('load_noconflict', '1') == '1') {
            if ($this->p_params->get('remove_other_jq', '0') == '0') {
                $document->addScript($lib_folder.'/jquery.noconflict.js');
            }
            else {
                $document->addScript("ACESHOPJQNOCONFLICT");
                $this->_jqncpath = $lib_folder.'/jquery.noconflict.js';
            }
		}

		if ($this->p_params->get('load_ui', '1') == '1') {
			$document->addScript($lib_folder.'/ui/jquery-ui-1.8.16.custom.min.js');
			$document->addStyleSheet($lib_folder.'/ui/themes/ui-lightness/jquery-ui-1.8.16.custom.css');
		}

		if ($app->isSite()) {
			if ($this->p_params->get('load_cookie', '1') == '1') {
				$document->addScript($lib_folder.'/ui/external/jquery.cookie.js');
			}

			if ($this->p_params->get('load_fancybox', '1') == '1') {
				$document->addScript($lib_folder.'/fancybox/jquery.fancybox-1.3.4.pack.js');

				if ($browser == 'msie') {
					$document->addScript($lib_folder.'/fancybox/jquery.fancybox-1.3.4-iefix.js'); // Only IE
				}

				$document->addStyleSheet($lib_folder.'/fancybox/jquery.fancybox-1.3.4.css');
			}

			$document->addScript($lib_folder.'/tabs_site.js');

			if ($route == 'product/product') {
				$document->addScript($lib_folder.'/ajaxupload.js');
				$document->addScript($lib_folder.'/ui/jquery-ui-timepicker-addon.js');
			}

			if ($this->p_params->get('load_cycle', '1') == '1') {
				$document->addScript($lib_folder.'/jquery.cycle.js');
			}

			if ($this->p_params->get('load_jcarousel', '1') == '1') {
				$document->addScript($lib_folder.'/jquery.jcarousel.min.js');
			}

			if ($this->p_params->get('load_nivo_slider', '1') == '1') {
				$document->addScript($lib_folder.'/nivo-slider/jquery.nivo.slider.pack.js');
			}
		}

        if (AceShop::get()->isAdmin() || AceShop::get()->isAdmin('joomla')) {
			$document->addScript($lib_folder.'/tabs_admin.js');
			$document->addScript($lib_folder.'/ui/external/jquery.bgiframe-2.1.2.js');
			$document->addScript($lib_folder.'/superfish/js/superfish.js');

			if (empty($route) || $route == 'common/home') {
				if ($browser == 'msie') {
					$document->addScript($lib_folder.'/flot/excanvas.js'); // Only IE
				}

				$document->addScript($lib_folder.'/flot/jquery.flot.js');
			}

			if ($route == 'catalog/product/insert' || $route == 'catalog/product/update' || strpos($route, 'order')) {
				$document->addScript($lib_folder.'/ui/jquery-ui-timepicker-addon.js');
			}
		}

		return;
	}

    public function onAfterRender() {
        if (!self::_checkUp()) {
            return;
        }

        if ($this->p_params->get('remove_other_jq', '0') == '0') {
            return true;
        }
        
        $app = JFactory::getApplication();
        $body =& JResponse::getBody();

        $load_jquery = false;
        switch ($this->p_params->get('load_main', 1)) {
            case 1:
                $load_jquery = true;
                break;
            case 2:
                if ($app->isSite()) {
                    $load_jquery = true;
                }
                break;
            case 3:
                if (AceShop::get()->isAdmin() || AceShop::get()->isAdmin('joomla')) {
                    $load_jquery = true;
                }
                break;
        }

        if ($load_jquery == true) {
            $body = preg_replace("#([\\\/a-zA-Z0-9_:\.-]*)jquery([0-9\.-]|min|pack)*?.js#", "", $body); // find jQuery versions
            $body = str_ireplace('<script src="" type="text/javascript"></script>', "", $body); // remove newly empty scripts
            $body = preg_replace("#ACESHOPJQLIB#", $this->_jqpath, $body); // use our version of jQuery
        }

        if ($this->p_params->get('load_noconflict', '1') == '1') {
            $body = preg_replace("#([\\\/a-zA-Z0-9_:\.-]*)jquery[.-]noconflict\.js#", "", $body); // find potential jquery-noconflict.js
            $body = preg_replace("#jQuery\.noConflict\(\);#", "", $body); // remove all jQuery.noConflict();
            $body = preg_replace("#ACESHOPJQNOCONFLICT#", $this->_jqncpath, $body);
        }

        JResponse::setBody($body);

        return true;
    }

    public function _checkUp() {
        $app = JFactory::getApplication();
        $document = JFactory::getDocument();

        if ($document->getType() != 'html') {
            return false;
        }

        if (!file_exists(JPATH_ROOT.'/components/com_aceshop/aceshop/aceshop.php')) {
            return false;
        }
		
		if (!is_object($this->p_params)) {
			return false;
		}

        if ($this->p_params->get('only_aceshop', '1') == '1') {
            $option = JRequest::getCmd('option');
            $module = JModuleHelper::getModule('aceshop');

            if ($app->isSite()) {
                if ($option != 'com_aceshop' && (!is_object($module) || $module->id == 0)) {
                    return false;
                }
            }
            else {
                if ($option != 'com_aceshop') {
                    return false;
                }
            }
        }

        return true;
    }
}