<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('J2STORE_PRO', '1');
define('J2STORE_VERSION', '2.5.1');
define('J2STORE_DATE', '2013-04-01');