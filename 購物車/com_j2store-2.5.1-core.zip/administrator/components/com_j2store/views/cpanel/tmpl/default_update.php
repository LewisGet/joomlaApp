<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// no direct access
defined('_JEXEC') or die('Restricted access');
?>

<div class="j2store_update row-fluid">
	<div class="well">
		<h3>
			<?php echo JText::_('J2STORE_CURRENT_VERSION'); ?>
			<span class="pull-right"><?php echo $this->row->version; ?> </span>
		</h3>

	</div>
	<div class="well">
		<h3>NewsFeed</h3>
		<iframe
			src="http://j2store.org/updates/newsfeed/j2store_<?php echo $this->row->version; ?>_newsfeed.html">
		</iframe>
	</div>

	<div class="well">

		<h3>Credits</h3>
		<div>
			<p>
				Copyright &copy;
				<?php echo date('Y');?>
				-
				<?php echo date('Y')+5; ?>
				Sasivarnakumar / <a href="http://www.j2store.org"><b><span
						style="color: #000; display: inline;">J2</span><span
						style="color: #666666; display: inline;">Store</span> </b>.org</a>
			</p>
			<p>
				If you use J2Store, please post a rating and a review at the <a
					target="_blank"
					href="http://extensions.joomla.org/extensions/e-commerce/shopping-cart/19687">Joomla!
					Extensions Directory</a>.
			</p>
		</div>

		<div style="text-align: center;">
			<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
				<input type="hidden" name="cmd" value="_donations"> <input
					type="hidden" name="business" value="payment.j2store@gmail.com"> <input
					type="hidden" name="lc" value="US"> <input type="hidden"
					name="item_name" value="J2Store"> <input type="hidden"
					name="no_note" value="0"> <input type="hidden" name="currency_code"
					value="USD"> <input type="hidden" name="bn"
					value="PP-DonationsBF:btn_donate_SM.gif:NonHostedGuest"> <input
					type="image"
					src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif"
					border="0" name="submit"
					alt="PayPal - The safer, easier way to pay online!"> <img alt=""
					border="0"
					src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1"
					height="1">
			</form>
		</div>

	</div>

</div>
