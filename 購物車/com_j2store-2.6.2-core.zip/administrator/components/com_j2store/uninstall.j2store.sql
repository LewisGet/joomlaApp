DROP TABLE `#__j2store_zones`;
DROP TABLE `#__j2store_countries`;