<?php
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

/**
 * View class for a list of j2store.
 *
 * @package		Joomla.Administrator
 * @subpackage	com_j2store
 * @since		1.5
*/
class J2StoreViewProductfiles extends J2StoreView
{

}
