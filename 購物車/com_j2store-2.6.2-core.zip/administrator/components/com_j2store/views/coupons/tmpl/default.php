<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<div class="j2store">
<h3><?php echo JText::_('J2STORE_COUPONS');?></h3>
<div class="alert alert-block">
	<a class="link purple" target="_blank" href="http://j2store.org/download.html">
		<?php echo JText::_('J2STORE_PRO_VERSION_ONLY');?>
	</a>
</div>
</div>