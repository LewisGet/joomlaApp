<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('J2STORE_PRO', '0');
define('J2STORE_VERSION', '2.6.2');
define('J2STORE_DATE', '2013-09-27');