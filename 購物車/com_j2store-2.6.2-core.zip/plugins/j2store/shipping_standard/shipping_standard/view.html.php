<?php

defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ADMINISTRATOR.'/components/com_j2store/views/view.php');

/*this file isn't used anymore and is set to be removed'*/

class J2StoreViewShipping_Standard extends J2StoreView
{

}
