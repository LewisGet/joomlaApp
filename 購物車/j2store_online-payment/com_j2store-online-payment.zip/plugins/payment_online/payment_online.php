<?php 
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 1.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/
 
/** ensure this file is being included by a parent file */
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2store'.DS.'library'.DS.'plugins'.DS.'payment.php');

class plgJ2StorePayment_online extends J2StorePaymentPlugin
{
	/**
	 * @var $_element  string  Should always correspond with the plugin's filename, 
	 *                         forcing it to be unique 
	 */
    var $_element    = 'payment_online';

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgJ2StorePayment_online(& $subject, $config) 
	{
		parent::__construct($subject, $config);
		$this->loadLanguage( '', JPATH_ADMINISTRATOR );
	}

   
    /**
     * Prepares the payment form
     * and returns HTML Form to be displayed to the user
     * generally will have a message saying, 'confirm entries, then click complete order'
     * 
     * @param $data     array       form post data
     * @return string   HTML to display
     */
    function _prePayment( $data )
    {
        // prepare the payment form
        

        $vars = new JObject();
        $vars->order_id = $data['order_id'];
        $vars->orderpayment_id = $data['orderpayment_id'];
        $vars->orderpayment_amount = $data['orderpayment_amount'];
        $vars->orderpayment_type = $this->_element;
        $vars->offline_payment_method = JRequest::setVar('offline_payment_method', $data);
        
        $html = $this->_getLayout('prepayment', $vars);
        return $html;
    }
    
    /**
     * Processes the payment form
     * and returns HTML to be displayed to the user
     * generally with a success/failed message
     *  
     * @param $data     array       form post data
     * @return string   HTML to display
     */
    function _postPayment( $data )
    {
        // Process the payment        
        $orderpayment_id = JRequest::getVar('orderpayment_id');
        $offline_payment_method = JRequest::getVar('offline_payment_method');
        $formatted = array( 'offline_payment_method' => $offline_payment_method ); 
       // load the orderpayment record and set some values
        JTable::addIncludePath( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2store'.DS.'tables' );
        $orderpayment = JTable::getInstance('Orders', 'Table');
        
        //remove this after live.
        //$orderpayment_id = substr($orderpayment_id, 2, 3);
               
        $orderpayment->load( $orderpayment_id );
        $orderpayment->transaction_details = implode("\n", $formatted); 
        //$orderpayment->transaction_status = JText::_('Pending_Payment'); 
        //$orderpayment->order_state = JText::_('Pending');
        $orderpayment->transaction_status = 'Pending_Payment'; 
        $orderpayment->order_state ='Pending';
        $orderpayment->order_state_id = 4; // PENDING
       
	    
       // save the orderpayment
        if ($orderpayment->save()) {
			JLoader::register( 'J2StoreHelperCart', JPATH_SITE.DS.'components'.DS.'com_j2store'.DS.'helpers'.DS.'cart.php');
			 // remove items from cart
            J2StoreHelperCart::removeOrderItems( $orderpayment->id );			
        }
        else
        {
        	$errors[] = $orderpayment->getError(); 
        }



        //add by jerry
		$user = JFactory::getUser();
		$userprofile = JUserHelper::getProfile($user->id);
		$vars = new JObject();
		$vars->orderpayment_id = $orderpayment->id;
		$vars->user_name=$user->name;
		$vars->user_email=$user->email;
		$vars->user_phone=$userprofile->profile['phone'];
		$vars->ezship_email=$this->params->get('ezmail');
		$vars->ret_url=JURI::base().'index.php/component/nicepayment';
		$vars->orderpayment_amount =ceil($orderpayment->orderpayment_amount);
		$vars->paymethod = $offline_payment_method;
		
		$ec_message='';
		if($offline_payment_method=='ecbank')	$ec_message=$this->makeEcbank($orderpayment->orderpayment_amount,$orderpayment->id);
		//end by jerry



         // let us inform the user that the order is successful
        require_once (JPATH_SITE.DS.'components'.DS.'com_j2store'.DS.'helpers'.DS.'orders.php');
        J2StoreOrdersHelper::sendUserEmail($orderpayment->user_id, $orderpayment->order_id, $orderpayment->transaction_status, $orderpayment->order_state, $orderpayment->order_state_id);
        
        // display the layout
        $html = $this->_getLayout('postpayment', $vars);
        
        // append the article with offline payment information
        $html .= $this->_displayArticle();
        
        return $html.$ec_message;
    }
    
    /**
     * Prepares variables and 
     * Renders the form for collecting payment info
     * 
     * @return unknown_type
     */
    function _renderForm( $data )
    {
    	$user = JFactory::getUser();  	
        $vars = new JObject();
        $vars->payment_method   = $this->_paymentMethods();
        
        $html = $this->_getLayout('form', $vars);
        
        return $html;
    }
    
    /**
     * Verifies that all the required form fields are completed
     * if any fail verification, set 
     * $object->error = true  
     * $object->message .= '<li>x item failed verification</li>'
     * 
     * @param $submitted_values     array   post data
     * @return unknown_type
     */
    function _verifyForm( $submitted_values )
    {
        $object = new JObject();
        $object->error = false;
        $object->message = '';
        $user = JFactory::getUser();
 
        foreach ($submitted_values as $key=>$value) 
        {
            switch ($key) 
            {
                case "offlinetype":
                    if (!isset($submitted_values[$key]) || !JString::strlen($submitted_values[$key])) 
                    {
                        $object->error = true;
                        $object->message .= "<li>".JText::_( "J2STORE_online_PAYMENT_TYPE_INVALID" )."</li>";
                    } 
                  break;
                default:
                  break;
            }
        }   
            
        return $object;
    }
	
   
    /**
     * Generates a dropdown list of valid payment methods
     * @param $fieldname
     * @param $default
     * @param $options
     * @return unknown_type
     */
    function _paymentMethods( $field='offline_payment_method', $default='', $options='' )
    {
        $types = array();
         if ($this->params->get('enable_ec')) {
            $types[] = JHTML::_('select.option', 'ecbank','ATM轉帳付款' );    
        }
        if ($this->params->get('enable_ez')) {
            $types[] = JHTML::_('select.option', 'ezship','全家超商到店取貨付款');    
        }
        if(count($types)) {       
			$return = JHTML::_('select.genericlist', $types, $field, $options, 'value','text', $default);
		} else {
			$return = '';
		} 
        return $return;
    }
	
	//add by jerry
	function makeEcbank($deposit,$idbook){

		$expire_day =$this->params->get('days');
		$mer_id = $this->params->get('pid');
		$enc_key =$this->params->get('keycode');
		$setbank ='ESUN';
		$ok_url =rawurlencode(JURI::base().'index.php?option=com_nicepayment');
		$ecbank_auth_url = 'https://ecbank.com.tw/gateway.php?payment_type=vacc'.
				 '&mer_id='.$mer_id.
				 '&setbank='.$setbank.
				 '&enc_key='.$enc_key.
				 '&amt='.ceil($deposit).
				 '&expire_day='.$expire_day.
				 '&od_sob='.$idbook.
				 '&ok_url='.$ok_url;

		$results=$ecbank_auth_url;
		//file_put_contents('ecbankpay.log',$results."\r\n",FILE_APPEND | LOCK_EX  );
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$ecbank_auth_url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$strAuth  = curl_exec($ch);
		curl_close($ch);
		parse_str($strAuth, $res);
		$results = '';
		if(!isset($res['error']) || $res['error'] != '0'){
		   $results='獲取虛擬帳號失敗！';
		}else {
		   //implode(',',$res);
		   $oid=explode('-',$idbook);
		   $results='<div style="margin: 0 auto;width:520px;font-size: 14px;color:#313131;line-height:36px;">
<p>感謝您的惠顧，請於<span style="color:#F00;font-size:16px;font-weight:bold;">'.date('Y年m月d日 G時i分',mktime(date("G")+8, date("i"), 0, date("m"), date("d")+$expire_day, date("Y"))).' </span>以前，將款項匯入以下帳號</p>
<table width="100%" cellspacing="1" cellpadding="5" style="background:#ccc;border:solid 1px #ccc;">
 <tr><td width="100" bgcolor="#eeeeee">交易編號</td><td bgcolor="#ffffff">'.$res['tsr'].'</td></tr>
 <tr><td bgcolor="#eeeeee">訂單編號</td><td bgcolor="#ffffff">'.($oid[0]+1000).'</td></tr>
 <tr><td bgcolor="#eeeeee">轉帳銀行代號</td><td style="color:#36C;background:white;">'.$res['bankcode'].'</td></tr>
 <tr><td bgcolor="#eeeeee">轉帳帳號</td><td style="color:#36C;background:white;">'.$res['vaccno'].'</td></tr>
 <tr><td bgcolor="#eeeeee">付款金額</td><td style="color:#36C;background:white;">新台幣 NT$'.$deposit.'元</td></tr>
 <tr><td></td><td></td></tr>
 <tr><td></td><td></td></tr>
</table>
<div id="ps" style="margin-top:15px;font-size:12px;line-height:22px;">
  	<li>此匯款帳號是你本次消費所專屬的，請勿做其他次消費使用。同時請務必抄下或是用手機<br />拍照此匯款帳號，以便去做匯款，若此頁面關閉就再也無法找到此匯款帳號了喔！</li>
	<li>繳款期限不受例假日所影響，只要於繳款期限內轉帳即可。</li>
  </div>
</div>';

		}
		
		return $results;
	}
	//end by jerry

}
