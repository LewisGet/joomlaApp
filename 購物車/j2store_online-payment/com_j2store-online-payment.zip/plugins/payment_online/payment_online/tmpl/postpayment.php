<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 1.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

 defined('_JEXEC') or die('Restricted access'); ?>

<div class="note"><?php echo JText::_( "J2STORE_OFFLINE_PAYMENT_SUBMITTED_MESSAGE" ); ?></div>
<?php
if($vars->paymethod=='ezship'){
?>
<form method="post" name="simulation_from" action="http://www.ezship.com.tw/emap/rv_request_web.jsp" <?php if($vars->offline_payment_method=='ecbank') {echo 'style="display:none"';} ?>>
	<input type="hidden" name="rv_name" value="<?php echo @$vars->user_name; ?>"> <!-- 取件人姓名 -->
    <input type="hidden" name="rv_email" value="<?php echo @$vars->user_email; ?>"> <!-- 取件人email -->
    <input type="hidden" name="rv_mobil" value="<?php echo @$vars->user_phone; ?>"> <!-- 取件人行動電話 -->
    <input type="hidden" name="order_id" value="<?php echo @$vars->orderpayment_id; ?>"> <!-- 購物網站自行產生之訂單編號 -->
    <input type="hidden" name="su_id"  value="<?php echo @$vars->ezship_email; ?>"> <!-- 業主在 ezShip 使用的帳號 -->
    <input type="hidden" name="rv_amount" value="<?php echo @$vars->orderpayment_amount; ?>"><!-- 金額 -->
    <input type="hidden" name="webtemp" value="<?php echo @$vars->user_email; ?>"><!-- 網站所需額外判別資料。ezShip 將原值回傳，供網站判別用 -->
    <input type="hidden" name="rturl"  value="<?php echo @$vars->ret_url; ?>"><!-- 回傳路徑及程式名稱 -->
	<span style="font-weight:bold;color:red">重要提示：請選擇取件門市，否則無法寄出！</span>&nbsp;&nbsp;<input name="Submit2" type="submit" value="選擇門市">
</form>
<?php
}
?>