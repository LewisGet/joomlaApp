<?php
/*------------------------------------------------------------------------
# com_j2store - J2 Store v 1.0
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2012 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/


defined('_JEXEC') or die('Restricted access'); ?>


    <div class="note">
        您選擇了線上付款，請選擇下一步完成您的訂單！
    
        <p>
            <strong>線上付款方式：</strong> 
            <?php echo JText::_( $vars->offline_payment_method ); ?>
        </p>
    </div>

<form action="<?php echo JRoute::_( "index.php?option=com_j2store&view=checkout" ); ?>" method="post" name="adminForm" enctype="multipart/form-data">   
    <input type='hidden' name='offline_payment_method' value='<?php echo @$vars->offline_payment_method; ?>'>
    <input type="submit" id="confirmbtn" class="button" value="<?php echo JText::_('J2STORE_CLICK_TO_COMPLETE_ORDER'); ?>" />
    <input type='hidden' name='order_id' value='<?php echo @$vars->order_id; ?>'>
    <input type='hidden' name='orderpayment_id' value='<?php echo @$vars->orderpayment_id; ?>'>
    <input type='hidden' name='orderpayment_type' value='<?php echo @$vars->orderpayment_type; ?>'>
    <input type='hidden' name='task' value='confirmPayment'>
</form>
<?php
/*
<script>
var paymethod='<?php echo @$vars->offline_payment_method; ?>';
if (paymethod=='ezship') document.adminForm.confirmbtn.disabled=true;
</script>
*/
?>