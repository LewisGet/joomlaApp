<?php
/*------------------------------------------------------------------------
# com_nicepayment - v 1.0
# email:jerry@cmsart.net
-------------------------------------------------------------------------*/


// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.installer.installer');

$db = & JFactory::getDBO();
$status = new JObject();
//$status->modules = array();
$status->plugins = array();
$src = $this->parent->getPath('source');

// install plugins

$plugins = &$this->manifest->xpath('plugins/plugin');
foreach($plugins as $plugin){

	$pname = $plugin->getAttribute('plugin');	
	$pgroup = $plugin->getAttribute('group');
	$path = $src.DS.'plugins'.DS.$pname;
	$installer = new JInstaller;
	$result = $installer->install($path);
	$status->plugins[] = array('name'=>$pname,'group'=>$pgroup, 'result'=>$result);
	//if($pgroup=='niceworld') $pgroup='j2store';
	$query = "UPDATE #__extensions SET enabled=1 WHERE type='plugin' AND element=".$db->Quote($pname)." AND folder=".$db->Quote($pgroup);
	$db->setQuery($query);
	$db->query();
}

?>

<?php $rows = 0;?>
<table class="adminlist">
	<thead>
		<tr>
			<th class="title" colspan="2"><?php echo JText::_('Extension'); ?></th>
			<th width="30%"><?php echo JText::_('Status'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="3"></td>
		</tr>
	</tfoot>
	<tbody>
		<tr class="row0">
			<td class="key" colspan="2"><?php echo 'J2 Store'.JText::_('Component'); ?>
			</td>
			<td><strong><?php echo JText::_('Installed'); ?> </strong></td>
		</tr>

		<?php if (count($status->plugins)) : ?>
		<tr>
			<th><?php echo JText::_('Plugin'); ?></th>
			<th><?php echo JText::_('Group'); ?></th>
			<th></th>
		</tr>
		<?php foreach ($status->plugins as $plugin) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo ucfirst($plugin['name']); ?></td>
			<td class="key"><?php echo ucfirst($plugin['group']); ?></td>
			<td><strong><?php echo ($plugin['result'])?JText::_('Installed'):JText::_('Not installed'); ?>
			</strong></td>
		</tr>
		<?php endforeach; ?>
		<?php endif; ?>
	</tbody>
</table>
