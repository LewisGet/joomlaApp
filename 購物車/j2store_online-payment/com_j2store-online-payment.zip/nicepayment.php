<?php
JTable::addIncludePath( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2store'.DS.'tables' );
$order = JTable::getInstance('Orders', 'Table');
if(isset($_POST["mer_id"])){
	paymentresult($order);
}elseif(isset($_REQUEST["st_cate"])){
	/*
	order_id 	= 訂單編號
	st_cate 	= 超商別
	st_code 	= 門市代碼
	st_name 	= 門市名稱
	st_addr 	= 門市地址
	st_tel 	= 門市電話
	webtemp 	= 網站所需額外判別資料。ezShip 將原值回傳，供網站判別使用。
	sn_id 	= 此筆資料在ezShip的寄件編號。如資料有誤，系統將回傳八個零
	*/
	$order_id=isset($_REQUEST["order_id"]) ? $_REQUEST["order_id"] : "";
	$st_cate=isset($_REQUEST["st_cate"]) ? $_REQUEST["st_cate"] : "";
	$st_code=isset($_REQUEST["st_code"]) ? $_REQUEST["st_code"] : "";
	$st_name=isset($_REQUEST["st_name"]) ? $_REQUEST["st_name"] : "";
	$st_addr=isset($_REQUEST["st_addr"]) ? $_REQUEST["st_addr"] : "";
	$st_tel =isset($_REQUEST["st_tel"]) ? $_REQUEST["st_tel"] : "";
	$webtemp=isset($_REQUEST["webtemp"]) ? $_REQUEST["webtemp"] : "";
	$sn_id=isset($_REQUEST["sn_id"]) ? $_REQUEST["sn_id"] : "";

	$results='<div style="margin: 0 auto;width:520px;font-size: 14px;color:#313131;line-height:36px;">
<p>感謝您的惠顧，請記下您的取貨資料！</p>
<table width="100%" cellspacing="1" cellpadding="5" style="background:#ccc;border:solid 1px #ccc;">
 <tr><td width="100" bgcolor="#eeeeee">訂單編號</td><td bgcolor="#ffffff">'.$order_id.'</td></tr>
 <tr><td bgcolor="#eeeeee">寄件編號</td><td bgcolor="#ffffff">'.$sn_id.'</td></tr>
 <tr><td bgcolor="#eeeeee">取件門市類別</td><td bgcolor="#ffffff">'.$st_cate.'</td></tr>
 <tr><td bgcolor="#eeeeee">取件門市代號</td><td style="color:#36C;background:white;">'.$st_code.'</td></tr>
 <tr><td bgcolor="#eeeeee">取件門市名稱</td><td style="color:#36C;background:white;">'.iconv('big5','utf-8',urldecode($st_name)).'</td></tr>
 <tr><td bgcolor="#eeeeee">取件門市地址</td><td style="color:#36C;background:white;">'.iconv('big5','utf-8',urldecode($st_addr)).'</td></tr>
 <tr><td bgcolor="#eeeeee">取件門市電話</td><td style="color:#36C;background:white;">'.$st_tel.'</td></tr>
 <tr><td></td><td></td></tr>
 <tr><td></td><td></td></tr>
</table></div>';

	if($sn_id=='00000000') echo '讀取超商取貨失敗！';
	elseif(!empty($sn_id) && !empty($order_id)){
		$order->load($order_id);
		$order->order_state = 'Confirmed';
		$order->order_state_id = '1';
		$order->save();
		if(!empty($webtemp)){
		$mainframe =& JFactory::getApplication();
		$config     = &JComponentHelper::getParams('com_j2store');
		$admin_emails = $config->get('admin_email') ;
		$admin_emails = explode(',',$admin_emails ) ;
		$mailfrom   = $config->get( 'emails_defaultemail', $mainframe->getCfg('mailfrom') );
		$fromname   = $config->get( 'emails_defaultname', $mainframe->getCfg('fromname') );

		$mailer =& JFactory::getMailer();
		$mode = 1;
		$mailer->addRecipient($webtemp);
			//   $mailer->addCC( $config->get('admin_email'));
			$mailer->addCC( $admin_emails );
			$mailer->setSubject('訂單編號：'.$order_id.'，超商取貨訊息！');
			$mailer->setBody($results);
			$mailer->IsHTML(1);
			$mailer->setSender(array( $mailfrom, $fromname ));
			$mailer->send();
		}
		echo $results;
	}
}else{
	echo '<a href="/index.php">返回</a>';
}

function paymentresult($o){
	$ncp=& JPluginHelper::getPlugin('j2store', 'payment_online');
	$para=json_decode($ncp->params);
	$enc_key =$para->keycode;
	$mer_id=isset($_POST["mer_id"]) ? $_POST["mer_id"] : "";
	$payment_type=isset($_POST["payment_type"]) ? $_POST["payment_type"] : "";
	$tsr=isset($_POST["tsr"]) ? $_POST["tsr"] : "";
	$od_sob=isset($_POST["od_sob"]) ? $_POST["od_sob"] : "";
	$amt=isset($_POST["amt"]) ? $_POST["amt"] : "";
	$expire_date=isset($_POST["expire_date"]) ? $_POST["expire_date"] : "";
	$succ=isset($_POST["succ"]) ? $_POST["succ"] : "";
	$payer_bank=isset($_POST["payer_bank"]) ? $_POST["payer_bank"] : "";
	$payer_acc=isset($_POST["payer_acc"]) ? $_POST["payer_acc"] : "";
	$proc_date=isset($_POST["proc_date"]) ? $_POST["proc_date"] : "";
	$proc_time=isset($_POST["proc_time"]) ? $_POST["proc_time"] : "";
	$tac=isset($_POST["tac"]) ? $_POST["tac"] : "";
	$content = $mer_id.'*'.$payment_type.'*'.$tsr.'*'.$od_sob.'*'.$amt.'*'.$expire_date.'*'.$succ.'*'.$payer_bank.'*'.$payer_acc.'*'.$proc_date.'*'.$proc_time.'*'.$tac;
	//file_put_contents('ecbankpay.log',$content."\r\n",FILE_APPEND | LOCK_EX  );
	if(str_replace('*','',$content)!="" && $succ==1){
		$serial = trim($proc_date.$proc_time.$tsr);
		$ws_url = 'https://ecbank.com.tw/web_service/get_outmac_valid.php?key='.$enc_key.
			  '&serial='.$serial.
			  '&tac='.$tac;
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$ws_url);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$tac_valid  = curl_exec($ch);
			curl_close($ch);
			
		
		if($tac_valid == 'valid=1'){
			//$order =& $this->_order;
			$o->load($od_sob);
			//file_put_contents('ecbankpay.log',$o->order_state."\r\n",FILE_APPEND | LOCK_EX  );
			$o->order_state = 'Confirmed';
			$o->order_state_id = '1';
			$o->save();
			echo 'OK';
		}
		else{
			echo 'check error!';
		}
	}
}

?>