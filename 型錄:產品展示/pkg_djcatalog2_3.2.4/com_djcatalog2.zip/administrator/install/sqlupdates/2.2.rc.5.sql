CREATE TABLE IF NOT EXISTS `#__djc2_items_categories` (
  `item_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) DEFAULT CHARSET=utf8;
