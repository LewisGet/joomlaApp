ALTER TABLE `#__djc2_categories` ADD `params` TEXT NULL;
