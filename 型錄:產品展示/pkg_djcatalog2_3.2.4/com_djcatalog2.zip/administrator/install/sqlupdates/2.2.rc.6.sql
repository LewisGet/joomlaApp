CREATE TABLE IF NOT EXISTS `#__djc2_items_related` (
  `item_id` int(11) NOT NULL,
  `related_item` int(11) NOT NULL
) DEFAULT CHARSET=utf8;
