ALTER TABLE `#__djc2_items` CHANGE `description` `description` MEDIUMTEXT CHARACTER SET utf8 NULL DEFAULT NULL;

ALTER TABLE `#__djc2_categories` CHANGE `description` `description` MEDIUMTEXT CHARACTER SET utf8 NULL DEFAULT NULL;

ALTER TABLE `#__djc2_producers` CHANGE `description` `description` MEDIUMTEXT CHARACTER SET utf8 NULL DEFAULT NULL;
