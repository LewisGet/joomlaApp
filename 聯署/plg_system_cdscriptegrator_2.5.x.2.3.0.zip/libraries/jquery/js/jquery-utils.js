// no conflict mode
jQuery.noConflict();
jQuery.uiBackCompat = false;