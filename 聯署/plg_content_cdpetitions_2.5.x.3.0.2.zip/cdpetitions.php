<?php
/**
 * Core Design Petitions plugin for Joomla! 2.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		2.5.x.3.0.2
 * @copyright	Copyright (C) 2007 - 2012 Great Joomla!, http://www.greatjoomla.com
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPL 3
 * 
 * This file is part of Great Joomla! extension.   
 * This extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die;

// Import library dependencies
jimport('joomla.plugin.plugin');
jimport('joomla.enviroment.request');
jimport('joomla.mail.helper');
jimport('joomla.utilities.string');
jimport('joomla.filesystem.file');

class PlgContentCDPetitions extends JPlugin
{
	/**
	 * Live path
	 * @var string
	 */
	private $livepath = '';
	
	/**
	 * JScriptegrator plugin instance
	 * @var JScriptegrator
	 */
	private $JScriptegrator	= null;
	
	/**
	 * Use Ajax or not
	 * @var boolean
	 */
	private $useAjax = true;
	
	/**
	 * DB object
	 * @var JDatabase
	 */
	private	$db = null;
	
	/**
	 * Form ACTION redirect URL
	 * @var string
	 */
	private $formActionURL = '';
	
	/**
	 * Redirection URL
	 * @var string
	 */
	private $redirectionURL = '';
	
	/**
	 * Joomla! Application
	 * @var JApplication
	 */
	private $JApplication = null;

	/**
	 * Joomla! Session
	 * @var JSession
	 */
	private $JSession = null;

	/**
	 * Joomla! Document
	 * @var JDocument
	 */
	private $JDocument = null;
	
	/**
	 * Joomla! User
	 * @var JUser
	 */
	private $JUser = null;
	
	/**
	 * Joomla! Application Input
	 * @var JInput
	 */
	private $JInput = null;
	
	/**
	 * Random string
	 * @var string
	 */
	private $random = '';
	
	/**
	 * Petition settings
	 * @var JRegistry
	 */
	private $settings = null;

    /**
     * Current article
     * @var null
     */
    private $article = null;

    /**
     * Unique ID
     * @var string
     */
    private $unique_id = '';

    /**
     * Set if plugin is calling from a single template or not
     * @var bool
     */
    private $isSingleTemplate = false;

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args (void) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	public function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);
		
		$this->loadLanguage();
	}

	/**
     * Call onContentPrepare function
     * Method is called by the view.
	 *
	 * @param	string	The context of the content being passed to the plugin.
	 * @param	object	The content object.  Note $article->text is also available
	 * @param	object	The content params
	 * @param	int		The 'page' number
	 * @since	1.6
	 */
	public function onContentPrepare($context, &$article, &$params, $page = 0)
	{
		// Don't run this plugin when the content is being indexed
		if ($context === 'com_finder.indexer') {
			return true;
		}

		// no petition
		if (JString::strpos($article->text, '{petition') === false) return false;

		$this->JApplication = JFactory::getApplication();
        $this->JInput = $this->JApplication->input;
        $this->JSession = JFactory::getSession();

		try
		{
			if (!class_exists('JScriptegrator'))
			{
			    throw new Exception(JText::_('PLG_CONTENT_CDPETITIONS_ENABLE_SCRIPTEGRATOR'), 404);
			}
			
			$this->JScriptegrator = JScriptegrator::getInstance('2.5.x.2.2.9');
			$this->JScriptegrator->importLibrary(
			array(
				'jQuery'
			));
			
			if ($message = $this->JScriptegrator->getError())
			{
			    throw new Exception($message, 500);
			}
		}
		catch (Exception $e)
		{
			$this->JApplication->enqueueMessage($e->getMessage(), 'error');
			return false;
		}

        $this->article = $article;
		
		$this->displayFields = array();
		$this->requiredFields = array();
		
		$this->JUser = JFactory::getUser();
		$this->livepath = JURI::root(true);
		$this->useAjax = (boolean) $this->params->get('use_ajax', false);
		
		$this->formActionURL = $this->JScriptegrator->buildURL('html', false, $this->_name);
		$this->redirectionURL = $this->JScriptegrator->buildURL('url', false, $this->_name);

		// include tables
		JTable::addIncludePath(array(
			dirname(__FILE__) . DS  . 'table')
		);
		
		$this->db = $this->dbInstance();
		
		$layout = $this->params->get('layout', 'default');
		
		$this->JDocument = JFactory::getDocument(); // set document
		
		// add general script declaration
		$this->JDocument->addScript($this->livepath . '/plugins/content/' . $this->_name . '/tmpl/' . $layout . '/js/' . $this->_name . '.js');
		
		// add CSS stylesheet
		$this->JDocument->addStyleSheet($this->livepath . '/plugins/content/' . $this->_name . '/tmpl/' . $layout . '/css/' . $this->_name . '.css');
		
		// add CSS stylesheet for RTL languages
		if ($this->JDocument->direction === 'rtl')
		{
			$this->JDocument->addStyleSheet($this->livepath . '/plugins/content/' . $this->_name . '/tmpl/' . $layout . '/css/' . $this->_name . '_rtl.css');
		}

        // define the regular expression
        $regex = '#{petition(.*?)?}#is';

        $article->text = preg_replace_callback($regex, array($this, 'replacer'), $article->text);

        // check Facebook status
        if ((string)$this->settings->get( 'facebook.signup.APP_ID', '' ) and $facebook_error = $this->JInput->get('error', '', 'string'))
        {
            $facebook_error_description = $this->JInput->get->get('error_description', '', 'string');
            if($facebook_error_description)
            {
                $facebook_redirection_url = $this->JScriptegrator->buildURL('redirect', false, array('error_reason', 'error', 'error_description', 'state'));
                $this->JApplication->redirect($facebook_redirection_url, $facebook_error_description, 'error');
                return false;
            }
        }
	}
	
	/**
	 * Replacer
	 * 
	 * @param $match
	 * 
	 * @return string
	 */
	private function replacer(&$match)
	{
        $this->unique_id = $this->JScriptegrator->randomString(5);

		$settings = new JRegistry((isset($match[1]) ? JUtility::parseAttributes(trim($match[1])) : ''));

		// petition id
		try
		{
			if (!$settings->get('identifier', ''))
			{
			    throw new Exception(JText::_('PLG_CONTENT_CDPETITIONS_NO_IDENTIFIER'), 500);
			}
		}
		catch (Exception $e)
		{
			$this->JApplication->enqueueMessage($e->getMessage(), 'error');
			return false;
		}
		
		$this->settings = $this->loadSettings($settings->get('identifier', ''));
        $this->settings->merge($settings);

        if (!isset($this->article->id) and $article_id = $this->settings->get('article_id', 0))
        {
            $this->article = $this->loadArticle($article_id);
        }

        if ($template = (string)$this->settings->get('template', ''))
        {
            $template = 'template_' . $template;
            $this->isSingleTemplate = true;
        }
        else
        {
            $template = 'view';
        }

		// process request
		if ($task = $this->JInput->get($this->_name . '_task', '', 'cmd'))
		{
			$response 	= array();
			$status 	= 'error';
			$content 	= '';
			$format		= 'json';
			
			if (is_callable(array($this, $task)))
			{
				$response = call_user_func(array($this, $task));
				
				if (!is_array($response))
				{
					// only string, create a "success" array
					$response = array('success', $response);
				}
				
				if (isset($response[0])) $status = trim($response[0]);
				if  (isset($response[1])) $content = trim($response[1]);
				if (isset($response[2])) $format = trim($response[2]);
				
				switch($format)
				{
					case 'json':
					default:
		    			$response = array();
						$response['status'] = $status;
						$response['content'] = $content;

						@ob_end_clean(); // clean potencial buffer

						if (!headers_sent())
						{
							// if headers not sent yet, make sure that the response is type of JSON
							header("Content-Type: application/json");
						}

		    			$this->JApplication->close(json_encode($response));
						break;
						
					case 'text':

						if ($status === 'success')
						{
							$status = 'message'; // Joomla! format for success in enqueue message
						}
						$this->JApplication->redirect($this->redirectionURL, $content, $status);
						
						break;
				}
			}
            jexit(); // make sure plugin terminates if related task is called but function is not registered
		}

		try
		{
			$this->JScriptegrator->importLibrary(
			array(
				'jQueryUI' => array(
					'uitheme' => (string)$this->settings->get('uitheme', 'ui-lightness')
				)
			));
			
			if ($message = $this->JScriptegrator->getError())
			{
			    throw new Exception($message, 500);
			}
		}
		catch (Exception $e)
		{
			$this->JApplication->enqueueMessage($e->getMessage(), 'error');
			return false;
		}

		// petition goal
		$this->goal = (int)$this->settings->get('goal', 0);
		
		// display fields
		$fields = (array)$this->settings->get('fields', array());

		$this->total = (int) $this->getTotal();

		// Facebook data - only in case that name and email fields are empty
		$facebook_data = $this->facebookData();
		if ((string)$this->settings->get('facebook.signup.APP_ID', '') and is_array($facebook_data))
		{
            if (isset($facebook_data['name']) and $facebook_data['name'])
            {
                $this->JSession->set($this->_name . '_fullname', $facebook_data['name']);
            }
            if (isset($facebook_data['email']) and $facebook_data['email'])
            {
                $this->JSession->set($this->_name . '_email', $facebook_data['email']);
            }
		}

        // user is logged in, prefill name and email field
        if (!$this->JUser->get('guest'))
        {
            if (!$this->JSession->get($this->_name . '_fullname'))
            {
                $this->JSession->set($this->_name . '_fullname', $this->JUser->get('name', ''));
            }
            if (!$this->JSession->get($this->_name . '_email'))
            {
                $this->JSession->set($this->_name . '_email', $this->JUser->get('email', ''));
            }
        }

		$script_options = array();
		
		$script_options[] = "name : '" . $this->_name . "'";
		
		if ($this->goal and (int)$this->settings->get('show_collected', 1))
		{
			$progressbar_value = round($this->total / $this->goal * 100);
			$script_options[] = "progressbarvalue : " . ($progressbar_value < 100 ? $progressbar_value : 100);
		}
		
		$script_options[] = "isAuthorized : " . ($this->authorisedTo('manage') ? 'true' : 'false');
		$script_options[] = "useAjax : " . ($this->useAjax ? 'true' : 'false');
		$script_options[] = "uitheme : '" . (string)$this->settings->get('uitheme', 'ui-lightness') . "'";
		
		$lang_array = array();
		$lang_array[] = "language : {";
		$lang_array[] = "PLG_CONTENT_CDPETITIONS_CONFIRMATION : '" . JText::_('PLG_CONTENT_CDPETITIONS_CONFIRMATION', true) . "',";
		$lang_array[] = "PLG_CONTENT_CDPETITIONS_UTILITIES_ENTER_PETITION_ID : '" . JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_ENTER_PETITION_ID', true) . "',";
		$lang_array[] = "PLG_CONTENT_CDPETITIONS_EMPTY_VALUE : '" . JText::_('PLG_CONTENT_CDPETITIONS_EMPTY_VALUE', true) . "', ";
		$lang_array[] = "PLG_CONTENT_CDPETITIONS_INTERACTIVE_OK : '" . JText::_('PLG_CONTENT_CDPETITIONS_INTERACTIVE_OK', true) . "'";
		$lang_array[] = "}";
		
		$script_options[] = implode(' ', $lang_array);
		unset($lang_array);

		// append custom script to header (just once)
		$this->JDocument->addScriptDeclaration("
		<!--
		if (typeof(jQuery) === 'function') {
			jQuery(document).ready(function($){
				if ($.fn." . $this->_name . ") {
					$('#" . $this->_name . "_" . $this->unique_id . "')." . $this->_name . "({
						" . implode(", ", $script_options) . "
					});
				}
			});
		}
		// -->
		");
		
		$limitstart = (int) $this->JInput->get->get($this->_name . '_limitstart', null, 'int');
		
		$signatures = $this->getSignatures($limitstart, (int)$this->settings->get('limit_per_page', 20));

		$this->random = $this->JScriptegrator->randomString(5);

        // layout
        if (!$layoutpath = $this->getLayoutPath($template)) return false;


		$tmpl = '';
		ob_start();
			require $layoutpath;
			$tmpl .= ob_get_contents();
		ob_end_clean();

		return $this->JScriptegrator->compressHTML($this->replaceVariables($tmpl));
	}

    /**
     * Get all signatures
     * @param null $limitstart
     * @param null $limit_per_page
     * @return bool
     * @throws JDatabaseException
     */
	private function getSignatures($limitstart = null, $limit_per_page = null)
	{
		$data = array();
		$data['identifier'] = $this->settings->get('identifier', '');
		$data['published'] = 1;

        $this->settings->set('limit_per_page', $limit_per_page);

        $data['settings'] = $this->settings;

		try
		{
			if (!$this->db->bind($data))
			{
			    throw new JDatabaseException($this->db->getError(), 500);
			}
			$signatures = $this->db->getRows($limitstart);
			
			 if ($error = $this->db->getError()) {
				throw new JDatabaseException($error, 500);
			}
		}
		catch (JDatabaseException $e)
		{
			JFactory::getApplication()->enqueueMessage($e->getMessage(), 'error');
			return false;
		}
		
		return $signatures;
	}
	
    /**
     * Get total rows
     * @return int
     * @throws JDatabaseException
     */
	private function getTotal()
	{
		$total = 0;
		
		$data = array();
		$data['identifier'] = $this->settings->get('identifier', '');;

		try
		{
			if (!$this->db->bind($data))
			{
			    throw new JDatabaseException($this->db->getError(), 500);
			}
			$total = (int) $this->db->getTotal();

			 if ($error = $this->db->getError()) {
				throw new JDatabaseException($error, 500);
			}
		}
		catch (JDatabaseException $e)
		{
			JFactory::getApplication()->enqueueMessage($e->getMessage(), 'error');
			return 0;
		}

		return (int) $total;
	}
	
	/**
	 * Get fields
	 * @param	string	$file
	 * @return 	array
	 */
	private function getSettingsFields($file = '')
	{
		if (!$file)
		{
			$file = dirname(__FILE__) . DS . 'data' . DS . 'fields.xml';
		}
		if (JFile::exists($file))
		{
			$file = dirname(__FILE__) . DS . 'data' . DS . 'fields.xml';
		}
		
		
		$xml = JFactory::getXML($file, true);
		
		try
		{
			if (!$xml)
			{
				throw new Exception(JText::sprintf('JLIB_INSTALLER_ERROR_LOAD_XML', $file), 404);
			}
		}
		catch (Exception $e)
		{
			$this->JApplication->enqueueMessage($e->getMessage(), 'error');
			return false;
		}
		
		return $xml;
	}
	
	/**
     * Sign Petition
     * @return array
     * @throws phpmailerException
     */
    private function post_signPetition()
	{
        // no Ajax on sign petition
        $this->useAjax = false;

        // remember fields first
        foreach((array)$this->settings->get('fields', array()) as $field_name=>$field_object)
        {
            $request_var = $this->JInput->post->get($this->_name . '_' . $field_name, '', 'string');
            if($request_var)
            {
                $this->JSession->set($this->_name . '_' . $field_name, $request_var);
            }
        }

        // security check
        if (!$this->checkToken())
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
        }

        $total_signatures = (int) $this->getTotal();

        // signatures already goaled
        if ($goal = (int)$this->settings->get('goal', 0) and $total_signatures === $goal)
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_GOAL_COLLECTED'));
        }

        $data = array();
        $data[$this->_name . '_identifier'] = 'string';

        foreach((array)$this->settings->get('fields', array()) as $field_name=>$field_object)
        {
            if (isset($field_object->enabled) and $field_object->enabled)
            {
                $data[$this->_name . '_' . $field_name] = (isset($field_object->type) ? $field_object->type : 'string');
            }
        }

        $data = $this->JScriptegrator->sanitizeRequest($data, 'post', '_');

        // published by default
        $data['published'] = 1;

        // user must verify email address, unpublish signature
        if ((int)$this->settings->get('security.signature_verification', 0))
        {
            $data['published'] = 0;
        }

        $data['authkey'] = (string)$this->JScriptegrator->randomString(20);

        $data['fields'] = (array)$this->settings->get('fields', array());

        if (!$this->db->bind($data))
        {
            return $this->response('error',  $this->db->getError());
        }

        if (!$this->db->check())
		{
			return $this->response('error',  $this->db->getError());
		}

		if (!$this->db->store())
		{
			return $this->response('error',  $this->db->getError());
		}

        // send auth email to user who signed the petition
		if ($signature_verification = (int)$this->settings->get('security.signature_verification', 0))
		{
            // unpublished petition, visitor must verify it first
            $this->db->set('published', 0);

            $config = JFactory::getConfig();
			$from = $config->get('mailfrom', '');
			$fromname = $config->get('fromname', '');

            $recipient = (string)$this->db->get('email', '');

            // missing email
            if (!$recipient)
            {
                return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_VERIFICATION_ERROR_MISSING_EMAIL'));
            }

			$verify_url =
                $this->JScriptegrator->buildURL('url', true, $this->_name,
                    array(
                        $this->_name . '_task' => 'get_verifySignature',
                        $this->_name . '_id' => (int)$this->db->get('id', 0),
                        $this->_name . '_authkey' => (string)$this->db->get('authkey', '')
                    )
                );

			$subject = JText::sprintf('PLG_CONTENT_CDPETITIONS_SIGNATURE_VERIFICATION_EMAIL_SUBJECT', $data['identifier']);

            $body = JText::sprintf('PLG_CONTENT_CDPETITIONS_SIGNATURE_VERIFICATION_EMAIL_BODY',
                $verify_url
			);

            unset($verify_url);

            try
            {
                if (
                    $this->sendMail(
                        $from,
                        $fromname,
                        $recipient,
                        $subject,
                        $body
                    ) !== true
                )
                {
                    throw new phpmailerException(JText::_('PLG_CONTENT_CDPETITIONS_EMAIL_SEND_FAILED'), 500);
                }
            }
            catch (phpmailerException $e)
            {
                // delete saved signature
                if (!$this->db->delete())
                {
                    return $this->response('error',  $this->db->getError());
                }

                if($error = @ob_get_clean()) {
                    return $this->response('error',  $error);
                } else {
                    return $this->response('error',  $e->getMessage());
                }
            }
		}

		// send "new signature" notification
		if (!$signature_verification and $new_signature_notification = (string)$this->settings->get('notifications.new_signature', 'disabled') and $new_signature_notification !== 'disabled')
		{
            $config = JFactory::getConfig();
			$from = $config->get('mailfrom', '');
			$fromname = $config->get('fromname', '');

            switch($new_signature_notification)
            {
                case 'global':
                    $recipient = $config->get('mailfrom', '');
                    break;

                case 'article_author':
                    if (isset($this->article))
                    {
                        $user = JFactory::getUser($this->article->created_by);
                        $recipient = $user->email;
                    }
                    else
                    {
                        $recipient = $config->get('mailfrom', '');
                    }
                    break;

                case 'custom':
                    if (!$recipient = $this->settings->get('notifications.new_signature_custom_address', ''))
                    {
                        $recipient = $config->get('mailfrom', '');
                    }
                    break;
            }

			$details = '';

            if($petition_title = $this->settings->get('title', ''))
            {
                $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_PETITION_ID') . ': ' . $petition_title . ' [#' . $data['identifier'] . ']';
            }
            else
            {
                $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_PETITION_ID') . ': ' . $data['identifier'];
            }
            $details .= "\n";

            foreach((array)$this->settings->get('fields', array()) as $name=>$field)
            {
                // check if field is enabled and data field is not empty
                if (isset($field->enabled) and $field->enabled and isset($data[$name]) and $data[$name])
                {
                    $details .= JText::_('PLG_CONTENT_CDPETITIONS_' . strtolower($name)) . ': ' . $data[$name];
                    $details .= "\n";
                }
            }

			$details .= "\n";
			$details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_DATE') . ': ' . JHTML::_('date', $this->db->get('date', ''), JText::_($this->params->get('dateformat', 'DATE_FORMAT_LC2')));

			$details .= "\n";
			$details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_IP') . ': ' . $_SERVER['REMOTE_ADDR'];

			$details .= "\n\n";

			$details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_URL') . ":\n" . $this->JScriptegrator->buildURL('url', true, $this->_name) . '#signatures';
            $details .= "\n\n";
			$details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_URL_DELETE') . ":\n" .
                $this->JScriptegrator->buildURL('url', true, $this->_name,
                    array(
                        $this->_name . '_task' => 'get_removeSignature',
                        $this->_name . '_id' => (int)$this->db->get('id', 0),
                        $this->_name . '_authkey' => (string)$this->db->get('authkey', '')
                    )
                );

			$subject = JText::sprintf('PLG_CONTENT_CDPETITIONS_NEW_SIGNATURE_NOTIFICATION_SUBJECT', $data['identifier']);
			$body = JText::sprintf('PLG_CONTENT_CDPETITIONS_NEW_SIGNATURE_NOTIFICATION_BODY',
				$details
			);

            try
            {
                if (
                    $this->sendMail(
                        $from,
                        $fromname,
                        $recipient,
                        $subject,
                        $body
                    ) !== true
                )
                {
                    throw new phpmailerException(JText::_('PLG_CONTENT_CDPETITIONS_EMAIL_SEND_FAILED'), 500);
                }
            }
            catch (phpmailerException $e)
            {
                // delete saved signature
                if (!$this->db->delete())
                {
                    return $this->response('error',  $this->db->getError());
                }

                if($error = @ob_get_clean()) {
                    return $this->response('error',  $error);
                } else {
                    return $this->response('error',  $e->getMessage());
                }
            }
		}

		// "goal reached" notification
        if ($goal_notification = (string) $this->settings->get('notifications.goal', 'disabled') and $goal_notification !== 'disabled' and $total_signatures + 1 === $goal)
        {
            $config = JFactory::getConfig();
            $from = $config->get('mailfrom', '');
            $fromname = $config->get('fromname', '');

            switch($goal_notification)
            {
                case 'global':
                    $recipient = $config->get('mailfrom', '');
                    break;

                case 'article_author':
                    if (isset($this->article))
                    {
                        $user = JFactory::getUser($this->article->created_by);
                        $recipient = $user->email;
                    }
                    else
                    {
                        $recipient = $config->get('mailfrom', '');
                    }
                    break;

                case 'custom':
                    if (!$recipient = $this->params->get('notifications.goal_custom_address', ''))
                    {
                        $recipient = $config->get('mailfrom', '');
                    }
                    break;
            }
			
			$goal_details = '';

            if($petition_title = $this->settings->get('title', ''))
            {
                $goal_details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_PETITION_ID') . ': ' . $petition_title . ' [#' . $data['identifier'] . ']';
            }
            else
            {
                $goal_details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_PETITION_ID') . ': ' . $data['identifier'];
            }
            $goal_details .= "\n";
			
			$goal_details .= "\n";
			$goal_details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_DATE') . ': ' . JHtml::_('date', 'now', JText::_($this->params->get('dateformat', 'DATE_FORMAT_LC2')));
			
			$subject = JText::sprintf('PLG_CONTENT_CDPETITIONS_GOAL_NOTIFICATION_SUBJECT', $data['identifier']);
			$body = JText::sprintf('PLG_CONTENT_CDPETITIONS_GOAL_NOTIFICATION_BODY',
				$goal_details
			);

            try
            {
                if (
                    $this->sendMail(
                        $from,
                        $fromname,
                        $recipient,
                        $subject,
                        $body
                    ) !== true
                )
                {
                    throw new phpmailerException(JText::_('PLG_CONTENT_CDPETITIONS_EMAIL_SEND_FAILED'), 500);
                }
            }
            catch (phpmailerException $e)
            {
                // delete saved signature
                if (!$this->db->delete())
                {
                    return $this->response('error',  $this->db->getError());
                }

                if($error = @ob_get_clean()) {
                    return $this->response('error',  $error);
                } else {
                    return $this->response('error',  $e->getMessage());
                }
            }
		}

        $success_msg = JText::_('PLG_CONTENT_CDPETITIONS_SIGN_SUCCESS_ADDED');
        if ($signature_verification)
        {
            $success_msg = JText::_('PLG_CONTENT_CDPETITIONS_SIGN_PETITION_SUCCESS_ADDED_WAITING_FOR_VERIFICATION');
        }

        return $this->response('success',  $success_msg);
	}

    /**
     * Check for email duplicaton
     * @return array
     */
    private function post_checkEmailDuplication()
    {
        // security check
        if (!$this->checkToken())
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
        }

        $data = array();
        $data[$this->_name . '_identifier'] = 'string';
        $data[$this->_name . '_email'] = 'string';

        $data = $this->JScriptegrator->sanitizeRequest($data, 'post', '_');

        // missing email field
        if (!$data['email'])
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_ERROR_NO_EMAIL_TO_CHECK'));
        }

        if (!$this->db->bind($data))
        {
            return $this->response('error', $this->db->getError());
        }

        // check if row really exists
        $result = $this->db->checkEmailDuplication();

        // string means error, integer existing signature in database
        if (is_string($result))
        {
            return $this->response('error', $this->db->getError());
        }

        // email already exists
        if ((int)$result)
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_EMAIL_DUPLICTY'));
        }

        return $this->response('success',  '');
    }

    /**
     * Get RSS feed
     * @return bool
     */
    private function get_rssFeed()
    {
        $this->useAjax = false;

        if(!(int)$this->settings->get('display_feed', 0))
        {
            return $this->response('error');
        }

        if((int)$this->settings->get('hide_signatures_for_guests', 0) and $this->JUser->guest)
        {
            return $this->response('error');
        }

        $feed = JDocument::getInstance('feed');

        $count_of_feed_items = (int)$this->settings->get('feed_limit', 50);
        $signatures = $this->getSignatures(null, ($count_of_feed_items ? $count_of_feed_items : null));

        $article_link = str_replace('&', '&amp;', $this->redirectionURL);

        $fields = (array)$this->settings->get('fields', array());

        if($signatures)
        {
            foreach($signatures as $signature)
            {
                $item = new JFeedItem();

                $item->title 		= '#' . $signature->identifier;
                if(
                    $signature->fullname
                    and isset($fields['fullname']->enabled) and $fields['fullname']->enabled
                    and isset($fields['fullname']->access_level) and array_intersect($this->JUser->getAuthorisedViewLevels(), $fields['fullname']->access_level)
                    or in_array(0, $fields['fullname']->access_level)
                    )
                {
                    $item->title .= ' - ' . $signature->fullname;
                }
                else if(
                    $signature->email
                    and isset($fields['email']) and isset($fields['email']->enabled)
                    and isset($fields['email']->access_level) and array_intersect($this->JUser->getAuthorisedViewLevels(), $fields['email']->access_level)
                    or in_array(0, $fields['email']->access_level)
                )
                {
                    $item->title .= ' - ' . $signature->email;
                }

                $item->link 		= $article_link . '#' . $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_TABTITLE_SIGNATURES'));
                $item->description 	= '';
                if(
                    $signature->note
                    and isset($fields['note']) and $fields['note']->enabled
                    and isset($fields['note']->access_level) and array_intersect($this->JUser->getAuthorisedViewLevels(), $fields['note']->access_level)
                    or in_array(0, $fields['note']->access_level)
                )
                {
                    $item->description = $signature->note;
                }
                $item->date			= $signature->created;

                // loads item info into rss array
                $feed->addItem($item);
            }
        }

        $feed->link = $article_link;
        $feed->title = JText::_('PLG_CONTENT_CDPETITIONS_FEED_TITLE_SIGNATURES') . ' - ' . '#' . $this->settings->get('identifier', '');;

        $this->JApplication->close($feed->render());
    }

    /**
     * Verify signature
     * @return array
     * @throws phpmailerException
     */
    private function get_verifySignature()
    {
        $this->useAjax = false;

        $data = array();
        $data[$this->_name . '_id'] = 'int';
        $data[$this->_name . '_authkey'] = 'string';

        $data = $this->JScriptegrator->sanitizeRequest($data, 'get', '_');

        if (!$this->db->bind($data))
        {
            return $this->response('error', $this->db->getError());
        }

        // check if row really exists
        if (!$this->db->load())
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_DOESNT_EXIST'));
        }

        // check auth key
        if ((string)$this->db->get('authkey', '') !== $data['authkey'])
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_ERROR_INVALID_AUTHKEY'));
        }

        // already verified
        if ((int)$this->db->get('published', 0))
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_VERIFICATION_ERROR_ALREADY_VERIFIED'));
        }

        // delete row
        if (!$this->db->verifySignature())
        {
            return $this->response('error', $this->db->getError());
        }

        // send "new signature" notification if required
        if ($new_signature_notification = (string)$this->settings->get('notifications.new_signature', 'disabled') and $new_signature_notification !== 'disabled')
        {
            $config = JFactory::getConfig();
            $from = $config->get('mailfrom', '');
            $fromname = $config->get('fromname', '');

            switch($new_signature_notification)
            {
                case 'global':
                    $recipient = $config->get('mailfrom', '');
                    break;

                case 'article_author':
                    if (isset($this->article))
                    {
                        $user = JFactory::getUser($this->article->created_by);
                        $recipient = $user->email;
                    }
                    else
                    {
                        $recipient = $config->get('mailfrom', '');
                    }
                    break;

                case 'custom':
                    if (!$recipient = $this->settings->get('notifications.new_signature_custom_address', ''))
                    {
                        $recipient = $config->get('mailfrom', '');
                    }
                    break;
            }

            $details = '';

            if($petition_title = $this->settings->get('title', ''))
            {
                $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_PETITION_ID') . ': ' . $petition_title . ' [#' . $this->db->get('identifier', '') . ']';
            }
            else
            {
                $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_PETITION_ID') . ': ' . $this->db->get('identifier', '');
            }
            $details .= "\n";

            foreach((array)$this->settings->get('fields', array()) as $name=>$field)
            {
                // check if field is enabled and data field is not empty
                if (isset($field->enabled) and $field->enabled and $this->db->get($name, ''))
                {
                    $details .= JText::_('PLG_CONTENT_CDPETITIONS_' . strtolower($name)) . ': ' . $this->db->get($name, '');
                    $details .= "\n";
                }
            }

            $details .= "\n";
            $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_DATE') . ': ' . JHTML::_('date', $this->db->get('date', ''), JText::_($this->params->get('dateformat', 'DATE_FORMAT_LC2')));

            $details .= "\n";
            $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_IP') . ': ' . $this->db->get('created_by_ip', '');

            $details .= "\n\n";

            $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_URL') . ":\n" . $this->JScriptegrator->buildURL('url', true, $this->_name) . '#signatures';
            $details .= "\n\n";
            $details .= JText::_('PLG_CONTENT_CDPETITIONS_NOTIFICATION_URL_DELETE') . ":\n" .
                $this->JScriptegrator->buildURL('url', true, $this->_name,
                    array(
                        $this->_name . '_task' => 'get_removeSignature',
                        $this->_name . '_id' => (int)$this->db->get('id', 0),
                        $this->_name . '_authkey' => (string)$this->db->get('authkey', '')
                    )
                );

            $subject = JText::sprintf('PLG_CONTENT_CDPETITIONS_NEW_SIGNATURE_NOTIFICATION_SUBJECT', $this->db->get('identifier', ''));
            $body = JText::sprintf('PLG_CONTENT_CDPETITIONS_NEW_SIGNATURE_NOTIFICATION_BODY',
                $details
            );

            try
            {
                if (
                    $this->sendMail(
                        $from,
                        $fromname,
                        $recipient,
                        $subject,
                        $body
                    ) !== true
                )
                {
                    throw new phpmailerException(JText::_('PLG_CONTENT_CDPETITIONS_EMAIL_SEND_FAILED'), 500);
                }
            }
            catch (phpmailerException $e)
            {
                // delete saved signature
                if (!$this->db->delete())
                {
                    return $this->response('error',  $this->db->getError());
                }

                if($error = @ob_get_clean()) {
                    return $this->response('error',  $error);
                } else {
                    return $this->response('error',  $e->getMessage());
                }
            }
        }

        return $this->response('success', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_VERIFICATION_SUCCESS'));
    }

    /**
     * Remove signature (GET)
     * @return array
     */
    private function get_removeSignature()
    {
        $this->useAjax = false;

        $data = array();
        $data[$this->_name . '_id'] = 'int';
        $data[$this->_name . '_authkey'] = 'string';

        $data = $this->JScriptegrator->sanitizeRequest($data, 'get', '_');

        if (!$this->db->bind($data))
        {
            return $this->response('error', $this->db->getError());
        }

        // check if row really exists
        if (!$this->db->load())
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_DOESNT_EXIST'));
        }

        if ((string)$this->db->get('authkey', '') !== $data['authkey'])
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_ERROR_INVALID_AUTHKEY'));
        }

        // delete row
        if (!$this->db->delete())
        {
            return $this->response('error', $this->db->getError());
        }

        return $this->response('success', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_DELETED'));
    }
	
	/**
	 * Remove signature (POST)
	 * @return		array
	 */
	private function post_removeSignature()
	{
		// security check
		if (!$this->checkToken())
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
		}
		
		// is authorized to delete signature (article author)
		if (!$this->authorisedTo('manage'))
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_NOT_AUTHORIZED'));
		}

        $data = array();
        $data[$this->_name . '_id'] = 'int';

        $data = $this->JScriptegrator->sanitizeRequest($data, 'post', '_');

        if (!$this->db->bind($data))
        {
            return $this->response('error', $this->db->getError());
        }

		// check if row really exists
		if (!$this->db->load())
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_DOESNT_EXIST'));
		}

		// delete row
		if (!$this->db->delete($data['id']))
		{
			return $this->response('error', $this->db->getError());
		}

		return $this->response('success', JText::_('PLG_CONTENT_CDPETITIONS_SIGNATURE_DELETED'));
	}
	
	/**
	 * Clean all signatures
	 * 
	 * @return		array
	 */
	private function post_deleteAllSignatures()
	{
		// security check
		if (!$this->checkToken())
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
		}
		
		// is authorized to delete signature (article author)
		if (!$this->authorisedTo('manage'))
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_NOT_AUTHORIZED'));
		}
		
		$data = array();
		$data['identifier'] = $this->JInput->post->get('identifier', '', 'cmd');
		
		if (!$this->db->bind($data))
		{
			return $this->response('error', $this->db->getError());
		}
		
		// nothing to delete
		if ($this->db->getTotal() === 0)
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_NOTHING_TO_DELETE'));
		}
		
		if (!$this->db->deleteAllSignatures())
		{
			return $this->response('error', $this->db->getError());
		}
		
		return $this->response('success', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_SIGNATURES_DELETED'));
	}
	
	/**
	 * Rename identifier
	 * 
	 * @return		array
	 */
	private function post_renameIdentifier()
	{
		// no Ajax on this function
		$this->useAjax = false;
		
		// security check
		if (!$this->checkToken())
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
		}
		
		// is authorized to delete signature (article author)
		if (!$this->authorisedTo('manage'))
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_NOT_AUTHORIZED'));
		}
		
		$data = array(
			'identifier' => 'cmd',
			'identifier_new' => 'cmd'
		);
		
		$data = $this->JInput->post->getArray($data);
		
		if (!$this->db->bind($data))
		{
			return $this->response('error', $this->db->getError());
		}
		
		$identifier_new = $data['identifier_new'];
		
		if (!$this->db->renameIdentifier($identifier_new))
		{
			return $this->response('error', $this->db->getError());
		}
		
		return $this->response('success', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_PETITION_ID_RENAMED'));
	}
	
	/**
	 * Export signatures
	 * 
	 * @return		mixed
	 */
	private function post_export()
	{
		$this->useAjax = false;
		
		// security check
		if (!$this->checkToken())
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
		}
		
		// is authorized to delete signature (article author)
		if (!$this->authorisedTo('manage'))
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_NOT_AUTHORIZED'));
		}
		
		$signatures = $this->getSignatures(null, null);

		if (!$signatures)
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_EXPORT_NO_DATES'));
		}

        $data = array();
        $data[$this->_name . '_utilities'] = 'array';
        $data = $this->JScriptegrator->sanitizeRequest($data, 'post', '_');

        $type = (isset($data['utilities']['export_type']) ? $data['utilities']['export_type'] : 'html');

		$rows = array();
		
		$settings_fields = (array)$this->settings->get('fields', array());
		
		$item = array();
		foreach($settings_fields as $name=>$field)
		{
			if (isset($name) and isset($field->enabled) and $field->enabled)
			{
				$item[] = JText::_('PLG_CONTENT_CDPETITIONS_' . strtoupper($name));
			}
		}
		$rows[] = $item;
		unset($item);
		
		foreach($signatures as $sig)
		{
			$item = array();
			foreach($settings_fields as $name=>$field)
			{
				if (isset($sig->$name) and isset($field->enabled) and $field->enabled)
				{
					$item[]= $sig->$name;
				}
			}
			$rows[] = $item;
		}
		unset($item);
		
		switch($type) {
			case 'xls':
				
				// requires PHP 5 to generate the XML file
				if((version_compare(phpversion(), '5.0') < 0))
				{
					return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_REQUIRES_PHP5'));
				}
				
				// get XLS class
				require_once dirname(__FILE__) . DS . 'helpers' . DS . 'php-excel.class.php';
				
				// generate file (constructor parameters are optional)
				$xls = new Excel_XML('UTF-8', false, JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_EXPORT_TO_XLS_SHEET_TITLE'));
				$xls->addArray($rows);
				$xls->generateXML('signatures');
				
				$this->JApplication->close();
				
				break;
				
			case 'html':
				// get XLS class
				require_once dirname(__FILE__) . DS . 'helpers' . DS . 'table.php';
				
				$table = new CI_Table();
				
				$table->template = array (
					'table_open' => '<table border="1" cellpadding="2" cellspacing="2" width="100%">'
				);
				
				$data = $table->make_columns($rows);
				
				$page = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
				$page .= "\n";
				$page .= '<html xmlns="http://www.w3.org/1999/xhtml"' . ($this->JDocument->direction === 'rtl' ? ' dir="rtl"' : '') . '>';
				$page .= "\n";
				$page .= '<head>';
				$page .= "\n";
				$page .= '<title>' . JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_EXPORT_TO_HTML_TITLE') . '</title>';
				$page .= "\n";
				$page .= '<meta http-equiv="content-type" content="text/html; charset=utf-8" />';
				$page .= "\n";
				$page .= '</head>';
				$page .= "\n";
				$page .= '<body>';
				$page .= "\n";
				$page .= $table->generate($data);
				$page .= "\n";
				$page .= '<br />';
				$page .= '<a href="' . str_replace('&', '&amp;', $this->redirectionURL) . '" title="">' . JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_EXPORT_BACK') . '</a>';
				$page .= '</body>';
				$page .= "\n";
				$page .= '</html>';

                $this->JApplication->close($page);
				
			default:
				
				break;
		}
	}

    /**
     * Backup signatures
     * @return array
     */
    private function post_backupSignatures()
    {
        // no Ajax on sign petition
        $this->useAjax = false;

        // security check
        if (!$this->checkToken())
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
        }

        $signatures = $this->db->getAllData();
        if($signatures === false)
        {
            return $this->response('error', $this->db->getError());
        }

        if (!$signatures)
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_BACKUP_NO_DATES'));
        }

        $xml_data = '';
        $xml_data .= '<?xml version="1.0" encoding="utf-8"?>';
        $xml_data .= "\n";
        $xml_data .= '<signatures>';
        $xml_data .= "\n";

        foreach($signatures as $sig_value)
        {
            $sig_value = (array)$sig_value;

            $xml_data .= "\t";
            $xml_data .= '<signature>';
            $xml_data .= "\n";

            foreach($sig_value as $name=>$val)
            {
                $xml_data .= "\t";
                $xml_data .= "\t";
                $xml_data .= '<' . $name . '>';
                if ($name === 'settings')
                {
                    $xml_data .= '<![CDATA[' . $val . ']]>';
                }
            else
                {
                    $xml_data .= $val;
                }
                $xml_data .= '</' . $name . '>';
                $xml_data .= "\n";
            }

            $xml_data .= "\n";
            $xml_data .= "\t";
            $xml_data .= '</signature>';
            $xml_data .= "\n";

        }
        $xml_data .= '</signatures>';

        while (@ob_end_clean())
            ;

        if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {

            // required for IE, otherwise Content-disposition is ignored
            if (ini_get('zlib.output_compression')) {
                ini_set('zlib.output_compression', 'Off');
            }

            header('Content-Type: "text/xml"');
            header('Content-Disposition: attachment; filename="' .
                'signatures.xml' . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header("Content-Transfer-Encoding: binary");
            header('Pragma: public');
            header("Content-Length: " . strlen($xml_data));
        } else {
            header('Content-Type: "text/xml"');
            header('Content-Disposition: attachment; filename="' .
                'signatures.xml' . '"');
            header("Content-Transfer-Encoding: binary");
            header('Expires: 0');
            header('Pragma: no-cache');
            header("Content-Length: " . strlen($xml_data));
        }

        if (!ini_get('safe_mode')) { // set_time_limit doesn't work in safe mode
            @set_time_limit(0);
        }

        $this->JApplication->close($xml_data);
    }

    /**
     * Restore signatures
     * @return array
     */
    private function post_restoreSignatures()
    {
        // no Ajax on sign petition
        $this->useAjax = false;

        // security check
        if (!$this->checkToken())
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
        }

        $files = new JInput($_FILES);
        $files = $files->get($this->_name . '_utilities', array(), 'array');

        // unique array
        foreach($files as $key=>$value)
        {
            $files[$key] = $value['restore_file'];
        }

        $filepath = $files['tmp_name'];

        if (!JFile::exists($filepath))
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE_ERROR'));
        }

        if(!$file_content = JFile::read($filepath))
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE_ERROR'));
        }

        if(!$xml = @simplexml_load_string($file_content))
        {
            return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE_ERROR'));
        }

        if (!$this->db->restoreSignatures($xml))
        {
            return $this->response('error', $this->db->getError());
        }

        return $this->response('success', JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE_SUCCESS'));
    }

	/**
	 * Save settings
	 * @return array
	 */
	private function post_saveSettings()
	{
		// no Ajax on sign petition
		$this->useAjax = false;
		
		// security check
		if (!$this->checkToken())
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_INVALID_TOKEN'));
		}
		
		$data = array();
		$data[$this->_name . '_identifier'] = 'string';
		$data[$this->_name . '_settings'] = 'array';
		
		$data = $this->JScriptegrator->sanitizeRequest($data, 'post', '_');

		$settings = new JRegistry($data['settings']);
		
		// goal can not be lower then count of collected signatures
		if ((int)$settings->get('goal', 0) > 0 and (int)$settings->get('goal', 0) < $this->getTotal())
		{
			return $this->response('error', JText::_('PLG_CONTENT_CDPETITIONS_ERROR_COLLECTED_IS_HIGHER_THEN_GOAL'));
		}
		
		$data['settings'] = $settings->toString();

		try
		{
			if (!$this->db->bind($data))
			{
			    throw new JDatabaseException($this->db->getError(), 500);
			}
			
			if (!$this->db->saveSettings())
			{
				throw new JDatabaseException($this->db->getError(), 500);
			}
		}
		catch (JDatabaseException $e)
		{
			return $this->response('error', $e->getMessage());
		}
		
		return $this->response('success', JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_STATUS_SUCCESSFULLY_SAVED'));	
	}
	
	/**
	 * Load settingsy
	 * @param string $identifier
	 * @return JRegistry
	 */
	private function loadSettings($identifier = '')
	{
		if (!$identifier) return null;
		
		$data = array();
		$data['identifier'] = $identifier;
		
		try
		{
			if (!$this->db->bind($data))
			{
			    throw new JDatabaseException($this->db->getError(), 500);
			}
			$settings = (string)$this->db->loadSettings();
			
			 if ($error = $this->db->getError()) {
				throw new JDatabaseException($error, 500);
			}
		}
		catch (JDatabaseException $e)
		{
			JFactory::getApplication()->enqueueMessage($e->getMessage(), 'error');
		}
		
		return new JRegistry($settings);
	}
	
	/**
	 * Load DB instance
	 * 
	 * @return 		A database object
	 */
	private function dbInstance($instance = '')
	{
		jimport('joomla.database.table');
		return JTable::getInstance('CDPetitions' . $instance);
	}
	
    /**
     * Get Layout
     * 
     * @param 		$file
     * @return 		string
     */
    private function getLayoutPath($file = '')
    {
    	if (!$file) return false;
    	
		$layout = $this->params->get('layout', 'default');
		$type = 'html';
		
		if ((int) $this->JInput->get->get('print', 0, 'int'))
		{
			$type = 'print';
		}
		
		$tmpldir = dirname(__FILE__) . DS  . 'tmpl' . DS . $layout;
		 
		$filepath = $tmpldir . DS . $file . '.' . $type .  '.php';
		
		if ($type !== 'html' and ! JFile::exists($filepath))
		{
			$type = 'html';
			$filepath = $tmpldir . DS . $file . '.' . $type .  '.php';
		}
		
		if (!JFile::exists($filepath)) {
			return false;
		}

		return $filepath;
    }
    
    /**
     * Get language string based on signature count.
     * Good routine for Non-English based languages like Czech etc.
     * 
     * @param		int 		$count
     * @return 		string
     */
    private function signatureLang($count = 0)
    {
    	$lang = 'PLG_CONTENT_CDPETITIONS_SIGNATURE';
    	
    	if ($count === 0)
    	{
    		$lang = 'PLG_CONTENT_CDPETITIONS_SIGNATURE_0';
    	}
    	elseif($count === 1)
    	{
    		$lang = 'PLG_CONTENT_CDPETITIONS_SIGNATURE_1';
    	}
    	elseif($count >= 2 and $count < 5)
    	{
    		$lang = 'PLG_CONTENT_CDPETITIONS_SIGNATURE_2_5';
    	}
    	elseif ($count >= 5)
    	{
    		$lang = 'PLG_CONTENT_CDPETITIONS_SIGNATURE_5_0';
    	}
    	
    	return $lang;
    }

    /**
     * Send mail wrapper
     *
     * @param	string	$from			From email address
     * @param	string	$fromname		From name
     * @param	mixed	$recipient		Recipient email address(es)
     * @param	string	$subject		Email subject
     * @param	string	$body			Message body
     * @param	boolean	$mode			false = plain text, true = HTML
     * @param	mixed	$cc				CC email address(es)
     * @param	mixed	$bcc			BCC email address(es)
     * @param	mixed	$attachments	Attachment file name(s)
     * @param	mixed	$replyto		Reply to email address(es)
     * @param	mixed	$replytoname 	Reply to name(s)
     *
     * @return	boolean	True on success
     */
    private function sendMail($from, $fromname, $recipient, $subject, $body, $mode=0, $cc=null, $bcc=null, $attachments=null, $replyto=null, $replytoname=null) {

        jimport('joomla.mail.helper');

        $from = JMailHelper::cleanAddress($from);
        $recipient = JMailHelper::cleanAddress($recipient);
        $subject = JMailHelper::cleanSubject($subject);
        $body = JMailHelper::cleanBody($body);

        $send = JFactory::getMailer()->sendMail(
            $from,
            $fromname,
            $recipient,
            $subject,
            $body,
            $mode,
            $cc,
            $bcc,
            $attachments,
            $replyto,
            $replytoname
        );
        return $send;
    }
	
	/**
	 * Response on post request
	 * 
	 * @param 	string	$status
	 * @param	string	$content
	 * @return 	array
	 */
	private function response($status = 'error', $content = '')
	{
		return array($status, $content, ($this->useAjax ? 'xml' : 'text'));
	}
	
	/**
	 * State template
	 * 
	 * @param	string	$message
	 * @param	string	$state
	 * @param	string	$icon
	 * @return 	string
	 */
	private function stateTmpl($message, $state = 'highlight', $icon = 'ui-icon-info')
	{
		$tmpl = '';
		if ($layoutpath = $this->getLayoutPath('state'))
		{
			ob_start();
				require $layoutpath;
				$tmpl .= ob_get_contents();
			ob_end_clean();
		}
		
		return $this->JScriptegrator->compressHTML($this->replaceVariables($tmpl));
	}
	
	/**
	 * Replace variables
	 * @param	string	 $string
	 * @return 	string
	 */
	private function replaceVariables($string = '')
	{
		if (!$string) return $string;
		
		$search = $replace = array();
		
		$search[] = '{$name}';
		$replace[] = $this->_name;
		
		return str_replace($search, $replace, $string);
	}
	
	/**
	 * Get Facebook data
	 * @return Facebook
	 */
	private function facebookData()
	{
		$data = array();
		
		$data['name'] = '';
		$data['email'] = '';
		$data['state'] = 0;
		$data['link'] = '';
		
		if (!(string)$this->settings->get('facebook.signup.APP_ID', ''))
		{
			return false;
		}
		
		if(	!$facebook_appId = (string) $this->settings->get('facebook.signup.APP_ID', ''))
		{
			$this->JApplication->enqueueMessage(JText::_('PLG_CONTENT_CDPETITIONS_FACEBOOK_MISSING_APPID'), 'error');
			return false;
		}
		if(	! $facebook_secret = (string) $this->settings->get('facebook.signup.secret', ''))
		{
			$this->JApplication->enqueueMessage(JText::_('PLG_CONTENT_CDPETITIONS_FACEBOOK_MISSING_SECRET'), 'error');
			return false;
		}
		
		$facebook_class_file = dirname(__FILE__) . DS . 'helpers' . DS . 'facebook' . DS . 'facebook.php';
		
		if (!JFile::exists($facebook_class_file))
		{
			$this->JApplication->enqueueMessage(JText::sprintf('PLG_CONTENT_CDPETITIONS_FACEBOOK_MISSING_HELPER_FILE', $facebook_class_file), 'error');
			return false;
		}

        require_once $facebook_class_file;
		
		$facebook = new Facebook(array(
		  'appId'  => $facebook_appId,
		  'secret' => $facebook_secret,
		));

		// Get User ID
		$user = $facebook->getUser();

		// We may or may not have this data based on whether the user is logged in.
		//
		// If we have a $user id here, it means we know the user is logged into
		// Facebook, but we don't know if the access token is valid. An access
		// token is invalid if the user logged out of Facebook.

		if ($user)
		{
		  try
		  {
		    // Proceed knowing you have a logged in user who's authenticated.
		    $user_profile = $facebook->api('/me');
		  }
		  catch (FacebookApiException $e)
		  {
              print_r($e);
              jexit();
		    error_log($e);
		    $user = null;
		  }
		}

        $params = array();
        $params["scope"] = 'email';
        $params["next"] = $this->JScriptegrator->buildURL('html', true, $this->_name);
        $params["cancel_url"] = $this->JScriptegrator->buildURL('html', true, $this->_name);
        $params["display"] = 'page';
		
		if ($user)
		{
			$data['name'] = (isset($user_profile['name']) ? $user_profile['name'] : '');
			$data['email'] = (isset($user_profile['email']) ? $user_profile['email'] : '');
			
			$data['state'] = 1;
			$data['link'] = str_replace('&', '&amp;', $facebook->getLoginUrl(array()));
		}
		else
		{
		  $data['state'] = 0;
		  $data['link'] = str_replace('&', '&amp;', $facebook->getLoginUrl($params));
		}
		
		return $data;
	}

	/**
	 * Check permissions
	 * @param	string|array	$permissions
	 * @return 	boolean
	 */
	private function authorisedTo($permissions = array('manage'))
	{
		$actions = 
			array(
				'manage'
			);
		
		if (!$permissions) return false;
		
		// make sure it's array
		if (!is_array($permissions))
		{
			$permissions = (array) $permissions;
		}
		
		// unknown permission
		if(!array_intersect($permissions, $actions)) return false;
		
		$user = JFactory::getUser();
		
		// user not logged in
		if ($user->get('guest'))
		{
			return false;
		}
		
		$user_groups = $user->get('groups', array());
		
		$allowed_count = 0;
		foreach($permissions as $permission)
		{
			$authorised_to = (array) $this->params->get('permission_to_' . $permission, null);
			
			if (!$authorised_to)
			{
				break;
			}
			
			// check groups
			if (array_intersect($authorised_to, $user_groups))
			{
				++$allowed_count; // increase permission count
			}
		}
		
		// no permission
		if (!$allowed_count)
		{
			return false;
		}
		
		// required edit privileges too
		if ((int)$this->params->get('permission_to_manage_edit', ''))
		{
			// com_content
			if (!isset($this->article->id) or !$aid = (int)$this->article->id)
			{
				// missing article ID, probably we're outside of article context (module), K2, ZOO
				return false;
			}
			
	        $asset	= 'com_content.article.' . (int)$aid;
	        
	        // global edit permission first
			if($user->authorise('core.edit', $asset))
			{
				return true;
			}
			
			$userId	= (int)$user->get('id');
			
			// individual edit permission per article
			if(!empty($userId) && $user->authorise('core.edit.own', $asset))
			{
				// Check for a valid user and that they are the owner.
				if ($userId === (int)$this->article->created_by)
				{
					return true;
				}
			}
			return false;
		}
		
		return true;
	}

    /**
     * Load article
     * @param int $article_id
     * @return object
     */
    private function loadArticle($article_id = 0)
    {
        if (!$article_id) return null;

        jimport('joomla.application.component.model');

        $article = JTable::getInstance('Content');
        if(!$article->load($article_id)) {
            return null;
        }
        return $article;
    }
	
	/**
	 * Check token
	 * @return boolean
	 */
	private function checkToken()
	{
		return (boolean) $this->JInput->get(JSession::getFormToken(), '', 'alnum');
	}

    /**
     * Get all user levels
     * @return array
     */
    private function loadUserLevels()
    {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query->select('a.id AS value, a.title AS text');
        $query->from('#__viewlevels AS a');
        $query->group('a.id, a.title, a.ordering');
        $query->order('a.ordering ASC');
        $query->order($query->qn('title') . ' ASC');

        // Get the options.
        $db->setQuery($query);
        $options = $db->loadObjectList();

        // Check for a database error.
        if ($db->getErrorNum())
        {
            JError::raiseNotice(500, $db->getErrorMsg());
            return null;
        }

        $empty_object = new stdClass();
        $empty_object->value = '0';
        $empty_object->text = JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FIELDS_VISIBILITY_ALL');

        array_unshift($options, $empty_object);

        return $options;
    }
}
?>