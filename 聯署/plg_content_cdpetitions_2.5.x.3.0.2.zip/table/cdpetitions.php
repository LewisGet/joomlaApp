<?php
/**
 * Core Design Petitions plugin for Joomla! 2.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		2.5.x.3.0.2
 * @copyright	Copyright (C) 2007 - 2012 Great Joomla!, http://www.greatjoomla.com
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPL 3
 * 
 * This file is part of Great Joomla! extension.   
 * This extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die;

/**
 * Table
 *
 * @package 		Joomla.Framework
 * @subpackage		Table
 * @since			1.0
 */
class JTableCDPetitions extends JTable
{
	/** @var int Primary key */
	public $id = null;
	
	/** @public string */
	public $identifier = null;
	
	/** @public string */
	public $fullname = null;
	
	/** @public string */
	public $email = null;
	
	/** @public int */
	public $age = null;
	
	/** @public string */
	public $address = null;
	
	/** @public string */
	public $city = null;
	
	/** @public string */
	public $country = null;
	
	/** @public string */
	public $postcode = null;
	
	/** @public string */
	public $telephone = null;
	
	/** @public string */
	public $mobile = null;
	
	/** @public string */
	public $note = null;

	/** @public string */
	public $job = null;

	/** @public string */
	public $settings = null;
	
	/** @public int */
	public $published = null;
	
	/** @public string */
	public $created = '0000-00-00 00:00:00';
	
	/** @public string */
	public $created_by_ip = null;
	
	/** @public string */
	public $authkey = null;

    /** @public array */
    public $fields = array();

	/**
	 * A database connector object
	 * 
	 * @param database A database connector object
	 * @return void
	 */
	public function __construct(&$db )
	{
		parent::__construct('#__cdpetitions', 'id', $db);
	}
	
	/**
	 * Get all rows
	 * 
	 * @param		int		$limitstart
	 * @return 		array
	 */
	public function getRows($limitstart = null)
	{
        $query = $this->_db->getQuery(true);
        $query->select('*');
        $query->from($this->_db->quoteName($this->_tbl));
        $query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote($this->identifier));
        $query->where($this->_db->quoteName('published') . ' = 1');
        $query->where($this->_db->quoteName('settings') . ' LIKE ' . $this->_db->quote(''));
        $query->where($this->_db->quoteName('fullname') . ' NOT LIKE ' . $this->_db->quote('*****'));

        switch((string)$this->settings->get('order_by', 'created_asc'))
        {
            case 'created_asc':
                $query->order($this->_db->quoteName('created') . ' ASC');
                break;

            case 'created_desc':
            default:
                $query->order($this->_db->quoteName('created') . ' DESC');
                break;
        }

		$this->_db->setQuery($query, $limitstart, (int)$this->settings->get('limit_per_page', 0));
		
		try
		{
			$result = $this->_db->loadObjectList();
			
			if (is_null($result)) {
				throw new JDatabaseException(JText::sprintf('PLG_CONTENT_CDPETITIONS_ERROR_DB', __METHOD__, __FILE__), 500);
			}
		}
		catch (JDatabaseException $e)
		{
			$this->setError($e->getMessage());
			return false;
		}
		
		return $result;
	}

	/**
     * Get all data
     * @return bool|mixed
     * @throws JDatabaseException
     */
	public function getAllData()
	{
        $query = $this->_db->getQuery(true);
        $query->select('*');
        $query->from($this->_db->quoteName($this->_tbl));

		$this->_db->setQuery($query);

		try
		{
			$result = $this->_db->loadObjectList();

			if (is_null($result)) {
				throw new JDatabaseException(JText::sprintf('PLG_CONTENT_CDPETITIONS_ERROR_DB', __METHOD__, __FILE__), 500);
			}
		}
		catch (JDatabaseException $e)
		{
			$this->setError($e->getMessage());
			return false;
		}

		return $result;
	}

	/**
	 * Get total rows
	 * 
	 * @return		integer
	 */
	public function getTotal()
	{
        $query = $this->_db->getQuery(true);
        $query->select('COUNT(*)');
        $query->from($this->_db->quoteName($this->_tbl));
        $query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote($this->identifier));
        $query->where($this->_db->quoteName('published') . ' = 1');
        $query->where($this->_db->quoteName('settings') . ' LIKE ' . $this->_db->quote(''));
        $query->where($this->_db->quoteName('fullname') . ' NOT LIKE ' . $this->_db->quote('*****'));

		$this->_db->setQuery($query);
		
		try
		{
			$result = $this->_db->loadResult();
			
			if (is_null($result)) {
				throw new JDatabaseException(JText::sprintf('PLG_CONTENT_CDPETITIONS_ERROR_DB', __METHOD__, __FILE__), 500);
			}
		}
		catch (JDatabaseException $e)
		{
			$this->setError($e->getMessage());
			return false;
		}
		
		return (int) $result;
	}
	
	/**
	 * Overloaded check function
	 *
	 * @access public
	 * @return boolean
	 * @see JTable::check
	 * @since 1.5
	 */
	public function check()
	{
		try
		{
            $error = false;

            // check for required field
            foreach($this->fields as $field_name=>$field_object)
            {
                if (!isset($field_object->enabled) or (int)$field_object->enabled !== 1)
                {
                    continue;
                }
                if (!isset($field_object->required) or (int)$field_object->required !== 1)
                {
                    continue;
                }

                if(!$this->get($field_name, ''))
                {
                    throw new JDatabaseException(JText::_('PLG_CONTENT_CDPETITIONS_EMPTY_VALUE'), 500);
                    $error = true;
                    break;
                }
            }

            if ($error === true) return false;

			// check age if necessary
			if (isset($this->age))
			{
				if ((int)$this->age < 0 or (int)$this->age > 122)
                {
					throw new JDatabaseException(JText::_('PLG_CONTENT_CDPETITIONS_INCORRECT_AGE_VALUE'), 500);
					return false;
				}
			}
			
			// check mail
			jimport('joomla.mail.helper');
			if (isset($this->email) and $this->email)
			{
				if(!JMailHelper::isEmailAddress(trim($this->email)))
				{
					throw new JDatabaseException(JText::_('PLG_CONTENT_CDPETITIONS_ERROR_VALIDATION_EMAIL'), 500);
					return false;
				}
				
				// check e-mail duplicity
				if ($this->emailDuplicity())
				{
					throw new JDatabaseException(JText::_('PLG_CONTENT_CDPETITIONS_EMAIL_DUPLICTY'), 500);
					return false;
				}
			}
			
			
			// set date
			$this->set('created', JFactory::getDate()->toSql());
			
			// set IP
			$this->set('created_by_ip', $_SERVER['REMOTE_ADDR']); 
		}
		catch (JDatabaseException $e )
		{
			$this->setError($e->getMessage());
			return false;
		}
		return true;
	}
	
	/**
     * Check e-mail duplicity
     * @return bool
     * @throws JDatabaseException
     */
	public function emailDuplicity()
	{
        $query = $this->_db->getQuery(true);
        $query->select($this->_db->quoteName('identifier'));
        $query->from($this->_db->quoteName($this->_tbl));
        $query->where($this->_db->quoteName('email') . ' LIKE ' . $this->_db->quote($this->email));
        $query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote($this->identifier));
        $query->where($this->_db->quoteName('settings') . ' LIKE ' . $this->_db->quote(''));
        $query->where($this->_db->quoteName('fullname') . ' NOT LIKE ' . $this->_db->quote('*****'));

		$this->_db->setQuery($query, null, 1);
		
		try
		{
			$result = $this->_db->loadResult();
			if (is_null($result)) {
				throw new JDatabaseException(JText::sprintf('PLG_CONTENT_CDPETITIONS_ERROR_DB', __METHOD__, __FILE__), 500);
			}
		}
		catch (JDatabaseException $e )
		{
			$this->setError($e->getMessage());
			return false;
		}
		
		return ($result ? true : false);
	}
	
	/**
     * Delete all signatures
     * @return bool
     * @throws JDatabaseException
     */
	public function deleteAllSignatures()
	{
        $query = $this->_db->getQuery(true);
        $query->delete();
        $query->from($this->_db->quoteName($this->_tbl));
        $query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote($this->identifier));
        $query->where($this->_db->quoteName('settings') . ' LIKE ' . $this->_db->quote(''));
        $query->where($this->_db->quoteName('fullname') . ' NOT LIKE ' . $this->_db->quote('*****'));

		$this->_db->setQuery($query);
		
		try
		{
			$result = $this->_db->query();
			
			if (is_bool($result) and $result === false) {
				throw new JDatabaseException(JText::sprintf('PLG_CONTENT_CDPETITIONS_ERROR_DB', __METHOD__, __FILE__), 500);
			}
		}
		catch (JDatabaseException $e )
		{
			$this->setError($e->getMessage());
			return false;
		}
		
		return $result === true ? true : false;
	}
	
	/**
     * Rename current identifier
     * @param string $identifier_new
     * @return bool
     * @throws JDatabaseException
     */
	public function renameIdentifier($identifier_new = '')
	{
		if (! $identifier_new ) {
			$this->setError(JText::_('PLG_CONTENT_CDPETITIONS_MISSING_IDENTIFIER'));
			return false;
		}

        $query = $this->_db->getQuery(true);
        $query->update($this->_db->quoteName($this->_tbl));
        $query->set($this->_db->quoteName('identifier') . ' = ' . $this->_db->quote($identifier_new ));
        $query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote($this->identifier));

		$this->_db->setQuery($query);
		
		try
		{
			$result = $this->_db->query();
			
			if (is_bool($result) and $result === false) {
				throw new JDatabaseException(JText::sprintf('PLG_CONTENT_CDPETITIONS_ERROR_DB', __METHOD__, __FILE__), 500);
			}
		}
		catch (JDatabaseException $e )
		{
			$this->setError($e->getMessage());
			return false;
		}
		
		return $result === true ? true : false;
	}
	
	/**
	 * Load settings
	 * @return string
	 */
	public function loadSettings()
	{
		$query = $this->_db->getQuery(true);
		$query->select($this->_db->quoteName('settings'));
		$query->from($this->_db->quoteName($this->_tbl));
		$query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote((string)$this->identifier));
		$query->where($this->_db->quoteName('settings') . ' NOT LIKE ' . $this->_db->quote(''));
		$query->where($this->_db->quoteName('fullname') . ' LIKE ' . $this->_db->quote('*****'));
		$query->where($this->_db->quoteName('published') . ' = 0');
		
		$this->_db->setQuery($query);
		$result = $this->_db->loadResult();
		
		return (string)$result;
	}
	
	/**
	 * Save settings
	 * @return boolean
	 */
	public function saveSettings()
	{
		// check for already existing configuration
		if(!$this->loadSettings())
		{
			// create a new settings first
			$query = $this->_db->getQuery(true);
			$query->insert($this->_db->quoteName($this->_tbl));
			$query->set($this->_db->quoteName('identifier') . ' = ' . $this->_db->quote((string)$this->identifier));
			$query->set($this->_db->quoteName('fullname') . ' = ' . $this->_db->quote('*****'));
			$query->set($this->_db->quoteName('settings') . ' = ' . $this->_db->quote((string)$this->settings));
			$query->set($this->_db->quoteName('published') . ' = 0');
			$query->set($this->_db->quoteName('created') . ' = ' . $this->_db->quote((string)JFactory::getDate()->toSQL()));
			$query->set($this->_db->quoteName('created_by_ip') . ' = ' . $this->_db->quote((string)$_SERVER['REMOTE_ADDR']));
			
			$this->_db->setQuery($query);
			
			try
			{
				if ($this->_db->query() === false)
				{
					throw new JDatabaseException($this->_db->getErrorMsg(), 500);
					return false;
				}
			}
			catch (JDatabaseException $e)
			{
				$this->setError($e->getMessage());
				return false;
			}
			return true;
		}
		
		$query = $this->_db->getQuery(true);
		$query->update($this->_db->quoteName($this->_tbl));
		$query->set($this->_db->quoteName('settings') . ' = ' . $this->_db->quote((string)$this->settings));
		$query->set($this->_db->quoteName('created') . ' = ' . $this->_db->quote((string)JFactory::getDate()->toSQL()));
		$query->set($this->_db->quoteName('created_by_ip') . ' = ' . $this->_db->quote((string)$_SERVER['REMOTE_ADDR']));
		$query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote((string)$this->identifier));
		$query->where($this->_db->quoteName('published') . ' = 0');
		$query->where($this->_db->quoteName('fullname') . ' LIKE ' . $this->_db->quote('*****'));
		
		$this->_db->setQuery($query);
		
		try
		{
			if ($this->_db->query() === false)
			{
				throw new JDatabaseException($this->_db->getErrorMsg(), 500);
				return false;
			}
		}
		catch (JDatabaseException $e)
		{
			$this->setError($e->getMessage());
			return false;
		}
		
		return true;
	}

    /**
     * Verify signature
     * @return boolean
     */
    public function verifySignature()
    {
        // create a new settings first
        $query = $this->_db->getQuery(true);
        $query->update($this->_db->quoteName($this->_tbl));
        $query->set($this->_db->quoteName('published') . ' = 1');
        $query->where($this->_db->quoteName('id') . ' = ' . (int)$this->id);
        $query->where($this->_db->quoteName('authkey') . ' LIKE ' . $this->_db->quote((string)$this->authkey));
        $query->where($this->_db->quoteName('published') . ' = 0');
        $query->where($this->_db->quoteName('settings') . ' LIKE ' . $this->_db->quote(''));
        $query->where($this->_db->quoteName('fullname') . ' NOT LIKE ' . $this->_db->quote('*****'));

        $this->_db->setQuery($query);

        try
        {
            if ($this->_db->query() === false)
            {
                throw new JDatabaseException($this->_db->getErrorMsg(), 500);
                return false;
            }
        }
        catch (JDatabaseException $e)
        {
            $this->setError($e->getMessage());
            return false;
        }

        return true;
    }

    /**
     * Check for email duplication
     * @return boolean
     */
    public function checkEmailDuplication()
    {
        $query = $this->_db->getQuery(true);
        $query->select($this->_db->quoteName('id'));
        $query->from($this->_db->quoteName($this->_tbl));
        $query->where($this->_db->quoteName('identifier') . ' LIKE ' . $this->_db->quote((string)$this->identifier));
        $query->where($this->_db->quoteName('email') . ' LIKE ' . $this->_db->quote((string)$this->email));
        $query->where($this->_db->quoteName('settings') . ' LIKE ' . $this->_db->quote(''));
        $query->where($this->_db->quoteName('fullname') . ' NOT LIKE ' . $this->_db->quote('*****'));

        $this->_db->setQuery($query);

        try
        {
            $result = (int)$this->_db->loadResult();
            if ($this->_db->query() === false)
            {
                throw new JDatabaseException($this->_db->getErrorMsg(), 500);
                return false;
            }
        }
        catch (JDatabaseException $e)
        {
            $this->setError($e->getMessage());
            return false;
        }

        return $result;
    }

    /**
     * Restore signatures
     * @param array $xml
     */
    public function restoreSignatures($xml = array())
    {
        $query = array();
        $query_part = array();

        $query[] = 'TRUNCATE TABLE ' . $this->_db->quoteName($this->_tbl) . ';';

        $this->_db->setQuery(implode("\n", $query));
        try
        {
            if ($this->_db->query() === false)
            {
                throw new JDatabaseException($this->_db->getErrorMsg(), 500);
                return false;
            }
        }
        catch (JDatabaseException $e)
        {
            $this->setError($e->getMessage());
            return false;
        }

        $query = array();

        static $once = false;
        foreach($xml->children() as $child)
        {
            $child = (array)$child;

            if (!$once)
            {
                $query[] = $this->_db->getQuery(true)->insert($this->_db->quoteName($this->_tbl));
                $query[] = '(' . implode(', ', array_keys($child)) . ') VALUES ';
                $once = true;
            }

            $query_part[] = '(' . implode(', ', array_map(array($this->_db, 'quote'), $child)) . ')';
        }
        $query[] = implode(', ', $query_part) . ';';

        $this->_db->setQuery(implode("\n", $query));

        try
        {
            if ($this->_db->query() === false)
            {
                throw new JDatabaseException($this->_db->getErrorMsg(), 500);
                return false;
            }
        }
        catch (JDatabaseException $e)
        {
            $this->setError($e->getMessage());
            return false;
        }
        return true;

    }
}
?>