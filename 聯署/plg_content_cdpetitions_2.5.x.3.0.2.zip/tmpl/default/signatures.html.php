<?php
/**
 * Core Design Petitions plugin for Joomla! 2.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		2.5.x.3.0.2
 * @copyright	Copyright (C) 2007 - 2012 Great Joomla!, http://www.greatjoomla.com
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPL 3
 * 
 * This file is part of Great Joomla! extension.   
 * This extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die;
static $some_fields_exists = false;
?>
<div class="{$name}_signatures">
    <a href="#" name="{$name}_signatures"></a>
    <?php if ((int) $this->settings->get('display_feed', 0)): ?>
        <?php if (!(int)$this->settings->get('hide_signatures_for_guests', 0) or !$this->JUser->guest): ?>
            <div class="{$name}_rssfeed">
                <a
                    href="<?php echo $this->JScriptegrator->buildURL('html', false, $this->_name, array($this->_name . '_task' => 'get_rssFeed')); ?>"
                    data-{$name}-ui-button='<?php echo json_encode( array( 'text' => true, 'icons' => array( 'primary' => 'ui-icon-feed' ) ) ); ?>'
                ><?php echo JText::_('PLG_CONTENT_CDPETITIONS_FEED_LINK'); ?></a>
            </div>
	<?php endif; ?>
	<div class="{$name}_cleaner"></div>
<?php endif; ?>
	<?php if ($this->settings->get('hide_signatures_for_guests', 0) and $this->JUser->guest): ?>
		<?php echo $this->stateTmpl( JText::_('PLG_CONTENT_CDPETITIONS_FOR_LOGGED_IN_ONLY'), 'error'); ?>
	<?php else: ?>
		<?php if (!$signatures): ?>
			<?php echo $this->stateTmpl( JText::_('PLG_CONTENT_CDPETITIONS_NO_SIGNATURES') ); ?>
		<?php else: ?>
			<table border="0" cellspacing="0" cellpadding="0">
				<thead class="ui-state-hover">
						<tr>
							<?php foreach($fields as $name=>$field): ?>
								<?php if (isset($field->enabled) and $field->enabled): ?>
									<?php if (isset($field->access_level) and array_intersect($this->JUser->getAuthorisedViewLevels(), $field->access_level) or in_array(0, $field->access_level)): ?>
										<?php $some_fields_exists = true; ?>
										<th><?php echo JText::_('PLG_CONTENT_CDPETITIONS_' . strtoupper($name)); ?></th>
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; ?>
						</tr>
				</thead>
				<tbody>
					<tr style="height: 10px;"><td colspan="4"></td></tr>
					<?php foreach($signatures as $key=>$signature): ?>
						<?php $key_class = (($key % 2) ? $this->_name . '_odd' : $this->_name . '_even'); ?>
						<tr>
							<?php foreach($fields as $name=>$field): ?>
								<?php if (isset($field->enabled) and (int)$field->enabled): ?>
									<?php if (isset($signature->$name)): ?>
                                        <?php if (isset($field->access_level) and array_intersect($this->JUser->getAuthorisedViewLevels(), $field->access_level) or in_array(0, $field->access_level)): ?>
											<td class="<?php echo $key_class; ?>">
												<?php static $anchor_once = 0; ?>
												<?php if (!$anchor_once): ?>
													<a href="#" name="{$name}_signatures_<?php echo $signature->id; ?>"></a>
													<?php $anchor_once = 1; ?>
												<?php endif; ?>
												<?php if ($signature->$name): ?>
													<?php
													$fields_numbered = array_keys($fields);
													$current = array_search($name, $fields_numbered);
													?>
													<?php if ($current === 0 and $this->authorisedTo('manage')): ?>
														<div class="{$name}_adminblock">
															<form style="display: inline-block;" action="<?php echo $this->formActionURL; ?>" method="post" data-{$name}-event='<?php echo json_encode( array( 'type' => 'submit', 'name' => 'removeSignature' ) ); ?>'>
																<a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_DELETE')); ?>" data-{$name}-event='<?php echo json_encode( array( 'type' => 'click', 'name' => 'removeSignature' ) ); ?>' class="{$name}_delete" title="<?php echo JText::_('PLG_CONTENT_CDPETITIONS_DELETE'); ?>">&nbsp;</a>
																<input type="hidden" name="{$name}_id" value="<?php echo $signature->id; ?>" />
																<input type="hidden" name="{$name}_task" value="post_removeSignature" />
																<?php echo JHTML::_('form.token'); ?>
															</form>
														</div>
													<?php endif; ?>
													<div class="{$name}_<?php echo $name; ?>">
														<?php if ($name === 'note' or $name === 'email'): ?>
															<a href=<?php if ($name === 'email'): ?>"mailto:<?php echo strip_tags($signature->$name); ?>"<?php else: ?>"#" data-{$name}-tooltip='<?php echo htmlspecialchars($signature->$name, ENT_QUOTES); ?>'<?php endif; ?>>
																<?php if ($name === 'email'): ?><?php echo strip_tags($signature->$name); ?><?php else: ?>&nbsp;<?php endif; ?>
															</a>
														<?php endif; ?>
														<?php if ($name !== 'note' and $name !== 'email'): ?>
															<?php echo htmlspecialchars($signature->$name); ?>
														<?php endif; ?>
													</div>
												<?php endif; ?>
											</td>
										<?php endif; ?>
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php if ($limit_per_page = (int)$this->settings->get('limit_per_page', 20) and $some_fields_exists): ?>
				<?php if ($this->total > $limit_per_page): ?>
					<?php 
					jimport('joomla.html.pagination');
					$pagination = new JPagination($this->total, $limitstart, $limit_per_page, $this->_name . '_');
					?>
					<div class="pagination">
						<?php echo preg_replace('#(' . $this->_name . '_limitstart=\d+)"#', '$1#' . $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_TABTITLE_SIGNATURES')) . '"', $pagination->getPagesLinks()); ?>
						<div><?php echo $pagination->getResultsCounter(); ?></div>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		<?php endif; ?>
	<?php endif; ?>
</div>