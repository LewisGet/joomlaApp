/**
 * Core Design Petitions plugin for Joomla! 2.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		2.5.x.3.0.2
 * @copyright	Copyright (C) 2007 - 2012 Great Joomla!, http://www.greatjoomla.com
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPL 3
 * 
 * This file is part of Great Joomla! extension.   
 * This extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


if (typeof(jQuery) === 'function') {
	
	(function($) {
		
		$.fn.cdpetitions = function(options) {

			// set defaults
			var defaults = {
					name : 'cdpetitions',
					uitheme : 'ui-lightness',
                    language : {
                        PLG_CONTENT_CDPETITIONS_CONFIRMATION : 'Really?',
                        PLG_CONTENT_CDPETITIONS_UTILITIES_ENTER_PETITION_ID : 'Enter new petition ID:',
                        PLG_CONTENT_CDPETITIONS_EMPTY_VALUE : 'Please check all form fields.',
                        PLG_CONTENT_CDPETITIONS_ERROR_VALIDATION_EMAIL : 'Please check your e-mail address.',
                        PLG_CONTENT_CDPETITIONS_INTERACTIVE_OK : 'OK'
                    },
					progressbarvalue : null,
					isAuthorized : false,
					useAjax : false
				},
			opts = $.extend(defaults, options);
			
			return this.each(function() {
				$this = $(this);

				var signPetitionForm = $('form[name="signPetitionForm"]', $this);
				
				// change url hash based on URL param
				var url_hash = getParamFromURL('cdpetitions_hash');
				if (url_hash) {
					window.location.hash = url_hash;
				}
				
				layout();
				initEvents();

				facebookComments();
				
				// process adminblock buttons
				if(opts.isAuthorized) {
					
					$('.adminblock button', $this).each(function() {
						
						if($(this).hasClass('button_delete')) {
							$(this).button({ icons : { primary: 'ui-icon-trash' }, text : false });
						}
						
						// mailto
						if($(this).hasClass('button_mailto')) {
							$(this).button({ icons : { primary: 'ui-icon-mail-closed' }, text : false }).click(function(e) {
								e.preventDefault();
								window.location.href = $(this).next('a').attr('href');
							});
						}
					});
				}
				
				// focus input
				$('.formfield', signPetitionForm).click(function() {
					$('input', $(this)).focus();
				});
				
				// change bg when focused
				$('.formfield input', signPetitionForm).each(function() {
					var bg_position = $(this).closest('.formfield').css('background-position');
					
					$(this).focus(function() {
						$(this).closest('.formfield').css('background-position', '50% 50%');
					}).blur(function() {
						$(this).closest('.formfield').css('background-position', bg_position);
					});
				});
				
				// add "signatures" hash to all links in pagination
				$('.navigation a', $this).each(function() {
					$(this).attr('href', $(this).attr('href') + '#signatures');
				});
				
				// progressbar
				if (typeof opts.progressbarvalue === 'number') {
					$('.' + opts.name + '_progressbar', $this).progressbar({
						value : opts.progressbarvalue
					});
				}
			});

			/**
			 * Facebook comments
			 */
			function facebookComments()
			{
                var element = $('.' + opts.name + '_facebook_comments', $this);
                if (typeof element === 'undefined') return false;

                var element_data = element.data(opts.name + '-facebook-comments');
                if (typeof element_data === 'undefined') return false;

				// missing Facebook application ID
				if (!element_data.APP_ID) return true;
				
				$.getScript("//connect.facebook.net/en_US/all.js", function(data, textStatus, jqxhr) {
				   if (jqxhr.status !== 200) return false;
				   
				   $('head').append('<meta property="fb:app_id" content="' + element_data.APP_ID + '" />');
				   $('head').append('<meta property="fb:admins" content="' + element_data.admins + '" />');
				   
				   FB.init({
				      appId      : element_data.APP_ID,
				      channelUrl : '//connect.facebook.net/en_US/all.js',
				      status     : true,
				      cookie     : true,
				      xfbml      : true 
				    });
				   
				  $('.' + opts.name + '_facebook_comments').append('<div class="fb-comments" data-href="' + window.location.href + '" data-num-posts="10" data-colorscheme="' + element_data.colorscheme + '" data-width="470"></div>');
				});
			};
			
			/**
			 * Rename identifier
			 */
			function submit_renameIdentifier(form, event)
			{
				var prompt_submit = prompt(opts.language.PLG_CONTENT_CDPETITIONS_UTILITIES_ENTER_PETITION_ID, $('input:hidden[name="identifier"]', form).val());
				
				if (!prompt_submit) {
					event.preventDefault();
					return false;
				} else {
					if (prompt_submit === $('input:hidden[name="identifier"]', form).val() ) {
						event.preventDefault();
						return false;
					}
					$('input:hidden[name="identifier_new"]', form).val(prompt_submit);
					return true;
				}
				return false;
			};
			
			/**
			 * Check if goal value is not higher or lower then allowed
			 */
			function blur_checkForGoalValue(element, event)
			{
				var collected = element.data(opts.name + '-collected') * 1,
				value = element.val() * 1;
				
				if (value > 0 && value < collected)
				{
                    custom_alert(element.data(opts.name + '-error-collected-higher'), element.closest('form'), function() {
                        element.val(collected);
                        element.focus();
                    });
                    return false;
				}
				return true;
			};
			
			/**
			 * Save setings
			 */
			function submit_saveSettings(form, event)
			{
				var submitform = true;
				
				if (!submitform)
				{
					event.preventDefault();
					return false;
				}
				
				return true;
			};
			
			/**
			 * Sign petition form
			 */
			function submit_signPetition(form, event)
			{
                /**
                 * Validation error handling
                 * @param field
                 */
                function validationErrorHandle(field)
                {
                    field.addClass('ui-state-error');
                    field.bind('change.' + opts.name + ', keypress.' + opts.name + '', function() {
                        $(this).removeClass('ui-state-error').unbind('change.' + opts.name + ', keypress.' + opts.name + '');
                    });
                };

				var submitform = true;

                // required fields
                $('input:text, select, textarea').filter(function() {
                    return $(this).data(opts.name + '-required');
                }).each(function() {
                        var field = $(this);

                        if (field.val() === '')
                        {
                            submitform = false;
                            custom_alert(opts.language.PLG_CONTENT_CDPETITIONS_EMPTY_VALUE, field.closest('form'), function() {
                                field.focus();
                                validationErrorHandle(field);
                            });
                            return false;
                        }
                    });

                if (submitform)
                {
                    // check also validation
                    $('input:text, select, textarea').filter(function() {
                        return $(this).data(opts.name + '-validation');
                    }).each(function() {
                            var field = $(this),
                                validation = field.data(opts.name + '-validation');

                            if (!field.val()) return true;

                            if (validation.type && eval('typeof validation_' + validation.type) === 'function')
                            {
                                if(!eval('validation_' + validation.type + '(field.val());'))
                                {
                                    custom_alert(validation.errorMsg, field.closest('form'), function() {
                                        field.focus();
                                        validationErrorHandle(field);
                                    });
                                    submitform = false;
                                    return false;
                                }
                            }

                        });
                }

				if (!submitform)
				{
					event.preventDefault();
                    return false;
				}

				return true;
			};

            /**
             * Check for email duplication
             * @param input
             * @param event
             */
            function blur_checkEmailDuplication(input, event)
            {
                // if no email entered do not perform a request
                if (input.val() === '') return false;

                var form = input.closest('form').clone();

                $(':hidden[name="' + opts.name + '_task"]', form).val('post_checkEmailDuplication');

                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    cache: true,
                    data: form.serialize(),
                    success: function(msg) {
                        if (msg.status === 'error') {
                            custom_alert(msg.content, input.closest('form'));
                            return false;
                        }

                        return true;
                    }
                });
            }

            /**
             * Validation - age
             * @param string
             * @return {Boolean}
             */
            function validation_age(mixed_var)
            {
                if(parseFloat(mixed_var) != parseInt(mixed_var))
                {
                    return false;
                }
                if (mixed_var * 1 < 1)
                {
                    return false;
                }
                // highest person age based on Wikipedia info
                if (mixed_var * 1 > 122)
                {
                    return false;
                }
                return true;
            };

            /**
             * Validation - email
             * @param string
             * @return {Boolean}
             */
            function validation_email(mixed_var) {
                var filter = new RegExp('^([a-z0-9\\+_\\-]+)(\\.[a-z0-9\\+_\\-]+)*@([a-z0-9\\-]+\\.)+[a-z]{2,6}$');
                if (!filter.test(mixed_var)) return false;
                return true;
            };
			
			/**
			 * Delete signature
			 */
			function submit_removeSignature(form, event)
			{
				var delete_submit = confirm(opts.language.PLG_CONTENT_CDPETITIONS_CONFIRMATION);
				
				if (!delete_submit) {
					event.preventDefault();
					return false;
				} else {
					if (opts.useAjax) {
						event.preventDefault();
						
						$.ajax({
							type: 'POST',				
							dataType: 'json',
							cache: true,
							data: form.serialize(),
							beforeSend: function() { $('button:submit', form).button('disable'); },
							success: function(msg) {
								if (msg.status === 'error') {
									alert(msg.content);
									return false;
								}
								
								// fadeOut signature
								form.closest('tr').fadeOut();
								
								// decrease "sofar" number
								var sofar_number = $('.' + opts.name + '_sofar', $this).html().match(/\d+/gi);
								var new_sofar = $('.' + opts.name + '_sofar', $this).html().replace(/\d+/i, sofar_number[0] * 1 - 1);
								$('.' + opts.name + '_sofar', $this).empty().html(new_sofar);

                                // decrease count of signatures in tab header
                                var count_element = $('.ui-tabs-nav li:eq(' + form.closest('.ui-tabs').tabs('option', 'selected') + ') a', form.closest('.ui-tabs')),
                                    current_count = count_element.text().match(/\((\d+)\)$/i)[1] * 1,
                                    new_current = count_element.html().replace(/\((\d+\))$/i, '(' + (current_count - 1) + ')');
                                count_element.empty().html(new_current);

								return true;
							},
							complete: function() { $('button:submit', form).button('enable'); }
						});
					}
					return true;
				}
			};
			
			/**
			 * Delete signature - click on image
			 */
			function click_removeSignature(element, event)
			{
				if (event.type !== 'click') return false;
				
				event.preventDefault();
				element.parent('form').submit();
			};
			
			/**
			 * Click and open tab with sign form
			 */
			function click_openSignForm(element, event)
			{
				if (event.type !== 'click') return false;
				event.preventDefault();
				
				$('.ui-tabs-nav a:first', element.closest('.ui-tabs')).click();
				window.location.href = '#' + opts.name + '_signpetition';
			};
			
			/**
			 * Delete all signatures;
			 */
			function submit_deleteAllSignatures(form, event)
			{
				var delete_submit = confirm(opts.language.PLG_CONTENT_CDPETITIONS_CONFIRMATION);
				
				if (!delete_submit) {
					event.preventDefault();
					return false;
				}
				
				if (opts.useAjax) {
					// set variable back to false to prevent other forms submission
					delete_submit = false;
					
					event.preventDefault();
					
					$.ajax({
						type: 'POST',				
						dataType: 'json',
						cache: true,
						data: form.serialize(),
						beforeSend: function() { $('button:submit', form).button('disable'); },
						success: function(msg) {
							if (msg.status === 'error') {
								alert(msg.content);
								return false;
							}
							
							// hide box with signatures
							$('table:first', $this).hide();
							
							// hide pagination
							$('table:first', $this).next('.pagination').hide();
							
							// null "sofar" number
							var new_sofar = $('.sofar', $this).html().replace(/\d+/i, "0");
							$('.sofar', $this).empty().html(new_sofar);
							
							return true;
						},
						complete: function() { $('button:submit', form).button('enable'); }
					});
				}
				return true;
			};

            /**
             * Check if submitted file is XML
             * @param form
             * @param event
             * @return boolean
             */
            function submit_checkForXML(form, event)
            {
                var error = false,
                    upload = $(':file', form);

                if (upload.val() === '')
                {
                    custom_alert(form.data(opts.name + '-incorrectfileformatmsg'), form.closest('.ui-accordion-content'));
                    error = true;
                }

                if (upload.val().substr(upload.val().lastIndexOf('.')) !== '.xml')
                {
                    custom_alert(form.data(opts.name + '-incorrectfileformatmsg'), form.closest('.ui-accordion-content'));
                    error = true;
                }

                if (error)
                {
                    event.preventDefault();
                    return false;
                }
                return true;
            };
			
			/**
			 * Connect Facebook
			 */
			function click_connectFacebook(element, event) {
				window.location.href = element.data(opts.name + '-facebook-link');
			};
			
			/**
			 * Tooltip
			 */
			function tooltip()
			{
				var tooltip = undefined;
				
				// UI Buttons
				$('a, input', $this ).filter( function() {
					return $(this).data(opts.name + '-tooltip');
				}).hover(
					function() {
						var element = $(this);
						
						tooltip = $('<div />', {
							'class' : opts.name + '_tooltip ui-widget-content ui-corner-all',
							html : element.data(opts.name + '-tooltip')
						});
						
						var frame = $('<div />', {
							'class' : opts.uitheme + ' ' + opts.name,
							html : tooltip
						}).appendTo('body');
						
						tooltip.show().position({
							my : 'center top',
							at : 'center bottom',
							of : element,
							offset: '5'
						}).hide().stop(true, true).fadeIn();
					},
					function() {
						tooltip.stop(true, true).fadeOut(function() { $(this).parent().remove(); });
						tooltip = undefined;
					}
				);
			};
			
			/**
			 * Layout area
			 * @return	void
			 */
			function layout()
			{
				// UI Buttons
				$( 'button, a', $this ).filter( function() {
					// select only BUTTON and A elements with specified set of data
					return $(this).data( opts.name + '-ui-button' )  && typeof $(this).data('button') === 'undefined';
				} ).each( function() {
					var	element = $(this),
					data = element.data( opts.name + '-ui-button' );
					element.button( (typeof data === 'object' ? data : null) );
				} );
				
				// accordion
				$( 'div', $this ).filter( function() {
					return $(this).data( opts.name + '-ui-accordion' ) && typeof $(this).data('accordion') === 'undefined';
				} ).each( function() {
					var	element = $(this),
					data = element.data( opts.name + '-ui-accordion' );
					element.accordion( (typeof data === 'object' ? data : null) );
				} );
				// tabs
				$( 'div', $this ).filter( function() {
					return $(this).data( opts.name + '-ui-tabs' ) && typeof $(this).data('tabs') === 'undefined';
				} ).each( function() {
					var	element = $(this),
					data = element.data( opts.name + '-ui-tabs' );
					element.tabs( (typeof data === 'object' ? data : null) );
				} );
				
				// tooltip
				tooltip();

                // autocomplete
                $('input', $this).filter(function() {
                    return $(this).data(opts.name + '-ui-autocomplete') && typeof $(this).data('autocomplete') === 'undefined';
                } ).each(function() {
                    var	element = $(this),
                    data = new Array();

                    $.each(element.data(opts.name + '-ui-autocomplete'), function(id, value) {
                        var item = {
                            id : id,
                            value : value
                        };
                        data.push(item);
                    });

                    element.autocomplete({
                        source : data,
                        appendTo : $this
                    });
                });
			};
			
			/**
			 * Register Events
			 */
			function initEvents()
			{
				var on_events = new Array();
				on_events[0] = {
						element : 'form',
						event : 'submit.' + opts.name
				},
				on_events[1] = {
						element : 'a, div',
						event : 'hover.' + opts.name
				},
				on_events[2] = {
						element : 'a, button',
						event : 'click.' + opts.name
				},
				on_events[3] = {
						element : 'input',
						event : 'blur.' + opts.name
				};
				$.each(on_events, function() {
					$this.on( this.event, this.element, function(e) {
						var element = $(this);
						
						if(element.data(opts.name + '-event')) {
							if (typeof element.data(opts.name + '-event') !== 'array') {
								// make array
								element.data(opts.name + '-event', $.makeArray(element.data(opts.name + '-event')));
							}
							$.each(element.data(opts.name + '-event'), function() {
								if (eval('typeof ' + this.type + '_' + this.name) === 'function') {
									eval(this.type + '_' + this.name + '(element, e);');
								}
							});
						}
					} );
				});
			};
			
			/**
			 * Validate e-mail
			 * 
			 * @param email
			 * @return boolean
			 */
			function validateEmail(email) {
				var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				if (!filter.test(email)) return false;
				return true;
			};
			
			/**
			 * Get URL param
			 * 
			 * @param	string	name
			 * @return	string
			 */
			function getParamFromURL(name) {
			  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
			  var regexS = "[\\?&]"+name+"=([^&#]*)";
			  var regex = new RegExp( regexS );
			  var results = regex.exec( window.location.href );
			  if( results == null )
			    return "";
			  else
			    return results[1];
			};

            /**
             * Alert replacement
             * @param message
             * @param element
             * @param click_on_ok
             */
            function custom_alert(message, element, click_on_ok)
            {
                if (typeof element === 'undefined') return false;
                if (typeof message === 'undefined') return false;

                // clean previous layer
                if ($('.ui-widget-overlay', element).length)
                {
                    var container = $('.' + opts.name + '_interactive_window', element);
                    container.prev().remove();
                    container.remove();
                    element.removeAttr('style');
                }

                element.css('position', 'relative');

                var layer = $('<div />', {
                    'class' : 'ui-widget-overlay'
                });
                element.append(layer);

                var interactive_window = $('<div />', {
                    'class' : 'ui-widget-content ui-corner-all ' + opts.name + '_interactive_window',
                    html : message
                });

                element.append(interactive_window);

                var buttons = $('<div />', {
                    'class' : opts.name + '_interactive_window_buttons',
                    html : '<button type="button">' + opts.language.PLG_CONTENT_CDPETITIONS_INTERACTIVE_OK + '</button>'
                });
                $('button:first', buttons).button({
                    icons : {
                        primary : 'ui-icon-circle-check'
                    }
                });

                // button events
                $('button:first', buttons).click(function() {
                    var container = $(this).closest('.' + opts.name + '_interactive_window');
                    container.prev().remove();
                    container.remove();
                    element.removeAttr('style');

                    if (typeof click_on_ok === 'function')
                    {
                        click_on_ok();
                    }

                });

                interactive_window.append(buttons)
                .position({
                    of : element,
                    my : 'center center',
                    at : 'center center'
                });

                $('button:first', buttons).focus();
            };
		};
	})(jQuery);
}