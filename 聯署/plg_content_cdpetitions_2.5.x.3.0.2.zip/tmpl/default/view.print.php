<?php
/**
 * Core Design Petitions plugin for Joomla! 2.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		2.5.x.3.0.2
 * @copyright	Copyright (C) 2007 - 2012 Great Joomla!, http://www.greatjoomla.com
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPL 3
 *
 * This file is part of Great Joomla! extension.
 * This extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die;
?>
<div class="{$name} <?php echo (string)$this->settings->get('uitheme', 'ui-lightness'); ?>" id="{$name}_<?php echo $this->unique_id; ?>">
    <?php if ($petition_title = (string)$this->settings->get('title', '')): ?>
    <h3 class="{$name}_petition_title"><?php echo htmlspecialchars($petition_title); ?></h3>
    <?php endif; ?>
    <div data-{$name}-ui-tabs='true'>
    <ul>
        <li><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_TABTITLE_SIGNATURES')); ?>"><span class="ui-icon ui-icon-person">&nbsp;</span><?php echo JText::_('PLG_CONTENT_CDPETITIONS_TABTITLE_SIGNATURES'); ?> (<?php echo (int)$this->total; ?>)</a></li>
    </ul>
    <div id="<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_TABTITLE_SIGNATURES')); ?>">
        <?php if ($signatures_filepath = $this->getLayoutPath('signatures')): ?>
        <?php require $signatures_filepath; ?>
        <?php endif; ?>
    </div>
</div>
<div class="{$name}_poweredby">Petitions by <a href="http://www.greatjoomla.com/" target="_blank" title="Great Joomla!">Great Joomla!</a></div>
</div>