<?php
/**
 * Core Design Petitions plugin for Joomla! 2.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		2.5.x.3.0.2
 * @copyright	Copyright (C) 2007 - 2012 Great Joomla!, http://www.greatjoomla.com
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPL 3
 * 
 * This file is part of Great Joomla! extension.   
 * This extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die;
?>
<a href="#" name="{$name}_signpetition"></a>
<div class="{$name}_signpetition">
	<?php if ((int)$this->settings->get('show_collected', 0) and !isset($template_do_not_show_collected)): ?>
		<?php if($collected_filepath = $this->getLayoutPath('collected')) require($collected_filepath); ?>
	<?php endif; ?>
	<?php if ((int)$this->settings->get('closed', 0)): ?>
		<div class="{$name}_petition_closed"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_CLOSED'); ?></div>
		<?php else: ?>
			<?php if ($this->goal and $this->goal - $this->total < 1): ?>
			 <div class="{$name}_goal_collected"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_GOAL_COLLECTED'); ?></div>
		<?php else: ?>
			<?php if ($fields): ?>
				<form action="<?php echo $this->formActionURL; ?>" method="post" name="signPetitionForm" data-{$name}-event='<?php echo json_encode( array( 'type' => 'submit', 'name' => 'signPetition' ) ); ?>'>
					<?php foreach($fields as $name=>$field): ?>
						<?php if (isset($field->enabled) and (int)$field->enabled and isset($field->field_type)): ?>
							<div class="{$name}_formfield ui-widget-content ui-helper-clearfix">
								<label for="<?php echo $name; ?>_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_' . strtoupper($name)); ?> <?php if (isset($field->required) and (int)$field->required): ?> <sup>[*]</sup><?php endif; ?><?php if (isset($field->access_level) and !array_intersect(array(0, 1), $field->access_level)): ?> <sup>[1]</sup><?php endif; ?></label>
								<?php switch($field->field_type):
									case 'text': ?>
                                        <?php if (isset($field->disabled_for_logged_in) and (int)$this->JUser->guest === 0): ?>
                                            <?php echo $this->JSession->get($this->_name . '_' . $name, ''); ?>
                                            <input
                                                type="hidden"
                                                name="{$name}_<?php echo $name; ?>"
                                                value="<?php echo $this->JSession->get($this->_name . '_' . $name, ''); ?>"
                                            />
                                        <?php else: ?>
                                            <input
                                                type="text"
                                                id="<?php echo $name; ?>_<?php echo $this->random; ?>"
                                                name="{$name}_<?php echo $name; ?>"
                                                value="<?php echo $this->JSession->get($this->_name . '_' . $name, ''); ?>"
                                                <?php if (isset($field->disabled_for_logged_in) and (int)$this->JUser->guest === 0): ?>
                                                    readonly="readonly"
                                                <?php endif; ?>
                                                <?php if (isset($field->required) and (int)$field->required): ?>
                                                    data-{$name}-required="required"
                                                <?php endif; ?>
                                                <?php if (isset($field->autocomplete)): ?>
                                                    data-{$name}-ui-autocomplete="<?php echo htmlspecialchars(json_encode($field->autocomplete), ENT_QUOTES); ?>"
                                                <?php endif; ?>
                                                <?php if (isset($field->javascript_event)): ?>
                                                    data-{$name}-event='<?php echo json_encode(eval(stripslashes($field->javascript_event))); ?>'
                                                <?php endif; ?>
                                                <?php if (isset($field->validation)): ?>
                                                    data-{$name}-validation='<?php echo json_encode(array('type' => $field->validation, 'errorMsg' => $field->validation_errorMsg), ENT_QUOTES); ?>'
                                                <?php endif; ?>
                                            />
                                        <?php endif; ?>
									<?php break; ?>
									<?php case 'textarea': ?>
										<textarea
                                            name="{$name}_<?php echo $name; ?>"
                                            id="<?php echo $name; ?>_<?php echo $this->random; ?>"
                                            rows="5"
                                            cols="22"
                                            <?php if (isset($field->validation)): ?>
                                                  data-{$name}-validation="<?php echo $field->validation; ?>"
                                            <?php endif; ?>
                                            <?php if (isset($field->javascript_event)): ?>
                                            data-{$name}-event='<?php echo json_encode(eval($field->javascript_event)); ?>'
                                            <?php endif; ?>
                                        ><?php echo $this->JSession->get($this->_name . '_' . $name, ''); ?></textarea>
									<?php break; ?>
								<?php endswitch; ?>
							</div>
						<?php endif; ?>
					<?php endforeach; ?>
					<div class="{$name}_formfield_submit {$name}_sign">
						<button
							type="submit"
							name="submit"
							data-{$name}-ui-button='<?php echo json_encode( array( 'icons' => array( 'primary' => 'ui-icon-pencil' ) ) ); ?>'
						><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SIGN_PETITION_SUBMIT'); ?></button>
						<?php if ($this->JUser->guest and (string)$this->settings->get( 'facebook.signup.APP_ID', '' ) and is_array( $facebook_data ) and $facebook_data['state'] === 0 ): ?>
							<button
								type="button"
								data-{$name}-ui-button='<?php echo json_encode( array( 'text' => false, 'icons' => array( 'primary' => 'ui-icon-facebook' ) ) ); ?>'
								data-{$name}-event='<?php echo json_encode( array( 'type' => 'click', 'name' => 'connectFacebook' ) ); ?>'
								data-{$name}-facebook-link='<?php echo $facebook_data['link']; ?>'
							><?php echo JText::_( 'PLG_CONTENT_CDPETITIONS_SIGN_PETITION_FACEBOOK_CONNECT' ); ?></button>
						<?php endif; ?>
					</div>
					<div class="required_info">
                        <sup>[*]</sup> <?php echo JText::_('PLG_CONTENT_CDPETITIONS_REQUIRED_FIELDS'); ?>
                        <?php
                        $not_visible_for_public_fields = false;
                        foreach($fields as $name=>$field)
                        {
                            if (isset($field->enabled) and $field->enabled and isset($field->access_level) and !array_intersect($this->JUser->getAuthorisedViewLevels(), $field->access_level))
                            {
                                $not_visible_for_public_fields = true;
                                break;
                            }
                        }
                        ?>
                        <?php if ($not_visible_for_public_fields): ?>
                            <br /><sup>[1]</sup> <?php echo JText::_('PLG_CONTENT_CDPETITIONS_FIELD_NOT_DISPLAYED_PUBLICLY'); ?>
                        <?php endif; ?>
                    </div>
					<input type="hidden" name="{$name}_identifier" value="<?php echo $this->settings->get('identifier', ''); ?>" />
					<input type="hidden" name="{$name}_task" value="post_signPetition" />
					<?php echo JHTML::_('form.token'); ?>
				</form>
			<?php else: ?>
				<?php echo $this->stateTmpl(JText::_('PLG_CONTENT_CDPETITIONS_ERROR_NO_FIELDS_DEFINED'), 'error', 'ui-icon-alert'); ?>
			<?php endif; ?>
		<?php endif; ?>
	<?php endif; ?>
</div>