<?php
/**
 * Core Design Petitions plugin for Joomla! 2.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		2.5.x.3.0.2
 * @copyright	Copyright (C) 2007 - 2012 Great Joomla!, http://www.greatjoomla.com
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPL 3
 *
 * This file is part of Great Joomla! extension.
 * This extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die;
?>
<div class="{$name}_settings">
	<div data-{$name}-ui-accordion='<?php echo json_encode( array( 'active' => false, 'collapsible' => true, 'heightStyle' => 'content' ) ); ?>'>
		<h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE'); ?></a></h3>
		<div class="ui-widget-content {$name}_settings_container">
			<form action="<?php echo $this->formActionURL; ?>" method="post" data-{$name}-event='<?php echo json_encode( array( 'type' => 'submit', 'name' => 'saveSettings' ) ); ?>'>
				<div data-{$name}-ui-tabs='true'>
					<ul>
                        <li><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FIELDS')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FIELDS'); ?></a></li>
                        <li><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_CONFIGURATION')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_CONFIGURATION'); ?></a></li>
                        <li><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_NOTIFICATIONS')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_NOTIFICATIONS'); ?></a></li>
                        <li><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK'); ?></a></li>
					</ul>
                <div id="<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FIELDS')); ?>" class="{$name}_settings_fields">
                    <div data-{$name}-ui-accordion='<?php echo json_encode( array( 'active' => false, 'collapsible' => true, 'heightStyle' => 'content' ) ); ?>'>
                        <?php foreach($this->getSettingsFields()->fieldset->field as $field): ?>
                            <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FIELDS') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FIELDS_TITLE_' . strtoupper($field['name']))); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FIELDS_TITLE_' . strtoupper($field['name'])); ?></a></h3>
                            <div>
                                <?php if ($field['description']): ?>
                                    <div class="{$name}_settings_description"><?php echo JText::_($field['description']); ?></div>
                                <?php endif; ?>
                                <input type="checkbox" name="{$name}_settings[fields][<?php echo $field['name']; ?>][enabled]" value="1" id="{$name}_settings_fields_enabled_<?php echo $field['name']; ?>_<?php echo $this->random; ?>"<?php if ((int)$this->settings->get('fields.' . $field['name'] . '.enabled', 0)): ?> checked="checked"<?php endif; ?> />
                                <label for="{$name}_settings_fields_enabled_<?php echo $field['name']; ?>_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FIELDS_ENABLED'); ?></label>
                                <input type="checkbox" name="{$name}_settings[fields][<?php echo $field['name']; ?>][required]" value="1" id="{$name}_settings_fields_required_<?php echo $field['name']; ?>_<?php echo $this->random; ?>"<?php if ((int)$this->settings->get('fields.' . $field['name'] . '.required', 0)): ?> checked="checked"<?php endif; ?> />
                                <label for="{$name}_settings_fields_required_<?php echo $field['name']; ?>_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FIELDS_REQUIRED'); ?></label>
                                <br /><br />
                                <div class="{$name}_form_fieldset">
                                    <label for="{$name}_settings_fields_access_level_<?php echo $field['name']; ?>_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FIELDS_VISIBILITY_ACCESS_LEVEL'); ?></label>
                                    <div>
                                        <?php
                                        $visibility_levels = (array)$this->settings->get('fields.' . $field['name'] . '.access_level', array());
                                        $levels = (array)$this->loadUserLevels();
                                        ?>
                                        <select name="{$name}_settings[fields][<?php echo $field['name']; ?>][access_level][]" multiple="multiple" id="{$name}_settings_fields_access_level_<?php echo $field['name']; ?>_<?php echo $this->random; ?>">
                                            <?php foreach($levels as $level): ?>
                                                <?php if ($visibility_levels): ?>
                                                    <option value="<?php echo (int)$level->value; ?>" <?php if (in_array((int)$level->value, $visibility_levels)): ?>selected="selected" <?php endif; ?>><?php echo $level->text; ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo (int)$level->value; ?>" <?php if ((int)$level->value === 0): ?>selected="selected" <?php endif; ?>><?php echo $level->text; ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <input type="hidden" name="{$name}_settings[fields][<?php echo $field['name']; ?>][type]" value="<?php echo $field['type']; ?>" />
                                <?php if (isset($field['disabled_for_logged_in'])): ?>
                                    <input type="hidden" name="{$name}_settings[fields][<?php echo $field['name']; ?>][disabled_for_logged_in]" value="<?php echo $field['disabled_for_logged_in']; ?>" />
                                <?php endif; ?>
                                <?php if (isset($field['field_type'])): ?>
                                    <input type="hidden" name="{$name}_settings[fields][<?php echo $field['name']; ?>][field_type]" value="<?php echo $field['field_type']; ?>" />
                                <?php endif; ?>
                                <?php if (isset($field['validation'])): ?>
                                    <input type="hidden" name="{$name}_settings[fields][<?php echo $field['name']; ?>][validation]" value="<?php echo $field['validation']; ?>" />
                                <?php endif; ?>
                                <?php if (isset($field['validation_errorMsg'])): ?>
                                    <input type="hidden" name="{$name}_settings[fields][<?php echo $field['name']; ?>][validation_errorMsg]" value="<?php echo JText::_($field['validation_errorMsg']); ?>" />
                                <?php endif; ?>
                                <?php if (isset($field['javascript_event'])): ?>
                                    <input type="hidden" name="{$name}_settings[fields][<?php echo $field['name']; ?>][javascript_event]" value="<?php echo $field['javascript_event']; ?>" />
                                <?php endif; ?>
                                <?php if (isset($field['autocomplete'])): ?>
                                    <?php if(isset($field->option)): ?>
                                        <?php foreach($field->option as $field_option): ?>
                                            <input type="hidden" name="{$name}_settings[fields][<?php echo $field['name']; ?>][autocomplete][<?php echo $field_option['value']; ?>]" value="<?php echo $field_option; ?>" />
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div id="<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_CONFIGURATION')); ?>">
                     <div data-{$name}-ui-accordion='<?php echo json_encode( array( 'active' => false, 'collapsible' => true, 'heightStyle' => 'content' ) ); ?>'>
                         <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_CONFIGURATION') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_GENERAL')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_GENERAL'); ?></a></h3>
                         <div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_title_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_TITLE'); ?></label>
                                 <input type="text" name="{$name}_settings[title]" value="<?php echo htmlspecialchars((string) $this->settings->get('title', '')); ?>" id="{$name}_settings_title_<?php echo $this->random; ?>" />
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_goal_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_GOAL'); ?></label>
                                 <input type="text" name="{$name}_settings[goal]" value="<?php echo (int) $this->settings->get('goal', 0); ?>" id="{$name}_settings_goal_<?php echo $this->random; ?>" data-{$name}-event='<?php echo json_encode( array( 'type' => 'blur', 'name' => 'checkForGoalValue' ) ); ?>' data-{$name}-collected='<?php echo (int)$this->getTotal(); ?>' data-{$name}-error-collected-higher='<?php echo JText::_('PLG_CONTENT_CDPETITIONS_ERROR_COLLECTED_IS_HIGHER_THEN_GOAL'); ?>' />
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_closed_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_CLOSED'); ?></label>
                                 <input type="checkbox" name="{$name}_settings[closed]" value="1" id="{$name}_settings_closed_<?php echo $this->random; ?>"<?php if ((int)$this->settings->get('closed', 0)): ?> checked="checked"<?php endif; ?> />
                             </div>
                         </div>
                        <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_CONFIGURATION') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_LAYOUT')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_LAYOUT'); ?></a></h3>
                         <div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_uitheme_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_UITHEME'); ?></label>
                                 <select name="{$name}_settings[uitheme]" id="{$name}_settings_uitheme_<?php echo $this->random; ?>">
                                     <?php foreach($this->JScriptegrator->themeList() as $uitheme): ?>
                                     <option value="<?php echo $uitheme; ?>"<?php if ($this->settings->get('uitheme', 'ui-lightness') === $uitheme): ?> selected="selected"<?php endif; ?>><?php echo $uitheme; ?></option>
                                     <?php endforeach; ?>
                                 </select>
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_limit_per_page_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_LIMIT_PER_PAGE'); ?></label>
                                 <input type="text" name="{$name}_settings[limit_per_page]" value="<?php echo (int)$this->settings->get('limit_per_page', 20); ?>" id="{$name}_settings_limit_per_page_<?php echo $this->random; ?>" data-{$name}-tooltip='<?php echo htmlspecialchars(JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_DESCRIPTION_LIMIT_PER_PAGE'), ENT_QUOTES); ?>' />
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_order_by_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_ORDER_BY'); ?></label>
                                 <?php
                                 $order_by = array('created_asc', 'created_desc');
                                 ?>
                                 <select name="{$name}_settings[order_by]" id="{$name}_settings_order_by_<?php echo $this->random; ?>">
                                     <?php foreach($order_by as $order): ?>
                                        <option value="<?php echo $order; ?>" <?php if ((string)$this->settings->get('order_by', '') === $order): ?> selected="selected"<?php endif; ?>><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_OPTION_ORDER_BY_' . strtoupper($order)); ?></option>
                                     <?php endforeach; ?>
                                 </select>
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_show_collected_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_SHOW_COLLECTED'); ?></label>
                                 <input type="checkbox" name="{$name}_settings[show_collected]" value="1" id="{$name}_settings_show_collected_<?php echo $this->random; ?>"<?php if ($show_collected = $this->settings->get('show_collected', '') and !empty($show_collected) and (int)$show_collected): ?> checked="checked"<?php endif; ?> data-{$name}-tooltip='<?php echo htmlspecialchars(JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_DESCRIPTION_SHOW_COLLECTED'), ENT_QUOTES); ?>' />
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_hide_signatures_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_HIDE_SIGNATURES'); ?></label>
                                 <input type="checkbox" name="{$name}_settings[hide_signatures]" value="1" id="{$name}_settings_hide_signatures_<?php echo $this->random; ?>"<?php if ($hide_signatures = $this->settings->get('hide_signatures', '') and !empty($hide_signatures) and (int)$hide_signatures): ?> checked="checked"<?php endif; ?> />
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_hide_signatures_for_guests_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_HIDE_SIGNATURES_FOR_GUESTS'); ?></label>
                                 <input type="checkbox" name="{$name}_settings[hide_signatures_for_guests]" value="1" id="{$name}_settings_hide_signatures_for_guests_<?php echo $this->random; ?>"<?php if ($hide_signatures_guest = $this->settings->get('hide_signatures_for_guests', '') and !empty($hide_signatures_guest) and (int)$hide_signatures_guest): ?> checked="checked"<?php endif; ?> />
                             </div>
                             <hr />
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_display_feed_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_DISPLAY_FEED'); ?></label>
                                 <input type="checkbox" name="{$name}_settings[display_feed]" value="1" id="{$name}_settings_display_feed_<?php echo $this->random; ?>"<?php if ($display_feed = $this->settings->get('display_feed', '') and !empty($display_feed) and (int)$display_feed): ?> checked="checked"<?php endif; ?> />
                             </div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_feed_limit_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FEED_LIMIT'); ?></label>
                                 <input type="text" name="{$name}_settings[feed_limit]" value="<?php echo (int)$this->settings->get('feed_limit', 50); ?>" id="{$name}_settings_feed_limit_<?php echo $this->random; ?>" data-{$name}-tooltip='<?php echo htmlspecialchars(JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_DESCRIPTION_FEED_LIMIT'), ENT_QUOTES); ?>' />
                             </div>
                         </div>
                        <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_CONFIGURATION') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_SECURITY')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_SECURITY'); ?></a></h3>
                         <div>
                             <div class="{$name}_form_fieldset">
                                 <label for="{$name}_settings_security_signature_verification_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_SIGNATURE_VERIFICATION'); ?></label>
                                 <input type="checkbox" name="{$name}_settings[security][signature_verification]" value="1" id="{$name}_settings_security_signature_verification_<?php echo $this->random; ?>"<?php if ((int)$this->settings->get('security.signature_verification', 0)): ?> checked="checked"<?php endif; ?> data-{$name}-tooltip='<?php echo htmlspecialchars(JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_DESCRIPTION_SIGNATURE_VERIFICATION'), ENT_QUOTES); ?>' />
                             </div>
                         </div>
                    </div>
                </div>
                    <div id="<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_NOTIFICATIONS')); ?>">
                        <div data-{$name}-ui-accordion='<?php echo json_encode( array( 'active' => false, 'collapsible' => true, 'heightStyle' => 'conteent' ) ); ?>'>
                            <?php
                            $notifications = array('new_signature', 'goal');
                            ?>
                            <?php foreach($notifications as $notification_key=>$notification): ?>
                                <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_NOTIFICATIONS') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_NOTIFICATIONS_' . strtoupper($notification))); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_NOTIFICATIONS_' . strtoupper($notification)); ?></a></h3>
                                <div>
                                    <div class="{$name}_form_fieldset">
                                        <label for="{$name}_settings_notifications_<?php echo $notification; ?>_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_NOTIFICATIONS_' . strtoupper($notification)); ?></label>
                                        <select name="{$name}_settings[notifications][<?php echo $notification; ?>]" id="{$name}_settings_notifications_<?php echo $notification; ?>_<?php echo $this->random; ?>">
                                            <?php
                                            $notification_recipient = array('disabled', 'global', 'article_author', 'custom');
                                            ?>
                                            <?php foreach($notification_recipient as $recipient): ?>
                                                <option value="<?php echo $recipient; ?>" <?php if ($recipient === $this->settings->get('notifications.' . $notification, '')): ?> selected="selected" <?php endif; ?>><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_OPTION_NEW_SIGNATURE_' . strtoupper($recipient)); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="{$name}_form_fieldset">
                                        <label for="{$name}_notifications_<?php echo $notification; ?>_custom_address_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_NOTIFICATIONS_' . strtoupper($notification) . '_CUSTOM_ADDRESS'); ?></label>
                                        <input type="text" name="{$name}_settings[notifications][<?php echo $notification; ?>_custom_address]" value="<?php echo (string)$this->settings->get('notifications.' . $notification . '_custom_address', ''); ?>" id="{$name}_notifications_<?php echo $notification; ?>_custom_address_<?php echo $this->random; ?>" />
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div id="<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK')); ?>">
                        <div data-{$name}-ui-accordion='<?php echo json_encode( array( 'active' => false, 'collapsible' => true, 'heightStyle' => 'content' ) ); ?>'>
                            <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK_SIGNUP')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK_SIGNUP'); ?></a></h3>
                            <div>
                                <div class="{$name}_form_fieldset">
                                    <label for="{$name}_settings_facebook_signup_appid_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FACEBOOK_SIGNUP_APPID'); ?></label>
                                    <input type="text" name="{$name}_settings[facebook][signup][APP_ID]" value="<?php echo htmlspecialchars((string) $this->settings->get('facebook.signup.APP_ID', '')); ?>" id="{$name}_settings_facebook_signup_appid_<?php echo $this->random; ?>" />
                                </div>
                                <div class="{$name}_form_fieldset">
                                    <label for="{$name}_settings_facebook_signup_secret_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FACEBOOK_SIGNUP_SECRET'); ?></label>
                                    <input type="text" name="{$name}_settings[facebook][signup][secret]" value="<?php echo htmlspecialchars((string) $this->settings->get('facebook.signup.secret', '')); ?>" id="{$name}_settings_facebook_signup_secret_<?php echo $this->random; ?>" />
                                </div>
                            </div>
                            <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE') . '_' .JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK_COMMENTS')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_FACEBOOK_COMMENTS'); ?></a></h3>
                            <div>
                                <div class="{$name}_form_fieldset">
                                    <label for="{$name}_settings_facebook_comments_appid_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FACEBOOK_COMMENTS_APPID'); ?></label>
                                    <input type="text" name="{$name}_settings[facebook][comments][APP_ID]" value="<?php echo htmlspecialchars((string) $this->settings->get('facebook.comments.APP_ID', '')); ?>" id="{$name}_settings_facebook_comments_appid_<?php echo $this->random; ?>" />
                                </div>
                                <div class="{$name}_form_fieldset">
                                    <label for="{$name}_settings_facebook_comments_admins_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FACEBOOK_COMMENTS_ADMINS'); ?></label>
                                    <input type="text" name="{$name}_settings[facebook][comments][admins]" value="<?php echo htmlspecialchars((string) $this->settings->get('facebook.comments.admins', '')); ?>" id="{$name}_settings_facebook_comments_admins_<?php echo $this->random; ?>" data-{$name}-tooltip='<?php echo htmlspecialchars(JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_DESCRIPTION_FACEBOOK_COMMENTS_ADMINS'), ENT_QUOTES); ?>' />
                                </div>
                                <div class="{$name}_form_fieldset">
                                    <label for="{$name}_settings_facebook_comments_colorscheme_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FORM_LABEL_FACEBOOK_COMMENTS_COLORSCHEME'); ?></label>
                                    <select name="{$name}_settings[facebook][comments][colorscheme]" id="{$name}_settings_facebook_comments_colorscheme_<?php echo $this->random; ?>">
                                        <?php $colorschemes = array('light', 'dark'); ?>
                                        <?php foreach($colorschemes as $colorscheme): ?>
                                            <option value="<?php echo $colorscheme; ?>" <?php if ($colorscheme === $this->settings->get('facebook.comments.colorscheme', 'light')): ?> selected="selected" <?php endif; ?>><?php echo $colorscheme; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                   </div>
                </div>
				<br />
				<button type="submit" data-{$name}-ui-button='<?php echo json_encode( array( 'icons' => array( 'primary' => 'ui-icon-gear' ) ) ); ?>'><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_FILEFORM_BUTTON_SAVE_SETTINGS'); ?></button>
				<input type="hidden" name="{$name}_task" value="post_saveSettings" />
				<input type="hidden" name="{$name}_identifier" value="<?php echo $this->settings->get('identifier', '');; ?>" />
				<?php echo JHtml::_('form.token'); ?>
			</form>
		</div>
		<h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_UTILITIES')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_UTILITIES'); ?></a></h3>
        <div class="ui-widget-content {$name}_settings_container">
            <div data-{$name}-ui-accordion='<?php echo json_encode( array( 'active' => false, 'collapsible' => true, 'heightStyle' => 'content' ) ); ?>'>
                <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_UTILITIES') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_MAINTAINANCE')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_MAINTAINANCE'); ?></a></h3>
                <div>
                    <div class="{$name}_settings_container_utilities_holder ui-widget-content">
                        <form action="<?php echo $this->formActionURL; ?>" method="post" data-{$name}-event='<?php echo json_encode( array( 'type' => 'submit', 'name' => 'deleteAllSignatures' ) ); ?>'>
                        <button type="submit" class="deleteAllSignatures" data-{$name}-ui-button='<?php echo json_encode( array( 'icons' => array( 'primary' => 'ui-icon-trash' ) ) ); ?>'><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_DELETE_ALL_SIGNATURES'); ?></button>
                        <input type="hidden" name="identifier" value="<?php echo $this->settings->get('identifier', '');; ?>" />
                        <input type="hidden" name="{$name}_task" value="post_deleteAllSignatures" />
                        <?php echo JHTML::_('form.token'); ?>
                        </form>
                    </div>
                    <div class="{$name}_settings_container_utilities_holder ui-widget-content">
                        <form action="<?php echo $this->formActionURL; ?>" method="post" data-{$name}-event='<?php echo json_encode( array( 'type' => 'submit', 'name' => 'renameIdentifier' ) ); ?>'>
                        <button type="submit" class="renameIdentifier" data-{$name}-ui-button='<?php echo json_encode( array( 'icons' => array( 'primary' => 'ui-icon-pencil' ) ) ); ?>'><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RENAME_IDENTIFIER'); ?></button>
                        <input type="hidden" name="identifier_new" value="" />
                        <input type="hidden" name="identifier" value="<?php echo $this->settings->get('identifier', '');; ?>" />
                        <input type="hidden" name="{$name}_task" value="post_renameIdentifier" />
                        <?php echo JHTML::_('form.token'); ?>
                        </form>
                    </div>
                </div>
                <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_UTILITIES') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_EXPORT')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_EXPORT'); ?></a></h3>
                <div>
                    <form action="<?php echo $this->formActionURL; ?>" method="post">
                        <div class="{$name}_form_fieldset">
                            <label for="{$name}_utilities_export_type_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_FORM_LABEL_EXPORT_TYPE'); ?></label>
                            <select name="{$name}_utilities[export_type]" id="{$name}_utilities_export_type_<?php echo $this->random; ?>">
                                <?php $export_types = array('html', 'xls'); ?>
                                <?php foreach($export_types as $export_type): ?>
                                <option value="<?php echo $export_type; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_FORM_OPTION_EXPORT_TYPE_' . strtoupper($export_type)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="export" data-{$name}-ui-button='<?php echo json_encode( array( 'icons' => array( 'primary' => 'ui-icon-document' ) ) ); ?>'><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_EXPORT'); ?></button>
                        <input type="hidden" name="{$name}_task" value="post_export" />
                        <?php echo JHTML::_('form.token'); ?>
                    </form>
                </div>
                <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_UTILITIES') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_BACKUP')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_BACKUP'); ?></a></h3>
                <div>
                    <form action="<?php echo $this->formActionURL; ?>" method="post">
                        <div class="{$name}_form_fieldset">
                            <label for="{$name}_utilities_backup_type_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_FORM_LABEL_BACKUP_TYPE'); ?></label>
                            <select name="{$name}_utilities[backup_type]" id="{$name}_utilities_backup_type_<?php echo $this->random; ?>">
                                <?php $backup_types = array('xml'); ?>
                                <?php foreach($backup_types as $backup_type): ?>
                                <option value="<?php echo $backup_type; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_FORM_OPTION_BACKUP_TYPE_' . strtoupper($backup_type)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" data-{$name}-ui-button='<?php echo json_encode( array( 'icons' => array( 'primary' => 'ui-icon-disk' ) ) ); ?>'><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_BACKUP_SIGNATURES'); ?></button>
                        <input type="hidden" name="{$name}_task" value="post_backupSignatures" />
                        <input type="hidden" name="{$name}_backup_type" value="xml" />
                        <?php echo JHTML::_('form.token'); ?>
                    </form>
                </div>
                <h3><a href="#<?php echo $this->JApplication->stringURLSafe($this->_name . '_' . JText::_('PLG_CONTENT_CDPETITIONS_SETTINGS_TITLE_UTILITIES') . '_' . JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE')); ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE'); ?></a></h3>
                <div>
                    <form action="<?php echo $this->formActionURL; ?>" method="post" enctype="multipart/form-data" data-{$name}-event='<?php echo json_encode( array( 'type' => 'submit', 'name' => 'checkForXML' ) ); ?>' data-{$name}-incorrectFileFormatMsg='<?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE_ERROR_INCORRECT_FILE_FORMAT', true); ?>'>
                        <div class="{$name}_form_fieldset">
                            <label for="{$name}_utilities_restore_file_<?php echo $this->random; ?>"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_FORM_LABEL_RESTORE_FILE'); ?></label>
                            <div class="{$name}_settings_description"><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE_SIGNATURES_DESCRIPTION'); ?></div>
                            <input type="file" name="{$name}_utilities[restore_file]" id="{$name}_utilities_restore_file_<?php echo $this->random; ?>" />
                        </div>
                        <button type="submit" data-{$name}-ui-button='<?php echo json_encode( array( 'icons' => array( 'primary' => 'ui-icon-refresh' ) ) ); ?>'><?php echo JText::_('PLG_CONTENT_CDPETITIONS_UTILITIES_RESTORE_SIGNATURES'); ?></button>
                        <input type="hidden" name="{$name}_task" value="post_restoreSignatures" />
                        <input type="hidden" name="{$name}_restore_type" value="xml" />
                        <?php echo JHTML::_('form.token'); ?>
                    </form>
                </div>
            </div>
		</div>
	</div>
</div>
<br />