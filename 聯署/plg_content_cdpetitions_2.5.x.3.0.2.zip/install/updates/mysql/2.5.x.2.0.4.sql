ALTER TABLE `#__cdpetitions`
ADD `city` varchar(255) NOT NULL DEFAULT '' AFTER `address`,
ADD `telephone` varchar(255) NOT NULL DEFAULT '' AFTER `postcode`,
ADD `mobile` varchar(255) NOT NULL DEFAULT '' AFTER `telephone`,
ADD `job` varchar(255) NOT NULL DEFAULT '' AFTER `mobile`,
CHANGE `note` `note` text NOT NULL DEFAULT '' AFTER `job`,
ADD `settings` text NOT NULL DEFAULT '' AFTER `note`,
CHANGE `created_time` `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `published`,
ADD `authkey` varchar(20) NOT NULL DEFAULT '' AFTER `created_by_ip`,
COMMENT=''
REMOVE PARTITIONING;