DROP TABLE IF EXISTS `#__localise`;
DELETE FROM `#__assets` WHERE `name` LIKE 'com_localise%';