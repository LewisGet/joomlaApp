<?php

/**
 * @author Daniel Dimitrov
 * @date: 23.03.12
 *
 * @copyright  Copyright (C) 2008 - 2012 compojoom.com . All rights reserved.
 * @license	GNU General Public License version 2 or later; see LICENSE
 */


defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');


class HotspotsControllerKmls extends JControllerLegacy {

}