<?php

/**
 * Hotspots - Frontend
 * @package Joomla!
 * @Copyright (C) 2010 - Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 beta1
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

class HotspotsControllerJson extends JControllerLegacy {

	public function search() {
        $input = JFactory::getApplication()->input;
        $searchWord = $input->getString('search', null);
		$view = &$this->getView('Json', 'raw');
        $offset = $input->getInt('offset', null);
        $limit = HotspotsHelper::getSettings('marker_list_length');
		$model = $this->getModel('hotspot');

		$searchResult = $model->search($searchWord, $offset, $limit);

		$view->setLayout('search');
		$view->search($searchResult);
	}
}
