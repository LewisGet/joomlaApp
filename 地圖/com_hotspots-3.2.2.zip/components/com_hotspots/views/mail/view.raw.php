<?php
/**
 * Hotspots - Frontend
 * @package Joomla!
 * @Copyright (C) 2010 - Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 beta1 $
 **/

defined( '_JEXEC' ) or die ( 'Restricted access' );
jimport('joomla.application.component.view');
class HotspotsViewMail extends JViewLegacy {
    public function display($tpl = null) {
		
		$user = & JFactory::getUser();
		
		$imageSrc = $this->getStaticMap();
		
		$this->assignRef('imageSrc', $imageSrc);
		$this->assignRef('name', $user->get('name'));
		$this->assignRef('email', $user->get('email'));
		
		parent::display($tpl);
    }
	
	public function getStaticMap() {
		$post = JRequest::get('post');
		$staticUrl = "http://maps.google.com/maps/api/staticmap?";
		
		$url[] = isset($post['zoom']) ? 'zoom='.($post['zoom']) : 'zoom=1';
		$url[] = isset($post['center']) ? 'center='.($post['center']) : '';
		
		$url[] = isset($post['markers']) ? 'markers='.($post['markers']) : '';
		$url[] = isset($post['sensor']) ? 'sensor='.($post['sensor']) : 'sensor=false';
		$url[] = isset($post['path']) ? 'path='.($post['path']) : '';
		$url[] = isset($post['maptype']) ? 'maptype='.($post['maptype']) : '';
		$url[] = 'size=' . HotspotsHelper::getSettings('map_static_width', 500) 
						. 'x' . HotspotsHelper::getSettings('map_static_height', 300);
		
		return $staticUrl.implode('&', $url);
	}
}