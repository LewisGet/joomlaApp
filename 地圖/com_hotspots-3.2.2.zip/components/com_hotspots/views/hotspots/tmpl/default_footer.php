<?php defined('_JEXEC') or die('Restricted Access'); ?>
<?php if (HotspotsHelper::getSettings('footer', 1) == 1) : ?>
<div class="hotspots-footer">
	<div class="hotspots-footer-box">
		<?php echo JText::_('COM_HOTSPOTS_POWERED_BY'); ?> <a href="http://www.compojoom.com" title="Joomla extensions, modules and plugins">compojoom.com</a>
	</div>
</div>
<?php endif; ?>