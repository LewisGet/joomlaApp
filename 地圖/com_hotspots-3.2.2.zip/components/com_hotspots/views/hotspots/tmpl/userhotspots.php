<?php
defined('_JEXEC') or die('Restricted access');
?>
<table class="contentpaneopen">
    <thead>
    <th>
        #
    </th>
    <th>
        <?php echo JText::_('COM_HOTSPOTS_TITLE'); ?>
    </th>
    <th>
        <?php echo JText::_('COM_HOTSPOTS_DATE'); ?>
    </th>
    </thead>
    <tbody>
    <?php foreach ($this->hotspots as $key => $hotspot) : ?>
    <tr>
        <td><?php echo $key + 1; ?></td>
        <td><a href="<?php echo $hotspot->link ?>"><?php echo $hotspot->name; ?></a>
            <?php if ($this->user->authorise('core.edit', 'com_hotspots') || $this->user->authorise('core.edit.own', 'com_hotspots')) : ?>
                <a href="<?php echo JRoute::_('index.php?option=com_hotspots&task=form.edit&id=' . $hotspot->id); ?>">
                    <img src="<?php echo JURI::root() ?>/media/com_hotspots/images/utils/edit.png" alt="edit"/></a>
                <?php endif; ?>
        </td>
        <td><?php echo $hotspot->created; ?></td>
    </tr>
        <?php endforeach; ?>
    </tbody>
</table>