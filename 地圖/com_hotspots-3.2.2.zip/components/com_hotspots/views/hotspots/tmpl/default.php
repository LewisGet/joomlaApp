<?php
/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.framework', true);
JHTML::_('behavior.tooltip');
JHTML::_('stylesheet', 'media/com_hotspots/css/hotspots.css');

$this->setMootoolsLocale();

// Load google maps
$doc = & JFactory::getDocument();
$gmapsapi = 'http://maps.google.com/maps/api/js?sensor=true';
$doc->addScript($gmapsapi);

JHTML::_('script', 'media/com_hotspots/js/libraries/mustache.js');
JHTML::_('script', 'media/com_hotspots/js/fixes.js');

JHTML::_('script', 'media/com_hotspots/js/spin/spin.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Class.SubObjectMapping.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Extras.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Marker.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.InfoWindow.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Geocoder.js');
JHTML::_('script', 'media/com_hotspots/js/helpers/helper.js');

JHTML::_('script', 'media/com_hotspots/js/core.js');
JHTML::_('script', 'media/com_hotspots/js/sandbox.js');

if (!HotspotsHelper::getSettings('hs_hide_categories', 0)) {
    JHTML::_('script', 'media/com_hotspots/js/modules/categories.js');
}
JHTML::_('script', 'media/com_hotspots/js/modules/loader.js');
JHTML::_('script', 'media/com_hotspots/js/modules/map.js');
JHTML::_('script', 'media/com_hotspots/js/modules/hotspot.js');
JHTML::_('script', 'media/com_hotspots/js/modules/kml.js');
JHTML::_('script', 'media/com_hotspots/js/modules/menubar.js');
JHTML::_('script', 'media/com_hotspots/js/modules/send.js');
JHTML::_('script', 'media/com_hotspots/js/modules/print.js');
if (HotspotsHelper::getSettings('show_copy_link', 0)) {
	JHTML::_('script', 'media/com_hotspots/js/modules/link.js');
}

if (HotspotsHelper::getSettings('custom_tiles', 0)) {
    JHTML::_('script', 'media/com_hotspots/js/modules/tiles.js');
}

if (HotspotsHelper::getSettings('hs_show_controllmenu', 1)) {
    JHTML::_('script', 'media/com_hotspots/js/modules/menu.js');
    JHTML::_('script', 'media/com_hotspots/js/modules/search.js');
    JHTML::_('script', 'media/com_hotspots/js/helpers/tab.js');
}
JHTML::_('script', 'media/com_hotspots/js/modules/welcome.js');
JHTML::_('script', 'media/com_hotspots/js/modules/navigator.js');
JHTML::_('script', 'media/com_hotspots/js/helpers/slide.js');

if (HotspotsHelper::getSettings('mail_map', 1) == 1) {
    JHTML::_('script', 'media/com_hotspots/js/lightface/LightFace.js');
    JHTML::_('script', 'media/com_hotspots/js/lightface/LightFace.Request.js');
}

$domready = "window.addEvent('domready', function(){ \n";

$domready .= ' var hotspots = new compojoom.hotspots.core();';
$domready .= hotspotsUtils::getJsLocalization();
$domready .= hotspotsUtils::getJSVariables();

$domready .= "
if(window.location.hash == '') {
    window.location.hash = '!/catid='+hotspots.DefaultOptions.startCat;
}
hotspots.addModule('welcome',hotspots.DefaultOptions);
hotspots.addModule('loader','map_cont',hotspots.DefaultOptions);";
if (HotspotsHelper::getSettings('hs_show_controllmenu', 1)) {
    $domready .= "hotspots.addModule('menu',hotspots.DefaultOptions);";
}
if (!HotspotsHelper::getSettings('hs_hide_categories', 0)) {
    $domready .= "hotspots.addModule('categories','#hotspots-category-items', 'span',hotspots.DefaultOptions);";
}
$domready .= "
hotspots.addModule('menubar',hotspots.DefaultOptions);
hotspots.addModule('send',hotspots.DefaultOptions);
hotspots.addModule('print',hotspots.DefaultOptions);";
if (HotspotsHelper::getSettings('show_copy_link', 0)) {
	$domready .= "hotspots.addModule('link','map_cont', hotspots.DefaultOptions);";
}
if (HotspotsHelper::getSettings('hs_show_controllmenu', 1)) {
    $domready .= "hotspots.addModule('search',hotspots.DefaultOptions);";
}

$domready .= "hotspots.addModule('hotspot',hotspots.DefaultOptions);
hotspots.addModule('kml',hotspots.DefaultOptions);
hotspots.addModule('map',hotspots.DefaultOptions);";
if (HotspotsHelper::getSettings('custom_tiles', 0)) {
    $domready .= "hotspots.addModule('tiles',hotspots.DefaultOptions);";
}
$domready .= "hotspots.addModule('navigator',hotspots.DefaultOptions);

hotspots.startAll();";
$domready .= "});";

$doc->addScriptDeclaration($domready);

?>

<?php if (HotspotsHelper::getSettings('show_page_title', 1)) : ?>
<div class="componentheading<?php echo $this->escape(HotspotsHelper::getSettings('pageclass_sfx')); ?>">
    <?php echo $this->escape(HotspotsHelper::getSettings('page_title', 'Hotspots')); ?>
</div>
<?php endif; ?>

<!-- START Hotspots by compojoom.com  -->
<div class="hotspots" id="hotspots">

    <div id="hotspots-navigation">

        <div class="navigation-bar">
			<?php if (HotspotsHelper::getSettings('show_copy_link', 0)) : ?>
				<span id="link-button" title="<?php echo JText::_('COM_HOTSPOTS_COPY_LINK'); ?>"></span>
			<?php endif; ?>
			<span id="center-button" title="<?php echo JTEXT::_('COM_HOTSPOTS_MARKER_CENTER'); ?>">
			</span>

            <?php if (HotspotsHelper::getSettings('hs_show_controllmenu', 1)) : ?>
            <span id="directions-button" title="<?php echo JText::_('COM_HOTSPOTS_DIRECTIONS'); ?>">
				</span>
            <?php endif; ?>

            <?php if (HotspotsHelper::getSettings('mail_map', 1) == 1) : ?>
            <span id="send-button" title="<?php echo JText::_('COM_HOTSPOTS_SEND'); ?>">
				</span>
            <?php endif; ?>
            <?php if (HotspotsHelper::getSettings('print_map', 1) == 1) : ?>
            <span id="print-button" title="<?php echo JText::_('COM_HOTSPOTS_PRINT'); ?>">
				</span>
            <?php endif; ?>

            <?php if (HotspotsHelper::getSettings('rss_enable', 1) == 1) : ?>
            <span id="rss-button">
					<a href="<?php echo JRoute::_('index.php?option=com_hotspots&view=hotspots&task=hotspots.rss'); ?>"
                       target="_blank"
                       title="<?php echo JTEXT::_('COM_HOTSPOTS_FEED'); ?>">
                        <img src="media/com_hotspots/images/utils/rss.png"
                             alt="<?php echo JTEXT::_('COM_HOTSPOTS_FEED'); ?>"/>
                    </a>
				</span>
            <?php endif; ?>
            <?php if (HotspotsHelper::getSettings('resize_map', 1) == 1) : ?>
            <span id="resize" title="<?php echo JText::_('COM_HOTSPOTS_RESIZE'); ?>">
				</span>
            <?php endif; ?>
        </div>


        <?php if (!HotspotsHelper::getSettings('hs_hide_categories', 0)) : ?>
        <div id="hotspots-categories">
            <div id="cat-back"><!--slide back button--></div>
            <div id="hotspots-categories-inner">
                <div id="hotspots-category-items">
                    <?php foreach ($this->cats as $key => $cat) : ?>
                    <?php
                    $path = JURI::root() . 'media/com_hotspots/images/categories/' . $cat['cat_icon'];
                    ?>
                    <span data-id="<?php echo $cat['id']; ?>" id="cat<?php echo $cat['id']; ?>"
                          class="hotspots-category-item hasTip "
                          title="<?php echo $cat['text'] ?>::<?php echo ($cat['cat_description']) ? $cat['cat_description'] : ' '; ?>">
                                <img border="0" alt="Tooltip" src="<?php echo $path; ?>"/>
                            </span>

                    <?php endforeach; ?>
                </div>
            </div>
            <div id="cat-forward"><!--slide forward button--></div>
        </div>
        <?php endif; ?>

        <?php // if the menu is hidden don't show the search form as we don't have a place ot show the results; ?>
        <?php if (HotspotsHelper::getSettings('hs_show_controllmenu', 1)) : ?>
        <form id="quick-search" class="form" action="">
            <input type="text" title="<?php echo JText::_('COM_HOTSPOTS_QUICK_SEARCH_TITLE'); ?>"/>
        </form>
        <?php endif; ?>

        <div class="clear-both"></div>
    </div>
    <div id="map_cont" style="height: <?php echo (HotspotsHelper::getSettings('map_height', 600)); ?>px;">

        <?php echo $this->loadTemplate('menu'); ?>

        <div id="map_canvas" class="map_canvas"
             style="height: <?php echo HotspotsHelper::getSettings('map_height', 600); ?>px;"></div>

        <?php if (HotspotsHelper::getSettings('show_welcome_text', 1) && !(isset($_COOKIE['hide-welcome']))) : ?>
        <div id="hotspots-welcome">
            <div style="margin:10px;">
                <?php echo HotspotsHelper::getSettings('welcome_text', 'You should not see this'); ?>
                <div class="clear-both"></div>
            </div>
            <div class="nav">
                <label for="hide-welcome">
                    <input type="checkbox" value="1" name="hide-welcome" id="hide-welcome"/>
                    <?php echo JText::_('COM_HOTSPOTS_HIDE_WELCOME'); ?>
                </label>

                <div style="float:right; margin-right:  10px;" id="close-welcome">
                    <img src="media/com_hotspots/images/utils/close.gif" width="14" height="13" alt="close"/>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php echo $this->loadTemplate('footer'); ?>
</div>
<!-- End Hotspots by compojoom.com  -->