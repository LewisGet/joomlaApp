<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class="hotspots">
	<?php if(!count($this->cats)) : ?>
	<?php echo JText::_('COM_HOTSPOTS_NO_CATS_EXPLAINED'); ?>
	<?php endif; ?>
</div>