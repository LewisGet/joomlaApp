<?php defined('_JEXEC') or die('Restricted access'); ?>

<div id="slide_menu" style="<?php echo HotspotsHelper::getSettings('hs_show_controllmenu', 1) ? '' : "display:none;"; ?>">
	<span id="toggle-menu" class="toggle-off" title="<?php echo JText::_('COM_HOTSPOTS_TOGGLE'); ?>">
	</span>
	<div class="hotspots-actions" id="hotspots-menu-actions">
		<label><input type="checkbox" id="all-hotspots" /><?php echo JText::_('COM_HOTSPOTS_SHOW_ALL_TABS'); ?></label>
	</div>
	<div id="tab-container">

		<div id="hotspots-slide-tabs-back"><!--slide back button--></div>
		<div id="tab-container-inner">
			<ul class="hotspots-tabs" id="hotspots-tabs"><li class="hotspots-tab" id="tab-search" data-id="search"><span><img src="<?php echo JURI::root(); ?>/media/com_hotspots/images/utils/search.png" alt="saerch" title="search" /></span></li></ul>
		</div>
		<div id="hotspots-slide-tabs-forward"><!--slide forward button--></div>

	</div>
	<div class="clear-both"></div>

	<div class="hotspots-tab-content" id="search-tab-container" data-id="search">
		<div class="search-actions">
			<span class="active" data-id="search-directions"><?php echo JText::_('COM_HOTSPOTS_SEARCH_DIRECTIONS'); ?></span><span data-id="search-address"><?php echo JText::_('COM_HOTSPOTS_SEARCH_ADDRESS'); ?></span><span data-id="search-hotspots"><?php echo JText::_('COM_HOTSPOTS_SEARCH_HOTSPOT'); ?></span>
		</div>
		<form id="search-directions" action="" class="form active menu">
			<div class="" style="width:100%">
				<input type="text" id="directions-departure" title="<?php echo JText::_('COM_HOTSPOTS_YOUR_START_ADDRESS'); ?>" class="required" />
				<input type="text" id="directions-arrival" title="<?php echo JText::_('COM_HOTSPOTS_YOUR_END_ADDRESS'); ?>" class="required"/>

				<button class="sexybutton right" type="submit">
					<span>
						<span><?php echo JText::_('COM_HOTSPOTS_GET_DIRECTIONS'); ?></span>
					</span>
				</button>
			</div>
			<div id="directions-display"></div>
		</form>
		<form id="search-address" class="form menu" action="">
			<input type="text" id="search-address-input" title="<?php echo JText::_('COM_HOTSPOTS_ADDRESS'); ?>" class="required"/>
			<button class="sexybutton right" type="submit">
				<span>
					<span><?php echo JText::_('COM_HOTSPOTS_SUBMIT'); ?></span>
				</span>
			</button>
			<div id="hotspots-address-result">

			</div>
		</form>
		<form id="search-hotspots" class="form menu" action="">
			<input type="text" id="search-hotspots-input" title="<?php echo JText::_('COM_HOTSPOTS_WHAT_ARE_YOU_LOOKING_FOR');?>" class="required" />
			<button class="sexybutton right" type="submit">
				<span>
					<span><?php echo JText::_('COM_HOTSPOTS_SUBMIT'); ?></span>
				</span>
			</button>
			<div class="clear-both"></div>
			<div id="hotspots-list">

			</div>
			<div id="hms" class="hotspots-more-spots">
			</div>
		</form>
	</div>

</div>
