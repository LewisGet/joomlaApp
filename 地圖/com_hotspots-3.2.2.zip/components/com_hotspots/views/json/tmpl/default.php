<?php
/**
* Hotspots - Frontend
* @package Joomla!
* @Copyright (C) 2010 - Daniel Dimitrov - compojoom.com
* @All rights reserved
* @Joomla! is Free Software
* @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @version $Revision: 1.1 stable
**/

defined( '_JEXEC' ) or die ( 'Restricted access' );

$html = array();
foreach ($this->list['hotspots'] as $catid => $hotspots) {

    foreach ($hotspots as $key => $value) {

        if($key !== 'categoryCount' && $key !== 'viewCount') {
            $this->hotspot = $value;

            $html['hotspots'][$catid][$key] = array(
                'id' => $value->hotspots_id,
                'latitude' => $value->gmlat,
                'longitude' => $value->gmlng,
                'title' => $value->name,
                'description' => preg_replace("@[\\r|\\n|\\t]+@", '', $this->hotspot->description_small),
                'street' => $this->hotspot->street,
                'city' => $this->hotspot->town,
                'zip' => $this->hotspot->plz,
                'country' => $this->hotspot->country,
                'created_by' => $this->hotspot->created_by_alias,
                'date' => $this->hotspot->created,
                'readmore' => $this->hotspot->link
            );
			if(HotspotsHelper::getSettings('show_date', 1)) {
				$html['hotspots'][$catid][$key]['date'] = hotspotsUtils::getLocalDate($this->hotspot->created);
			}
            if($value->picture_thumb) {
                $html['hotspots'][$catid][$key]['thumb'] = $value->picture_thumb;
            }
            if($value->params->get('markerimage')) {
                $html['hotspots'][$catid][$key]['icon'] =  HOTSPOTS_PICTURE_CATEGORIES_PATH . $value->params->get('markerimage');
            }

        } else {
            if($key == 'categoryCount') {
                $html['hotspots'][$catid]['categoryCount']  = $value;
            }
            if($key == 'viewCount') {
                $html['hotspots'][$catid]['viewCount']  = $value;
            }
        }
    }
}

$html['count'] = $this->list['count'];
$html['offset'] = JRequest::getInt('offset');

echo json_encode($html);

jexit();