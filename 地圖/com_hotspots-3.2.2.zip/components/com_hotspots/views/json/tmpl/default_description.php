<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php if ($this->hotspot->picture) : ?>
<a href='<?php echo $this->hotspot->link; ?>' title='<?php echo $this->hotspot->name; ?>'>
    <img src='<?php echo $this->hotspot->picture_thumb; ?>' align='right' alt='<?php echo $this->hotspot->name ?>'/>
</a>
<?php endif; ?>
<?php echo $this->hotspot->description_small; ?>
<div class="clear-both"></div>
<p>
    <?php if ($this->settings->get('show_author')) : ?>
    <?php echo JTEXT::_('COM_HOTSPOTS_POSTED_BY'); ?>
    <strong>
        <?php echo $this->hotspot->created_by_alias; ?>
    </strong>
    <?php endif; ?>

    <?php if ($this->settings->get('show_date')) : ?>
    <?php echo JText::_('COM_HOTSPOTS_ON'); ?>

    <?php echo $this->hotspot->postdate; ?>
    <?php endif; ?>
</p>