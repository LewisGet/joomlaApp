<?php

/**
 * @author Daniel Dimitrov
 * @date: 23.03.12
 *
 * @copyright  Copyright (C) 2008 - 2012 compojoom.com . All rights reserved.
 * @license	GNU General Public License version 2 or later; see LICENSE
 */


defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');

class hotspotsModelKmls extends JModelLegacy {

	private $catid = '';

	public function __construct() {
		parent::__construct();

		$this->catid = explode(';',JRequest::getVar('cat', 1));

	}

	public function getKmls() {
		$db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $where = '';
        foreach($this->catid as $cat) {
            $where[] = $db->quote($cat);
        }

        $query->select('*')
            ->from('#__hotspots_kmls')
            ->where('catid IN ('.implode(',', $where ) . ')');

        $db->setQuery($query);
        return $db->loadObjectList();
	}

}