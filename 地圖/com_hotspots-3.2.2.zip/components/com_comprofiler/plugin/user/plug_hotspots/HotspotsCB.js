new Class('compojoom.hotspots.modules.hotspotscb', {
    Implements:[Options, Events],
    Extends:compojoom.hotspots.modules.hotspot,

    options:{
        mapStartZoom:6,
        showDirections:0,
        readMore:1
    },

    initialize:function (markers, options, sb) {
        this.sb = sb;
        this.setOptions(options);

        this.infoWindow = Map.InfoWindow;
        this.parse(markers);
        window.fireEvent('zoomToMarkers');

        $$('#new-spots span').addEvent('click', function () {
            window.fireEvent('openUniqueInfoWindow', this.get('data-id'));
        });
    },

    parse:function (locations) {
        var self = this;
        Object.each(locations, function (hotspot) {
            var position = new google.maps.LatLng(hotspot.gmlat, hotspot.gmlng),
                category = this.options.categories[hotspot.catid],
                icon = new google.maps.MarkerImage(hotspot.icon),
                shadow = new google.maps.MarkerImage(category.cat_shadowicon),
                markerOptions = {
                    'title':hotspot.title,
                    'icon':icon,
                    'shadow':shadow
                };

            // create the marker only if it doesn't exist
            if (!self.sb.markers[hotspot.hotspots_id]) {
                var marker = self.sb.createMarker(position, markerOptions, hotspot.catid, hotspot.hotspots_id);
                var refInfoWindow = self.createInfoWindow(marker, hotspot);
                marker.addEvent('click', refInfoWindow);
            }

        }, this);


    },

    createInfoWindow:function (marker, hotspot) {
        return (function () {
            var container = this.infoWindowToolbarActions(hotspot);
            var text = new Element('div', {
                style:'width: 300px;',
                html:'<h2>' + hotspot.name + '</h2>' + hotspot.description_small
            });
            container.inject(text);
            this.infoWindow.setOptions({
                'content':text,
                'position':new google.maps.LatLng(hotspot.latitude, hotspot.longitude)
            });

            this.infoWindow.open(this.sb.getMap(), marker.markerObj);

        }.bind(this));
    },

    infoWindowToolbarActions:function (hotspot) {
        var self = this, readmore = '', zoom = '',
            links = new Element('div', {
                id:'hotspots-links'
            });

        if (this.options.readMore.toInt()) {
            readmore = new Element('span', {
                'class':'link'
            }).adopt(new Element('a', {
                href:hotspot.link,
                html:this.translate('COM_HOTSPOTS_READ_MORE', 'Read more')
            }));
        }

        if(this.sb.getMap().getZoom() < 10) {
            zoom = new Element('span', {
                'html' : this.translate('COM_HOTSPOTS_ZOOM','zoom'),
                'class' : 'link',
                events: {
                    click: function(){
                        self.sb.getMap().setCenter(new google.maps.LatLng(hotspot.gmlat, hotspot.gmlng));
                        self.sb.getMap().setZoom(10);
                        self.infoWindow.close();
                    }
                }
            });
        }

        return new Element('div', {
            id:'hotspots-container'
        }).adopt([
            links.adopt([zoom, readmore])
        ]);
    }
});