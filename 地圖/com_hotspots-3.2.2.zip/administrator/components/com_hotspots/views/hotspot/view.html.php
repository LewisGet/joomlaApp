<?php
/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 20102 - Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.3 beta $
 * */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class HotspotsViewHotspot extends HotspotsView
{

    public function display($tpl = null)
    {
        $this->form = $this->get('Form');
        $this->hotspot = $this->get('Item');

        $this->canDo	= HotspotsHelper::getActions($this->hotspot->id);

        $doc = & JFactory::getDocument();
        $gmapsapi = 'http://maps.google.com/maps/api/js?sensor=true';
        $doc->addScript($gmapsapi);

        $this->addToolbar();
        parent::display($tpl);
    }

    public function addToolbar()
    {
        JToolBarHelper::title(JText::_('COM_HOTSPOTS_EDIT_MARKER'));
        JToolBarHelper::save('hotspot.save');
        JToolBarHelper::apply('hotspot.apply');
        JToolBarHelper::cancel('hotspot.cancel');
    }
}