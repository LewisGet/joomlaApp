<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2009 Yves Hoppe - lunajoom.de
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.3 beta $
 * */
defined('_JEXEC') or die();
jimport('joomla.application.component.view');

class HotspotsViewSettings extends JViewLegacy {

	public function display($tpl = null) {

		$uri = & JFactory::getURI();
		$document = & JFactory::getDocument();
		$db = & JFactory::getDBO();

		$items = &$this->get('Data');
		
		for ($i = 0; $i < count($items); $i++) {
			$item = $items[$i];

			if ($item->catdisp == "basic") {
				$items_basic[$item->id] = $item;
			}
			if ($item->catdisp == "layout"){
				$items_layout[$item->id] = $item;
			}
			if ($item->catdisp == "advanced"){
				$items_advanced[$item->id] = $item;
			}
			if ($item->catdisp == "security"){
				$items_security[$item->id] = $item;
			}
		}



		$this->assignRef('items', $items);
		$this->assignRef('items_basic', $items_basic);
		$this->assignRef('items_layout', $items_layout);
		$this->assignRef('items_advanced', $items_advanced);
		$this->assignRef('items_security', $items_security);
		$this->assignRef('request_url', $uri->toString());

        $this->addToolbar();
		parent::display($tpl);
	}

    private function addToolbar() {
        JToolBarHelper::title(JText::_('COM_HOTSPOTS_SETTINGS'), 'config');
        JToolBarHelper::save('settings.save');
        JToolBarHelper::apply('settings.apply');
        JToolBarHelper::cancel('settings.cancel');
        JToolBarHelper::help('screen.hotspots', true);

        // Options button.
        if (JFactory::getUser()->authorise('core.admin', 'com_hotspots')) {
            JToolBarHelper::preferences('com_hotspots');
        }

    }
}