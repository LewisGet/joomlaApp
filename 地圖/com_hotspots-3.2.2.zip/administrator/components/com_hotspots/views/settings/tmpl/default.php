<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
/**
* Hotspots - Adminstrator
* @package Joomla!
* @Copyright (C) 2009 Yves Hoppe - lunajoom.de
* @All rights reserved
* @Joomla! is Free Software
* @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @version $Revision: 0.9.3 beta $
**/

defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
jimport( 'joomla.html.pane' );
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">

<?php
$options = array(
    'startOffset' => 0,  // 0 starts on the first tab, 1 starts the second, etc...
    'useCookie' => true, // this must not be a string. Don't use quotes.
);

echo  JHtml::_('tabs.start', $options);
echo JHtml::_('tabs.panel', JText::_( 'COM_HOTSPOTS_BASIC' ), 'basic' );
?>
<div class="col60">
<fieldset class="adminform">
<legend><?php echo JText::_( 'COM_HOTSPOTS_BASIC' ); ?></legend>

<table class="admintable">
<?php
foreach ($this->items_basic as $value) {

        echo '<tr>';
        echo '<td class="key">';
        echo '<label for="'.$value->title.'" width="100" title="'.JText::_('COM_HOTSPOTS_'.strtoupper($value->title). '_DESC').'">';
        echo JText::_('COM_HOTSPOTS_'.strtoupper($value->title));
        echo '</label>';
        echo '</td>';

        echo '<td colspan="2">';

        switch ($value->type) {
                case 'textarea':
                        echo HotspotsHelper::getTextareaSettings($value->id, $value->title, $value->value);
                break;

                case 'select':
                        echo HotspotsHelper::getSelectSettings($value->id, $value->title, $value->value, $value->values);
                break;


                case 'text':
                default:
                        echo HotspotsHelper::getTextSettings($value->id, $value->title, $value->value);
                break;

        }
        echo '</td>';
        echo '</tr>';

}
?>
</table>
</fieldset>
</div>
<div class="clr"></div>
<?php
//echo $pane->endPanel();

echo JHtml::_('tabs.panel', JText::_( 'COM_HOTSPOTS_LAYOUT' ), 'layout' );
?>
<div class="col60">
<fieldset class="adminform">
<legend><?php echo JText::_( 'COM_HOTSPOTS_LAYOUT' ); ?></legend>

<table class="admintable">
<?php 
foreach ($this->items_layout as $value) {

        echo '<tr>';
        echo '<td class="key">';
        echo '<label for="'.$value->title.'" width="100" title="'.JText::_('COM_HOTSPOTS_'.strtoupper($value->title). '_DESC').'">';
        echo JText::_('COM_HOTSPOTS_'.strtoupper($value->title));
        echo '</label>';
        echo '</td>';

        echo '<td colspan="2">';

        switch ($value->type) {
                case 'textarea':
                        echo HotspotsHelper::getTextareaSettings($value->id, $value->title, $value->value);
                break;

                case 'select':
                        echo HotspotsHelper::getSelectSettings($value->id, $value->title, $value->value, $value->values);
                break;


                case 'text':
                default:

                        echo HotspotsHelper::getTextSettings($value->id, $value->title, $value->value);
                break;

        }
        echo '</td>';
        echo '</tr>';

}
?>
</table>
</fieldset>
</div>
<div class="clr"></div>
<?php

//echo $pane->endPanel();

echo JHtml::_('tabs.panel', JText::_( 'COM_HOTSPOTS_ADVANCED' ), 'advanced' );
?>
<div class="col60">
<fieldset class="adminform">
<legend><?php echo JText::_( 'COM_HOTSPOTS_ADVANCED' ); ?></legend>

<table class="admintable">
<?php
foreach ($this->items_advanced as $value) {

        echo '<tr>';
        echo '<td class="key">';
        echo '<label for="'.$value->title.'" width="100" title="'.JText::_('COM_HOTSPOTS_'.strtoupper($value->title). '_DESC').'">';
        echo JText::_('COM_HOTSPOTS_'.strtoupper($value->title));
        echo '</label>';
        echo '</td>';

        echo '<td colspan="2">';

        switch ($value->type) {
                case 'textarea':
                        echo HotspotsHelper::getTextareaSettings($value->id, $value->title, $value->value);
                break;

                case 'select':
                        echo HotspotsHelper::getSelectSettings($value->id, $value->title, $value->value, $value->values);
                break;


                case 'text':
                default:
                        echo HotspotsHelper::getTextSettings($value->id, $value->title, $value->value);
                break;

        }
        echo '</td>';
        echo '</tr>';
}
?>
</table>
</fieldset>
</div>
<div class="clr"></div>
<?php
//echo $pane->endPanel();

echo JHtml::_('tabs.panel', JText::_( 'COM_HOTSPOTS_SECURITY_TAB' ), 'security' );
// Display the parameters defined in the <params> group with the 'group' attribute of 'GROUP_NAME'
//echo $this->params->render( 'params', 'ADVANCED' )
?>
<div class="col60">
<fieldset class="adminform">
<legend><?php echo JText::_( 'COM_HOTSPOTS_SECURITY_TAB' ); ?></legend>

<table class="admintable">
<?php
foreach ($this->items_security as $value) {

        echo '<tr>';
        echo '<td class="key">';
        echo '<label for="'.$value->title.'" width="100" title="'.JText::_('COM_HOTSPOTS_'.strtoupper($value->title). '_DESC').'">';
        echo JText::_('COM_HOTSPOTS_'.strtoupper($value->title));
        echo '</label>';
        echo '</td>';

        echo '<td colspan="2">';

        switch ($value->type) {
                case 'textarea':
                        echo HotspotsHelper::getTextareaSettings($value->id, $value->title, $value->value);
                break;

                case 'select':
                        echo HotspotsHelper::getSelectSettings($value->id, $value->title, $value->value, $value->values);
                break;


                case 'text':
                default:
                        echo HotspotsHelper::getTextSettings($value->id, $value->title, $value->value);
                break;

        }
        echo '</td>';
        echo '</tr>';
}
?>
</table>
</fieldset>
</div>
<div class="clr"></div>
<?php
echo JHtml::_('tabs.end');
?>




<input type="hidden" name="option" value="com_hotspots" />
<input type="hidden" name="view" value="settings" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="settings" />
    
<?php echo JHTML::_( 'form.token' ); ?>
</form>

