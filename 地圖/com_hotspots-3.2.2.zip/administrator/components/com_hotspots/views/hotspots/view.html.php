<?php

/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2009 Yves Hoppe - lunajoom.de
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.3 beta $
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class HotspotsViewHotspots extends JViewLegacy
{

    public function display($tpl = null)
    {
        $appl = JFactory::getApplication();
        $uri = & JFactory::getURI();
        $db = & JFactory::getDBO();
        $model = &$this->getModel();


        //Filter
        $context = 'com_hotspots.marker.list.';
        $filter_state = $appl->getUserStateFromRequest($context . 'filter_state', 'filter_state', '', 'word');
        $filter_sectionid = $appl->getUserStateFromRequest($context . 'filter_sectionid', 'filter_sectionid', 0, 'int');
        $filter_order = $appl->getUserStateFromRequest($context . 'filter_order', 'filter_order', 'cc.catid', 'cmd');
        $filter_order_Dir = $appl->getUserStateFromRequest($context . 'filter_order_Dir', 'filter_order_Dir', '', 'word');
        $search = $appl->getUserStateFromRequest($context . 'search', 'search', '', 'string');
        $search = JString::strtolower($search);

        $list = $model->getList();
        $pagination = & $this->get('Pagination');

        $javascript = 'onchange="document.adminForm.submit();"';

        // state filter
        $lists['state'] = JHTML::_('grid.state', $filter_state, 'JPUBLISHED', 'JUNPUBLISHED');

        // table ordering
        $lists['order_Dir'] = $filter_order_Dir;
        $lists['order'] = $filter_order;

        $lists['search'] = $search;

        // sectionid
        $query = 'SELECT s.cat_name AS text, s.id AS value'
            . ' FROM #__hotspots_categorie AS s'
            . ' ORDER BY s.id';
        $db->setQuery($query);
        $hotspotssets = $db->loadObjectList();

        array_unshift($hotspotssets, JHTML::_('select.option', '0', '- ' . JText::_('COM_HOTSPOTS_SELECT_CATEGORY') . ' -', 'value', 'text'));
        $lists['sectionid'] = JHTML::_('select.genericlist', $hotspotssets, 'filter_sectionid', $javascript, 'value', 'text', $filter_sectionid);

        $ordering = ($lists['order'] == 'cc.catid'); //Ordering allowed ?


        $this->assignRef('list', $list);
        $this->assignRef('lists', $lists);
        $this->assignRef('pagination', $pagination);
        $this->assignRef('ordering', $ordering);
        $this->assignRef('request_url', $uri->toString());
        $this->assignRef('user', JFactory::getUser());

        if (JRequest::getVar('layout') == 'element') {
            $this->setLayout('element');
        }
        $this->addToolbar();
        parent::display($tpl);
    }

    public function addToolbar()
    {
        $canDo = HotspotsHelper::getActions();

        JToolBarHelper::title(JText::_('COM_HOTSPOTS_MARKERS'), 'generic.png');
        JToolBarHelper::custom('geocode', 'geocoding', 'geocoding', 'COM_HOTSPOTS_GEOCODE');
        if ($canDo->get('core.edit.state')) {
            JToolBarHelper::publishList('hotspots.publish');
            JToolBarHelper::unpublishList('hotspots.unpublish');
        }
        JToolBarHelper::deleteList(JText::_('COM_HOTSPOTS_DO_YOU_REALLY_WANTO_TO_REMOVE_THIS_MARKER'), 'hotspots.remove');
        if ($canDo->get('core.edit')) {
            JToolBarHelper::editList('hotspot.edit');
        }
        if ($canDo->get('core.create')) {
            JToolBarHelper::addNew('hotspot.add');
        }

    }
}