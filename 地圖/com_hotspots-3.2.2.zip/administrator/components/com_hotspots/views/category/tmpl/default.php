<?php
/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */

defined('_JEXEC') or die('Restricted access');

$editor = & JFactory::getEditor();

JHTML::_('behavior.framework', true);
JHTML::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');

JHTML::_('stylesheet', 'media/com_hotspots/css/hotspots-backend.css');
JHTML::_('script', 'media/com_hotspots/js/fixes.js');

JHTML::_('script', 'media/com_hotspots/js/lazy/LazyLoad.js', '');
JHTML::_('script', 'media/com_hotspots/js/modules/backend/category.js');


$domready = <<<ABC
window.addEvent('domready', function() {
	var hotspotCategory = new compojoom.hotspots.modules.categories();
});
ABC;

$doc = & JFactory::getDocument();
$doc->addScriptDeclaration($domready);

JHtml::_('stylesheet', 'system/mooRainbow.css', array('media' => 'all'), true);
JHtml::_('script', 'system/mooRainbow.js', false, true);

JFactory::getDocument()
    ->addScriptDeclaration(
    "window.addEvent('domready', function(){
				var nativeColorUi = false;
				if (Browser.opera && (Browser.version >= 11.5)) {
					nativeColorUi = true;
				}
				$$('.input-colorpicker').each(function(item){
					if (nativeColorUi) {
						item.type = 'color';
					} else {
						new MooRainbow(item, {
							id: item.id,
							imgPath: '" . JURI::root(true) . "/media/system/images/mooRainbow/',
							onComplete: function(color) {
								this.element.value = color.rgb;
							},
							startColor: item.value.hexToRgb(true) ? item.value.hexToRgb(true) : [0, 0, 0]
						});
					}
				});
			});
		");
?>
<script type="text/javascript">
	Joomla.submitbutton = function (button) {
		if (button != 'category.cancel') {
			var validator = new Form.Validator.Inline(document.id('adminForm'), {wrap:true});
			if (validator.validate()) {
				var selected = document.id('select-icon').get('value');
				if (!document.id('category-icon').getElement('img') && selected != 'delete' && selected != 'new') {
					document.id('category-icon').addClass('validation-failed');
					return false;
				}
				var selected = document.id('select-shadow').get('value');
				if (!document.id('category-shadow').getElement('img') && selected != 'delete' && selected != 'new') {
					document.id('category-shadow').addClass('validation-failed');
					return false;
				}
				Joomla.submitform(button);
				return true;
			}
			;
			return false;
		}
		Joomla.submitform(button);
	}
</script>

<div id="hotspots" class="hotspots">
	<form action="index.php" method="post" name="adminForm" id="adminForm" class="form" enctype="multipart/form-data">
		<fieldset class="adminform">
			<legend><?php echo JText::_('COM_HOTSPOTS_EDIT_CATEGORY'); ?></legend>
			<table>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('COM_HOTSPOTS_CATEGORY_NAME'); ?>:
					</td>
					<td>
						<input class="required" type="text" name="cat_name" id="cat_name" size="50" maxlength="250"
						       value="<?php echo $this->row->cat_name; ?>"/>
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('COM_HOTSPOTS_PUBLISHED'); ?>:
					</td>
					<td>
						<div class="radio">
							<div>
								<?php
								echo $this->lists['published'];
								?>
							</div>
						</div>
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('COM_HOTSPOTS_CATEGORY_DESCRIPTION'); ?>:
					</td>
					<td>
						<textarea class="text_area" type="text" cols="20" rows="4" name="cat_description"
						          id="cat_description"
						          style="width:500px"/><?php echo $this->row->cat_description; ?></textarea>
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('COM_HOTSPOTS_ICON'); ?>:
					</td>
					<td>
						<div id="category-icon">
							<?php if ($this->row->cat_icon) : ?>
							<img
								src="<?php echo JURI::root() ?>media/com_hotspots/images/categories/<?php echo $this->row->cat_icon ?>"
								alt="<?php echo $this->row->cat_name ?>"/>
							<?php else : ?>
							<?php echo JText::_('COM_HOTSPOTS_NEED_IMAGE'); ?>
							<?php endif; ?>
						</div>
						<div class="clear-both"></div>
						<select id="select-icon" name="select-icon" class="chzn-done">
							<option value=""><?php echo JText::_('COM_HOTSPOTS_SELECT'); ?></option>
							<option value="new"><?php echo JText::_('COM_HOTSPOTS_UPLOAD_NEW_IMAGE'); ?></option>
							<option value="delete"><?php echo JText::_('COM_HOTSPOTS_DELETE_CURRENT_IMAGE'); ?></option>
							<option value="sample"><?php echo JText::_('COM_HOTSPOTS_SELECT_SAMPLE_IMAGE'); ?></option>
						</select>

						<div class="clear-both"></div>
						<input type="hidden" name="MAX_FILE_SIZE" value="1000000"/>

						<div id="iconupload" style="display: none;">
							<input type="file" name="cat_icon" id="cat_icon"/>
						</div>
						<div id="deleteicon-text" style="display: none;">
							<?php echo JText::_('COM_HOTSPOTS_OLD_ICON_WILL_BE_DELETED_WHEN_SAVING'); ?>:
						</div>

						<div id="select-sample-image" style="display:none;" >
							<?php foreach ($this->sampleIcons as $icon) : ?>
							<div>
								<img
									src="<?php echo JURI::root(); ?>media/com_hotspots/images/categories/sample/blank.gif"
									data-src="<?php echo $icon['path']; ?>" title="<?php echo $icon['title'] ?>"/>
								<span data-id="<?php echo $icon['original']; ?>"> <?php echo $icon['title'] ?> </span>
							</div>
							<?php endforeach; ?>
						</div>
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('COM_HOTSPOTS_SHADOW_ICON'); ?>:
					</td>
					<td>
						<div id="category-shadow">
							<?php if ($this->row->cat_shadowicon) : ?>
							<img
								src="<?php echo JURI::root(); ?>media/com_hotspots/images/categories/<?php echo $this->row->cat_shadowicon ?> "/>
							<?php else : ?>
								<?php echo JText::_('COM_HOTSPOTS_NEED_CAT_SHADOW'); ?>
							<?php endif; ?>
						</div>
						<select name="select-shadow" id="select-shadow" class="chzn-done">
							<option value=""><?php echo JText::_('COM_HOTSPOTS_SELECT'); ?></option>
							<option value="new"><?php echo JText::_('COM_HOTSPOTS_UPLOAD_NEW_SHADOW'); ?></option>
							<option
								value="delete"><?php echo JText::_('COM_HOTSPOTS_DELETE_CURRENT_SHADOW'); ?></option>
							<option value="sample"><?php echo JText::_('COM_HOTSPOTS_SELECT_SAMPLE_SHADOW'); ?></option>
						</select>

						<div class="clear-both"></div>
						<input type="hidden" name="MAX_FILE_SIZE" value="1000000"/>

						<div id="shadowupload" style="display: none;">
							<input type="file" name="cat_shadowicon" id="cat_shadowicon"/>
						</div>
						<div id="deleteshadow_text" style="display: none;">
							<?php echo JText::_('COM_HOTSPOTS_OLD_SHADOW_WILL_BE_DELETED_WHEN_SAVING'); ?>
						</div>

						<div id="select-sample-shadow" style="display:none;">
							<?php foreach ($this->sampleShadows as $icon) : ?>
							<div>
								<img
									src="<?php echo JURI::root(); ?>media/com_hotspots/images/categories/sample/blank.gif"
									data-src="<?php echo $icon['path']; ?>" title="<?php echo $icon['title'] ?>"/>
								<span data-id="<?php echo $icon['original']; ?>"> <?php echo $icon['title'] ?> </span>
							</div>
							<?php endforeach; ?>
						</div>
					</td>
				</tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label class="hasTip" title="<?php echo JText::_('COM_HOTSPOTS_CUSTOM_TILE_MARKER_COLOR'); ?>::<?php echo JText::_('COM_HOTSPOTS_CUSTOM_TILE_MARKER_COLOR_DESC'); ?>">
                        <?php echo JText::_('COM_HOTSPOTS_CUSTOM_TILE_MARKER_COLOR'); ?>:
                        </label>
                    </td>
                    <td>
                        <input name="params[tile_marker_color]"
                               class="input-colorpicker required" type="text" id="color"
                               value="<?php echo isset($this->row->params['tile_marker_color']) ? $this->row->params['tile_marker_color'] : '' ?>"
                                />
                    </td>
                </tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('COM_HOTSPOTS_CAT_IMAGE'); ?>:
					</td>
					<td>
						<?php if ($this->row->cat_image) : ?>
						<img
							src="<?php echo JURI::root(); ?>media/com_hotspots/images/categories/<?php echo $this->row->cat_image ?> "/>
						<?php endif; ?>
						<div class="clear-both"></div>
						<input type="file" name="cat_image" id="cat_image"/>
					</td>

				</tr>

			</table>

		</fieldset>
		<input type="hidden" name="id" value="<?php echo $this->row->id; ?>"/>
		<input type="hidden" name="option" value="com_hotspots"/>
		<input type="hidden" name="wsampleshadow" id="wsampleshadow" value=""/>
		<input type="hidden" name="wsampleicon" id="wsampleicon" value=""/>
		<input type="hidden" name="deleteicon" id="deleteicon" value=""/>
		<input type="hidden" name="deleteshadow" id="deleteshadow" value=""/>
		<input type="hidden" name="view" value="category"/>
		<input type="hidden" name="task" value=""/>
	</form>
</div>