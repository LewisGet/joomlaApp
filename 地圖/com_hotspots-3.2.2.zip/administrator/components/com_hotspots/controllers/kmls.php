<?php

/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2012 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

require_once( JPATH_COMPONENT_ADMINISTRATOR . '/helpers/hotspots.php');

class HotspotsControllerKmls extends JControllerAdmin {

	public function __construct() {
		parent::__construct();

		// Register Extra tasks
		$this->registerTask('add', 'edit');
		$this->registerTask('apply', 'save');
		$this->registerTask('unpublish', 'publish');
	}

	public function getModel($name = 'Kml', $prefix = 'HotspotsModel') {
		$model = parent::getModel($name, $prefix);
		return $model;
	}

	public function remove() {
		$cid = JRequest::getVar('cid', array(), '', 'array');
		$db = & JFactory::getDBO();
		if (count($cid)) {
			$cids = implode(',', $cid);
			$query = "DELETE FROM #__hotspots_kmls WHERE hotspots_kml_id IN ( $cids )";
			$db->setQuery($query);
			if (!$db->query()) {
				echo "<script> alert ('" . $db->getErrorMsg() . "');
			window.history.go(-1); </script>\n";
			}
		}

		$this->setRedirect('index.php?option=com_hotspots&view=kmls');
	}

//	public function publish() {
//		$cid = JRequest::getVar('cid', array(), '', 'array');
//		$task = '_task';
//		if(HOTSPOTS_JVERSION == 16) {
//			$task = 'task';
//		}
//		if ($this->$task == 'publish') {
//			$publish = 1;
//		} else {
//			$publish = 0;
//		}
//
//		$msg = "";
//		$hotspotTable = & JTable::getInstance('marker', 'Table');
//		$hotspotTable->publish($cid, $publish);
//
//		$link = 'index.php?option=com_hotspots';
//
//		$this->setRedirect($link, $msg);
//	}


	/**
	 * Gets all hotspots categories
	 */
	private function getCategories() {
		$db = & JFactory::getDBO();
		$query = "SELECT * FROM #__hotspots_categorie ORDER BY " . HotspotsHelper::getSettings('category_ordering', 'id ASC');
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		return $rows;
	}
	


}