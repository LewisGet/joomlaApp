<?php
/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2012 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 3.0
 * */
defined('_JEXEC') or die('Restricted access');

class TableMarker extends JTable {

	public function __construct(&$db) {
		parent::__construct('#__hotspots_marker', 'id', $db);
	}

	public function store($updateNulls=false) {
        $date = JFactory::getDate();
        $user = JFactory::getUser();
        if ($this->id) {
            // Existing item
            $this->modified     = $date->toSql();
            $this->modified_by  = $user->get('id');
        } else {
            // New Marker. Created and created_by field can be set by the user,
            // so we don't touch either of these if they are set.
            if (!intval($this->created)) {
                $this->created = $date->toSql();
            }
            if (empty($this->created_by)) {
                $this->created_by = $user->get('id');
            }
        }
//      If we manage to store the marker -> update the count
        if(parent::store($updateNulls)) {
            $this->countCategoryMarker();
            return true;
        }

        return false;
	}


    /**
     * Overloaded bind function to pre-process the params.
     *
     * @param	array		Named array
     * @return	null|string	null is operation was satisfactory, otherwise returns an error
     * @see		JTable:bind
     * @since	1.5
     */
    public function bind($array, $ignore = '')
    {
        // Search for the {readmore} tag and split the text up accordingly.
        if (isset($array['hotspotText']))
        {
            $pattern = '#<hr\s+id=("|\')system-readmore("|\')\s*\/*>#i';
            $tagPos = preg_match($pattern, $array['hotspotText']);

            if ($tagPos == 0)
            {
                $this->description_small = $array['hotspotText'];
                $this->description = '';
            }
            else
            {
                list ($this->description_small, $this->description) = preg_split($pattern, $array['hotspotText'], 2);
            }
        }

        if (isset($array['params']) && is_array($array['params'])) {
            $registry = new JRegistry();
            $registry->loadArray($array['params']);
            $array['params'] = (string)$registry;
        }

        // Bind the rules.
        if (isset($array['rules']) && is_array($array['rules']))
        {
            $rules = new JAccessRules($array['rules']);
            $this->setRules($rules);
        }

        return parent::bind($array, $ignore);
    }

	/**
	 * Generic Publish/Unpublish function
	 *
	 * @access public
	 * @param array An array of id numbers
	 * @param integer 0 if unpublishing, 1 if publishing
	 * @param integer The id of the user performnig the operation
	 * @since 1.0.4
	 */
	public function publish( $cid=null, $publish=1, $user_id=0 )
	{
        if(parent::publish($cid,$publish,$user_id)) {
            $this->countCategoryMarker();
            return true;
        }

        return false;
	}

    public function check()
    {
        // Check the publish down date is not earlier than publish up.
        if (intval($this->publish_down) > 0 && $this->publish_down < $this->publish_up) {
            // Swap the dates.
            $temp = $this->publish_up;
            $this->publish_up = $this->publish_down;
            $this->publish_down = $temp;
        }
        return true;
    }

	/**
	 * Updates all Categories count fields
	 * Perhaps a little dirty to update all categories, we need to think
	 * on a better solution and not waste resources
	 *
	 * @access public
	 * @param $oid
	 * @param $log
	 */
	public function countCategoryMarker() {
		$db = $this->_db;
		
		$query = 'SELECT id FROM ' . $db->quoteName('#__hotspots_categorie');
		$db->setQuery($query);
		
		$catIds = $db->loadResultArray();

		$insertQuery = '';
		foreach($catIds as $key => $value) {
			$query = ' SELECT COUNT(*) FROM ' . $db->quoteName('#__hotspots_marker')
					. ' WHERE catid = ' . $db->Quote($value)
					. ' AND published = ' . $db->Quote(1);
			$db->setQuery($query);
			$count = $db->loadRow();
			$insert =  ' UPDATE ' . $db->quoteName('#__hotspots_categorie') . ' AS c '
						. ' SET c.count = ' . $db->Quote($count[0]) 
						. ' WHERE c.id = ' . $db->Quote($value)
						. ';'; 
			$insertQuery .= $insert;
		}
		$db->setQuery($insertQuery);
		$db->queryBatch();
	}

    /**
     * Method to compute the default name of the asset.
     * The default name is in the form `table_name.id`
     * where id is the value of the primary key of the table.
     *
     * @return	string
     * @since	2.5
     */
    protected function _getAssetName()
    {
        $k = $this->_tbl_key;
        return 'com_hotspots.marker.'.(int) $this->$k;
    }


    /**
     * Get the parent asset id for the record
     *
     * @return	int
     * @since	2.5
     */
    protected function _getAssetParentId()
    {
        $asset = JTable::getInstance('Asset');
        $asset->loadByName('com_hotspots');
        return $asset->id;
    }

}
