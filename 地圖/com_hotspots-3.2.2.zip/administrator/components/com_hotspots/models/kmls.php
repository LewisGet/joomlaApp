<?php
/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2010 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 beta2
 * */
defined('_JEXEC') or die();
jimport('joomla.application.component.modellist');

class HotspotsModelKmls extends JModelList {

    /**
     * @var		string	The prefix to use with controller messages.
     * @since	1.6
     */
    protected $text_prefix = 'COM_HOTSPOTS';

	public $_total = null;
	public $_pagination = null;

	public function __construct() {
		parent::__construct();
		$mainframe = JFactory::getApplication();
		$context = 'com_hotspots.kmls.list.';
		// Get the pagination request variables
		$limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest($context . 'limitstart', 'limitstart', 0, 'int');

		// In case limit has been changed, adjust limitstart accordingly
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
	}

	public function getKmls() {
		if (empty($this->_data)) {
			$query = $this->_buildQuery();
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_data;
	}

	public function getTotal() {
		if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$this->_total = $this->_getListCount($query);
		}
		return $this->_total;
	}

	public function getPagination() {
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_pagination;
	}

	private function _buildQuery() {
		$context = 'com_hotspots.kmls.list.';
		// Get the WHERE and ORDER BY clauses for the query
		$where = $this->_buildContentWhere($context);
		$orderby = $this->_buildContentOrderBy($context, 'kmls.title');

		$query = ' SELECT kmls.*, cat.cat_name , u.name as user_name FROM #__hotspots_kmls AS kmls '
                . ' LEFT JOIN #__hotspots_categorie as cat'
                . ' ON cat.id = kmls.catid'
				. ' LEFT JOIN #__users as u'
				. ' ON u.id= kmls.created_by'
				. $where
				. $orderby
		;

		return $query;
	}

	private function _buildContentOrderBy($context, $cc_or_a) {
		$appl = JFactory::getApplication();
		$filter_order = $appl->getUserStateFromRequest($context . 'filter_order', 'filter_order', 'kmls.catid', 'cmd'); // Category tree works with id not with ordering
		$filter_order_Dir = $appl->getUserStateFromRequest($context . 'filter_order_Dir', 'filter_order_Dir', '', 'word');

		if ($filter_order == 'cat.cat_name') {
			$orderby = ' ORDER BY  cat.cat_name ' . $filter_order_Dir;
		} else if ($filter_order == 'category') {
			$orderby = ' ORDER BY ' . $cc_or_a . ', kmls.hotspots_kml_id ' . $filter_order_Dir;
		} else {
			$orderby = ' ORDER BY ' . $filter_order . ' ' . $filter_order_Dir . ', kmls.catid ';
		}
		return $orderby;
	}

	private function _buildContentWhere($context) {
		$mainframe = JFactory::getApplication();
		$filter_state = $mainframe->getUserStateFromRequest($context . 'filter_state', 'filter_state', '', 'word');
		$filter_sectionid = $mainframe->getUserStateFromRequest($context . 'filter_sectionid', 'filter_sectionid', 0, 'int');
		$filter_order = $mainframe->getUserStateFromRequest($context . 'filter_order', 'filter_order', 'cc.catid', 'cmd');
		$filter_order_Dir = $mainframe->getUserStateFromRequest($context . 'filter_order_Dir', 'filter_order_Dir', '', 'word');
		$search = $mainframe->getUserStateFromRequest($context . 'search', 'search', '', 'string');
		$search = JString::strtolower($search);
		$where = array();

		if ($search) {
			$where[] = 'LOWER(kmls.original_filename) LIKE ' . $this->_db->Quote('%' . $search . '%');
		}
		if ($filter_state) {
			if ($filter_state == 'P') {
				$where[] = 'kmls.state = 1';
			} else if ($filter_state == 'U') {
				$where[] = 'kmls.state = 0';
			}
		}

		if ($filter_sectionid) {
			$where[] = 'kmls.catid = ' . (int) $filter_sectionid;
		}

		$where = ( count($where) ? ' WHERE ' . implode(' AND ', $where) : '' );

		return $where;
	}




}