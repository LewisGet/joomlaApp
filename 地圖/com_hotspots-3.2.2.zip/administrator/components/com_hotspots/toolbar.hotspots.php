<?php
/**
* Hotspots - Adminstrator
* @package Joomla!
* @Copyright (C) 2010 - Daniel Dimitrov - http://compojoom.com
* @All rights reserved
* @Joomla! is Free Software
* @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @version $Revision: 1.0 stable
**/

defined('_JEXEC') or die('Restricted access');

$language = JFactory::getLanguage();
$language->load('com_hotspots.sys', JPATH_ADMINISTRATOR, null, true);

$view	= JFactory::getApplication()->input->getCmd('view');

$subMenus = array (
	'controlcenter'=> 'COM_HOTSPOTS_DASHBOARD',
	'hotspots' => 'COM_HOTSPOTS_LOCATIONS',
    'kmls' => 'COM_HOTSPOTS_KML',
	'categories' => 'COM_HOTSPOTS_CATEGORIES',
	'import' => 'COM_HOTSPOTS_IMPORT',
	'settings' => 'COM_HOTSPOTS_CONFIGURATION',
    'liveupdate' => 'COM_HOTSPOTS_LIVEUPDATE'
);

// Options button.
if (!JFactory::getUser()->authorise('core.admin', 'com_hotspots')) {
    unset($subMenus['settings']);
    unset($subMenus['import']);
    unset($subMenus['liveupdate']);
}
foreach($subMenus as $key => $name) {
	$active	= ( $view == $key );
	
	JSubMenuHelper::addEntry( JText::_($name) , 'index.php?option=com_hotspots&view=' . $key , $active );
}