<?php
/**
 * Compojoom Control Center
 * @package Joomla!
 * @Copyright (C) 2012 - Yves Hoppe - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.0 beta $
 **/

defined('_JEXEC') or die('Restricted access');
require_once(JPATH_ADMINISTRATOR.'/components/com_hotspots/helpers/hotspots.php');
$version = HotspotsHelper::getSettings('version')

?>
<div style="padding: 12px;">
	<div style="float:right;margin:10px;">
		<?php
		echo JHTML::_('image', JURI::root() . 'media/com_hotspots/images/utils/logo.jpg', 'compojoom.com', 'style="width:200px;"');
		?>
	</div>

	<div>
		<h1><?php echo JText::_('COM_HOTSPOTS_INFORMATIONS'); ?></h1>

		<h3><?php echo JText::_('COM_HOTSPOTS_VERSION'); ?></h3>
		<p><?php echo $version; ?></p>

		<h3><?php echo JText::_('COM_HOTSPOTS_COPYRIGHT'); ?></h3>
		<p>Copyrigth &copy; <?php echo date("Y"); ?> Compojoom.com</p>

		<h3><?php echo JText::_('COM_HOTSPOTS_LICENSE'); ?></h3>
		<p><a href="http://www.gnu.org/licenses/gpl-2.0.html" target="_blank">GPLv2</a></p>
		<br />


		<h3>Thank you</h3>
		<div>
			This software would not have been possible without the help of those listed here.
			THANK YOU for your continuous help, support and inspiration!
		</div>
		<ul>
			<li>
				<em>Nicholas Dionysopoulos</em> (<a href="http://www.dionysopoulos.me/" target="_blank">http://www.dionysopoulos.me/</a> && <a href="http://www.akeebabackup.com/" target="_blank">http://www.akeebabackup.com/</a>) <br />
				For his continuous help and support
			</li>
			<li>
				<em>Yves Hoppe </em> (<a href="http://yves-hoppe.de/" target="_blank">http://yves-hoppe.de/</a>) - for creating the first ever version of Hotspots :)
			</li>
			<li>
				<em>Kyle Ledbetter </em> (<a href="http://pixelpraise.com" target="_blank">http://pixelpraise.com</a>) - for helping with the design and giving ideas :)
			</li>
			<li>
				<em>O.Schwab</em> (<a href="http://castle4us.de" target="_blank">http://castle4us.de</a>) - for helping with testing and translating
			</li>
			<li>
				<em>Nils Ally</em> - for helping with testing and translating
			</li>
			<li>
				The whole MooTools channel on irc.freenode.org and specially: <br />
				<em>fakedarren (<a href="http://blog.fakedarren.com/" target="_blank">http://blog.fakedarren.com/</a></em> <br />
				<em>arian (<a href="http://aryweb.nl/" target="_blank">http://aryweb.nl/</a></em> <br />
				<em>timmeh (<a href="http://tim.wienk.name/" target="_blank">http://tim.wienk.name/</a></em> <br />
				<em>keeto</em> (<a href="http://keetology.com/" target="_blank">http://keetology.com/</a>)
			</li>
			<li>
				The Google maps group:
				<a href="https://groups.google.com/group/google-maps-js-api-v3" target="_blank">https://groups.google.com/group/google-maps-js-api-v3</a>
				and specially <em>Rossko</em>
			</li>
			<li>
				Last but not least - <em>Nicolas Mollet</em> for providing us with the sample icons for the categories. <br />
				If you need more icons, then please look at
				Nicolas's website: <a href="http://mapicons.nicolasmollet.com/" target="_blank">http://mapicons.nicolasmollet.com/</a> <br />
				And don't forget to buy him a beer: <a href="http://mapicons.nicolasmollet.com/about/donations/" target="_blank">http://mapicons.nicolasmollet.com/about/donations/</a>

			</li>

		</ul>


		<h3><?php echo JText::_('COM_HOTSPOTS_HELP'); ?></h3>
		<p>
			<a href="http://www.compojoom.com/">Hotspots main site</a><br />
		</p>
		<p><br />
			Maps are created by Google Maps&trade;<br />
			<br />
			Google&trade; is a trademark of Google Inc.<br />
			Google Maps&trade; is a trademark of Google Inc.<br /><br />
			Sigsiu Online Business Index 2 (SOBI2) is developed by Sigsiu.NET
		</p>
	</div>
</div>