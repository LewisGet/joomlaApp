<?php
/**
 * Compojoom Control Center
 * @package Joomla!
 * @Copyright (C) 2012 - Yves Hoppe - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.0 beta $
 **/

// No direct access.
defined('_JEXEC') or die;

class modHotspotsHelper
{
	public static function getHotspots() {
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('m.id AS hotspots_id, m.gmlat as latitude,
					m.gmlng as longitude, m.name as title, m.*')
			->from('#__hotspots_marker as m')
			->leftJoin('#__hotspots_categorie AS c ON m.catid = c.id')
			->order('m.created DESC');
		$db->setQuery($query, 0, 25);

		return $db->loadObjectList();
	}

	public static function prepareHotspots($hotspots) {
		$json = array();

		foreach($hotspots as $hotspot) {
			$json['hotspots'][$hotspot->catid][$hotspot->id] = hotspotsUtils::prepareHotspot($hotspot);
		}

		return json_encode($json);
	}
}