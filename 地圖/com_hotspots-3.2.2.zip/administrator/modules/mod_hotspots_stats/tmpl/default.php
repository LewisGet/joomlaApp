<?php
/**
 * Mod hotspots
 * @package Joomla!
 * @Copyright (C) 2012 - Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 3.0 $
 **/

defined('_JEXEC') or die('Restricted access');
$stats = modHotspotsStatsHelper::getStats();
$state = array(
	'all' => '',
	'published' => 'P',
	'unpublished' => 'U'
);

$tiles = modHotspotsStatsHelper::tilesStats();
?>

<table>
	<tbody>
		<?php foreach($stats as $key => $value) : ?>

			<tr>
				<td>
					<?php echo JText::_('MOD_HOTSPOTS_STATS_'.strtoupper($key)); ?>
				</td>
				<td>
					<a href="<?php echo JRoute::_('index.php?option=com_hotspots&view=hotspots&filter_state='.$state[$key]); ?>">
						<?php echo $value; ?>
					</a>
				</td>
			</tr>
		<?php endforeach; ?>

        <?php if($tiles['files']) : ?>
        <tr>
                <td><?php echo JText::_('MOD_HOTSPOTS_STATS_TILES'); ?></td>
                <td><?php echo JText::sprintf('COM_HOTSPOTS_NUMBER_OF_TILES_TAKE_X_SPACE', $tiles['files'], modHotspotsStatsHelper::formatBytes($tiles['size'])); ?></td>
                <td><a href="<?php echo JRoute::_('index.php?option=com_hotspots&task=tiles.delete'); ?>"><?php echo JText::_('JACTION_DELETE'); ?></a></a></td>
            </tr>
         <?php else: ?>
            <tr>
                <td><?php echo JText::_('MOD_HOTSPOTS_STATS_TILES'); ?></td>
                <td>0</td>
            </tr>
        <?php endif; ?>
	</tbody>
</table>

