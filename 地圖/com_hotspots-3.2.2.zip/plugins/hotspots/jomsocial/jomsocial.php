<?php
/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2012 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.plugin.plugin');

class plgHotspotsJomSocial extends JPlugin {

	function __construct(&$subject, $params) {
		JPlugin::loadLanguage('plg_hotspots_jomsocial', JPATH_ADMINISTRATOR);
		parent::__construct($subject, $params);
	}

	/**
	 * @param $context
	 * @param $data
	 * @return bool
	 */
	public function onAfterHotspotSave($context, $data) {

		if($context != 'com_hotspots.hotspot') {
			return false;
		}

		$userPoints = $this->params->get('userPointsOnAddHotspot', 0);
		$activityStream = $this->params->get('activityStreamNewHotspot', 0);

		if ($userPoints) {
			$this->setUserPointsOnAddHotspot($data);
		}

		if ($activityStream) {
			$this->setActivity($data, 'save');
		}

		return true;
	}

	private function setUserPointsOnAddHotspot($data) {
		include_once( JPATH_ROOT . '/components/com_community/libraries/userpoints.php');
		CuserPoints::assignPoint('com_hotspots.addHotspot', $data->created_by);
	}

	private function setActivity($data, $activity) {
		jimport('joomla.filesystem.file');
		$utils = JPATH_ROOT . '/components/com_hotspots/utils.php';
		$appl = JFactory::getApplication();
		
//		if hotspots is not installed, if the hotspot is unpublished per default or if
//		we are in backend we don't assign any activity
		if($data->published == 0 || !JFile::exists($utils) || $appl->isAdmin()) {
			return;
		}

		$target = 0;

		if ($activity == 'save') {
			$catTitle = JFilterOutput::stringURLSafe($this->getCatTitle($data->catid));
			$url = JRoute::_('index.php?option=com_hotspots&view=hotspot&catid='.
					$data->catid.':'.$catTitle.'&id='.$data->id.':'
					.JFilterOutput::stringURLSafe($data->name).
					'&Itemid='.hotspotsUtils::getItemid('com_hotspots','hotspots'));
			$title = $data->name;

			$actTitle = JText::_('JOMSOCIAL_ADDHOTSPOTS') . ':' . ' <a href="' . $url . '">' . $title . '</a>';
			
			$content = stripslashes($data->description);
		}

		$act = new stdClass();
		$act->cmd = 'com_hotspots.addHotspot';
		$act->actor = $data->created_by;
		$act->target = $target; // no target
		$act->title = $actTitle;
		$act->content = $content;
		$act->app = 'com_hotspots';
		$act->cid = $data->id;

		CFactory::load('libraries', 'activities');
		CActivityStream::add($act);
	}
	
	private function getCatTitle($id) {
		$db = JFactory::getDBO();
		$query = 'SELECT cat_name FROM ' . $db->nameQuote('#__hotspots_categorie')
				. ' WHERE ' . $db->nameQuote('id') . '=' . $db->Quote($id);
		$db->setQuery($query, 0, 1);
		
		return $db->loadObject()->cat_name;
	}
}