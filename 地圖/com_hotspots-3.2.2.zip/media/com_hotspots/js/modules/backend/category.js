new Class('compojoom.hotspots.modules.categories', {
	lazyLoading: false,
	lazyLoadingShadow: false,
	
	initialize: function() {
		
		document.id('select-icon').addEvent('change', function() {
			this.editIconForm();
		}.bind(this));
		document.id('select-shadow').addEvent('change', function() {
			this.editShadowForm();
		}.bind(this));
	},
	
	editIconForm: function() {
		var selected = document.id('select-icon').get('value');

		if (selected == "new") {
			this._resetElements();
			document.id('iconupload').setStyle('display','block');
		}

		if (selected == "delete"){
			this._resetElements();
			document.id('deleteicon').value = '1';
			document.id('deleteicon-text').setStyle('display','block');
		}

		if (selected == "sample") {
			this._resetElements();
			
			document.id('select-sample-image').setStyle('display','block');
			
			this.loadImages();
		}
	},
	
	editShadowForm: function() {
		var selected = document.id('select-shadow').get('value');
		if (selected == "new") {
			this._resetShadowElements();
			document.getElementById('shadowupload').setStyle('display','block');
		}

		if (selected == "delete") {
			this._resetShadowElements();
			document.id('deleteshadow').value = '1';
			document.id('deleteshadow_text').setStyle('display','block');
		}

		if (selected == "sample"){
			this._resetShadowElements();
			document.id('select-sample-shadow').setStyle('display','block');
			this.loadShadows();
		}
	},
	
	_resetElements: function() {
		document.id('deleteicon-text').setStyle('display','none');
		document.id('select-sample-image').setStyle('display','none');
		document.id('iconupload').setStyle('display','none');
		document.id('deleteicon').value = '0';
	},
	
	_resetShadowElements: function() {
		document.id('deleteshadow_text').setStyle('display','none');
		document.id('select-sample-shadow').setStyle('display','none');
		document.id('shadowupload').setStyle('display','none');
		document.id('deleteshadow').value = '0';
	},
	
	loadImages: function() {
		if(this.lazyLoading === false) {
			new LazyLoad({
				range: 50, 
				container: 'select-sample-image'
			});
			this.lazyLoading = true;
		}
		
		var self = this;
		document.id('select-sample-image').getElements('div').addEvent('click', function() {
			self.addicon(this.getElement('span').get('data-id'),this.getElement('img').get('src'), this.getElement('img').get('title'));
		})
	},
	
	loadShadows: function() {
		if(this.lazyLoadingShadow === false) {
			new LazyLoad({
				range: 50, 
				container: 'select-sample-shadow'
			});
			this.lazyLoadingShadow = true;
		}
		var self = this;
		document.id('select-sample-shadow').getElements('div').addEvent('click', function() {
			self.addshad(this.getElement('span').get('data-id'),this.getElement('img').get('src'), this.getElement('img').get('title'));
		})
	},
	
	addicon: function(icon, path, title) {
		document.id('wsampleicon').value = '/sample/'+icon;
		
		alert('Sample Icon ' + title + ' selected');
		
		var categoryIcon = document.id('category-icon').getElement('img');
		if(categoryIcon) {
			categoryIcon.set('src', path);
		} else {
			var image = new Element('img', {
				src: path
			});
			document.id('category-icon').set('html', '');
			image.inject(document.id('category-icon'));
		}
		document.id('category-icon').removeClass('validation-failed');
	},
	
	addshad: function(icon, path, title) {
		document.id('wsampleshadow').value = 'sample_shadow/'+icon;
		
		alert('Sample Icon ' + title + ' selected');
		
		var categoryShadow = document.id('category-shadow').getElement('img');
		if(categoryShadow) {
			categoryShadow.set('src', path);
		} else {
			var image = new Element('img', {
				src: path
			});
			document.id('category-shadow').set('html', '');
			image.inject(document.id('category-shadow'));
		}
		document.id('category-shadow').removeClass('validation-failed');
	}
});

