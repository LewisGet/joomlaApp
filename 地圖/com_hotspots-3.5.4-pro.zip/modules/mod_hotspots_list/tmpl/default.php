<?php
/**
 * @package    com_hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       10.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

JLoader::register('HotspotsHelper', JPATH_ADMINISTRATOR . '/components/com_hotspots/helpers/hotspots.php');
JLoader::discover('HotspotsHelper', JPATH_BASE . '/components/com_hotspots/helpers/');
JLoader::register('HotspotsUtils', JPATH_BASE . '/components/com_hotspots/utils.php');
?>
<ul>
	<?php foreach($list as $hotspot) : ?>
		<?php $hotspot->hotspots_id = $hotspot->id; ?>
		<li>
			<a href="<?php echo HotspotsUtils::createLink($hotspot); ?>">
				<?php echo $hotspot->name; ?>
			</a>
			created by
			<?php if($hotspot->created_by) : ?>
				<?php $hotspot->user_name; ?>
			<?php else: ?>
				<?php echo $hotspot->created_by_alias; ?>
			<?php endif; ?>
			on
			<?php echo hotspotsUtils::getLocalDate($hotspot->created); ?>
		</li>

	<?php endforeach; ?>
</ul>