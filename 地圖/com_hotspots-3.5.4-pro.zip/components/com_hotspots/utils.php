<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       02.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

/**
 * Class hotspotsUtils
 *
 * @since  1
 */
class HotspotsUtils
{
	private static $frontCategories;

	/**
	 * Check if the current user is member of the supplied groups
	 *
	 * @param   array  $groups  - the groups to check against
	 *
	 * @return bool
	 */
	public static function isUserInGroups($groups = array())
	{
		$user = JFactory::getUser();

		$userGroups = $user->getAuthorisedGroups();

		if (array_intersect($groups, $userGroups))
		{
			return true;
		}

		return false;
	}

	/**
	 * Returns a formated date that also takes in account the user timezone
	 *
	 * @param   string  $date  - the date
	 *
	 * @return mixed
	 */
	public static function getLocalDate($date)
	{
		$format = HotspotsHelper::getSettings('date_format', 'Y-m-d H:i:s');
		$formattedDate = JHtml::_('date', $date, $format, true, true);

		return $formattedDate;
	}

	/**
	 * This function is based on the singleton pattern
	 *
	 * @return array $categories
	 */
	public static function get_front_categories()
	{
		if (!isset(self::$frontCategories))
		{
			$db = JFactory::getDBO();
			$query = "SELECT id, id AS value, cat_name AS text, cat_description, count, cat_icon FROM
			#__hotspots_categorie WHERE published='1' ORDER BY " . HotspotsHelper::getSettings('category_ordering', 'id ASC');
			$db->setQuery($query);
			$rows = $db->loadAssocList('id');

			if ($db->getErrorNum())
			{
				echo $db->stderr();

				return false;
			}

			self::$frontCategories = $rows;
		}

		return self::$frontCategories;
	}

	/**
	 * Prepares all variables that we would need in JS
	 *
	 * @param   boolean  $array  - determines if we should return the variables as  array or as a json string
	 *
	 * @return string|array - array with the variables or json string with variables for js
	 */
	public static function getJSVariables($array = false)
	{
		$settings = array();
		$app = JFactory::getApplication();
		$uri = JUri::getInstance();
		$settings['rootUrl'] = JUri::root();
		$settings['baseUrl'] = $uri->toString(array('scheme', 'user', 'pass', 'host', 'port', 'path'));
		$settings['mapStartPosition'] = HotspotsHelper::getSettings('map_startposition', 'Karlsruhe, Germany');
		$settings['mapStartZoom'] = (int) HotspotsHelper::getSettings('map_startzoom', 4);

		$settings['centerType'] = (int) HotspotsHelper::getSettings('map_centertyp', 1);

		$settings['customUserZoom'] = (int) HotspotsHelper::getSettings('map_center_user_zoom', 15);

		// Center by user's location
		if ($settings['centerType'] === 2 && $app->input->getCmd('view') == 'hotspots')
		{
			$settings['highAccuracy'] = (int) HotspotsHelper::getSettings('high_accuracy', 0);
			$location = HotspotsHelperLocation::getUserLocation();

			if ($location)
			{
				if ($location->latitude && $location->longitude)
				{
					$settings['mapStartPosition'] = $location->latitude . ',' . $location->longitude;

					// Set a higher zoom if we know the user's location
					$settings['mapStartZoom'] = 10;
				}
			}
		}

		$settings['searchZoom'] = (int) HotspotsHelper::getSettings('search_zoom', 14);

		if ($app->isSite() && $app->input->getCmd('view') == 'hotspots')
		{
			$settings['startCat'] = implode(';', HotspotsHelper::getSettings('hs_startcat', 1));
		}

		$settings['staticMapWidth'] = (int) HotspotsHelper::getSettings('map_static_width', 500);
		$settings['staticMapHeight'] = (int) HotspotsHelper::getSettings('map_static_height', 300);
		$settings['getDirections'] = (int) HotspotsHelper::getSettings('routenplaner', 1);
		$settings['gmControl'] = (int) HotspotsHelper::getSettings('gm_control', '1');
		$settings['gmControlPos'] = HotspotsHelper::getSettings('gm_control_pos', 'topLeft');
		$settings['mapType'] = (int) HotspotsHelper::getSettings('map_type', 1);
		$settings['panControl'] = (int) HotspotsHelper::getSettings('panControl', 1);
		$settings['zoomControl'] = (int) HotspotsHelper::getSettings('zoomControl', 1);
		$settings['mapTypeControl'] = (int) HotspotsHelper::getSettings('mapTypeControl', 1);
		$settings['scaleControl'] = (int) HotspotsHelper::getSettings('scaleControl', 1);
		$settings['streetViewControl'] = (int) HotspotsHelper::getSettings('streetViewControl', 1);
		$settings['overviewMapControl'] = (int) HotspotsHelper::getSettings('overviewMapControl', 1);
		$settings['scrollwheel'] = (int) HotspotsHelper::getSettings('scrollwheel', 1);
		$settings['styledMaps'] = HotspotsHelper::getSettings('styled_maps', '');
		$settings['userInterface'] = (int) HotspotsHelper::getSettings('user_interface', 1);
		$settings['print'] = (int) HotspotsHelper::getSettings('print_map', 1);
		$settings['resizeMap'] = (int) HotspotsHelper::getSettings('resize_map', 1);
		$settings['mailMap'] = (int) HotspotsHelper::getSettings('mail_map', 1);
		$settings['listLength'] = (int) HotspotsHelper::getSettings('marker_list_length', 20);

		// There is no dedicated setting to the directions right now, but if the
		// menu is not there we should hide them
		$settings['showDirections'] = (int) HotspotsHelper::getSettings('show_marker_directions', 1);
		$settings['showAddress'] = (int) HotspotsHelper::getSettings('show_address', 1);
		$settings['showCountry'] = (int) HotspotsHelper::getSettings('show_address_country', 0);
		$settings['showZoomButton'] = (int) HotspotsHelper::getSettings('show_zoom_button', 0);
		$settings['showAuthor'] = (int) HotspotsHelper::getSettings('show_author', 1);
		$settings['showDate'] = (int) HotspotsHelper::getSettings('show_date', 1);
		$settings['showMenu'] = (int) HotspotsHelper::getSettings('hs_show_controllmenu', 1);
		$settings['numOfCatsToShow'] = (int) HotspotsHelper::getSettings('number_of_cats_to_show', 4);
		$settings['categoryInfo'] = (int) HotspotsHelper::getSettings('category_info', 4);
		$settings['showMarkerCount'] = (int) HotspotsHelper::getSettings('show_marker_count', 4);
		$settings['weather'] = (int) HotspotsHelper::getSettings('weather_api', 0);
		$settings['cloudsLayer'] = (int) HotspotsHelper::getSettings('clouds_layer', 0);
		$settings['weatherTemperatureUnit'] = HotspotsHelper::getSettings('weather_api_temperature_unit', 'CELSIUS');
		$settings['weatherWindSpeedUnit'] = (int) HotspotsHelper::getSettings('weather_api_wind_speed_unit', 'KILOMETERS_PER_HOUR');
		$settings['weatherClickable'] = (int) HotspotsHelper::getSettings('weather_api_data_clickable', 1);
		$settings['trafficLayer'] = (int) HotspotsHelper::getSettings('traffic_layer', 0);
		$settings['transitLayer'] = (int) HotspotsHelper::getSettings('transit_layer', 0);
		$settings['bicyclingLayer'] = (int) HotspotsHelper::getSettings('bicycling_layer', 0);
		$settings['panoramioLayer'] = (int) HotspotsHelper::getSettings('panoramio_layer', 0);
		$settings['panoramioUserId'] = (int) HotspotsHelper::getSettings('panoramio_user_id', "");
		$settings['visualRefresh'] = (int) HotspotsHelper::getSettings('visual_refresh', 1);
		$settings['draggableDirections'] = (int) HotspotsHelper::getSettings('draggable_directions', 1);
		$settings['startClosedMenu'] = (int) HotspotsHelper::getSettings('start_closed_menu', 0);

		$settings['categories'] = self::getCategoriesInfo();

		// Return the settings array as it is
		if ($array)
		{
			return $settings;
		}

		return 'hotspots.DefaultOptions = ' . json_encode($settings) . ';';
	}

	/**
	 * Prepares the categories for output
	 *
	 * @return mixed
	 */
	public static function getCategoriesInfo()
	{
		$catModel = JModelLegacy::getInstance('Category', 'hotspotsModel');
		$boundaries = self::boundaries();
		$categories = $catModel->getCategories();

		foreach ($categories as $key => $category)
		{
			$categories[$key] = self::prepareCategory($category);

			if (isset($boundaries[$key]))
			{
				$categories[$key]->boundaries = $boundaries[$key];
			}
		}

		return $categories;
	}

	/**
	 * I'm not sure that this function belongs here. Maybe we should
	 * add it to a model???
	 *
	 * The function returns the map boundaries of all categories
	 *
	 * @return mixed
	 */
	public static function boundaries()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('catid, MIN( gmlat ) AS south, MAX( gmlat ) AS north, MAX( gmlng ) AS east, MIN( gmlng ) AS west')
			->from('#__hotspots_marker')
			->group('catid')
			->where('published = 1');
		$db->setQuery($query);

		return $db->loadObjectList('catid');
	}

	/**
	 * Outputs a localisation array for JS
	 *
	 * @return void
	 */
	public static function getJsLocalization()
	{
		$strings = array(
			'COM_HOTSPOTS_JS_DIRECTIONS',
			'COM_HOTSPOTS_GET_DIRECTIONS',
			'COM_HOTSPOTS_ZOOM',
			'COM_HOTSPOTS_TO',
			'COM_HOTSPOTS_FROM',
			'COM_HOTSPOTS_SUBMIT',
			'COM_HOTSPOTS_LOADING_DATA',
			'COM_HOTSPOTS_NO_HOTSPOTS_IN_CATEGORY',
			'COM_HOTSPOTS_MORE_HOTSPOTS',
			'COM_HOTSPOTS_READ_MORE',
			'COM_HOTSPOTS_CANCEL',
			'COM_HOTSPOTS_COULDNT_FIND_LOCATION',
			'COM_HOTSPOTS_ZERO_RESULTS_LOCATION',
			'COM_HOTSPOTS_PRINT',
			'COM_HOTSPOTS_SOMETHING_IS_WRONG',
			'COM_HOTSPOTS_ENTER_FULL_DESCRIPTION',
			'COM_HOTSPOTS_ENTER_SOBI2_ID',
			'COM_HOTSPOTS_ENTER_ARTICLE_ID',
			'COM_HOTSPOTS_GEOLOCATION_NO_SUPPORT',
			'COM_HOTSPOTS_DRAG_ME',
			'COM_HOTSPOTS_THERE_ARE',
			'COM_HOTSPOTS_THERE_IS',
			'COM_HOTSPOTS_EMAIL_THIS_MAP',
			'COM_HOTSPOTS_CLEAR_ROUTE',
			'COM_HOTSPOTS_SEND',
			'COM_HOTSPOTS_CLOSE',
			'COM_HOTSPOTS_SEARCH_RETURNED_NO_RESULTS',
			'COM_HOTSPOTS_POSTED_BY',
			'COM_HOTSPOTS_ON',
			'COM_HOTSPOTS_IN_YOUR_CURRENT_VIEW_THERE_ARE',
			'COM_HOTSPOTS_HOTSPOTS',
			'COM_HOTSPOTS_SEARCH_RESULTS_AROUND_THE_WORLD',
			'COM_HOTSPOTS_SEARCH_RETURNED_NO_RESULTS_IN_THIS_VIEW',
			'COM_HOTSPOTS_SEARCH_IN_YOUR_CURRENT_VIEW_RETURNED',
			'COM_HOTSPOTS_NO_LOCATIONS_IN_CURRENT_VIEW'
		);

		foreach ($strings as $string)
		{
			JText::script($string);
		}
	}

	/**
	 * Prepares a category for output
	 *
	 * @param   object  $category  - the category object
	 *
	 * @return mixed
	 */
	public static function prepareCategory($category)
	{
		$iconWebPath = (JURI::root() . "media/com_hotspots/images/categories/");

		if ($category->cat_icon)
		{
			$category->cat_icon = $iconWebPath . $category->cat_icon;
		}

		return $category;
	}

	/**
	 * Prepares a hotspot for output
	 *
	 * @param   object  $hotspot  - hotspot object
	 *
	 * @return mixed
	 */
	public static function prepareHotspot($hotspot)
	{
		$descriptionSmall = $hotspot->description_small;

		if (HotspotsHelper::getSettings('marker_allow_plugin', 0) == 1)
		{
			$descriptionSmall = JHTML::_('content.prepare', $descriptionSmall, '');
		}

		$hotspot->postdate = hotspotsUtils::getLocalDate($hotspot->created);

		if ($hotspot->picture_thumb)
		{
			$hotspot->picture_thumb = HOTSPOTS_THUMB_PATH . $hotspot->picture_thumb;
		}

		if ($hotspot->picture)
		{
			$hotspot->picture = HOTSPOTS_PICTURE_PATH . $hotspot->picture;
		}

		// We should actually have always just one plugin that executes for that
		// particular component
		$parameters = new JRegistry;
		$parameters->loadString($hotspot->params);
		$hotspot->params = $parameters;

		$hotspot->link = self::createLink($hotspot);

		$descriptionSmall = self::sef($descriptionSmall);
		$hotspot->description_small = $descriptionSmall;

		return $hotspot;
	}

	/**
	 * When we display the content in the map view the links and images in content
	 * are not run through the sef plugin and that's why in some situations images are not displayed properly
	 * and the links in the short description are not SEF
	 *
	 * TODO: check to see if there is a better way to solve this
	 *
	 * @param   string  $content  - the content for the hotspot
	 *
	 * @return mixed
	 */
	private static function sef($content)
	{
		$app = JFactory::getApplication();

		if ($app->getCfg('sef') == '0')
		{
			return $content;
		}

		// Replace src links
		$base = JURI::base(true) . '/';

		$regex = '#href="index.php\?([^"]*)#m';
		$content = preg_replace_callback($regex, array('self', 'route'), $content);

		// To check for all unknown protocals (a protocol must contain at least one alpahnumeric fillowed by :
		$protocols = '[a-zA-Z0-9]+:';
		$regex = '#(src|href|poster)="(?!/|' . $protocols . '|\#|\')([^"]*)"#m';
		$content = preg_replace($regex, "$1=\"$base\$2\"", $content);

		$regex = '#(onclick="window.open\(\')(?!/|' . $protocols . '|\#)([^/]+[^\']*?\')#m';
		$content = preg_replace($regex, '$1' . $base . '$2', $content);

		// ONMOUSEOVER / ONMOUSEOUT
		$regex = '#(onmouseover|onmouseout)="this.src=([\']+)(?!/|' . $protocols . '|\#|\')([^"]+)"#m';
		$content = preg_replace($regex, '$1="this.src=$2' . $base . '$3$4"', $content);

		// Background image
		$regex = '#style\s*=\s*[\'\"](.*):\s*url\s*\([\'\"]?(?!/|' . $protocols . '|\#)([^\)\'\"]+)[\'\"]?\)#m';
		$content = preg_replace($regex, 'style="$1: url(\'' . $base . '$2$3\')', $content);

		// OBJECT <param name="xx", value="yy"> -- fix it only inside the <param> tag
		$regex = '#(<param\s+)name\s*=\s*"(movie|src|url)"[^>]\s*value\s*=\s*"(?!/|' . $protocols . '|\#|\')([^"]*)"#m';
		$content = preg_replace($regex, '$1name="$2" value="' . $base . '$3"', $content);

		// OBJECT <param value="xx", name="yy"> -- fix it only inside the <param> tag
		$regex = '#(<param\s+[^>]*)value\s*=\s*"(?!/|' . $protocols . '|\#|\')([^"]*)"\s*name\s*=\s*"(movie|src|url)"#m';
		$content = preg_replace($regex, '<param value="' . $base . '$2" name="$3"', $content);

		// OBJECT data="xx" attribute -- fix it only in the object tag
		$regex = '#(<object\s+[^>]*)data\s*=\s*"(?!/|' . $protocols . '|\#|\')([^"]*)"#m';
		$content = preg_replace($regex, '$1data="' . $base . '$2"$3', $content);

		return $content;
	}

	/**
	 * Replaces the matched tags
	 *
	 * @param   array  &$matches  An array of matches (see preg_match_all)
	 *
	 * @return  string
	 */
	protected static function route(&$matches)
	{
		$url = $matches[1];
		$url = str_replace('&amp;', '&', $url);
		$route = JRoute::_('index.php?' . $url);

		return 'href="' . $route;
	}

	/**
	 * Creates a link to single view of a hotspot
	 *
	 * @param   object  $hotspot  - the hotspot object
	 *
	 * @return string $hotspotsLink
	 */
	public static function createLink($hotspot)
	{
		$hotspotsLink = '';

		if (!is_object($hotspot->params))
		{
			$parameters = new JRegistry;
			$parameters->loadString($hotspot->params);
			$hotspot->params = $parameters;
		}

		$globalReadMore = HotspotsHelper::getSettings('hotspot_detailpage', 1);
		$hotspotReadMore = $hotspot->params->get('show_readmore');

		if (($hotspotReadMore == null && $globalReadMore) || $hotspotReadMore)
		{
			if ($hotspot->params->get('link_to'))
			{
				$plugin = JPluginHelper::getPlugin('hotspotslinks', $hotspot->params->get('link_to'));

				if (is_object($plugin))
				{
					JPluginHelper::importPlugin('hotspotslinks', $hotspot->params->get('link_to'));
					$dispatcher = JDispatcher::getInstance();
					$links = $dispatcher->trigger('onCreateLink', $hotspot->params->get('link_to_id'));
					$hotspotsLink = $links[0];
				}
				else
				{
					// If we don't have an object, then let us link to the single view
					$hotspotsLink = self::linkToHotspot($hotspot);
				}
			}
			else
			{
				$hotspotsLink = self::linkToHotspot($hotspot);
			}
		}

		return $hotspotsLink;
	}

	/**
	 * Create a link to single view of a marker.
	 *
	 * @param   object  $hotspot  - the whole marker object
	 *
	 * @return The
	 */
	public static function linkToHotspot($hotspot)
	{
		$cats = hotspotsUtils::get_front_categories();

		if (isset($cats[$hotspot->catid]))
		{
			$urlcat = $hotspot->catid . ':' . JFilterOutput::stringURLSafe($cats[$hotspot->catid]['text']);
		}

		$urlid = $hotspot->hotspots_id . ':' . JFilterOutput::stringURLSafe($hotspot->name);
		$hotspotsLink = JRoute::_(HotspotsHelperRoute::getHotspotRoute($urlid, $urlcat), false);

		return $hotspotsLink;
	}

	/**
	 * Creates the rss feed
	 *
	 * @return void
	 */
	public static function createFeed()
	{
		jimport('joomla.filesystem.folder');
		require_once JPATH_COMPONENT_ADMINISTRATOR . "/libraries/rss/feedcreator.php";

		$rss = new UniversalFeedCreator;
		$folderPath = JPATH_SITE . '/media/com_hotspots/rss';
		$folderExists = JFolder::exists($folderPath);

		if (!$folderExists)
		{
			JFolder::create($folderPath);
		}

		$rss->useCached("RSS2.0", $folderPath . '/hotspotsfeed.xml');

		$rss->title = JURI::Base() . " - " . JTEXT::_('Newest Hotspots');
		$rss->description = JTEXT::_('New Hotspots at') . ' ' . JURI::Base();
		$rss->link = JURI::Base();

		$image = new FeedImage;
		$image->title = JURI::Base() . " " . "Hotspots";
		$image->url = HotspotsHelper::getSettings('rss_logopath', JURI::Base() . "media/com_hotspots/images/utils/logo.jpg");
		$image->link = JURI::Base();
		$image->description = JTEXT::_('Feed provided by') . " " . JURI::Base() . ". " . JTEXT::_('Click to visit');
		$rss->image = $image;
		$hs_show_address = HotspotsHelper::getSettings('show_address', 1);
		$hs_show_address_country = HotspotsHelper::getSettings('show_address_country', 0);
		$hs_show_author = HotspotsHelper::getSettings('show_author', 1);
		$hs_show_detailpage = HotspotsHelper::getSettings('hotspot_detailpage', 1);
		$db = JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__hotspots_marker WHERE published = 1 ORDER BY created DESC", 0, HotspotsHelper::getSettings('rss_limit', "100"));
		$rows = $db->loadObjectList();

		if ($rows != null)
		{
			foreach ($rows as $row)
			{
				$row->hotspots_id = $row->id;
				$name = htmlspecialchars("$row->name");
				$street = htmlspecialchars("$row->street");
				$plz = htmlspecialchars("$row->plz");
				$town = htmlspecialchars("$row->town");
				$country = htmlspecialchars("$row->country");

				if ($hs_show_address == "1")
				{
					if ($hs_show_address_country == "1")
					{
						$adress = "$street, $plz $town<br />$country<br /><br />";
					}
					else
					{
						$adress = "$street, $plz $town<br /><br />";
					}
				}

				if ($hs_show_detailpage == "1")
				{
					$mlink = self::createLink($row);
				}

				if ($hs_show_author == "1")
				{
					$autor = JURI::Base();

					if ($row->created_by_alias)
					{
						$autor = $row->created_by_alias;
					}
				}

				if (substr(ltrim($mlink), 0, 7) != 'http://')
				{
					$uri = JURI::getInstance();
					$base = $uri->toString(array('scheme', 'host', 'port'));
					$mlink = $base . $mlink;
				}

				$rss_item = new FeedItem;
				$rss_item->title = $name;
				$rss_item->link = $mlink;
				$rss_item->description = $adress . $row->description_small;
				$rss_item->date = JFactory::getDate($row->created)->toRFC822();
				$rss_item->source = JURI::Base();
				$rss_item->author = $autor;
				$rss->addItem($rss_item);
			}
		}

		$rss->cssStyleSheet = "http://www.w3.org/2000/08/w3c-synd/style.css";

		if (HotspotsHelper::getSettings('rss_type', 0) == 0)
		{
			$rss->saveFeed("RSS2.0", $folderPath . '/hotspotsfeed.xml');
		}
		elseif (HotspotsHelper::getSettings('rss_type', 0) == 1)
		{
			$rss->saveFeed("RSS1.0", $folderPath . '/hotspotsfeed.xml');
		}
		else
		{
			$rss->saveFeed("ATOM", $folderPath . '/hotspotsfeed.xml');
		}
	}

	/**
	 * Gets the item id for the provided component & view
	 *
	 * @param   string  $component  - the component string
	 * @param   string  $view       - the view name
	 *
	 * @internal  param $ <string> $component
	 * @return mixed <int>
	 */
	public static function getItemid($component = '', $view = '')
	{
		$appl = JFactory::getApplication();
		$menu = $appl->getMenu();
		$itemId = '';
		$items = $menu->getItems('component', $component);

		if ($view)
		{
			foreach ($items as $value)
			{
				if (strstr($value->link, 'view=' . $view))
				{
					$itemId = $value->id;
					break;
				}
			}
		}
		else
		{
			$itemId = isset($items[0]) ? $items[0]->id : '';
		}

		return $itemId;
	}

	/**
	 * TODO: fix this function - change the german language and output proper error messages
	 *
	 * @param   string  $picture  - the picture name
	 *
	 * @return string
	 */
	public static function createThumb($picture)
	{
		jimport('joomla.filesystem.folder');

		// Based on thumbnail script by forsterm @ tutorials.de
		$upload_path = (JPATH_ROOT . '/media/com_hotspots/images/hotspots/');
		$img_src = $upload_path . $picture;

		$thumb_dir = (JPATH_ROOT . '/media/com_hotspots/images/thumbs');
		$cache = true;

		if (!isset($img_src))
		{
			return "Es wurde kein Bildpfad �bergeben aus dem ein Thumbnail ezeugt werden k�nnte";
		}

		if (!$image_infos = @getimagesize($img_src))
		{
			return JText::_('COM_HOTSPOTS_PIC_NOT_FOUND');
		}

		$width = $image_infos[0];
		$height = $image_infos[1];
		$type = $image_infos[2];
		$mime = $image_infos['mime'];

		$w = HotspotsHelper::getSettings('picturethumb_width', "80");
		$h = HotspotsHelper::getSettings('picturethumb_height', "80");
		$p = true;

		// Should we make the thumb proportional?
		if (strstr($w, 'p'))
		{
			$p = (int) str_replace('p', '', $w);
			$w = null;
			$h = null;
		}

		if (isset($p) && !isset($w) && !isset($h))
		{
			// Überprüfen ob die Bildgr��e proportional berechnet werden soll
			if ($width < $height)
			{
				// Überpr�fen ob das Bild Hoch- oder Querformat ist
				$new_width = ceil(($p / $height) * $width);

				// Zuweisen der neuen H�he
				$new_height = intval($p);
			}
			else
			{
				$new_height = ceil(($p / $width) * $height);

				// Zuweisen der neuen Breite
				$new_width = intval($p);
			}
		}
		else if (isset($w) && !isset($h) && !isset($p))
		{
			// Überpr�fen ob die Breite oder die H�he berechnent werden soll
			// Zuweisen der neuen Breite
			$new_width = intval($w);

			// Berechnen der neuen H�he
			$new_height = ceil($height * $new_width / $width);
		}
		else if (isset($h) && !isset($w) && !isset($p))
		{
			// Überprüfen ob die Breite oder die H�he berechnent werden soll
			// Zuweisen der neuen H�he
			$new_height = intval($h);

			// Berechnen der neuen Breite
			$new_width = ceil($width * $new_height / $height);
		}
		else if (isset($h) && isset($w) && isset($p))
		{
			// Zuweisen der neuen H�he
			$new_height = intval($h);

			// Zuweisen der neuen Breite
			$new_width = intval($w);
		}
		else
		{
			return 'Es muss entweder die neu H�he oder die neu Breite angegeben werden.';
		}

		if ($cache === true && !JFolder::exists($thumb_dir))
		{
			// Legt das Cache Verzeichnis an. Sollte dies nicht m�glich sein, so wird ein Fehler ausgegeben
			JFolder::create($thumb_dir);
		}

		switch ($type)
		{
			case 1:
				if (imagetypes() & IMG_GIF)
				{
					// Überpr�fen ob das Bildformat untest�tzt wird
					if (!JFile::exists($thumb_dir . '/thumb_' . $picture))
					{
						// Wenn das Thumbnail nicht existiert wird es erstellt
						// Bild aus dem Orginalbild erstellen
						$orginal = imagecreatefromgif($img_src);

						// Das Thumbnailbild erstellen
						$thumb = imagecreatetruecolor($new_width, $new_height);
						imagecopyresampled($thumb, $orginal, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

						if ($cache === true)
						{
							// Pr�ft ob das Bild gespeichert werden soll
							imagegif($thumb, $thumb_dir . '/thumb_' . $picture);
						}
					}
					else
					{
						// Bild ausgeben
						JFile::read($thumb_dir . '/thumb_' . $picture);
					}
				}
				else
				{
					return JText::_('COM_HOTSPOTS_GIF_NOT_SUPPORTED');
				}
				break;
			case 2:
				if (imagetypes() & IMG_JPG)
				{
					// Überprüfen ob das Bildformat untest�tzt wird
					if (!JFile::exists($thumb_dir . '/thumb_' . $picture))
					{
						// Wenn das Thumbnail nicht existiert wird es erstellt
						// Bild aus dem Orginabild erstellen
						$orginal = imagecreatefromjpeg($img_src);

						// Das Thumbnailbild erstellen
						$thumb = imagecreatetruecolor($new_width, $new_height);
						imagecopyresampled($thumb, $orginal, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

						if ($cache === true)
						{
							// Prüft ob das Bild gespeichert werden soll
							// Bild speichern
							imagejpeg($thumb, $thumb_dir . '/thumb_' . $picture);
						}
					}
					else
					{
						// Bild ausgeben
						JFile::read($thumb_dir . '/thumb_' . $picture);
					}
				}
				else
				{
					// Fehlermeldung ausgeben, wenn das Bildformat nicht unterst�tzt wird
					return JText::_('COM_HOTSPOTS_JPG_NOT_SUPPORTED');
				}
				break;
			case 3:
				if (imagetypes() & IMG_PNG)
				{
					// Überpr�fen ob das Bildformat untest�tzt wird
					if (!JFile::exists($thumb_dir . '/thumb_' . $picture))
					{
						// Wenn das Thumbnail nicht existiert wird es erstellt
						// Bild aus dem Orginalbild erstellen
						$orginal = imageCreateFromPNG($img_src);

						// Das Thumbnailbild erstellen
						$thumb = imagecreatetruecolor($new_width, $new_height);
						imagecopyresampled($thumb, $orginal, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

						if ($cache === true)
						{
							// Pr�ft ob das Bild gespeichert werden soll
							imagepng($thumb, $thumb_dir . '/thumb_' . $picture);
						}
					}
					else
					{
						file_get_contents($thumb_dir . '/thumb_' . $picture);
					}
				}
				else
				{
					// Fehlermeldung ausgeben, wenn das Bildformat nicht unterst�tzt wird
					return JText::_('COM_HOTSPOTS_PNG_NOT_SUPPORTED');
				}
				break;
			default:
				// Fehlermeldung ausgeben, wenn das Bildformat nicht unterst�tzt wird
				return JText::_('COM_HOTSPOTS_PIC_NOT_SUPPORTED');
		}

		return false;
	}

	/**
	 * TODO: fix this function - return proper error messages
	 *
	 * @param   array  $picture  - the picture array
	 *
	 * @return bool|string
	 */
	public static function uploadPicture($picture)
	{
		if (is_array($picture) && isset($picture['tmp_name']))
		{
			$errormsg = '';
			$imageinfo = getimagesize($picture['tmp_name']);

			if ($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg' && $imageinfo['mime'] != 'image/png')
			{
				$errormsg .= "Sorry this is no supported image - gif, jpg, png";

				return false;
			}
			else
			{
				$blacklist = array(".php", ".phtml", ".php3", ".php4", ".php5", ".html", ".txt", ".dhtml", ".htm", ".doc", ".asp", ".net", ".js", ".rtf");

				foreach ($blacklist as $item)
				{
					if (preg_match("/$item\$/i", $picture['name']))
					{
						$errormsg .= "We do not allow uploading PHP files\n";

						return false;
					}
				}

				$upload_path = (JPATH_ROOT . '/media/com_hotspots/images/hotspots/');
				$upload_image = $upload_path . basename($picture['name']);

				if (JFile::upload($picture['tmp_name'], $upload_image))
				{
					echo "<script> alert('File " . basename($picture['name']) . "sucessfully uploaded'); window.histroy.go(-1); </script>\n";
					$errormsg .= "sucessfull upload at $upload_path";
				}
				else
				{
					echo "<script> alert('Error uploading " . basename($picture['name']) . "!!!'); window.histroy.go(-1); </script>\n";
					$errormsg .= "failed to upload at $upload_path";
				}

				return basename($picture['name']);
			}
		}

		return false;
	}

	/**
	 * Creates a correct google maps URL depending on the turned on options
	 *
	 * @return string
	 */
	public static function getGmapsUrl()
	{
		$url = 'https://maps.googleapis.com/maps/api/js?sensor=true';
		$libraries = array();
		$key = HotspotsHelper::getSettings('api_key', '');

		if ($key)
		{
			$url .= '&key=' . $key;
		}

		if (HotspotsHelper::getSettings('weather_api') || HotspotsHelper::getSettings('clouds_layer'))
		{
			$libraries[] = 'weather';
		}

		if (HotspotsHelper::getSettings('panoramio_layer', 0))
		{
			$libraries[] = 'panoramio';
		}

		if (count($libraries))
		{
			$url .= '&libraries=' . implode(',', $libraries);
		}

		return htmlspecialchars($url);
	}
}
