<?php
/**
 * Hotspots - Frontend
 * @package Joomla!
 * @Copyright (C) 2010 - Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 stable
 * */
defined('_JEXEC') or die('Restricted access');
?>
<div style="padding: 10px;">

	<div class="componentheading">
		<?php echo JText::_('COM_HOTSPOTS_EMAIL_SENT'); ?>
	</div>

	<p>
		<?php echo JText::_('COM_HOTSPOTS_MAIL_SENT_SUCCESS'); ?>
	</p>
</div>
