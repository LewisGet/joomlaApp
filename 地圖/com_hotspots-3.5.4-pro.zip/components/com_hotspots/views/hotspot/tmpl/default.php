<?php
/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.framework', true);
JHTML::_('behavior.tooltip');
JHTML::_('stylesheet', 'media/com_hotspots/css/hotspots.css');
$this->setMootoolsLocale();

$doc = JFactory::getDocument();
$doc->addScript(hotspotsUtils::getGmapsUrl());

JHTML::_('script', 'media/com_hotspots/js/fixes.js');
JHTML::_('script', 'media/com_hotspots/js/libraries/infobubble/infobubble.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Class.SubObjectMapping.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Extras.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Marker.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.InfoBubble.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Geocoder.js');
JHTML::_('script', 'media/com_hotspots/js/helpers/helper.js', '');

JHTML::_('script', 'media/com_hotspots/js/core.js');
JHTML::_('script', 'media/com_hotspots/js/sandbox.js');

JHTML::_('script', 'media/com_hotspots/js/modules/map.js', '');
JHTML::_('script', 'media/com_hotspots/js/modules/hotspot/hotspot.js');
JHTML::_('script', 'media/com_hotspots/js/modules/menu.js');

JHTML::_('script', 'media/com_hotspots/js/helpers/slide.js');
JHTML::_('script', 'media/com_hotspots/js/helpers/tab.js');


$doc = JFactory::getDocument();
$hotspot = array(
	'id' => $this->hotspot->id,
	'latitude' => $this->hotspot->gmlat,
	'longitude' => $this->hotspot->gmlng,
	'title' => $this->hotspot->name,
	'description' => $this->loadTemplate('description'),
	'icon' => $this->category->cat_icon,
	'shadow' => $this->category->cat_shadowicon
);
hotspotsUtils::getJsLocalization();
$domready = "window.addEvent('domready', function(){ \n";
$domready .= 'var hotspots = new compojoom.hotspots.core();';
$domready .= hotspotsUtils::getJSVariables() . "\n";
$domready .= 'var hotspot = ' . json_encode($hotspot) . ';' . "\n";
$domready .="
hotspots.addSandbox('map_canvas', hotspots.DefaultOptions);
hotspots.addModule('map',hotspots.DefaultOptions);
hotspots.addModule('hotspot', hotspot, hotspots.DefaultOptions);
hotspots.addModule('menu',hotspots.DefaultOptions);
hotspots.startAll();
var tabs = new compojoom.hotspots.tab('tab-details',{
			tabSelector: '.tab-details-tab',
			contentSelector: '.tab-details-tab-content'
		});;
";
$domready .= "});";

$doc->addScriptDeclaration($domready);
?>
<div id="hotspots" class="hotspots">
	<h2 class="componentheading"><?php echo $this->hotspot->name; ?></h2>


	<div id="tab-details">


		<ul class="tab-details-tabs"><li class="tab-details-tab" data-id="map"><span><?php echo JText::_('COM_HOTSPOTS_MAP_SINGLE_VIEW_TAB'); ?></span></li><?php if ($this->hotspot->picture) : ?><li class="tab-details-tab" data-id="photo"><span><?php echo JText::_('COM_HOTSPOTS_PHOTO'); ?></span></li><?php endif; ?></ul>

		<div class="clear-both"></div>
		<div id="hotspots-navigation" style="display:none" ></div>
		<div class="tab-details-tab-content" data-id="map">
			<?php echo $this->loadTemplate('one_line_address'); ?>
			<div id="map_cont" class="single-view" style="width: 100%; height: 400px;position: relative;">
				<?php echo $this->loadTemplate('menu'); ?>
				<div id="map_canvas" class="map_canvas" style="height: <?php echo HotspotsHelper::getSettings('map_height', 600); ?>px;"></div>
			</div>
		</div>
		<?php if ($this->hotspot->picture) : ?>
			<div class="tab-details-tab-content" data-id="photo">
				<div class="hotspots-image">
					<?php
					echo "<img src=\"" . $this->hotspot->picture . "\" title=\"" . $this->hotspot->name . "\" alt=\"" . $this->hotspot->name . "\" />";
					?>
				</div>
				<div class="clear-both"></div>
		</div>
	<?php endif; ?>


	<div class="hotspots-description">
        <?php echo $this->hotspot->description_small; ?>
		<?php echo $this->hotspot->description; ?>
	</div>

	<div class="hotspot-creation-info">
		<?php if ($this->settings->get('show_author')) : ?>
			<?php echo JTEXT::_('COM_HOTSPOTS_POSTED_BY'); ?>
				<?php if ($this->profile) : ?>
					<a href="<?php echo $this->profile; ?>">
				<?php endif; ?>

			<?php
				if($this->hotspot->created_by) {
					$user = JFactory::getUser($this->hotspot->created_by);
					$userName = $user->name;
				} else {
					$userName = $this->hotspot->created_by_alias;
				}

				echo $userName;
			?>

				<?php if ($this->profile) : ?>
					</a>
				<?php endif; ?>
		<?php endif; ?>

		<?php if ($this->settings->get('show_date')) : ?>
			<?php echo JText::_('COM_HOTSPOTS_ON'); ?>
			<?php echo $this->hotspot->created; ?>
		<?php endif; ?>
	</div>

	<div class="clear-both"></div>

	<?php if ($this->hotid != ""): ?>
		<div class="hotspots-backlink">
			<a href="<?php echo $this->backlink; ?>" title="<?php echo $this->hotspot->name; ?>">
				<?php echo JTEXT::_('COM_HOTSPOTS_BACK_TO_HOTSPOTS'); ?>
			</a>
		</div>

		<div class="clear-both"></div>
	<?php endif; ?>

	<?php if (HotspotsHelper::getSettings('josc_support', '0') == 1) : ?>
        <?php
            $file=JPATH_BASE .'/administrator/components/com_comment/plugins/com_hotspots/hotspots.php';
            if(file_exists($file)) :
        ?>
		<div class="hotspots-comments">
			<?php
			JLoader::discover('ccommentHelper', JPATH_ROOT . '/components/com_comment/helpers');
			echo ccommentHelperUtils::commentInit('com_hotspots', $this->hotspot, $this->hotspot->params);
			?>
		</div>
        <?php else : ?>
            <div class="alert alert-error">
                <?php echo JText::_('COM_HOTSPOTS_CCOMMENT_ENABLED_BUT_NO_CCOMMENT_INSTALLED'); ?>
            </div>
        <?php endif; ?>
	<?php endif; ?>

	<?php require_once(JPATH_COMPONENT . '/views/hotspots/tmpl/default_footer.php'); ?>

</div>
</div>