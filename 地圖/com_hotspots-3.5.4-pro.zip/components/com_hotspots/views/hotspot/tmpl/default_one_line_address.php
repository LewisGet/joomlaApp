<?php
/**
 * @author     Daniel Dimitrov
 * @date: 19.04.2013
 *
 * @copyright  Copyright (C) 2008 - 2012 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');
?>
<?php if (HotspotsHelper::getSettings('show_address', 1)) : ?>
	<div class="one-line-address">
		<?php if (HotspotsHelper::getSettings('user_interface', 0)) : ?>
			<?php echo $this->hotspot->street ?><?php echo ($this->hotspot->town) ? ',' : ''; ?>
			<?php echo $this->hotspot->town ?><?php echo ($this->hotspot->plz) ? ',' : ''; ?>
			<?php echo $this->hotspot->plz ?><?php echo ($this->hotspot->country && $this->settings->get('show_country')) ? ',' : ''; ?>


			<?php if ($this->settings->get('show_country')) : ?>
				<?php echo $this->hotspot->country; ?>
			<?php endif; ?>

		<?php else: ?>
			<?php echo $this->hotspot->street ?><?php echo ($this->hotspot->plz) ? ',' : ''; ?>
			<?php echo $this->hotspot->plz ?>
			<?php echo $this->hotspot->town ?><?php echo ($this->hotspot->country && $this->settings->get('show_country')) ? ',' : ''; ?>

			<?php if ($this->settings->get('show_country')) : ?>
				<?php echo $this->hotspot->country; ?>
			<?php endif; ?>

		<?php endif; ?>
	</div>
<?php endif; ?>