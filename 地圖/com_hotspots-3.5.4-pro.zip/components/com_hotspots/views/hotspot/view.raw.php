<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

/**
 * The view class for raw requests
 *
 * Class HotspotsViewHotspot
 *
 * @package  Hotspots
 * @since    3.4
 */
class HotspotsViewHotspot extends HotspotsView
{
	/**
	 * The display funciton
	 *
	 * @param   null $tpl  - the template
	 *
	 * @return mixed|void
	 */
	public function display($tpl = null)
	{
		$model = $this->getModel();
		$this->profile = '';
		$this->hotspot = hotspotsUtils::prepareHotspot($model->getHotspot());

		if (HotspotsHelper::getSettings('profile_link', ''))
		{
			$this->profile = HotspotsHelperProfiles::getProfileLink($this->hotspot->created_by, HotspotsHelper::getSettings('profile_link', ''));
		}

		$this->settings = $this->prepareSettings();

		$this->setLayout('single');
		parent::display('raw');
	}


	/**
	 * Prepare some settings
	 *
	 * @return JObject
	 */
	private function prepareSettings()
	{
		$settings = new JObject;
		$properties = array(
			'show_address' => HotspotsHelper::getSettings('show_address', 1),
			'show_country' => HotspotsHelper::getSettings('show_address_country', 0),
			'show_author' => HotspotsHelper::getSettings('show_author', 1),
			'show_date' => HotspotsHelper::getSettings('show_date', 1),
			'show_detailpage' => HotspotsHelper::getSettings('hotspot_detailpage', 1)
		);

		$settings->setProperties($properties);

		return $settings;
	}
}
