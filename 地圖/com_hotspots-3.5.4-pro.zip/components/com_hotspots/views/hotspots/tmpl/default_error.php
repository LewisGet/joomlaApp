<?php
/**
 * @author     Daniel Dimitrov
 * @date: 19.04.2013
 *
 * @copyright  Copyright (C) 2008 - 2012 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access'); ?>

<div class="hotspots">
	<?php if (!count($this->cats)) : ?>
		<?php echo JText::_('COM_HOTSPOTS_NO_CATS_EXPLAINED'); ?>
	<?php endif; ?>
</div>