<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       01.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die ('Restricted access');

$html = array();

foreach ($this->list['hotspots'] as $catid => $hotspots)
{
	$catid = (int) $catid;

	foreach ($hotspots as $key => $value)
	{
		if ($key !== 'categoryCount' && $key !== 'viewCount')
		{
			$this->hotspot = $value;
			$key = (int) $key;

			$html['hotspots'][$catid][$key] = array(
				'id' => (int) $value->hotspots_id,
				'latitude' => (float) $value->gmlat,
				'longitude' => (float) $value->gmlng,
				'title' => $value->name,
				'description' => preg_replace("@[\\r|\\n|\\t]+@", '', $this->hotspot->description_small),
				'street' => $this->hotspot->street,
				'city' => $this->hotspot->town,
				'zip' => $this->hotspot->plz,
				'country' => $this->hotspot->country,
				'date' => $this->hotspot->created,
				'readmore' => $this->hotspot->link
			);

			if (HotspotsHelper::getSettings('show_author', 1))
			{
				$html['hotspots'][$catid][$key]['created_by'] = $this->hotspot->created_by_alias ? $this->hotspot->created_by_alias : $this->hotspot->user_name;
			}

			if (HotspotsHelper::getSettings('show_date', 1))
			{
				$html['hotspots'][$catid][$key]['date'] = hotspotsUtils::getLocalDate($this->hotspot->created);
			}

			if ($value->picture_thumb)
			{
				$html['hotspots'][$catid][$key]['thumb'] = $value->picture_thumb;
			}

			if ($value->params->get('markerimage'))
			{
				$html['hotspots'][$catid][$key]['icon'] = HOTSPOTS_PICTURE_CATEGORIES_PATH . $value->params->get('markerimage');
			}
		}
		else
		{
			if ($key == 'categoryCount')
			{
				$html['hotspots'][$catid]['categoryCount'] = (int) $value;
			}

			if ($key == 'viewCount')
			{
				$html['hotspots'][$catid]['viewCount'] = (int) $value;
			}
		}
	}
}

$html['offset'] = JRequest::getInt('offset');

echo json_encode($html);

jexit();