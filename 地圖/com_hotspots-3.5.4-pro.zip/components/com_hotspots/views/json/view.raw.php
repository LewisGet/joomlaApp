<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       01.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die ('Restricted access');
require_once JPATH_COMPONENT_SITE . '/views/json.php';

/**
 * Class hotspotsViewJson
 *
 * @since  3
 */
class HotspotsViewJson extends HotspotsJson
{
	/**
	 * The display function
	 *
	 * @param   string  $tpl  - the template
	 *
	 * @return mixed|void
	 */
	public function display($tpl = null)
	{
		$model = $this->getModel();
		$list = ($model->getHotspots());

		// Prepare the hotspot - create proper links etc...
		if (!isset($list['hotspots']))
		{
			$list['hotspots'] = array();
		}

		foreach ($list['hotspots'] as $catid => $hotspot)
		{
			foreach ($hotspot as $key => $value)
			{
				if ($key !== 'viewCount' && $key !== 'categoryCount')
				{
					$list['hotspots'][$catid][$key] = hotspotsUtils::prepareHotspot($value);
				}
			}
		}

		$this->list = $list;
		$this->settings = $this->prepareSettings();

		parent::display($tpl);
	}

	/**
	 * Creates an array with options for easier access
	 *
	 * @return JObject
	 */
	private function prepareSettings()
	{
		$settings = new JObject;
		$properties = array(
			'show_address' => HotspotsHelper::getSettings('show_address', 1),
			'show_country' => HotspotsHelper::getSettings('show_address_country', 0),
			'show_author' => HotspotsHelper::getSettings('show_author', 1),
			'show_date' => HotspotsHelper::getSettings('show_date', 1),
			'show_detailpage' => HotspotsHelper::getSettings('hotspot_detailpage', 1)
		);

		$settings->setProperties($properties);

		return $settings;
	}

	/**
	 * The search view function
	 *
	 * @param   array  $list  - the list with hotspots
	 *
	 * @return void
	 */
	public function search(array $list)
	{
		$cat = JRequest::getVar('cat', false);
		$level = JRequest::getVar('level', false);
		$position = JRequest::getVar('position', false);

		$settings = $this->prepareSettings();

		foreach ($list['hotspots'] as $key => $hotspot)
		{
			$list['hotspots'][$key] = hotspotsUtils::prepareHotspot($hotspot);
		}

		$this->list = $list;
		$this->settings = $settings;
		$this->categoryid = $cat;
		$this->hsposition = $position;
		$this->hslevel = $level;

		parent::display(null);
	}
}
