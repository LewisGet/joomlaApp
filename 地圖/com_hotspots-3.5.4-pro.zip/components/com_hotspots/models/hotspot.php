<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       01.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.modeladmin');

/**
 * Class hotspotsModelHotspot
 *
 * @since  3
 */
class HotspotsModelHotspot extends JModelAdmin
{
	private $hotspot = null;

	private $id = null;

	private $hotspots = null;

	/**
	 * Constructor
	 *
	 * @param   array  $config  - the config
	 */
	public function __construct($config = array())
	{
		$config['event_before_save'] = 'onBeforeHotspotSave';
		$config['event_after_save'] = 'onAfterHotspotSave';

		parent::__construct($config);

		$input = JFactory::getApplication()->input;
		$id = $input->getInt('id', 0);
		$this->_catid = $input->getInt('cat', 1);

		if ($id != 0)
		{
			$this->id = $id;
		}
	}

	/**
	 * Gets a single hotspot
	 *
	 * @return mixed|null
	 */
	public function getHotspot()
	{
		if (!$this->hotspot)
		{
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			$query->select(' m.id as hotspots_id, m.*, u.name AS user_name')
				->from($db->qn('#__hotspots_marker') . ' AS m')
				->leftJoin('#__users AS u ON u.id = m.created_by')
				->where('m.id = ' . $db->Quote($this->id));
			$db->setQuery($query, 0, 1);
			$this->hotspot = $db->loadObject();

			if (!$this->hotspot->published)
			{
				JError::raiseError(404, "Invalid ID provided");
			}

			if ($this->hotspot)
			{
				$query = 'SELECT * FROM ' . $db->qn('#__hotspots_categorie')
					. ' WHERE id = ' . $db->Quote($this->hotspot->catid);
				$db->setQuery($query, 0, 1);
				$this->hotspot->category = $db->loadObject();
			}
		}

		return $this->hotspot;
	}

	/**
	 * Gets the user hotspots
	 *
	 * @param   int  $userId  - the user id
	 *
	 * @return mixed
	 */
	public function getUserHotspots($userId)
	{
		$db = JFActory::getDBO();
		$query = 'SELECT m.*, c.cat_name FROM ' . $db->qn('#__hotspots_marker') . ' AS m'
			. ' LEFT JOIN ' . $db->qn('#__hotspots_categorie') . ' AS c'
			. ' ON m.catid = c.id'
			. ' WHERE m.created_by = ' . $db->Quote($userId)
			. ' AND m.published = 1'
			. ' ORDER BY m.' . HotspotsHelper::getSettings('hotspots_order', 'name ASC');
		$db->setQuery($query);

		return $db->loadObjectList();
	}

	/**
	 * Searches the hotspots matching a keyword
	 *
	 * @param   string  $sentence  - the word we are looking for
	 * @param   int     $offset    - the offset
	 * @param   int     $limit     - the limit
	 *
	 * @return array
	 */
	public function search($sentence, $offset = null, $limit = null)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$data = array();

		$query->select('SQL_CALC_FOUND_ROWS m.id AS hotspots_id, m.*,c.*, m.params as params, c.params as cat_params, u.name AS user_name')
			->from($db->quoteName('#__hotspots_marker') . 'AS m')
			->leftJoin($db->quoteName('#__hotspots_categorie') . 'AS c ON  m.catid = c.id')
			->leftJoin('#__users AS u ON u.id = m.created_by')
			->order('m.' . HotspotsHelper::getSettings('hotspots_order', 'name ASC'));

		// Restrict by coordinates
		$this->buildWhereCoordQuery($query);

		// Restrict by search term
		$this->buildWhereSearchQuery($sentence, $query);

		// Restrict by general stuff such as publish, publish_up...
		$this->buildWhereGeneralQuery($query);

		$db->setQuery($query, $offset, $limit);
		$data['hotspots'] = $db->loadObjectList();

		$db->setQuery('SELECT FOUND_ROWS()');
		$data['count'] = $db->loadResult();

		// Now count how many we have in the whole world
		$query->clear('select');
		$query->select('COUNT(*) AS count');
		$query->clear('where');
		$this->buildWhereSearchQuery($sentence, $query);
		$this->buildWhereGeneralQuery($query);

		$db->setQuery($query);

		$data['worldCount'] = $db->loadObject()->count;

		return $data;
	}

	/**
	 * populating the state
	 *
	 * @return void
	 */
	protected function populateState()
	{
		$app = JFactory::getApplication();
		$this->setState('filter.language', $app->getLanguageFilter());
	}

	/**
	 * Where part of the query
	 *
	 * @param   object  &$query  - the query object
	 *
	 * @return void
	 */
	public function buildWhereGeneralQuery(&$query)
	{
		$input = JFactory::getApplication()->input;

		$query->where(' m.published = 1');
		$query->where(' c.published = 1');

		$nullDate = $query->nullDate();
		$nowDate = $query->Quote(JFactory::getDate()->toSQL());

		$query->where('(m.publish_up = ' . $nullDate . ' OR m.publish_up <= ' . $nowDate . ')');
		$query->where('(m.publish_down = ' . $nullDate . ' OR m.publish_down >= ' . $nowDate . ')');

		if ($this->getState('filter.language'))
		{
			$query->where('m.language in (' . $query->quote($input->getString('hs-language')) . ',' . $query->quote('*') . ')');
		}
	}

	/**
	 * The where part of the query for a search
	 *
	 * @param   string  $sentence  - the word we search for
	 * @param   object  &$q        - the query
	 *
	 * @return void
	 */
	public function buildWhereSearchQuery($sentence, &$q)
	{
		$name = $q->quoteName('m.name');
		$description = $q->quoteName('m.description');
		$descriptionSmall = $q->quoteName('m.description_small');
		$plz = $q->quoteName('m.plz');
		$catName = $q->quoteName('c.cat_name');
		$street = $q->quoteName('m.street');
		$country = $q->quoteName('m.country');
		$town = $q->quoteName('m.town');
		$and = array();

		if (preg_match('/"([^"]+)"/', $sentence, $m))
		{
			/*
			 * example:
			 * 1. "test something" else
			 * will match -> "something else" AND else
			 * 2. test something else
			 * will match -> test OR something OR else
			 */
			$searchWord = $q->Quote('%' . $q->escape(trim($m[1]), true) . '%', false);

			$search[] = $name . ' LIKE ' . $searchWord;
			$search[] = $description . ' LIKE ' . $searchWord;
			$search[] = $descriptionSmall . ' LIKE ' . $searchWord;
			$search[] = $plz . ' LIKE ' . $searchWord;
			$search[] = $catName . ' LIKE ' . $searchWord;
			$search[] = $street . ' LIKE ' . $searchWord;
			$search[] = $country . ' LIKE ' . $searchWord;
			$search[] = $town . ' LIKE ' . $searchWord;

			$word = trim(str_replace('"' . $m[1] . '"', '', $sentence));

			if ($word)
			{
				$searchWord = $q->Quote('%' . $q->escape(trim($word), true) . '%', false);
				$and[] = $name . ' LIKE ' . $searchWord;
				$and[] = $description . ' LIKE ' . $searchWord;
				$and[] = $descriptionSmall . ' LIKE ' . $searchWord;
				$and[] = $plz . ' LIKE ' . $searchWord;
				$and[] = $catName . ' LIKE ' . $searchWord;
				$and[] = $street . ' LIKE ' . $searchWord;
				$and[] = $country . ' LIKE ' . $searchWord;
				$and[] = $town . ' LIKE ' . $searchWord;
			}
		}
		else
		{
			$words = explode(' ', $sentence);

			foreach ($words as $word)
			{
				$searchWord = $q->Quote('%' . $q->escape($word, true) . '%', false);
				$search[] = $name . ' LIKE ' . $searchWord;
				$search[] = $description . ' LIKE ' . $searchWord;
				$search[] = $descriptionSmall . ' LIKE ' . $searchWord;
				$search[] = $plz . ' LIKE ' . $searchWord;
				$search[] = $catName . ' LIKE ' . $searchWord;
				$search[] = $street . ' LIKE ' . $searchWord;
				$search[] = $country . ' LIKE ' . $searchWord;
				$search[] = $town . ' LIKE ' . $searchWord;
			}
		}

		$q->where('(' . implode(' OR ', $search) . ')');

		if (count($and))
		{
			$q->where('(' . implode(' OR ', $and) . ')');
		}
	}

	/**
	 * The where part of the query for the coordinates
	 *
	 * @param   object  &$query  - the db query
	 *
	 * @return mixed
	 */
	public function buildWhereCoordQuery(&$query)
	{
		$input = JFactory::getApplication()->input;
		$level = $input->get('z', 0);

		$levels = array(0, 1);
		/**
		 * at small zoomelevels we can end up having 2 datelines
		 * because of this our queries will fail. To go around that
		 * problem we will get all hohtspots in the categories
		 * a nasty trick, but it should work in most situations...
		 */
		if (!in_array($level, $levels))
		{
			$ne = $input->getString('ne', '');
			$sw = $input->getString('sw', '');
			list($nelat, $nelng) = explode(',', $ne);
			list($swlat, $swlng) = explode(',', $sw);

			/**
			 * We need to take in account the meridian in the Mercator
			 * projection of the map. In the Mercator projection the meridian of the earth
			 * is at the left and right edges. When you slide to the left the
			 * or right, the map will wrap as you move past the meridian
			 * at +/- 180 degrees. In that case, the bounds are partially split
			 * across the left and right edges of the map and the northeast
			 * corner is actually positioned at a poin that is greater than 180 degree.
			 * The gmaps API automatiacally adjusts the longitude values to fit
			 * between -180 and +180 degrees so we ned to request 2 portions of the map
			 * from our database convering the left and right sides.
			 */
			if ($nelng > $swlng)
			{
				$query->where(' (m.gmlng > ' . $swlng . ' AND m.gmlng < ' . $nelng . ')');
				$query->where(' (m.gmlat <= ' . $nelat . ' AND m.gmlat >= ' . $swlat . ')');
			}
			else
			{
				$query->where(' (m.gmlng >= ' . $swlng . ' OR m.gmlng <= ' . $nelng . ')');
				$query->where(' (m.gmlat <= ' . $nelat . ' AND m.gmlat >= ' . $swlat . ')');
			}
		}

		return $query;
	}

	/**
	 * method to get an instance of a JTable class if it can be found in
	 * the table include paths.
	 *
	 * @param   string  $type    The type (name) of the JTable class to get an instance of.
	 * @param   string  $prefix  An optional prefix for the table class name.
	 * @param   array   $config  An optional array of configuration values for the JTable object.
	 *
	 * @return  mixed    A JTable object if found or boolean false if one could not be found.
	 *
	 */
	public function getTable($type = 'Marker', $prefix = 'Table', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   array    $data      - An optional array of data for the form to interogate.
	 * @param   boolean  $loadData  - True if the form is to load its own data (default case), false if not.
	 *
	 * @return   JForm  - A JForm object on success, false on failure
	 *
	 * @since    1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_hotspots.marker', 'marker', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		// Determine correct permissions to check.
		if ($this->getState('hotspot.id'))
		{
			// Existing record. Can only edit in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.edit');
		}
		else
		{
			// New record. Can only create in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.create');
		}

		return $form;
	}

	/**
	 * Validates the data
	 *
	 * @param   JForm  $form   - the form
	 * @param   array  $data   - the data
	 * @param   null   $group  - the group
	 *
	 * @return mixed
	 */
	public function validate($form, $data, $group = null)
	{
		$user = JFactory::getUser();
		$jform = JFactory::getApplication()->input->get('jform', array(), 'ARRAY');

		// Do those checks only if we don't have userId
		if (!$user->id)
		{
			$data['created_by_alias'] = $jform['created_by_alias'];
			$data['email'] = $jform['email'];
		}
		else
		{
			$data['created_by_alias'] = $user->name;
			$data['created_by'] = $user->id;
		}

		// Test if it is a shared client
		if (!empty($_SERVER['HTTP_CLIENT_IP']))
		{
			$ip = $_SERVER['HTTP_CLIENT_IP'];

			// Is it a proxy address
		}
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else
		{
			$ip = $_SERVER['REMOTE_ADDR'];
		}

		// The value of $ip at this point would look something like: "192.0.34.166"
		$data['created_by_ip'] = ip2long($ip);

		return parent::validate($form, $data);
	}


	/**
	 * Method to save the form data. Basically the only difference with the parent
	 * method is the use of the hotspots plugins instead of content
	 *
	 * @param   array  $data  The form data.
	 *
	 * @return  boolean  True on success, False on error.
	 *
	 * @since   11.1
	 */
	public function save($data)
	{
		// Initialise variables;
		$dispatcher = JDispatcher::getInstance();
		$table = $this->getTable();
		$key = $table->getKeyName();
		$pk = (!empty($data[$key])) ? $data[$key] : (int) $this->getState($this->getName() . '.id');
		$isNew = true;

		// Include the content plugins for the on save events.
		JPluginHelper::importPlugin('hotspots');

		$file = JRequest::getVar('jform', '', 'files', 'array');
		$emptyFile = true;

		if (!empty($file))
		{
			if (!empty($file['name']['picture']))
			{
				foreach ($file as $key => $value)
				{
					$newFile[$key] = $value['picture'];
				}

				$emptyFile = false;
			}
		}

		if (!$emptyFile)
		{
			$picture = HotspotsUtils::uploadPicture($newFile);

			if ($picture)
			{
				$data['picture'] = $picture;
				hotspotsUtils::createThumb($picture);
				$data['picture_thumb'] = "thumb_" . $picture;
			}
		}



		// Allow an exception to be thrown.
		try
		{
			// Load the row if saving an existing record.
			if ($pk > 0)
			{
				$table->load($pk);
				$isNew = false;
			}

			// Bind the data.
			if (!$table->bind($data))
			{
				$this->setError($table->getError());

				return false;
			}

			// Prepare the row for saving
			$this->prepareTable($table);

			// Check the data.
			if (!$table->check())
			{
				$this->setError($table->getError());

				return false;
			}

			// Trigger the onContentBeforeSave event.
			$result = $dispatcher->trigger($this->event_before_save, array($this->option . '.' . $this->name, &$table, $isNew));

			if (in_array(false, $result, true))
			{
				$this->setError($table->getError());

				return false;
			}

			// Store the data.
			if (!$table->store())
			{
				$this->setError($table->getError());

				return false;
			}

			// Clean the cache.
			$this->cleanCache();

			// Trigger the onContentAfterSave event.
			$dispatcher->trigger($this->event_after_save, array($this->option . '.' . $this->name, &$table, $isNew));
		}
		catch (Exception $e)
		{
			$this->setError($e->getMessage());

			return false;
		}

		$pkName = $table->getKeyName();

		if (isset($table->$pkName))
		{
			$this->setState($this->getName() . '.id', $table->$pkName);
		}

		$this->setState($this->getName() . '.new', $isNew);

		return true;
	}
}
