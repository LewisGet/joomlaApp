<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       02.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

/**
 * Class HotspotsHelperLocation
 *
 * @since  3.5
 */
class HotspotsHelperProfiles
{
	/**
	 * Gets a profile link
	 *
	 * @param   int     $userId  - the user id
	 * @param   string  $type    - what kind of profileLink do we need?
	 *
	 * @return string
	 */
	public static function getProfileLink($userId, $type)
	{
		$link = '';

		if (!$userId)
		{
			return $link;
		}

		if ($type == 'CB')
		{
			$link = self::getCB($userId);
		}

		if ($type == 'jomsocial')
		{
			$link = self::getJomsocial($userId);
		}

		return $link;
	}

	/**
	 * Creates a link to the CB profile
	 *
	 * @param   int  $userId  - the user id
	 *
	 * @return string $link
	 */
	private static function getCB($userId)
	{
		$itemId = '';

		if (HotspotsUtils::getItemid('com_comprofiler'))
		{
			$itemId = '&Itemid=' . HotspotsUtils::getItemid('com_comprofiler');
		}

		$link = JRoute::_('index.php?option=com_comprofiler&task=userProfile&user=' . $userId . $itemId);

		return $link;
	}

	/**
	 * Creates a link to the Jomsocial profile
	 *
	 * @param   int  $userId  - the user id
	 *
	 * @return string $link
	 */
	private static function getJomsocial($userId)
	{
		$jspath = JPATH_ROOT . '/components/com_community';
		include_once $jspath . '/libraries/core.php';

		$link = CRoute::_('index.php?option=com_community&view=profile&userid=' . $userId);

		return $link;
	}
}
