<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       13.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

define('HOTSPOTS_PICTURE_PATH', JURI::root() . 'media/com_hotspots/images/hotspots/');
define('HOTSPOTS_THUMB_PATH', JURI::root() . 'media/com_hotspots/images/thumbs/');
define('HOTSPOTS_PICTURE_CATEGORIES_PATH', JURI::root() . 'media/com_hotspots/images/categories/');
