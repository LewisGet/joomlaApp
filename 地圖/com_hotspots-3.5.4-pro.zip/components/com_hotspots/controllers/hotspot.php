<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

require_once(JPATH_COMPONENT_ADMINISTRATOR . '/libraries/recaptcha/hotspotsRecaptcha.php');

class HotspotsControllerHotspot extends JControllerForm
{

	protected function allowEdit($data = array(), $key = 'id')
	{
		$recordId = (int) isset($data[$key]) ? $data[$key] : 0;
		$user = JFactory::getUser();
		$userId = $user->get('id');
		$asset = 'com_hotspots.marker.' . $recordId;

		// Check general edit permission first.
		if ($user->authorise('core.edit', $asset))
		{
			return true;
		}

		// Fallback on edit.own.
		// First test if the permission is available.
		if ($user->authorise('core.edit.own', $asset))
		{
			// Now test the owner is the user.
			$ownerId = (int) isset($data['created_by']) ? $data['created_by'] : 0;
			if (empty($ownerId) && $recordId)
			{
				// Need to do a lookup from the model.
				$record = $this->getModel()->getItem($recordId);

				if (empty($record))
				{
					return false;
				}

				$ownerId = $record->created_by;
			}

			// If the owner matches 'me' then do the test.
			if ($ownerId == $userId)
			{
				return true;
			}
		}

		// Since there is no asset tracking, revert to the component permissions.
		return parent::allowEdit($data, $key);
	}

	/**
	 * Method to save a record.
	 *
	 * @param   string $key     The name of the primary key of the URL variable.
	 * @param   string $urlVar  The name of the URL variable if different from the primary key (sometimes required to avoid router collisions).
	 *
	 * @return  boolean  True if successful, false otherwise.
	 *
	 * @since   11.1
	 */
	public function save($key = null, $urlVar = null)
	{
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		// Initialise variables.
		$app = JFactory::getApplication();
		$input = $app->input;
		$lang = JFactory::getLanguage();
		$model = $this->getModel();
		$table = $model->getTable();
		$user = JFactory::getUser();
		$data = JRequest::getVar('jform', array(), 'post', 'array');
		$context = "$this->option.edit.$this->context";

		$itemId = '&Itemid=' . hotspotsUtils::getItemid('com_hotspots', 'hotspots');

		// Determine the name of the primary key for the data.
		if (empty($key))
		{
			$key = $table->getKeyName();
		}

		// To avoid data collisions the urlVar may be different from the primary key.
		if (empty($urlVar))
		{
			$urlVar = $key;
		}

		$recordId = JRequest::getInt($urlVar);

		// Do the captcha check only if we don't edit a hotspot
		if (!$recordId && HotspotsHelper::getSettings('captcha', 1))
		{
			$userRecaptcha = hotspotsUtils::isUserInGroups(HotspotsHelper::getSettings('captcha_usergroup', array()));

			if ($userRecaptcha)
			{
				$recaptcha = new hotspotsRecaptcha;
				$challengeField = JRequest::getVar('recaptcha_challenge_field');
				$responseField = JRequest::getVar('recaptcha_response_field');
				$answer = $recaptcha->checkAnswer($challengeField, $responseField);

				if (!$answer->is_valid)
				{
					$app->setUserState($context . '.data', $data);
					$this->setRedirect($this->getReturnPage(), JText::_('COM_HOTSPOTS_INVALID_CAPTCHA'));

					return false;
				}
			}
		}


		if (!$this->checkEditId($context, $recordId))
		{
			// Somehow the person just went to the form and tried to save it. We don't allow that.
			$this->setError(JText::sprintf('JLIB_APPLICATION_ERROR_UNHELD_ID', $recordId));
			$this->setMessage($this->getError(), 'error');

			$this->setRedirect(
				JRoute::_(
					'index.php?option=' . $this->option . '&view=' . $this->view_list
					. $this->getRedirectToListAppend(), false
				)
			);

			return false;
		}

		// Populate the row id from the session.
		$data[$key] = $recordId;


		// Access check.
		if (!$this->allowSave($data, $key))
		{
			$this->setError(JText::_('JLIB_APPLICATION_ERROR_SAVE_NOT_PERMITTED'));
			$this->setMessage($this->getError(), 'error');


			$this->setRedirect(
				JRoute::_(
					'index.php?option=com_hotspots&view=hotspots' . $itemId
					. $this->getRedirectToListAppend(), false
				)
			);

			return false;
		}

		// Validate the posted data.
		// Sometimes the form needs some posted data, such as for plugins and modules.
		$form = $model->getForm($data, false);

		if (!$form)
		{
			$app->enqueueMessage($model->getError(), 'error');

			return false;
		}

		// If we have a logged in user, we don't have the email field -> so we need to trick the validate function
		if ($user->get('id'))
		{
			$data['email'] = $user->get('email');
		}

		// Test whether the data is valid.
		$validData = $model->validate($form, $data);

		// Check for validation errors.
		if ($validData === false)
		{
			// Get the validation messages.
			$errors = $model->getErrors();

			// Push up to three validation messages out to the user.
			for ($i = 0, $n = count($errors); $i < $n && $i < 3; $i++)
			{
				if ($errors[$i] instanceof Exception)
				{
					$app->enqueueMessage($errors[$i]->getMessage(), 'warning');
				}
				else
				{
					$app->enqueueMessage($errors[$i], 'warning');
				}
			}

			// Save the data in the session.
			$app->setUserState($context . '.data', $data);

			// Redirect back to the edit screen.
			$this->setRedirect(
				JRoute::_(
					'index.php?option=com_hotspots&view=form'
					. $this->getRedirectToItemAppend($recordId, $key), false
				)
			);

			return false;
		}

		// If the user can't edit the state of the hotspot set the published value to the autopublish value
		if (!$user->authorise('core.edit.state', 'com_hotspots'))
		{
			$validData['published'] = HotspotsHelper::getSettings('addhs_autopublish', 1) ? 1 : 0;
		}

		// Attempt to save the data.
		if (!$model->save($validData))
		{
			// Save the data in the session.
			$app->setUserState($context . '.data', $validData);

			// Redirect back to the edit screen.
			$this->setError(JText::sprintf('JLIB_APPLICATION_ERROR_SAVE_FAILED', $model->getError()));
			$this->setMessage($this->getError(), 'error');

			$this->setRedirect(
				JRoute::_(
					'index.php?option=com_hotspots&view=form'
					. $this->getRedirectToItemAppend($recordId, $key), false
				)
			);

			return false;
		}

		$this->setMessage(
			JText::_(
				($lang->hasKey($this->text_prefix . ($recordId == 0 && $app->isSite() ? '_SUBMIT' : '') . '_SAVE_SUCCESS')
					? $this->text_prefix
					: 'JLIB_APPLICATION') . ($recordId == 0 && $app->isSite() ? '_SUBMIT' : '') . '_SAVE_SUCCESS'
			)
		);

		// Redirect the user and adjust session state.
		// Clear the record id and data from the session.
		$this->releaseEditId($context, $recordId);
		$app->setUserState($context . '.data', null);

		if (HotspotsHelper::getSettings('addhs_autopublish', 1))
		{
			$cats = hotspotsUtils::get_front_categories();

			if (isset($cats[$validData['catid']]))
			{
				$urlcat = $validData['catid'] . ':' . JFilterOutput::stringURLSafe($cats[$validData['catid']]['text']);
			}

			$urlid = $model->getState('hotspot.id') . ':' . JFilterOutput::stringURLSafe($validData['name']);
			$redirect = HotspotsHelperRoute::getHotspotRoute($urlid, $urlcat);
		}
		else
		{
			$redirect = 'index.php?option=com_hotspots&view=hotspots' . $itemId;
		}

		if ($validData['published'])
		{
			// Redirect to the single view for that item.
			$this->setRedirect(JRoute::_($redirect, false), JText::_('COM_HOTSPOTS_HOTSPOT_' . ($data['id'] ? 'EDITED' : 'ADDED')));
		}
		else
		{
			// Redirect to the map for unpublished items
			$this->setRedirect(
				JRoute::_('index.php?option=com_hotspots&view=hotspots' . $itemId, false),
				JText::sprintf('COM_HOTSPOTS_N_ITEMS_UNPUBLISHED', 1)
			);
		}

		// Invoke the postSave method to allow for the child class to access the model.
		$this->postSaveHook($model, $validData);

		return true;
	}


	/**
	 *
	 * @return JURI|string
	 */
	public function getReturnPage()
	{
		$input = JFactory::getApplication()->input;
		$return = base64_encode($input->getBase64('returnPage', null));

		if (empty($return) || !JUri::isInternal(base64_decode($return)))
		{
			return JFactory::getURI();
		}
		else
		{
			return base64_decode($return);
		}
	}

}