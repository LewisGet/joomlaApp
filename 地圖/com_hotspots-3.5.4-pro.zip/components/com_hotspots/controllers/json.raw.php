<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       01.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

/**
 * Class HotspotsControllerJson
 *
 * @since  3
 */
class HotspotsControllerJson extends JControllerLegacy
{
	/**
	 * The search
	 *
	 * @return void
	 */
	public function search()
	{
		$input = JFactory::getApplication()->input;
		$searchWord = $input->getString('search', null);
		$view = $this->getView('Json', 'raw');
		$offset = $input->getInt('offset', null);
		$limit = HotspotsHelper::getSettings('marker_list_length');
		$model = $this->getModel('hotspot');

		$searchResult = $model->search($searchWord, $offset, $limit);

		$view->setLayout('search');
		$view->search($searchResult);
	}
}
