<?php

/**
 * Joomla Community Builder Plugin: plug_hotspots
 * @package Joomla!
 * @Copyright (C) 2009 Yves Hoppe - lunajoom.de
 * @Copyright (C) 2010 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 beta1
 * */
defined('_JEXEC') or die('Restricted access');

class gethotspotsTab extends cbTabHandler {

	private $hotspots = null;

	public function gethotspotsTab() {
		$this->cbTabHandler();
		$language = JFactory::getLanguage();
		$language->load('plg_plug_hotspots', JPATH_ADMINISTRATOR);
		
//		check if hotspots is installed
		if(!file_exists(JPATH_BASE . '/components/com_hotspots/includes/defines.php')) {
			return JText::_('PLG_CBHOTSPOTS_HOTSPOTS_NOT_INSTALLED');
		}
	}

	private function getHotspots() {
		if ($this->hotspots == null){
			$db = JFactory::getDBO();
            $query = $db->getQuery(true);
			$params = $this->params;

			$hslimit = $params->get('hslimit', "15");
            $query->select(array('m.id AS hotspots_id', 'm.catid','m.name',
                'm.description_small','m.params','m.picture','m.picture_thumb',
                'm.gmlat', 'm.gmlng', 'm.created', 'c.*'))
                ->from('#__hotspots_marker AS m')
                ->leftJoin('#__hotspots_categorie AS c ON m.catid = c.id')
                ->where('m.created_by = ' . $db->quote($this->user->id))
                ->where('m.published = 1')
                ->order('m.created DESC');

			$db->setQuery($query, 0, $hslimit);

			$this->hotspots = $db->loadObjectList();
		}

		return $this->hotspots;
	}

	public function getSpotsList() {
		$params = $this->params; // get parameters (plugin and related tab)
		$hsname = $params->get('hsname', "1");
		if ($hsname == 1) {
			$name = $this->user->name;
		} else {
			$name = $this->user->username;
		}

		$markrows = $this->getHotspots();
		
		$newspots = "<div id='new-spots'>";
		$newspots .= JText::_('PLG_CBHOTSPOTS_NEWEST_SPOTS_FROM') . " <strong>"  . $name . ":</strong>";
		$newspots .= "<br /><br />\n";

		for ($j = 0; $j < count($markrows); $j++) {
			$markrow = &$markrows[$j];
			$newspots .= '<span data-id="'.$markrow->hotspots_id.'">'.$markrow->name.'</span>';
		}

		$newspots .= "</div>";
		return $newspots;
	}

	function getDisplayTab($tab, $user, $ui) {
		global $my;
        jimport('joomla.application.component.model');
        JModelLegacy::addIncludePath(JPATH_SITE . '/components/com_hotspots/models');
		$this->user = $user;
		$html = '';

		$document = JFactory::getDocument();
		$document->addStylesheet(JURI::root().'components/com_comprofiler/plugin/user/plug_hotspots/hotspots.css');
		$gmapsapi = 'http://maps.google.com/maps/api/js?sensor=true';
		$document->addScript($gmapsapi);
		JHTML::_('behavior.framework', true);

        JHTML::_('script', 'media/com_hotspots/js/fixes.js');
        JHTML::_('script', 'media/com_hotspots/js/libraries/infobubble/infobubble.js');
		JHTML::_('script', 'media/com_hotspots/js/moo/Class.SubObjectMapping.js');
		JHTML::_('script', 'media/com_hotspots/js/moo/Map.js');
		JHTML::_('script', 'media/com_hotspots/js/moo/Map.Extras.js');
		JHTML::_('script', 'media/com_hotspots/js/moo/Map.Marker.js');
		JHTML::_('script', 'media/com_hotspots/js/moo/Map.InfoBubble.js');
        JHTML::_('script', 'media/com_hotspots/js/moo/Map.Geocoder.js');

        JHTML::_('script', 'media/com_hotspots/js/helpers/helper.js');
        JHTML::_('script', 'media/com_hotspots/js/core.js');
        JHTML::_('script', 'media/com_hotspots/js/sandbox.js');

        JHTML::_('script', 'media/com_hotspots/js/modules/map.js');
        JHTML::_('script', 'media/com_hotspots/js/modules/hotspot.js');
		JHTML::_('script', 'components/com_comprofiler/plugin/user/plug_hotspots/HotspotsCB.js');
		
		// Vars
		$gmapheight = $this->params->get('gmapheight', "400");

		//Output:
		$html .= '<div id="hotspots">';
		$html .= '<div id="map-holder">';
		$html .= '<div id="map_canvas" style="height: ' . $gmapheight . 'px; "></div>';
		$html .= "</div>";	
		$html .= $this->getSpotsList();
		$html .= '<div style="clear:both"></div>';
		$html .= "</div>";
		
		$markers = $this->prepareHotspots($this->getHotspots());
		if(!count($markers)) {
			return JText::_('PLG_CBHOTSPOTS_USER_HAS_NO_HOTSPOTS');
		}

		$start = "window.addEvent('domready', function() {";
        $start .= 'var hotspots = new compojoom.hotspots.core();';
        $start .= hotspotsUtils::getJSVariables();
		$start .= 'var markers = ' . json_encode($markers) . ';';
        $start .= "hotspots.addModule('hotspot',hotspots.DefaultOptions);";
        $start .= "hotspots.addModule('hotspotscb',markers,hotspots.DefaultOptions);";
        $start .= "hotspots.startAll();";
        $start .= "});";
		
		$document->addScriptDeclaration($start);
		
		
		return $html;
	}
	
	private function prepareHotspots($hotspots) {
		require_once(JPATH_BASE . '/components/com_hotspots/includes/defines.php' );
		require_once(JPATH_BASE . '/components/com_hotspots/utils.php' );
		require_once(JPATH_BASE . '/components/com_hotspots/helpers/route.php' );
		require_once(JPATH_ADMINISTRATOR . '/components/com_hotspots/helpers/hotspots.php' );
		
		$markers = array();
		foreach($hotspots as $key=> $hotspot) {
            $markers[] = hotspotsUtils::prepareHotspot($hotspot);
		}

        foreach($markers as $key => $marker) {
            if($marker->params->get('markerimage')) {
                $markers[$key]->icon =  HOTSPOTS_PICTURE_CATEGORIES_PATH . $marker->params->get('markerimage');
            } else {
                $markers[$key]->icon = HOTSPOTS_PICTURE_CATEGORIES_PATH . $marker->cat_icon;
            }
        }
		
		return $markers;
	}

}
