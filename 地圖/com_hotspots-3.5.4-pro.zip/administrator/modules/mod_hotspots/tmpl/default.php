<?php
/**
 * Mod hotspots
 * @package Joomla!
 * @Copyright (C) 2012 - Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 3.0 $
 **/

defined('_JEXEC') or die('Restricted access');


$doc = JFactory::getDocument();
$doc->addScript(hotspotsUtils::getGmapsUrl());

JHTML::_('stylesheet', 'media/com_hotspots/css/hotspots.css');
JHTML::_('stylesheet', 'media/com_hotspots/css/mod_hotspots.css');

JHTML::_('script', 'media/com_hotspots/js/fixes.js');
JHTML::_('script', 'media/com_hotspots/js/spin/spin.js');
JHTML::_('script', 'media/com_hotspots/js/libraries/infobubble/infobubble.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Class.SubObjectMapping.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Extras.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Marker.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.InfoBubble.js');
JHTML::_('script', 'media/com_hotspots/js/moo/Map.Geocoder.js');
JHTML::_('script', 'media/com_hotspots/js/helpers/helper.js');

JHTML::_('script', 'media/com_hotspots/js/core.js');
JHTML::_('script', 'media/com_hotspots/js/sandbox.js');

JHTML::_('script', 'media/com_hotspots/js/modules/hotspot.js');
JHTML::_('script', 'media/mod_hotspots/js/modules/latesthotspots.js');

$doc = JFactory::getDocument();
hotspotsUtils::getJsLocalization();
$domready = "window.addEvent('domready', function(){ \n";

$domready .= 'hotspots = new compojoom.hotspots.core();';
$domready .= 'var latesthotspots = ' . modHotspotsHelper::prepareHotspots(modHotspotsHelper::getHotspots()) . ';';
$domready .= hotspotsUtils::getJSVariables();
$domready .= "
hotspots.addSandbox('map_canvas', hotspots.DefaultOptions);
//hotspots.addModule('map',hotspots.DefaultOptions);
hotspots.addModule('latesthotspots', latesthotspots, hotspots.DefaultOptions);
//hotspots.addModule('menu',hotspots.DefaultOptions);
hotspots.startAll();";


$domready .= "});";

$doc->addScriptDeclaration($domready);
JHtml::script('JTOOLBAR_EDIT');
?>

<div class="mod_hotspots">
	<div id="map_cont" style="height: <?php echo $params->get('map_height', 300); ?>px;">

		<div id="map_canvas" class="map_canvas"
		     style="height: <?php echo $params->get('map_height', 300); ?>px;"></div>

	</div>
</div>