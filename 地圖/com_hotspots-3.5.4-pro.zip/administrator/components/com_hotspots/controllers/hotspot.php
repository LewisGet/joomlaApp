<?php

/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2010 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 beta2
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');
require_once( JPATH_COMPONENT_ADMINISTRATOR .'/helpers/hotspots.php');

class HotspotsControllerHotspot extends JControllerForm {

    public function __construct() {
        parent::__construct();

        // Register Extra tasks
        $this->registerTask('add', 'edit');
    }

    public function getModel($name = 'Hotspot', $prefix = 'HotspotsModel') {
        $model = parent::getModel($name, $prefix);
        return $model;
    }

    public function edit() {

        $document = & JFactory::getDocument();
        if (!$this->getCategories()) {
            $message = JText::_('COM_HOTSPOTS_CREATE_CATEGORIES_FIRST');
            $this->setRedirect('index.php?option=com_hotspots&view=categories', $message, 'notice');
	        return;
        }

        parent::edit();

    }

    public function cancel() {
        $link = 'index.php?option=com_hotspots&view=hotspots';
        $this->setRedirect($link);
    }

    /**
     * Gets all hotspots categories
     */
    private function getCategories() {
        $db = & JFactory::getDBO();
        $query = "SELECT * FROM #__hotspots_categorie ORDER BY " . HotspotsHelper::getSettings('category_ordering', 'id ASC');
        $db->setQuery($query);
        $rows = $db->loadObjectList();
        return $rows;
    }

}