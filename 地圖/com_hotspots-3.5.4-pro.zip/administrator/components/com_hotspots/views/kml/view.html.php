<?php

/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2009 Yves Hoppe - lunajoom.de
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.3 beta $
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');
jimport('joomla.filesystem');

class HotspotsViewKML extends HotspotsView {

	public function display($tpl = null) {
        $this->form = $this->get('Form');
		$this->item = $this->get('Item');


        $this->addToolbar();
		parent::display($tpl);
	}

    public function addToolbar() {
        JToolBarHelper::title(JText::_('COM_HOTSPOTS_EDIT_KML'), 'kml');
        JToolBarHelper::save('kml.save');
        JToolBarHelper::apply('kml.apply');
        JToolBarHelper::cancel('kml.cancel');
    }
}