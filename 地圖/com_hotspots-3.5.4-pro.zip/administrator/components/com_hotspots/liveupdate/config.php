<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       14.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die();

/**
 * Configuration class for your extension's updates. Override to your liking.
 *
 * @since  3.5
 **/
class LiveUpdateConfig extends LiveUpdateAbstractConfig
{
	var $_extensionName = 'com_hotspots';
	var $_versionStrategy = 'different';

	/**
	 * Constructor
	 */
	public function __construct()
	{
		$this->_extensionTitle = 'CComment ' . (HOTSPOTS_PRO == 1 ? 'Professional' : 'Core');
		$this->_requiresAuthorization = (HOTSPOTS_PRO == 1);
		$this->_currentVersion = HOTSPOTS_VERSION;
		$this->_currentReleaseDate = HOTSPOTS_DATE;

		if (HOTSPOTS_PRO)
		{
			$this->_updateURL = 'http://compojoom.com/index.php?option=com_ars&view=update&format=ini&id=4';
		}
		else
		{
			$this->_updateURL = 'https://compojoom.com/index.php?option=com_ars&view=update&format=ini&id=18';
		}

		// Populate downloadID as liveupdate cannot find the download id in the unknown for it scope
		$this->_downloadID = JComponentHelper::getParams('com_hotspots')->get('global.downloadid');

		parent::__construct();
	}
}
