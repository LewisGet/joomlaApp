<?php
/**
 * ControlCenter
 * @package Joomla!
 * @Copyright (C) 2012 - Yves Hoppe - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.0 beta $
 **/

defined('_JEXEC') or die;

// Module Helper for our Positions
jimport( 'joomla.application.module.helper' );

$modules_left = JModuleHelper::getModules('ccc_'. $this->config->extensionPosition . '_left');
$modules_slider = JModuleHelper::getModules('ccc_'. $this->config->extensionPosition . '_slider');
$modules_promotion = JModuleHelper::getModules('ccc_'. $this->config->extensionPosition . '_promotion');

JHTML::_('behavior.tooltip');
JHTML::_('stylesheet', 'media/com_hotspots/ccc/css/ccc.css');
JHTML::_('script', 'media/com_hotspots/ccc/js/ccc.js');
?>
<div class="row-fluid">
    <div id="ccc_left" class="span8">
        <div id="ccc_left_inner">
            <?php
                foreach ($modules_left as $module) {
                    $output = JModuleHelper::renderModule($module);
                    echo $output;
                }
            ?>
        </div>
        <div id="ccc_promotion">
            <?php
            foreach ($modules_promotion as $module) {
                $output = JModuleHelper::renderModule($module);
                echo $output;
            }
            ?>
        </div>
    </div>
    <div id="ccc_right" class="span4">
        <div id="ccc_right_inner">
            <?php
                echo JHtml::_('sliders.start', 'panel-sliders', array('useCookie'=>'1'));

                foreach ($modules_slider as $module) {
                    $output = JModuleHelper::renderModule($module);
                    $params = new JRegistry;
                    $params->loadString($module->params);
                    if ($params->get('automatic_title', '0')=='0') {
                        echo JHtml::_('sliders.panel', JText::_($module->title), 'cpanel-panel-'.$module->name);
                    }
                    elseif (method_exists('mod'.$module->name.'Helper', 'getTitle')) {
                        echo JHtml::_('sliders.panel', call_user_func_array(array('mod'.$module->name.'Helper', 'getTitle'),
                            array($params)), 'cpanel-panel-'.$module->name);
                    }
                    else {
                        echo JHtml::_('sliders.panel', JText::_('MOD_'.$module->name.'_TITLE'), 'cpanel-panel-'.$module->name);
                    }
                    echo $output;
                }

                echo JHtml::_('sliders.end');
            ?>
            <div id="ccc_right_footer">

            </div>
        </div>
    </div>
</div>
<div class="clr"></div>
<hr />
<div style="font-size: small">
    <strong>
        Hotspots <?php echo HOTSPOTS_PRO ? 'Professional' : 'Core' ?> <?php echo HOTSPOTS_VERSION; ?>
    </strong>
    <br />

	<span style="font-size: x-small">
		Copyright &copy;2008&ndash;<?php echo date('Y'); ?> Daniel Dimitrov / compojoom.com
	</span>
	<br />

	<strong>
		If you use Hotspots, please post a rating and a review at the
		<?php
			$url = 'http://extensions.joomla.org/extensions/maps-a-weather/maps-a-locations/maps/24962';
			if(HOTSPOTS_PRO) {
				$url = 'http://extensions.joomla.org/extensions/maps-a-weather/maps-a-locations/maps/9468';
			}
		?>
		<a href="<?php echo $url; ?>" target="_blank">Joomla! Extensions Directory</a>.
	</strong>
	<br />
	<span style="font-size: x-small">
		Hotspots is Free software released under the
		<a href="www.gnu.org/licenses/gpl.html">GNU General Public License,</a>
		version 2 of the license or &ndash;at your option&ndash; any later version
		published by the Free Software Foundation.
	</span>
</div>
<div>
	<div class="row-fluid">
		<strong><?php echo JText::_('COM_HOTSPOTS_LATEST_NEWS_PROMOTIONS'); ?>:</strong>
	</div>
	<div class="row-fluid">
		<div class="span3">
			<?php echo JText::_('COM_HOTSPOTS_LIKE_FB'); ?><br/>
			<iframe
				src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fcompojoom&amp;width=292&amp;height=62&amp;show_faces=false&amp;colorscheme=light&amp;stream=false&amp;border_color&amp;header=false&amp;appId=545781062132616"
				scrolling="no" frameborder="0"
				style="border:none; overflow:hidden; width:292px; height:62px;"
				allowTransparency="true"></iframe>
		</div>
		<div class="span3">
			<?php echo JText::_('COM_HOTSPOTS_FOLLOW_TWITTER'); ?><br/><br/>
			<a href="https://twitter.com/compojoom" class="twitter-follow-button" data-show-count="false">Follow
				@compojoom</a>
			<script>!function (d, s, id) {
					var js, fjs = d.getElementsByTagName(s)[0];
					if (!d.getElementById(id)) {
						js = d.createElement(s);
						js.id = id;
						js.src = "//platform.twitter.com/widgets.js";
						fjs.parentNode.insertBefore(js, fjs);
					}
				}(document, "script", "twitter-wjs");</script>
		</div>
	</div>
</div>

<div>
	<?php if (!HOTSPOTS_PRO) : ?>
		<p class="alert alert-warning"><?php echo JText::sprintf('COM_HOTSPOTS_UPGRADE_TO_PRO', 'https://compojoom.com/joomla-extensions/hotspots'); ?></p>
	<?php endif; ?>
</div>