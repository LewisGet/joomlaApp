<?php
/**
 * @package    Ccomment
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       10.06.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

/**
 * Class com_hotspotsInstallerScript
 *
 * @since  3.0
 */
class com_hotspotsInstallerScript extends CompojoomInstaller
{
	/*
	 * The release value to be displayed and checked against throughout this file.
	 */
	public $release = '3.0';

	public $minimum_joomla_release = '2.5.6';

	public $extension = 'com_hotspots';

	private $type = '';

	private $installationQueue = array(
		'free' => array(
			// Modules => { (folder) => { (module) => { (position), (published) } }* }*
			'modules' => array(
				'admin' => array(
					'mod_hotspots' => array('ccc_hotspots_left', 1),
					'mod_ccc_hotspots_icons' => array('ccc_hotspots_left', 1),
					'mod_hotspots_stats' => array('ccc_hotspots_slider', 1),
					'mod_ccc_hotspots_newsfeed' => array('ccc_hotspots_slider', 1),
					'mod_ccc_hotspots_overview' => array('ccc_hotspots_slider', 1),
					'mod_ccc_hotspots_update' => array('ccc_hotspots_slider', 1)
				),
			),
			'plugins' => array(
				'plg_hotspots_email' => 0,
				'plg_hotspotslinks_content' => 1,
				'plg_hotspotslinks_k2' => 0,
				'plg_hotspotslinks_sobipro' => 0
			)
		),
		'pro' => array(
			// Modules => { (folder) => { (module) => { (position), (published) } }* }*
			'modules' => array (
				'site' => array(
					'mod_hotspots_list' => array('left', 0)
				)
			),
			'plugins' => array(
				'plg_hotspots_aup' => 0,
				'plg_hotspots_jomsocial' => 0,
				'plg_hotspotslinks_external' => 0,
				'plg_hotspotslinks_flexicontent' => 0,
				'plg_search_hotspots' => 0,
				'plg_content_hotspots' => 0
			)
		)
	);


	/**
	 * method to uninstall the component
	 *
	 * @param   object  $parent  - the parent class
	 *
	 * @return void
	 */
	public function uninstall($parent)
	{
		$this->type = 'uninstall';
		$this->parent = $parent;
		require_once JPATH_ADMINISTRATOR . '/components/com_hotspots/version.php';

		// Let us install the modules & plugins
		$plugins = $this->uninstallPlugins($this->installationQueue['free']['plugins']);
		$modules = $this->uninstallModules($this->installationQueue['free']['modules']);

		if (HOTSPOTS_PRO)
		{
			$plugins = array_merge($plugins, $this->uninstallPlugins($this->installationQueue['pro']['plugins']));
			$modules = array_merge($modules, $this->uninstallModules($this->installationQueue['pro']['modules']));
		}

		$this->status->plugins = $plugins;
		$this->status->modules = $modules;

		$this->droppedTables = false;

		if (hotspotsInstallerDatabase::isCompleteUninstall())
		{
			hotspotsInstallerDatabase::dropTables();
			$this->droppedTables = true;
		}

		echo $this->displayInfoUninstallation();
	}

	/**
	 * method to run after an install/update/discover method
	 *
	 * @param   string  $type    - the type of installation (install, update etc)
	 * @param   object  $parent  - the parent class
	 *
	 * @return void
	 */
	public function postflight($type, $parent)
	{
		JError::$legacy = false;
		require_once $parent->getParent()->getPath('source') . '/administrator/components/com_hotspots/version.php';
		$this->loadLanguage();
		$this->update = hotspotsInstallerDatabase::checkIfUpdating();

		switch ($this->update)
		{
			case '1b':
				hotspotsInstallerFiles::dropToolbars();
				hotspotsInstallerFiles::updateFiles();
				hotspotsInstallerDatabase::updateCatTable1b();
			case '1b2':
				hotspotsInstallerFiles::updateFilesBeta2();
			case '1stable':
				hotspotsInstallerFiles::updateFiles1stable();
			case '2.0':
			case '2.0.1':
			case '2.0.2':
			case '2.0.3':
			case '2.0.4':
			case '2.0.5':
				hotspotsInstallerDatabase::updateDatabaseStructure205();
			case '3.0':
				hotspotsInstallerFiles::updateFilesTo3_0();
				hotspotsInstallerDatabase::updateDatabaseStructureTo3_0();
				hotspotsInstallerDatabase::updateMenuTo3_0();
			case 'git_1253cfa':
			case '3.0.1':
				hotspotsInstallerDatabase::updateKMLStructureTo3_0_1();
			case '3.1':
				hotspotsInstallerDatabase::updateCategoriesTiles3_1();
			case '3.1.1':
				hotspotsInstallerDatabase::updateHotspots3_1_1();
			case '3.2':
			case '3.2.1':
			case 'git_b1b3931':
			case '3.2.2':
				hotspotsInstallerDatabase::updateHotspots3_2_2();
				break;
			case 'new':
				// Do nothing for now
				break;
		}

		hotspotsInstallerDatabase::updateVersionNumber(HOTSPOTS_VERSION);


		// Let us install the modules & plugins
		$plugins = $this->installPlugins($this->installationQueue['free']['plugins']);
		$modules = $this->installModules($this->installationQueue['free']['modules']);

		if (HOTSPOTS_PRO)
		{
			$plugins = array_merge($plugins, $this->installPlugins($this->installationQueue['pro']['plugins']));
			$modules = array_merge($modules, $this->installModules($this->installationQueue['pro']['modules']));
		}

		$this->status->plugins = $plugins;
		$this->status->modules = $modules;

		// Install the cb plugin if CB is installed
		$this->status->cb = false;

		if (HOTSPOTS_PRO && JFile::exists(JPATH_ADMINISTRATOR . '/components/com_comprofiler/library/cb/cb.installer.php'))
		{
			global $_CB_framework;
			require_once JPATH_ADMINISTRATOR . '/components/com_comprofiler/plugin.foundation.php';
			require_once JPATH_ADMINISTRATOR . '/components/com_comprofiler/plugin.class.php';
			require_once JPATH_ADMINISTRATOR . '/components/com_comprofiler/comprofiler.class.php';

			require_once JPATH_ADMINISTRATOR . '/components/com_comprofiler/library/cb/cb.installer.php';

			$cbInstaller = new cbInstallerPlugin;

			if ($cbInstaller->install($parent->getParent()->getPath('source') . '/components/com_comprofiler/plugin/user/plug_hotspots/'))
			{
				$path = $parent->getParent()->getPath('source') . '/components/com_comprofiler/plugin/user/plug_hotspots/administrator/language';
				$languages = JFolder::folders($path);

				foreach ($languages as $language)
				{
					if (JFolder::exists(JPATH_ROOT . '/administrator/language/' . $language))
					{
						JFile::copy(
							$path . '/' . $language . '/' . $language . '.plg_plug_hotspots.ini',
							JPATH_ROOT . '/administrator/language/' . $language . '/' . $language . '.plg_plug_hotspots.ini'
						);
					}
				}

				$this->status->cb = true;
			}
		}

		$this->status->aup = false;

		if (HOTSPOTS_PRO && JFile::exists(JPATH_ADMINISTRATOR . '/components/com_alphauserpoints/alphauserpoints.php'))
		{
			jimport('joomla.filesystem.folder');
			jimport('joomla.filesystem.file');

			$rules = JFolder::files($parent->getParent()->getPath('source') . '/components/com_hotspots/assets/aup', '\.xml', true, true);

			foreach ($rules as $rule)
			{
				hotspotsInstallAUP::installRule($rule);
			}

			$this->status->aup = true;
		}

		echo $this->displayInfoInstallation();
	}

	/**
	 * Ads CSS to the page
	 *
	 * @return string
	 */
	public function addCss()
	{
		$css = '<style type="text/css">
					.compojoom-info {
						background-color: #D9EDF7;
					    border-color: #BCE8F1;
					    color: #3A87AD;
					    border-radius: 4px 4px 4px 4px;
					    padding: 8px 35px 8px 14px;
					    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
					    margin-bottom: 18px;
					}

				</style>
				';

		return $css;
	}

	/**
	 * Output installation info to the user
	 *
	 * @return string
	 */
	private function displayInfoInstallation()
	{
		$html[] = $this->addCSS();
		$html[] = '<div class="compojoom-info alert alert-info">'
			. JText::sprintf('COM_HOTSPOTS_INSTALLATION_SUCCESS', (HOTSPOTS_PRO ? 'Professional' : 'Core'))
			. '</div>';

		if (!HOTSPOTS_PRO)
		{
			$html[] .= '<p>' . JText::sprintf('COM_HOTSPOTS_UPGRADE_TO_PRO', 'https://compojoom.com/joomla-extensions/hotspots') . '</p>';
		}

		$html[] .= '<p>' . JText::_('COM_HOTSPOTS_LATEST_NEWS_PROMOTIONS') . ':</p>';
		$html[] .= '<table><tr><td>' . JText::_('COM_HOTSPOTS_LIKE_FB') . ': </td><td><iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2Fcompojoom&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=true&amp;font&amp;colorscheme=light&amp;action=like&amp;height=21&amp;appId=119257468194823" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:21px;" allowTransparency="true"></iframe></td></tr>
							<tr><td>' . JText::_('COM_HOTSPOTS_FOLLOW_TWITTER') . ': </td><td><a href="https://twitter.com/compojoom" class="twitter-follow-button" data-show-count="false">Follow @compojoom</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></td></tr></table>';

		$html[] = '<img src="' . JURI::root() . 'media/com_hotspots/images/utils/logo.jpg "/>';
		$html[] = '<p>' . JText::_('COM_HOTSPOTS_INSTALLATION_DOC_FORUMS_FIND');
		$html[] = ' <a href="https://compojoom.com" target="_blank">compojoom.com</a>';
		$html[] = '<br/>';
		$html[] = '<br/>';
		$html[] = '<strong>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_QUICK_INSTRUCTIONS') . ' <br/>';

		$html[] = '</strong></p>';
		$html[] = '<div>';
		$html[] = '<ol>';
		$html[] = '<li>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_CREATE_A_CATEGORY');
		$html[] = '(<a href="' . JRoute::_('index.php?option=com_hotspots&task=category.edit') . '"
			    target="_blank">' . JText::_('COM_HOTSPOTS_INSTALLATION_CLICK_HERE') . ' </a>)';
		$html[] = '</li>';
		$html[] = '<li>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_CREATE_A_HOTSPOT') . '(<a
			href="' . JRoute::_('index.php?option=com_hotspots&task=hotspot.edit') . '"
			target="_blank">' . JText::_('COM_HOTSPOTS_INSTALLATION_CLICK_HERE') . '</a>)';
		$html[] = '</li>';
		$html[] = '<li>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_CREATE_A_MENU_LINK') . '(<a
			href="' . JRoute::_('index.php?option=com_menus&view=items&menutype=mainmenu') . '"
			target="_blank">' . JText::_('COM_HOTSPOTS_INSTALLATION_CLICK_HERE') . '</a>)';
		$html[] = '</li>';
		$html[] = '</ol>';
		$html[] = '</div>';


		if ($this->status->plugins)
		{
			$html[] = $this->renderPluginInfoInstall($this->status->plugins);
		}

		if ($this->status->modules)
		{
			$html[] = $this->renderModuleInfoInstall($this->status->modules);
		}

		if ($this->status->cb)
		{
			$html[] = '<br /><span style="color:green;">Community builder detected. CB plugin installed!</span>';
		}

		if ($this->status->aup)
		{
			$html[] = '<br /><span style="color:green;">Alpha user points detected. AUP rules installed!</span>';
		}

		return implode('', $html);
	}

	/**
	 * Displays uninstall info
	 *
	 * @return string
	 */
	public function displayInfoUninstallation()
	{
		$html[] = '<div class="header">Hotspots is now removed from your system</div>';

		if ($this->droppedTables)
		{
			$html[] = '<p>The option uninstall complete mode was set to true. Database tables were removed</p>';
		}
		else
		{
			$html[] = '<p>The option uninstall complete mode was set to false. The database tables were not removed.</p>';
		}

		$html[] = $this->renderPluginInfoUninstall($this->status->plugins);
		$html[] = $this->renderModuleInfoUninstall($this->status->modules);

		return implode('', $html);
	}
}

/**
 * Class CompojoomInstaller - helper
 *
 * @since  3.0
 */
class CompojoomInstaller
{
	/**
	 * Constructor
	 */
	public function __construct()
	{
		$this->status = new stdClass;
	}

	/**
	 * Loads the necessary language files
	 *
	 * @return void
	 */
	public function loadLanguage()
	{
		$extension = $this->extension;
		$jlang = JFactory::getLanguage();
		$path = $this->parent->getParent()->getPath('source') . '/administrator';
		$jlang->load($extension, $path, 'en-GB', true);
		$jlang->load($extension, $path, $jlang->getDefault(), true);
		$jlang->load($extension, $path, null, true);
		$jlang->load($extension . '.sys', $path, 'en-GB', true);
		$jlang->load($extension . '.sys', $path, $jlang->getDefault(), true);
		$jlang->load($extension . '.sys', $path, null, true);
	}

	/**
	 * Installs all modules
	 *
	 * @param   array $modulesToInstall  - the modules that need to be installed
	 *
	 * @return array
	 */
	public function installModules($modulesToInstall)
	{
		$src = $this->parent->getParent()->getPath('source');
		$status = array();

		// Modules installation
		if (count($modulesToInstall))
		{
			foreach ($modulesToInstall as $folder => $modules)
			{
				if (count($modules))
				{
					foreach ($modules as $module => $modulePreferences)
					{
						// Install the module
						if (empty($folder))
						{
							$folder = 'site';
						}

						$path = "$src/modules/$module";

						if ($folder == 'admin')
						{
							$path = "$src/administrator/modules/$module";
						}

						if (!is_dir($path))
						{
							continue;
						}

						$db = JFactory::getDbo();

						// Was the module alrady installed?
						$query = $db->getQuery('true');
						$query->select('COUNT(*)')->from($db->qn('#__modules'))
							->where($db->qn('module') . '=' . $db->q($module));
						$db->setQuery($query);

						$count = $db->loadResult();

						$installer = new JInstaller;
						$result = $installer->install($path);
						$status[] = array('name' => $module, 'client' => $folder, 'result' => $result);

						// Modify where it's published and its published state
						if (!$count)
						{
							list($modulePosition, $modulePublished) = $modulePreferences;
							$query->clear();
							$query->update($db->qn('#__modules'))->set($db->qn('position') . '=' . $db->q($modulePosition));

							if ($modulePublished)
							{
								$query->set($db->qn('published') . '=' . $db->q(1));
							}

							$query->set($db->qn('params') . '=' . $db->q($installer->getParams()));
							$query->where($db->qn('module') . '=' . $db->q($module));
							$db->setQuery($query);
							$db->query();
						}

						// Get module id
						$query->clear();
						$query->select('id')->from($db->qn('#__modules'))
							->where($db->qn('module') . '=' . $db->q($module));
						$db->setQuery($query);

						$moduleId = $db->loadObject()->id;

						$query->clear();
						$query->select('COUNT(*) as count')->from($db->qn('#__modules_menu'))
							->where($db->qn('moduleid') . '=' . $db->q($moduleId));

						$db->setQuery($query);

						$result = $db->loadObject();

						if (!$db->loadObject()->count)
						{
							// Insert the module on all pages, otherwise we can't use it
							$query->clear();
							$query->insert(
								$db->qn('#__modules_menu')
							)->columns(
									$db->qn('moduleid') . ',' . $db->qn('menuid')
								)->values(
									$db->q($moduleId) . ' , ' . $db->q('0')
								);
							$db->setQuery($query);
							$db->query();
						}
					}
				}
			}
		}

		return $status;
	}

	public function uninstallModules($modulesToUninstall)
	{
		$status = array();
		if (count($modulesToUninstall))
		{
			$db = JFactory::getDbo();
			foreach ($modulesToUninstall as $folder => $modules)
			{
				if (count($modules))
				{

					foreach ($modules as $module => $modulePreferences)
					{
						// Find the module ID
						$query = $db->getQuery(true);
						$query->select('extension_id')->from('#__extensions')->where($db->qn('element') . '=' . $db->q($module))
							->where($db->qn('type') . '=' . $db->q('module'));
						$db->setQuery($query);

						$id = $db->loadResult();
						// Uninstall the module
						$installer = new JInstaller;
						$result = $installer->uninstall('module', $id, 1);
						$status[] = array('name' => $module, 'client' => $folder, 'result' => $result);
					}
				}
			}
		}
		return $status;
	}

	public function installPlugins($plugins)
	{
		$src = $this->parent->getParent()->getPath('source');

		$db = JFactory::getDbo();
		$status = array();

		foreach ($plugins as $plugin => $published)
		{
			$parts = explode('_', $plugin);
			$pluginType = $parts[1];
			$pluginName = $parts[2];

			$path = $src . "/plugins/$pluginType/$pluginName";

			$query = $db->getQuery(true);
			$query->select('COUNT(*)')
				->from('#__extensions')
				->where($db->qn('element') . '=' . $db->q($pluginName))
				->where($db->qn('folder') . '=' . $db->q($pluginType));

			$db->setQuery($query);
			$count = $db->loadResult();

			$installer = new JInstaller;
			$result = $installer->install($path);
			$status[] = array('name' => $plugin, 'group' => $pluginType, 'result' => $result);

			if ($published && !$count)
			{
				$query->clear();
				$query->update('#__extensions')
					->set($db->qn('enabled') . '=' . $db->q(1))
					->where($db->qn('element') . '=' . $db->q($pluginName))
					->where($db->qn('folder') . '=' . $db->q($pluginType));
				$db->setQuery($query);
				$db->query();
			}
		}

		return $status;
	}

	public function uninstallPlugins($plugins)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$status = array();

		foreach ($plugins as $plugin => $published)
		{
			$parts = explode('_', $plugin);
			$pluginType = $parts[1];
			$pluginName = $parts[2];
			$query->clear();
			$query->select('extension_id')->from($db->qn('#__extensions'))
				->where($db->qn('type') . '=' . $db->q('plugin'))
				->where($db->qn('element') . '=' . $db->q($pluginName))
				->where($db->qn('folder') . '=' . $db->q($pluginType));
			$db->setQuery($query);

			$id = $db->loadResult();

			if ($id)
			{
				$installer = new JInstaller;
				$result = $installer->uninstall('plugin', $id, 1);
				$status[] = array('name' => $plugin, 'group' => $pluginType, 'result' => $result);
			}
		}

		return $status;
	}

	/*
		  * get a variable from the manifest file (actually, from the manifest cache).
		  */
	public function getParam($name)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery('true');
		$query->select($db->qn('manifest_cache'))
			->from($db->qn('#__extensions'))
			->where($db->qn('name') . '=' . $db->q($this->extension));
		$manifest = json_decode($db->loadResult(), true);
		return $manifest[$name];
	}

	public function renderModuleInfoInstall($modules)
	{
		$rows = 0;

		$html = array();
		if (count($modules))
		{
			$html[] = '<table class="table">';
			$html[] = '<tr>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_MODULE') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_CLIENT') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_STATUS') . '</th>';
			$html[] = '</tr>';
			foreach ($modules as $module)
			{
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $module['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($module['client']) . '</td>';
				$html[] = '<td>';
				$html[] = '<span style="color:' . (($module['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($module['result']) ? JText::_(strtoupper($this->extension) . '_MODULE_INSTALLED') : JText::_(strtoupper($this->extension) . '_MODULE_NOT_INSTALLED');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = '</tr>';
			}
			$html[] = '</table>';
		}


		return implode('', $html);
	}

	public function renderModuleInfoUninstall($modules)
	{
		$rows = 0;
		$html = array();
		if (count($modules))
		{
			$html[] = '<table class="table">';
			$html[] = '<tr>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_MODULE') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_CLIENT') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_STATUS') . '</th>';
			$html[] = '</tr>';
			foreach ($modules as $module)
			{
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $module['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($module['client']) . '</td>';
				$html[] = '<td>';
				$html[] = '<span style="color:' . (($module['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($module['result']) ? JText::_(strtoupper($this->extension) . '_MODULE_UNINSTALLED') : JText::_(strtoupper($this->extension) . '_MODULE_COULD_NOT_UNINSTALL');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = '</tr>';
			}
			$html[] = '</table>';
		}

		return implode('', $html);
	}

	public function renderPluginInfoInstall($plugins)
	{
		$rows = 0;
		$html[] = '<table class="table">';
		if (count($plugins))
		{
			$html[] = '<tr>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_PLUGIN') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_GROUP') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_STATUS') . '</th>';
			$html[] = '</tr>';
			foreach ($plugins as $plugin)
			{
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $plugin['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($plugin['group']) . '</td>';
				$html[] = '<td>';
				$html[] = '<span style="color: ' . (($plugin['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($plugin['result']) ? JText::_(strtoupper($this->extension) . '_PLUGIN_INSTALLED') : JText::_(strtoupper($this->extension) . 'PLUGIN_NOT_INSTALLED');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = '</tr>';
			}
		}
		$html[] = '</table>';

		return implode('', $html);
	}

	public function renderPluginInfoUninstall($plugins)
	{
		$rows = 0;
		$html = array();
		if (count($plugins))
		{
			$html[] = '<table class="table">';
			$html[] = '<tbody>';
			$html[] = '<tr>';
			$html[] = '<th>Plugin</th>';
			$html[] = '<th>Group</th>';
			$html[] = '<th></th>';
			$html[] = '</tr>';
			foreach ($plugins as $plugin)
			{
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $plugin['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($plugin['group']) . '</td>';
				$html[] = '<td>';
				$html[] = '	<span style="color:' . (($plugin['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($plugin['result']) ? JText::_(strtoupper($this->extension) . '_PLUGIN_UNINSTALLED') : JText::_(strtoupper($this->extension) . '_PLUGIN_NOT_UNINSTALLED');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = ' </tr> ';
			}
			$html[] = '</tbody > ';
			$html[] = '</table > ';
		}

		return implode('', $html);
	}

	/**
	 * method to run before an install/update/discover method
	 *
	 * @param $type
	 * @param $parent
	 *
	 * @return void
	 */
	public function preflight($type, $parent)
	{
		$jversion = new JVersion();

		// Extract the version number from the manifest file
		$this->release = $parent->get("manifest")->version;

		// Find mimimum required joomla version from the manifest file
		$this->minimum_joomla_release = $parent->get("manifest")->attributes()->version;

		if (version_compare($jversion->getShortVersion(), $this->minimum_joomla_release, 'lt'))
		{
			Jerror::raiseWarning(null, 'Cannot install ' . $this->extension . ' in a Joomla release prior to '
				. $this->minimum_joomla_release);
			return false;
		}

		// abort if the component being installed is not newer than the currently installed version
		if ($type == 'update')
		{
			$oldRelease = $this->getParam('version');
			$rel = $oldRelease . ' to ' . $this->release;
			if (!strstr($this->release, 'git_'))
			{
				if (version_compare($this->release, $oldRelease, 'lt'))
				{
					Jerror::raiseWarning(null, 'Incorrect version sequence. Cannot upgrade ' . $rel);
					return false;
				}
			}
		}

	}

	/**
	 * method to update the component
	 *
	 * @param $parent
	 *
	 * @return void
	 */
	public function update($parent)
	{
		$this->parent = $parent;
	}

	/**
	 * method to install the component
	 *
	 * @param $parent
	 *
	 * @return void
	 */
	public function install($parent)
	{
		$this->parent = $parent;

	}

}

class hotspotsInstallerDatabase
{

	public static function updateDatabaseStructure205()
	{
		$db = JFactory::getDBO();
		try
		{
			$query = 'ALTER TABLE ' . $db->quoteName('#__hotspots_categorie') . ' ADD `cat_image` VARCHAR( 255 ) NOT NULL ';
			$db->setQuery($query);
			$db->query();
			$query = 'ALTER TABLE ' . $db->quoteName('#__hotspots_marker') .
				' CHANGE `description_small` `description_small` MEDIUMTEXT
					CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ';
			$db->setQuery($query);
			$db->query();
		}
		catch (Exception $e)
		{
			// don't kill the installation process
		}
	}

	public static function updateVersionNumber($number)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*')->from('#__hotspots_version');
		$db->setQuery($query, 0, 1);

		$version = $db->loadObject();
		$query->clear();
		if ($version)
		{
			$query->update('#__hotspots_version')->set($db->qn('version') . '=' . $db->q($number))
				->where($db->qn('id') . '=' . $db->q(1));
		}
		else
		{
			$query->insert('#__hotspots_version')->columns('id, version')->values($db->q(1) . ',' . $db->q($number));
		}

		$db->setQuery($query);
		$db->execute();
	}


	public static function updateCatTable1b()
	{
		$db = JFactory::getDBO();
		try
		{

			$updateCategory = 'ALTER TABLE ' . $db->quoteName('#__hotspots_categorie')
				. ' ADD count INT( 11 ) NOT NULL ';
			$db->setQuery($updateCategory);
			$db->Query();

			/**
			 * update count for markers
			 */
			self::countCategoryMarker();
		}
		catch (Exception $e)
		{
			// don't kill the installation process
		}
	}

	public static function countCategoryMarker()
	{
		$db = JFactory::getDBO();

		try
		{
			$query = 'SELECT id FROM ' . $db->quoteName('#__hotspots_categorie');
			$db->setQuery($query);

			$catIds = $db->loadColumn();

			foreach ($catIds as $key => $value)
			{
				$query = ' SELECT COUNT(*) FROM ' . $db->quoteName('#__hotspots_marker')
					. ' WHERE catid = ' . $db->Quote($value)
					. ' AND published = ' . $db->Quote(1);
				$db->setQuery($query);
				$count = $db->loadRow();
				$insert = ' UPDATE ' . $db->quoteName('#__hotspots_categorie') . ' AS c '
					. ' SET c.count = ' . $db->Quote($count[0])
					. ' WHERE c.id = ' . $db->Quote($value)
					. ';';
				$db->setQuery($insert);
				$db->execute();
			}
		}
		catch (Exception $e)
		{
			// don't kill the installation process
		}
	}

	/**
	 * This function checks if we are updating and if true from which version
	 * @return string
	 */
	public static function checkIfUpdating()
	{
		$update = 'new';

		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		$query->select('version')->from('#__hotspots_version');

		$db->setQuery($query);

		try
		{
			$version = $db->loadObject();
			if (is_object($update))
			{
				$update = $version->version;
			}
		}
		catch (Exception $e)
		{
			// if we are here, then let us see if we are updating from an old version
			$query = 'SELECT * FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE title = ' . $db->Quote('api_key');

			$db->setQuery($query);

			try
			{
				$update1b = $db->loadObject();

				if ($update1b)
				{
					$update = '1b';
				}

				$query = 'SELECT * FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE title = ' . $db->Quote('complete_uninstall');

				$db->setQuery($query);
				$update1b2 = $db->loadObject();

				$folder = JPATH_ROOT . '/components/com_hotspots/views/all';
				if ($update1b2 && JFolder::exists($folder))
				{
					$update = '1b2';
				}

				$query = 'SELECT count(*) as count FROM ' . $db->quoteName('#__hotspots_settings');

				$db->setQuery($query);
				$stable = $db->loadObject();

				$fileThatShouldNotExistInStable = JPATH_ROOT . '/media/com_hotspots/js/utils.js';
				// in 1.0 stable there were exactly 55 settings
				if ($stable->count == 55 && !JFile::exists($fileThatShouldNotExistInStable))
				{
					$update = '1stable';
				}

				$query = 'SELECT * FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE title = ' . $db->Quote('version');

				$db->setQuery($query);
				$dbVersion = $db->loadObject();

				if ($dbVersion)
				{
					$update = $dbVersion->value;
				}
			}
			catch (Exception $e)
			{
				$update = 'new';
			}
		}

		return $update;
	}

	public static function isCompleteUninstall()
	{
		$params = JComponentHelper::getParams('com_comment');
		$completeUninstall = $params->get('complete_uninstall', 0);
		return $completeUninstall;
	}

	public static function updateDatabaseStructureTo3_0()
	{
		$db = JFactory::getDbo();
		try
		{
			$db->setQuery(
				"ALTER TABLE `#__hotspots_marker`
				ADD `asset_id` int(11) NOT NULL COMMENT 'FK to #__assets',
				ADD `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				ADD `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				ADD `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				ADD `modified_by` int(11) NOT NULL,
				ADD `params` text NOT NULL,
				ADD `language` char(7) NOT NULL,
				ADD `access` int(10) unsigned NOT NULL DEFAULT '0',
				ADD `import_table` varchar(255) NOT NULL COMMENT 'If we import data from 3rd party components we store the table_id here',
				ADD `import_id` int(11) NOT NULL COMMENT 'Original id of the stored object',
				CHANGE `autoruserid` `created_by` int(11) NOT NULL,
				CHANGE `autor` `created_by_alias` varchar(255) NOT NULL,
				CHANGE `autorip` `created_by_ip` int(11) unsigned NOT NULL,
				CHANGE `postdate` `created` datetime NOT NULL,
				ADD KEY `gmlat` (`gmlat`),
	            ADD KEY `gmlng` (`gmlng`),
	            ADD KEY `catid` (`catid`);");

			$db->query();

			$db->setQuery(
				"ALTER TABLE `#__hotspots_categorie`
					ADD `import_table` varchar(255) NOT NULL COMMENT 'If we import data from 3rd party components we store the table_id here',
					ADD `import_id` int(11) NOT NULL COMMENT 'Original id of the stored object';
				");
			$db->query();

			$db->setQuery(
				"CREATE TABLE IF NOT EXISTS `#__hotspots_kmls` (
				  `hotspots_kml_id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `catid` int(11) NOT NULL COMMENT 'FK to #__hotspots_categorie',
				  `original_filename` varchar(1024) NOT NULL,
				  `mangled_filename` varchar(1024) NOT NULL,
				  `mime_type` varchar(255) NOT NULL DEFAULT 'application/octet-stream',
				  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				  `created_by` bigint(20) NOT NULL DEFAULT '0',
				  `status` tinyint(4) NOT NULL DEFAULT '1',
				  PRIMARY KEY (`hotspots_kml_id`)
				) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;");
			$db->query();

		}
		catch (Exception $e)
		{
			// could not update, but don't crash the instlalation process
		}

	}

	public static function updateKMLStructureTo3_0_1()
	{
		$db = JFactory::getDbo();
		try
		{
			$db->setQuery(
				"ALTER TABLE `#__hotspots_kmls`
				ADD `title` varchar(255) NOT NULL ,
				ADD `description` text NOT NULL,
				CHANGE `created_on` `created` datetime NOT NULL,
				CHANGE `status` `state` tinyint(4) NOT NULL DEFAULT '1';");
			$db->query();
		}
		catch (Exception $e)
		{
			// don't kill the installation process please
		}
	}

	public static function updateCategoriesTiles3_1()
	{
		$db = JFactory::getDbo();
		try
		{
			$db->setQuery(
				"ALTER TABLE `#__hotspots_categorie`
				ADD `params` TEXT NOT NULL;");
			$db->query();
		}
		catch (Exception $e)
		{
			// don't kill the installation process please
		}
	}

	public static function updateMenuTo3_0()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*')->from('#__menu')
			->where('link = "index.php?option=com_hotspots&view=hotspots" AND client_id = 0');

		$db->setQuery($query, 0, 1);

		$menu = $db->loadObject();

		if ($menu)
		{
			$params = json_decode($menu->params);

			if (isset($params->hs_startcat) && is_string($params->hs_startcat))
			{
				$params->hs_startcat = array($params->hs_startcat);
				$query->update('#__menu')->set('params = ' . $db->quote(json_encode($params)))->where('id = ' . $db->quote($menu->id));
				$db->setQuery($query);
				$db->query();
			}
		}
	}

	public static function updateHotspots3_1_1()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__hotspots_marker')->set($db->qn('access') . '=' . $db->q(1))
			->where($db->qn('access') . '=' . $db->q(0));
		$db->setQuery($query);
		$db->query();
	}


	public static function updateHotspots3_2_2()
	{
		$db = JFactory::getDbo();
		$query = 'CREATE TABLE IF NOT EXISTS ' . $db->qn('#__hotspots_version') . ' (
					  `id` int(11) NOT NULL,
					  `version` varchar(55) NOT NULL
					) DEFAULT CHARSET=utf8;';
		$db->setQuery($query);
		$db->execute();

		$query = 'DROP TABLE IF EXISTS ' . $db->quoteName('#__hotspots_settings');
		$db->setQuery($query);
		$db->execute();
	}

	public static function dropTables()
	{
		$db = JFactory::getDBO();
		$dropTables[] = 'DROP TABLE IF EXISTS ' . $db->quoteName('#__hotspots_marker') . ';';
		$dropTables[] = 'DROP TABLE IF EXISTS ' . $db->quoteName('#__hotspots_categorie') . ';';
		$dropTables[] = 'DROP TABLE IF EXISTS ' . $db->quoteName('#__hotspots_settings') . ';';
		$dropTables[] = 'DROP TABLE IF EXISTS ' . $db->quoteName('#__hotspots_kmls') . ';';

		foreach ($dropTables as $drop)
		{
			$db->setQuery($drop);
			$db->execute();
		}
		return true;
	}


}

class hotspotsInstallerFiles
{
	public static function dropToolbars()
	{
		$toolbar_rem = (JPATH_BASE . '/components/com_hotspots/toolbar.hotspots.html.php');
		$toolbar2_rem = (JPATH_BASE . '/components/com_hotspots/toolbar.hotspots.php');
		if (file_exists($toolbar_rem))
		{
			unlink($toolbar_rem);
		}
		if (file_exists($toolbar2_rem))
		{
			unlink($toolbar2_rem);
		}
	}

	/**
	 * This function moves files to the media folder and deletes
	 * unnecessary folders
	 */
	public static function updateFiles()
	{
		jimport('joomla.filesystem');
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$frontendPath = JPATH_ROOT . '/components/com_hotspots/';


		$filesToMove = array(
			'frontend' => array(
				'categories' => $frontendPath . 'images/categories',
				'hotspots' => $frontendPath . 'images/hotspots',
				'thumbs' => $frontendPath . 'images/thumbs',
				'utils' => $frontendPath . 'images/utils'
			)
		);

		$foldersToDelete = array(
			'backend' => array(
				$adminPath . 'images',
			),
			'frontend' => array(
				$frontendPath . 'js',
				$frontendPath . 'lang',
				$frontendPath . 'images'
			)
		);

		$filesToDelete = array(
			'backend' => array(
				$adminPath . 'admin.hotspots.html.php',
				$adminPath . 'install.mysql.sql',
				$adminPath . 'uninstall.mysql.sql',
				$adminPath . 'helpers/feed.php',
				$adminPath . 'sql/unistall.mysql.sql'
			),
			'frontend' => array(
				$frontendPath . 'hotspots.css',
				$frontendPath . 'hotspots.html.php',
				$frontendPath . 'views/all/tmpl/default.css',
				$frontendPath . 'views/all/tmpl/default_old.css',
				$frontendPath . 'views/all/tmpl/default_old.php',
				$frontendPath . 'views/all/tmpl/default_slider_old.php',
				$frontendPath . 'views/all/tmpl/slider.css',
				$frontendPath . 'views/all/tmpl/slider_old.css',
				$frontendPath . 'views/all/tmpl/default_slider.php',
				$frontendPath . 'views/all/tmpl/border_watcher.css'
			)
		);

		$captchaPath = $frontendPath . 'captcha';

		$exclude = array('.svn', 'CVS', 'captcha.PNG', 'XFILES.TTF', 'index.html');
		$captchaImages = JFolder::files($captchaPath, $filter = '.', false, false, $exclude);

		if (is_array($captchaImages) && !empty($captchaImages))
		{
			foreach ($captchaImages as $captchaImage)
			{
				JFile::delete($captchaPath . '/' . $captchaImage);
			}
		}

		foreach ($filesToMove as $pathToFiles)
		{
			foreach ($pathToFiles as $key => $pathToFile)
			{
				if (JFolder::exists($pathToFile))
				{
					$oldDestination = $frontendPath . 'images/' . $key . '/';
					$moveTo = JPATH_ROOT . '/media/com_hotspots/images/' . $key . '/';
					$files = JFolder::files($pathToFile);
					foreach ($files as $file)
					{
						if (!JFile::exists($moveTo . $file))
						{
							JFile::move($oldDestination . $file, $moveTo . $file);
						}
					}
				}
			}
		}

		foreach ($foldersToDelete as $pathToFolders)
		{
			foreach ($pathToFolders as $pathToFolder)
			{
				if (JFolder::exists($pathToFolder))
				{
					JFolder::delete($pathToFolder);
				}
			}
		}

		foreach ($filesToDelete as $paths)
		{
			foreach ($paths as $path)
			{
				if (JFile::exists($path))
				{
					JFile::delete($path);
				}
			}
		}
	}

	public static function updateFiles1stable()
	{
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$frontendPath = JPATH_ROOT . '/components/com_hotspots/';
		$mediaPath = JPATH_ROOT . '/media/com_hotspots/';

		$foldersToDelete = array(
			'frontend' => array(
				$frontendPath . 'captcha',
				$frontendPath . 'views/all',
				$frontendPath . 'views/getcords',
				$frontendPath . 'views/gethotspots',
				$frontendPath . 'views/popupmail',
				$frontendPath . 'views/showaddhotspot',
			),
			'media' => array(
				$mediaPath . 'captcha'
			)
		);

		$filesToDelete = array(
			'backend' => array(
				$adminPath . 'admin.hotspots.php'
			),
			'frontend' => array(
				$frontendPath . 'controller.php',
				$frontendPath . 'models/all.php',
				$frontendPath . 'models/getcords.php',
				$frontendPath . 'models/gethotspots.php',
				$frontendPath . 'models/popupmail.php',
				$frontendPath . 'models/showaddhotspot.php',
			),
			'media' => array(
				$mediaPath . 'css/border_watcher.css',
				$mediaPath . 'js/borderwatcher.js',
				$mediaPath . 'js/progressbarcontrol_packed.js',
				$mediaPath . 'js/hsslider.js',
				$mediaPath . 'images/utils/bg-foot.gif',
				$mediaPath . 'images/utils/gps.png',
				$mediaPath . 'images/utils/hr-space.png',
				$mediaPath . 'images/utils/map_overlay_black.png',
				$mediaPath . 'images/utils/map_overlay_blue.png',
				$mediaPath . 'images/utils/map_overlay_close.png',
				$mediaPath . 'images/utils/map_overlay_red.png',
				$mediaPath . 'images/utils/map_overlay_white.png',
				$mediaPath . 'images/utils/map_overlay_yellow.png',
				$mediaPath . 'images/utils/open.png',
				$mediaPath . 'images/utils/satellite.png',
				$mediaPath . 'images/utils/thumb_up_icon.gif',
				$mediaPath . 'images/utils/arrow-up.png',
				$mediaPath . 'images/utils/categories.png',
				$mediaPath . 'images/utils/city-48x48.png',
				$mediaPath . 'images/utils/city.png',
				$mediaPath . 'images/utils/dialog_close.png',
				$mediaPath . 'images/utils/hybrid.png',
				$mediaPath . 'images/utils/info_off.gif',
				$mediaPath . 'images/utils/left.gif',
				$mediaPath . 'images/utils/right.gif',
				$mediaPath . 'images/utils/terrain.png',
				$mediaPath . 'images/utils/map.png',
				$mediaPath . 'images/utils/menu.gif',
				$mediaPath . 'images/utils/menu_small.gif',
				$mediaPath . 'images/utils/mini-categories.png',
				$mediaPath . 'images/utils/Mountain-32x32.png',
				$mediaPath . 'images/utils/reset-map.png',
				$mediaPath . 'images/utils/thumb_down_icon.gif',
				$mediaPath . 'images/utils/117043-matte-blue-and-white-square-icon-business-printer.png'
			)
		);


		foreach ($foldersToDelete as $pathToFolders)
		{
			foreach ($pathToFolders as $pathToFolder)
			{
				if (JFolder::exists($pathToFolder))
				{
					JFolder::delete($pathToFolder);
				}
			}
		}

		foreach ($filesToDelete as $paths)
		{
			foreach ($paths as $path)
			{
				if (JFile::exists($path))
				{
					JFile::delete($path);
				}
			}
		}
	}

	/**
	 * removes unnecessary files and folders from beta2
	 */
	public static function updateFilesBeta2()
	{
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$frontendPath = JPATH_ROOT . '/components/com_hotspots/';
		$mediaPath = JPATH_ROOT . '/media/com_hotspots/';

		$foldersToDelete = array(
			'frontend' => array(
				$frontendPath . 'views/mailsent',
				$frontendPath . 'views/getold',
			)
		);

		$filesToDelete = array(
			'frontend' => array(
				$frontendPath . 'models/mailsent.php',
				$frontendPath . 'models/getold.php',
			),
			'media' => array(
				$mediaPath . 'js/utils.js'
			)
		);

		foreach ($foldersToDelete as $pathToFolders)
		{
			foreach ($pathToFolders as $pathToFolder)
			{
				if (JFolder::exists($pathToFolder))
				{
					JFolder::delete($pathToFolder);
				}
			}
		}

		foreach ($filesToDelete as $paths)
		{
			foreach ($paths as $path)
			{
				if (JFile::exists($path))
				{
					JFile::delete($path);
				}
			}
		}
	}

	public static function updateFilesTo3_0()
	{
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$mediaPath = JPATH_ROOT . '/media/com_hotspots/';

		$filesToDelete = array(
			'backend' => array(
				$adminPath . 'admin.utils.php',
				$adminPath . 'install.hotspots.php',
				$adminPath . 'uninstall.hotspots.php',
				$adminPath . 'mootools.php',
			),
			'media' => array(
				$mediaPath . 'js/Hotspots.Add.Backend.js',
				$mediaPath . 'js/Hotspots.Add.js',
				$mediaPath . 'js/Hotspots.Backend.js',
				$mediaPath . 'js/Hotspots.Categories.js',
				$mediaPath . 'js/Hotspots.Helper.js',
				$mediaPath . 'js/Hotspots.Hotspot.js',
				$mediaPath . 'js/Hotspots.js',
				$mediaPath . 'js/Hotspots.Layout.js',
				$mediaPath . 'js/Hotspots.Layout.Hotspot.js',
				$mediaPath . 'js/Hotspots.Layout.Hotspots.js',
				$mediaPath . 'js/Hotspots.Slide.js',
				$mediaPath . 'js/Hotspots.Tab.js',
			)
		);

		foreach ($filesToDelete as $paths)
		{
			foreach ($paths as $path)
			{
				if (JFile::exists($path))
				{
					JFile::delete($path);
				}
			}
		}

	}
}

class hotspotsInstallAUP
{
	public static function installRule($xmlFile)
	{
		jimport('joomla.utilities.simplexml');
		$xmlDoc = JFactory::getXMLParser('Simple');

		if ($xmlDoc->loadFile($xmlFile))
		{
			$root = $xmlDoc->document;

			if ($root->name() == 'alphauserpoints')
			{
				$element = $root->rule;
				$ruleName = $element ? $element[0]->data() : '';
				$element = $root->description;
				$ruleDescription = $element ? $element[0]->data() : '';

				$element = $root->component;
				$component = $element ? $element[0]->data() : '';
				$element = $root->plugin_function;
				$pluginFunction = $element ? $element[0]->data() : '';
				$element = $root->fixed_points;
				$fixedpoints = $element ? $element[0]->data() : '';
				$fixedpoints = (trim(strtolower($fixedpoints)) == 'true') ? 1 : 0;

				if ($ruleName != '' && $ruleDescription != '' && $pluginFunction != '' && $component != '')
				{
					$db = JFactory::getDBO();
					$query = "SELECT COUNT(*) FROM `#__alpha_userpoints_rules` WHERE `plugin_function` = '$pluginFunction'";
					$db->setQuery($query);
					$count = $db->loadResult();

					if (!$count)
					{
						$query = "INSERT INTO #__alpha_userpoints_rules (`id`, `rule_name`, `rule_description`, `rule_plugin`, `plugin_function`, `component`, `fixedpoints`, `category`, `access`) "
							. " VALUES ('', '$ruleName', '$ruleDescription', '$component', '$pluginFunction', '$component', '$fixedpoints', 'fo', 1);";
						$db->setQuery($query);
						$db->query();
					}
				}
			}
		}
	}
}