<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       09.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die ('Restricted access');

/**
 * Class Tablecategorie
 *
 * @since  3.0
 */
class Tablecategorie extends JTable
{
	/**
	 * Constructor
	 *
	 * @param   object  &$db  - the db object
	 */
	public function __construct(&$db)
	{
		parent::__construct('#__hotspots_categorie', 'id', $db);
	}

	/**
	 * Binds the data
	 *
	 * @param   array   $array   - the array with data
	 * @param   string  $ignore  - elements to ignore
	 *
	 * @return bool
	 */
	public function bind($array, $ignore = '')
	{
		if (isset($array['params']) && is_array($array['params']))
		{
			// Convert the tile marker color to rgb for later use
			if (isset($array['params']['tile_marker_color']))
			{
				$array['params']['tile_marker_color'] = hotspotsHelperColor::hex2rgb($array['params']['tile_marker_color']);
			}

			$registry = new JRegistry;
			$registry->loadArray($array['params']);
			$array['params'] = (string) $registry;
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * Overrides JTable::store to set modified data
	 *
	 * @param   boolean  $updateNulls  True to update fields even if they are null.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   11.1
	 */
	public function store($updateNulls = false)
	{
		$date = JFactory::getDate();

		if (!$this->id)
		{
			// New article. An article created and created_by field can be set by the user,
			// so we don't touch either of these if they are set.
			if (!(int) $this->cat_date)
			{
				$this->cat_date = $date->toSql();
			}
		}

		return parent::store($updateNulls);
	}
}
