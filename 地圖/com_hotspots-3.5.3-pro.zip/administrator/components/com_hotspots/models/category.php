<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       04.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die();
jimport('joomla.application.component.modeladmin');

class HotspotsModelCategory extends JModelAdmin
{
	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param string|\The $type
	 * @param string      $prefix A prefix for the table class name. Optional.
	 * @param array       $config Configuration array for model. Optional.
	 *
	 * @internal param \The $type table type to instantiate
	 * @return    JTable    A database object
	 * @since    1.6
	 */
	public function getTable($type = 'Categorie', $prefix = 'Table', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param    array   $data        An optional array of data for the form to interogate.
	 * @param    boolean $loadData    True if the form is to load its own data (default case), false if not.
	 *
	 * @return    JForm    A JForm object on success, false on failure
	 * @since    1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_hotspots.categorie', 'categorie', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}


	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return    mixed    The data for the form.
	 * @since    1.6
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_hotspots.edit.hotspot.data', array());

		if (empty($data))
		{
			$data = $this->getItem();

			// Prime some default values.
			if ($this->getState('category.id') == 0)
			{
				$app = JFactory::getApplication();
				$data->set('catid', JRequest::getInt('catid', $app->getUserState('com_hotspots.hotspot.filter.category_id')));
			}
		}

		return $data;
	}

	/**
	 * returns a list with categories ordered by id
	 * @return mixed
	 */
	public function getCategories()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('id, cat_name, cat_description, cat_icon, cat_shadowicon, count')
			->from('#__hotspots_categorie');
		$db->setQuery($query);

		return $db->loadObjectList('id');
	}
}
