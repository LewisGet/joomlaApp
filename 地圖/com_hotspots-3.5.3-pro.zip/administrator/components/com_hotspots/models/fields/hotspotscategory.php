<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       04.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('JPATH_BASE') or die;

JFormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Framework.
 *
 * @since  3.0
 */
class JFormFieldHotspotsCategory extends JFormFieldList
{
	/**
	 * A flexible category list that respects access controls
	 *
	 * @var        string
	 * @since    1.6
	 */
	public $type = 'HotspotsCategory';

	/**
	 * Method to get a list of categories that respects access controls and can be used for
	 * either category assignment or parent category assignment in edit screens.
	 * Use the parent element to indicate that the field will be used for assigning parent categories.
	 *
	 * @return    array    The field option objects.
	 *
	 * @since    1.6
	 */
	protected function getOptions()
	{
		// Initialise variables
		$appl = JFactory::getApplication();
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('a.id AS value, a.cat_name AS text, a.published, a.params');
		$query->from('#__hotspots_categorie AS a');
		$query->where('a.published = 1');

		// A.published is not necessary here, but we are trying to make sql server happy
		$query->group('a.id, a.cat_name, a.published');
		$query->order('a.cat_name ASC');

		// Get the options.
		$db->setQuery($query);

		$options = $db->loadObjectList();

		if ($appl->isSite())
		{
			foreach ($options as $key => $value)
			{
				$registry = new JRegistry($value->params);

				if ($registry->get('exclude_frontend', 0))
				{
					unset($options[$key]);
				}
			}
		}

		if (isset($this->element['none']))
		{
			array_unshift($options, JHtml::_('select.option', '-1', JText::_('COM_HOTSPOTS_CATEGORY_NONE')));
		}

		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);

		return $options;
	}
}
