<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       13.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

$language = JFactory::getLanguage();
$language->load('com_hotspots.sys', JPATH_ADMINISTRATOR, null, true);

$view = JFactory::getApplication()->input->getCmd('view');

$subMenus = array(
	'controlcenter' => 'COM_HOTSPOTS_DASHBOARD',
	'hotspots' => 'COM_HOTSPOTS_LOCATIONS',
	'categories' => 'COM_HOTSPOTS_CATEGORIES',
	'import' => 'COM_HOTSPOTS_IMPORT',
	'liveupdate' => 'COM_HOTSPOTS_LIVEUPDATE'
);

if (HOTSPOTS_PRO)
{
	$subMenus['kmls'] = 'COM_HOTSPOTS_KML';
}

// Options button.
if (!JFactory::getUser()->authorise('core.admin', 'com_hotspots'))
{
	unset($subMenus['import']);
	unset($subMenus['liveupdate']);
}

foreach ($subMenus as $key => $name)
{
	$active = ($view == $key);
	JSubMenuHelper::addEntry(JText::_($name), 'index.php?option=com_hotspots&view=' . $key, $active);
}
