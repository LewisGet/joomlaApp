<?php
/**
 * @author     Daniel Dimitrov - compojoom.com
 * @date: 18.03.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */
defined('_JEXEC') or die('Restricted Access');

define('HOTSPOTS_PRO', '1');
define('HOTSPOTS_VERSION', '3.5.3');
define('HOTSPOTS_DATE', '2013-08-09');