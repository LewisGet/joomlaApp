<?php


/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

class HotspotsControllercategories extends HotspotsController {

	private $blacklist = array( ".php", 
								".phtml", 
								".php3", 
								".php4", 
								".php5", 
								".html", 
								".txt", 
								".dhtml", 
								".htm", 
								".doc", 
								".asp", 
								".net", 
								".js", 
								".rtf"
		);

    public function __construct() {
        parent::__construct();

        // Register Extra tasks
        $this->registerTask('unpublish', 'publish');
    }

    public function display() {
        $document = & JFactory::getDocument();
        $viewName = JRequest::getVar('view', 'categories');
        $viewType = $document->getType();
        $view = &$this->getView($viewName, $viewType);
        $model = $this->getModel('Category', 'HotspotsModel');
        $view->setModel($model, true);
        $view->setLayout('default');
        $view->display();
    }

    public function remove() {
        $cid = JRequest::getVar('cid', array(), '', 'array');
        $db = & JFactory::getDBO();
        $msg = JText::_('COM_HOTSPOTS_REMOVE_CATEGORIES_FAILED');
        if (count($cid)) {
            $cids = implode(',', $cid);
            $query = "DELETE FROM #__hotspots_categorie where id IN ( $cids )";
            $db->setQuery($query);
            if (!$db->query()) {
                echo "<script> alert('" . $db->getErrorMsg() . "'); window.history.go (-1); </script>\n";
            } else {
                $msg = JText::_('COM_HOTSPOTS_REMOVE_CATEGORIES_SUCCESS');
            }
        }
        $this->setRedirect('index.php?option=com_hotspots&view=categories', $msg);
    }


    public function publish() {
        $cid = JRequest::getVar('cid', array(), '', 'array');

		if ($this->task == 'publish') {
            $publish = 1;
        } else {
            $publish = 0;
        }

        $msg = "";
        $hotspotTable = & JTable::getInstance('categorie', 'Table');
        $hotspotTable->publish($cid, $publish);

        $link = 'index.php?option=com_hotspots&view=categories';

        $this->setRedirect($link, $msg);
    }

}