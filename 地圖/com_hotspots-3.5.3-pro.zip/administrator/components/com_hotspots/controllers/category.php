<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       04.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controllerform');

/**
 * Class HotspotsControllerCategory
 *
 * @since  3.0
 */
class HotspotsControllerCategory extends JControllerForm
{
	private $blacklist = array(".php",
		".phtml",
		".php3",
		".php4",
		".php5",
		".html",
		".txt",
		".dhtml",
		".htm",
		".doc",
		".asp",
		".net",
		".js",
		".rtf"
	);

	/**
	 * Constructor
	 */
	public function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask('add', 'edit');
		$this->registerTask('apply', 'save');
	}

	/**
	 * Method to save a record.
	 *
	 * @param   string  $key     The name of the primary key of the URL variable.
	 * @param   string  $urlVar  The name of the URL variable if different from the primary key (sometimes required to avoid router collisions).
	 *
	 * @return  boolean  True if successful, false otherwise.
	 */
	public function save($key = null, $urlVar = null)
	{
		$db = JFactory::getDBO();
		$row = JTable::getInstance('categorie', 'Table');
		$input = JFactory::getApplication()->input;

		$id = $input->getInt('id', 0);

		$selectIcon = $input->getString('select-icon');
		$data = $input->get('jform', array(), 'array');

		if (!$row->bind($data))
		{
			echo "<script> alert('" . $row->getError() . "'); window.history.go (-1); </script>\n";
			exit();
		}

		if (!isset($row->cat_date))
		{
			$row->cat_date = date('Y-m-d H:i:s');
		}

		switch ($selectIcon)
		{
			case 'new':
				$name = $this->uploadFile('cat_icon');

				if ($name !== false)
				{
					$row->cat_icon = $name;
				}
				break;
			case 'delete':
				$this->deleteImage('cat_icon', $id);
				break;
			case 'sample':
				$name = $this->copySampleImage($data['wsampleicon']);

				if ($name !== false)
				{
					$row->cat_icon = $name;
				}
				break;
		}

		$catImage = $this->uploadFile('cat_image');

		if ($catImage !== false)
		{
			$row->cat_image = $catImage;
		}

		if ($row->id)
		{
			$query = 'SELECT COUNT(*) AS count FROM ' . $db->quoteName('#__hotspots_marker') . ' WHERE catid = ' . $row->id;
			$db->setQuery($query);
			$row->count = $db->loadObject()->count;
		}

		if (!$row->store())
		{
			echo "<script> alert('" . $row->getError() . "'); window.history.go (-1); </script>\n";
			exit();
		}


		switch ($this->task)
		{
			case 'apply':
				$msg = JText::_('COM_HOTSPOTS_CATAPPLY');
				$link = 'index.php?option=com_hotspots&task=category.edit&id=' . $row->id;
				break;
			case 'save':
			default:
				$msg = JText::_('COM_HOTSPOTS_CATSAVE');
				$link = 'index.php?option=com_hotspots&view=categories';
				break;
		}

		$this->setRedirect($link, $msg);
	}

	/**
	 * Copies the sample image to the appropriate location
	 *
	 * @param   string  $image  - path to the image
	 *
	 * @return bool|string
	 */
	private function copySampleImage($image)
	{
		$appl = JFactory::getApplication();
		$user = JFactory::getUser();
		$sampleImagePath = JPATH_ROOT . '/media/com_hotspots/images/categories/' . $image;
		$newImageName = time() . '_' . JString::substr($user->name, 0, 1) . '_' . preg_replace('#(sample|_shadow|\/)#', '', $image);

		$moveTo = JPATH_ROOT . '/media/com_hotspots/images/categories/' . $newImageName;

		if (JFile::copy($sampleImagePath, $moveTo))
		{
			$msg = JText::sprintf('COM_HOTSPOTS_SAMPLE_IMAGE_COPIED', $newImageName);
			$appl->enqueueMessage($msg);

			return $newImageName;
		}
		else
		{
			$msg = JText::sprintf('COM_HOTSPOTS_SAMPLE_IMAGED_COPY_FAILED', $image);
		}

		$appl->enqueueMessage($msg);

		return false;
	}

	/**
	 * Deletes an image
	 *
	 * @param $column
	 * @param $id
	 */
	private function deleteImage($column, $id)
	{
		$db = JFactory::getDBO();
		$query = "SELECT '.$column.' FROM #__hotspots_categorie WHERE id = " . $id;
		$db->setQuery($query);
		$image = $db->loadResult();
		$imagePath = JPATH_ROOT . '/media/com_hotspots/images/categories/' . $image;
		unlink($imagePath);

		$query = 'UPDATE #__hotspots_categorie SET ' . $column . ' = "" WHERE id = ' . $db->Quote($id);
		$db->setQuery($query);
		$db->query();
	}

	private function uploadFile($fileName)
	{
		$appl = JFactory::getApplication();
		$fileData = JRequest::getVar($fileName, 0, 'FILES');
		$msg = '';

		if ($fileData['name'] != '')
		{
			$user = JFactory::getUser();
			$name = time() . '_' . JString::substr($user->name, 0, 1) . '_' . $fileData['name'];
			$tmpName = $fileData['tmp_name'];

			$imageinfo = getimagesize($fileData['tmp_name']);
			$mime = $imageinfo['mime'];

			if ($mime != 'image/gif' && $mime != 'image/jpeg' && $mime != 'image/png')
			{
				$msg .= JText::_('COM_HOTSPOTS_IMAGE_MIME_NOT_SUPPORTED');
			}
			else
			{
				$blacklist = $this->blacklist;

				foreach ($blacklist as $item)
				{
					if (preg_match("/$item\$/i", $name))
					{
						$msg .= JText::sprintf('COM_HOTSPOTS_DONT_ALLOW_THIS_TYPE', $item);
					}
				}

				$uploadPath = JPATH_ROOT . '/media/com_hotspots/images/categories/';
				$uploadImage = $uploadPath . basename($name);

				if (JFile::move($fileData['tmp_name'], $uploadImage))
				{
					$msg .= JText::sprintf('COM_HOTSPOTS_ICON_SUCCESSFULLY_UPLOADED_TO', $uploadImage);
				}
				else
				{
					$msg .= JText::sprintf('COM_HOTSPOTS_FAILED_TO_UPLOAD_ICON', $uploadPath);
				}

				$appl->enqueueMessage($msg);

				return basename($name);
			}
		}

		$appl->enqueueMessage($msg);

		return false;
	}

	/**
	 * Cancel and return to the correct screen
	 *
	 * @param null $key
	 *
	 * @return bool|void
	 */
	public function cancel($key = null)
	{
		$link = 'index.php?option=com_hotspots&view=categories';
		$this->setRedirect($link);
	}
}
