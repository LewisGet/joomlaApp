<?php

/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2012 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class HotspotsViewKmls extends JViewLegacy {

	public function display($tpl = null) {
        $appl = JFactory::getApplication();
        $this->kmls = $this->get('Items');
        $this->pagination = $this->get('Pagination');
		$this->state = $this->get('State');

        $context = 'com_hotspots.kmls.list.';
        $filter_order = $appl->getUserStateFromRequest($context . 'filter_order', 'filter_order', '', 'cmd');
        $filter_order_Dir = $appl->getUserStateFromRequest($context . 'filter_order_Dir', 'filter_order_Dir', '', 'word');

        // table ordering
        $lists['order_Dir'] = $filter_order_Dir;
        $lists['order'] = $filter_order;

        $this->lists = $lists;

        $this->addToolbar();
		parent::display($tpl);
	}

    public function addToolbar() {
        // Set toolbar items for the page
        JToolBarHelper::title(JText::_('COM_HOTSPOTS_KML'), 'kmls');
        JToolBarHelper::publishList('kmls.publish');
        JToolBarHelper::unpublishList('kmls.unpublish');
        JToolBarHelper::deleteList(JText::_('COM_HOTSPOTS_DO_YOU_REALLY_WANTO_TO_REMOVE_THIS_KML_FILE'),'kmls.remove');
        JToolBarHelper::editList('kml.edit');
        JToolBarHelper::addNew('kml.add');

    }

}