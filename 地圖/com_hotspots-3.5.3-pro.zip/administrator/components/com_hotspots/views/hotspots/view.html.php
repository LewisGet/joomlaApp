<?php

/**
 * Hotspots - Adminstrator
 * @package  Joomla!
 * @Copyright (C) 2009 Yves Hoppe - lunajoom.de
 * @All      rights reserved
 * @Joomla   ! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version  $Revision: 0.9.3 beta $
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class HotspotsViewHotspots extends JViewLegacy
{

	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$appl = JFactory::getApplication();
		$db = JFactory::getDBO();


		//Filter
		$context = 'com_hotspots.marker.list.';
		$filter_sectionid = $appl->getUserStateFromRequest($context . 'filter_category_id', 'filter_category_id', 0, 'int');
		$filter_order = $appl->getUserStateFromRequest($context . 'filter_order', 'filter_order', 'cc.catid', 'cmd');
		$filter_order_Dir = $appl->getUserStateFromRequest($context . 'filter_order_Dir', 'filter_order_Dir', '', 'word');

		$this->list = $this->get('Items');
		$this->pagination = $this->get('Pagination');

		// table ordering
		$lists['order_Dir'] = $filter_order_Dir;
		$lists['order'] = $filter_order;


		// sectionid
		$query = 'SELECT s.cat_name AS text, s.id AS value'
			. ' FROM #__hotspots_categorie AS s'
			. ' ORDER BY s.id';
		$db->setQuery($query);
		$hotspotssets = $db->loadObjectList();

		array_unshift($hotspotssets, JHTML::_('select.option', '', '- ' . JText::_('COM_HOTSPOTS_SELECT_CATEGORY') . ' -', 'value', 'text'));
		$lists['sectionid'] = JHTML::_('select.genericlist', $hotspotssets, 'filter_category_id', array('onchange' => 'this.form.submit();'), 'value', 'text', $filter_sectionid);

		$ordering = ($lists['order'] == 'cc.catid'); //Ordering allowed ?

		$this->lists = $lists;
		$this->ordering = $ordering;

		if (JRequest::getVar('layout') == 'element')
		{
			$this->setLayout('element');
		}
		$this->addToolbar();
		parent::display($tpl);
	}

	public function addToolbar()
	{
		$canDo = HotspotsHelper::getActions();

		JToolBarHelper::title(JText::_('COM_HOTSPOTS_MARKERS'), 'generic.png');
		JToolBarHelper::custom('geocode', 'geocoding', 'geocoding', 'COM_HOTSPOTS_GEOCODE');
		if ($canDo->get('core.edit.state'))
		{
			JToolBarHelper::publishList('hotspots.publish');
			JToolBarHelper::unpublishList('hotspots.unpublish');
		}
		JToolBarHelper::deleteList(JText::_('COM_HOTSPOTS_DO_YOU_REALLY_WANTO_TO_REMOVE_THIS_MARKER'), 'hotspots.remove');
		if ($canDo->get('core.edit'))
		{
			JToolBarHelper::editList('hotspot.edit');
		}

		if (HOTSPOTS_PRO || (!HOTSPOTS_PRO && $this->pagination->total <= 100))
		{
			if ($canDo->get('core.create'))
			{
				JToolBarHelper::addNew('hotspot.add');
			}
		}

	}
}
