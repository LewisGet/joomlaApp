<?php
/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');

$editor = JFactory::getEditor();

JHTML::_('behavior.framework');
JHTML::_('behavior.tooltip');

JHTML::_('stylesheet', 'hotspots-backend.css', 'media/com_hotspots/css/');

?>

<form enctype="multipart/form-data" action="<?php echo JRoute::_('index.php?option=com_hotspots&view=kml&hotspots_kml_id=' . (int)$this->item->hotspots_kml_id); ?>" method="post" class="form" name="adminForm" id="adminForm" >
    <div class="width-60 span8 fltlft">
        <fieldset class="adminform">
            <legend><?php echo empty($this->item->hotspots_kml_id) ? JText::_('COM_HOTSPOTS_NEW_KML') : JText::sprintf('COM_HOTSPOTS_EDIT_KML', $this->item->hotspots_kml_id); ?></legend>
            <ul class="adminformlist">
                <li>
                    <?php echo $this->form->getLabel('title'); ?>
                    <?php echo $this->form->getInput('title'); ?>
                </li>
                <li>
                    <?php echo $this->form->getLabel('catid'); ?>
                    <?php echo $this->form->getInput('catid'); ?>
                </li>
                <li>
                    <?php echo $this->form->getLabel('state'); ?>
                    <?php echo $this->form->getInput('state'); ?>
                </li>
                <li>
                    <?php echo $this->form->getLabel('hotspots_kml_id'); ?>
                    <?php echo $this->form->getInput('hotspots_kml_id'); ?>
                </li>
				<?php if($this->item->mangled_filename) : ?>
					<li>
						<label><?php echo JText::_('COM_HOTSPOTS_CURRENT_KML_FILE'); ?>:</label>
						<div class="fltlft">
							<a href="<?php echo JURI::root() . 'media/com_hotspots/kmls/'. $this->item->mangled_filename; ?>">
								<?php echo $this->item->original_filename; ?>
							</a>
						</div>
					</li>
				<?php endif; ?>
                <li>
                    <?php echo $this->form->getLabel('kml_file'); ?>
                    <?php echo $this->form->getInput('kml_file'); ?>
                </li>
            </ul>

            <div class="clr"></div>
            <?php echo $this->form->getLabel('description'); ?>
            <div class="clr"></div>
            <?php echo $this->form->getinput('description'); ?>

        </fieldset>
    </div>
    <div class="width-40 span4 fltrt">
        <?php echo JHtml::_('sliders.start', 'content-sliders-' . $this->item->hotspots_kml_id, array('useCookie' => 1)); ?>

        <?php echo JHtml::_('sliders.panel', JText::_('COM_HOTSPOTS_FIELDSET_PUBLISHING'), 'publishing-details'); ?>
        <fieldset class="panelform">
            <ul class="adminformlist">
                <li><?php echo $this->form->getLabel('created_by'); ?>
                    <?php echo $this->form->getInput('created_by'); ?></li>

                <li><?php echo $this->form->getLabel('created'); ?>
                    <?php echo $this->form->getInput('created'); ?></li>

            </ul>
        </fieldset>

        <?php echo JHtml::_('sliders.end'); ?>
    </div>
    <input type="hidden" name="task" value=""/>
    <?php echo JHTML::_('form.token'); ?>
</form>