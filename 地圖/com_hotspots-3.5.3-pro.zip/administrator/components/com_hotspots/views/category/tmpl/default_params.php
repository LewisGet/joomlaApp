<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       01.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die;

$fieldSets = $this->form->getFieldsets('params');

foreach ($fieldSets as $name => $fieldSet) : ?>
	<?php foreach ($this->form->getFieldset($name) as $field) : ?>
		<li style="clear: both"><?php echo $field->label; ?>
			<?php echo $field->input; ?>
		</li>
	<?php endforeach; ?>
<?php endforeach; ?>
