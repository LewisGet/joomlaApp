<?php
/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */

defined('_JEXEC') or die('Restricted access');

$editor = JFactory::getEditor();

JHTML::_('behavior.framework', true);
JHTML::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
JHtml::_('behavior.colorpicker');
JHTML::_('stylesheet', 'media/com_hotspots/css/hotspots-backend.css');

?>
<script type="text/javascript">
	Joomla.submitbutton = function (button) {
		if (button != 'category.cancel') {
			var validator = new Form.Validator.Inline(document.id('adminForm'), {wrap: true});
			if (validator.validate()) {
				var selected = document.id('select-icon').get('value');
				if (!document.id('category-icon').getElement('img') && selected != 'delete' && selected != 'new') {
					document.id('category-icon').addClass('validation-failed');
					return false;
				}
				Joomla.submitform(button);
				return true;
			}
			;
			return false;
		}
		Joomla.submitform(button);
	}
</script>

<div id="hotspots" class="hotspots">
	<form action="<?php echo JRoute::_('index.php?option=com_hotspots&view=category&id=' . (int)$this->row->id); ?>" method="post" name="adminForm" id="adminForm" class="form" enctype="multipart/form-data">
		<div class="width-60 span8 fltlft">
			<fieldset class="adminform">
				<legend><?php echo empty($this->row->id) ? JText::_('COM_HOTSPOTS_NEW_CATEGORY') : JText::sprintf('COM_HOTSPOTS_EDIT_CATEGORY', $this->row->id); ?></legend>
				<ul class="adminformlist">
					<li><?php echo $this->form->getLabel('cat_name'); ?>
						<?php echo $this->form->getInput('cat_name'); ?></li>
					<li><?php echo $this->form->getLabel('id'); ?>
						<?php echo $this->form->getInput('id'); ?></li>

					<li><?php echo $this->form->getLabel('published'); ?>
						<?php echo $this->form->getInput('published'); ?></li>

					<li><div class="clr"></div>
						<?php echo $this->form->getLabel('cat_description'); ?>
						<?php echo $this->form->getInput('cat_description'); ?></li>

					<li><?php echo $this->form->getLabel('cat_icon'); ?>
						<div style="float:left;">
							<?php echo $this->form->getInput('cat_icon'); ?>
						</div>
						<div style="clear:both"></div>
					</li>

					<li><?php echo $this->form->getLabel('cat_date'); ?>
						<?php echo $this->form->getInput('cat_date'); ?></li>

					<?php echo $this->loadTemplate('params'); ?>
				</ul>


			</fieldset>
		</div>

		<input type="hidden" name="id" value="<?php echo $this->row->id; ?>"/>
		<input type="hidden" name="option" value="com_hotspots"/>
		<input type="hidden" name="jform[wsampleicon]" id="wsampleicon" value=""/>
		<input type="hidden" name="jform[deleteicon]" id="deleteicon" value=""/>
		<input type="hidden" name="task" value=""/>
	</form>
</div>