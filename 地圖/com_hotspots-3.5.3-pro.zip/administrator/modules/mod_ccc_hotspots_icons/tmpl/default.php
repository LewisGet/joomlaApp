<?php
/**
 * Compojoom Control Center
 * @package Joomla!
 * @Copyright (C) 2012 - Yves Hoppe - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.0 beta $
 **/
defined('_JEXEC') or die();
$lang = JFactory::getLanguage();
$lang->load('com_hotspots.sys',JPATH_ADMINISTRATOR);
$path = JURI::root() . '/media/com_hotspots/backend/images/';
?>
<div id="cpanel" style="margin-top: 10px;">

	<div class="icon-wrapper">
		<div class="icon">
			<a href="<?php echo JRoute::_('index.php?option=com_hotspots&view=hotspots'); ?>">
				<img src="<?php echo $path; ?>hotspots-48px.png" alt="" />
				<span><?php echo JText::_('COM_HOTSPOTS_LOCATIONS'); ?></span>
			</a>
		</div>
		<?php if(HOTSPOTS_PRO): ?>
			<div class="icon">
				<a href="<?php echo JRoute::_('index.php?option=com_hotspots&view=kml'); ?>">
					<img src="<?php echo $path; ?>kmls-48px.png" alt="" />
					<span><?php echo JText::_('COM_HOTSPOTS_KML'); ?></span>
				</a>
			</div>
		<?php endif; ?>
		<div class="icon">
			<a href="<?php echo JRoute::_('index.php?option=com_hotspots&view=categories'); ?>">
				<img src="<?php echo $path; ?>categories-48px.png" alt="" />
				<span><?php echo JText::_('COM_HOTSPOTS_CATEGORIES'); ?></span>
			</a>
		</div>
		<?php echo LiveUpdate::getIcon(); ?>
	</div>

</div>