<?php
/**
 * Hotspots - Frontend
 * @package Joomla!
 * @Copyright (C) 2010 - Daniel Dimitrov (http://compojoom.com)
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.1 
 * */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');

class hotspotsModelCategory extends JModelLegacy {

	private $_category = null;
	private $_id = null;

	public function __construct() {
		parent::__construct();
		
		$this->_id = JRequest::getInt('cat', false);
	}

	public function getCategory($id = null) {
		if (!$this->_category) {
			if($id === null) {
				$id = $this->_id;
			}
			$query = 'SELECT * FROM ' . $this->_db->qn('#__hotspots_categorie')
					. ' WHERE id = ' . $this->_db->Quote($id);
			$this->_db->setQuery($query, 0, 1);
			$this->_category = $this->_db->loadObject();
		}
		
		return $this->_category;
	}

    public function getCategories() {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('id, cat_name, cat_description, cat_icon, cat_shadowicon, params, count')
            ->from('#__hotspots_categorie')
            ->where('published = 1');
        $db->setQuery($query);
        return $db->loadObjectList('id');
    }
	
}