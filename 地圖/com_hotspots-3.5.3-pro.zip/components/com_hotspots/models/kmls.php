<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       09.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');

/**
 * Class hotspotsModelKmls
 *
 * @since  3.0
 */
class HotspotsModelKmls extends JModelLegacy
{
	private $catid = '';

	/**
	 * Constructor
	 */
	public function __construct()
	{
		parent::__construct();
		$this->catid = explode(';', JFactory::getApplication()->input->getString('cat', 1));
	}

	/**
	 * Loads the necessary KML files
	 *
	 * @return mixed
	 */
	public function getKmls()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$where = '';

		foreach ($this->catid as $cat)
		{
			$where[] = $db->quote($cat);
		}

		$query->select('*')
			->from('#__hotspots_kmls')
			->where('catid IN (' . implode(',', $where) . ')')
			->where('state = 1');

		$db->setQuery($query);

		return $db->loadObjectList();
	}
}
