<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');

/**
 * This doesn't make a lot of sence.
 * We should use the hotspots model instead of this one..
 * TODO: refactor in a future version
 *
 * @since  3.0
 */
class HotspotsModelJson extends JModelLegacy
{
	private $hotspots = null;

	private $catid = null;

	/**
	 * Constructor
	 *
	 */
	public function __construct()
	{
		parent::__construct();
		$this->catid = JFactory::getApplication()->input->getInt('cat', 1);
	}

	/**
	 * Populate state
	 *
	 * @return void
	 */
	protected function populateState()
	{
		$app = JFactory::getApplication();
		$this->setState('filter.language', $app->getLanguageFilter());
	}

	/**
	 * this function is nearly the same as the one in the Hotspots model
	 * TODO: think of a way to combine the functions and get rid of that model
	 *
	 * @return array with objects
	 */
	public function getHotspots()
	{
		if (!$this->hotspots)
		{
			$db = JFactory::getDBO();

			$offset = JFactory::getApplication()->input->getInt('offset');
			$cats = $this->getCats();

			$hotspots = array();

			// Return 20 hotspots from each category
			foreach ($cats as $cat)
			{
				$query = $db->getQuery(true);
				$query->select('m.id as hotspots_id, m.*, u.name AS user_name')
					->from('#__hotspots_marker as m')
					->leftJoin('#__users AS u ON u.id = m.created_by')
					->where(implode(' AND ', $this->buildWhereQuery($cat)))
					->order('m.' . HotspotsHelper::getSettings('hotspots_order', 'name ASC'));

				$db->setQuery($query, $offset, HotspotsHelper::getSettings('marker_list_length', 20));
				$rows = $db->loadObjectList();
				$hotspots = array_merge($hotspots, $rows);
			}

			/**
			 * order the hotspots in
			 * cat1
			 * --hotspot1
			 * --hotspot2
			 * cat2
			 * --hotspot3
			 * --hotspot4
			 *
			 */

			if (count($hotspots))
			{
				foreach ($hotspots as $value)
				{
					$this->hotspots['hotspots'][$value->catid][] = $value;
					$this->hotspots['hotspots'][$value->catid]['viewCount'] = $this->countHotspotsInMapView($value->catid);
					$this->hotspots['hotspots'][$value->catid]['categoryCount'] = $this->countHotspotsInCategory($value->catid);
				}
			}
			else
			{
				$cats = $this->getCats();

				foreach ($cats as $category)
				{
					$this->hotspots['hotspots'][$category]['viewCount'] = $this->countHotspotsInMapView($category);
					$this->hotspots['hotspots'][$category]['categoryCount'] = $this->countHotspotsInCategory($category);
				}
			}
		}

		return $this->hotspots;
	}

	/**
	 * Counts the hotspots in a category
	 *
	 * @param   int  $category  - the category id
	 *
	 * @return mixed
	 */
	public function countHotspotsInCategory($category)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('count')->from('#__hotspots_categorie')
			->where('id = ' . $db->quote($category));
		$db->setQuery($query);

		return $db->loadObject()->count;
	}

	/**
	 * Counts the hotspots in the current map view
	 *
	 * @param   int  $catId  - the category id
	 *
	 * @return mixed
	 */
	public function countHotspotsInMapView($catId)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('COUNT(*) as count')
			->from('#__hotspots_marker as m')
			->where(implode('  AND ', $this->buildWhereQuery($catId)));
		$db->setQuery($query);

		return $db->loadObject()->count;
	}


	/**
	 * Gets the category ids
	 *
	 * @return array
	 */
	private function getCats()
	{
		$cats = explode(';', $this->catid);
		$secure = array();

		if (is_array($cats))
		{
			foreach ($cats as $cat)
			{
				if (is_numeric($cat) && $cat > 0)
				{
					$secure[] = $cat;
				}
			}
		}

		return $secure;
	}

	/**
	 * the Where part of the query
	 *
	 * @param   null  $cat  - the category
	 *
	 * @return array
	 */
	public function buildWhereQuery($cat = null)
	{
		$db = JFactory::getDBO();
		$input = JFactory::getApplication()->input;
		$where = array();

		if ($cat === null)
		{
			$cats = $this->getCats();
			$secure = array();

			foreach ($cats as $cat)
			{
				$secure[] = $db->quote($cat);
			}

			$where[] = ' m.catid IN (' . implode(',', $secure) . ')';
		}
		else
		{
			$where[] = ' m.catid = ' . $db->quote($cat);
		}

		$level = $input->getInt('level');

		$levels = array(0, 1);
		/**
		 * at small zoomelevels we can end up having 2 datelines
		 * because of this our queries will fail. To go around that
		 * problem we will get all hohtspots in the categories
		 * a nasty trick, but it should work in most situations...
		 */
		if (!in_array($level, $levels))
		{
			$ne = $input->getString('ne');
			$sw = $input->getString('sw');
			list($nelat, $nelng) = explode(',', $ne);
			list($swlat, $swlng) = explode(',', $sw);

			/**
			 * We need to take in account the meridian in the Mercator
			 * projection of the map. In the Mercator projection the meridian of the earth
			 * is at the left and right edges. When you slide to the left the
			 * or right, the map will wrap as you move past the meridian
			 * at +/- 180 degrees. In that case, the bounds are partially split
			 * across the left and right edges of the map and the northeast
			 * corner is actually positioned at a poin that is greater than 180 degree.
			 * The gmaps API automatiacally adjusts the longitude values to fit
			 * between -180 and +180 degrees so we ned to request 2 portions of the map
			 * from our database convering the left and right sides.
			 */
			if ($nelng > $swlng)
			{
				$where[] = ' (m.gmlng > ' . $db->quote($swlng) . ' AND m.gmlng < ' . $db->quote($nelng) . ')';
				$where[] = ' (m.gmlat <= ' . $db->quote($nelat) . ' AND m.gmlat >= ' . $db->quote($swlat) . ')';
			}
			else
			{
				$where[] = ' (m.gmlng >= ' . $db->quote($swlng) . ' OR m.gmlng <= ' . $db->quote($nelng) . ')';
				$where[] = ' (m.gmlat <= ' . $db->quote($nelat) . ' AND m.gmlat >= ' . $db->quote($swlat) . ')';
			}
		}

		$where[] = ' m.published = 1';

		$nullDate = $db->Quote($db->getNullDate());
		$nowDate = $db->Quote(JFactory::getDate()->toSQL());

		$where[] = ('(m.publish_up = ' . $nullDate . ' OR m.publish_up <= ' . $nowDate . ')');
		$where[] = ('(m.publish_down = ' . $nullDate . ' OR m.publish_down >= ' . $nowDate . ')');

		if ($this->getState('filter.language'))
		{
			$where[] = 'm.language in (' . $db->quote($input->getString('hs-language')) . ',' . $db->quote('*') . ')';
		}

		$user = JFactory::getUser();
		$groups = implode(',', $user->getAuthorisedViewLevels());
		$where[] = 'm.access IN (' . $groups . ')';

		return $where;
	}
}
