<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class HotspotsViewHotspot extends HotspotsView
{

	public function display($tpl = null)
	{
		$this->profile = '';
		$mainframe = JFactory::getApplication();
		$input = $mainframe->input;
		$model = $this->getModel();
		$user = JFactory::getUser();
		$hotspot = $this->prepareHotspot($model->getHotspot());
		$categoryModel = JModelLegacy::getInstance('category', 'HotspotsModel');
		$category = hotspotsUtils::prepareCategory($categoryModel->getCategory($hotspot->catid));

		$settings = $this->prepareSettings();
		$pathway = $mainframe->getPathWay();
		$pathway->additem($hotspot->name, '');

		$hsid = $input->getInt('id', 0);

		$itemId = '&Itemid=' . hotspotsUtils::getItemid('com_hotspots', 'hotspots');

		$backlink = JRoute::_('index.php?option=com_hotspots' . $itemId);

		$this->hotid = $hsid;
		$this->hotspot = $hotspot;
		$this->category = $category;
		$this->settings = $settings;
		$this->backlink = $backlink;
		$this->name = $user->name;

		if (HotspotsHelper::getSettings('profile_link', ''))
		{
			$this->profile = HotspotsHelperProfiles::getProfileLink($this->hotspot->created_by, HotspotsHelper::getSettings('profile_link', ''));
		}

		parent::display($tpl);
	}

	/**
	 * Sets some settings so that they can be easily accessed
	 *
	 * @return JObject
	 */
	private function prepareSettings()
	{
		$settings = new JObject();
		$properties = array(
			'show_address' => HotspotsHelper::getSettings('show_address', 1),
			'show_country' => HotspotsHelper::getSettings('show_address_country', 0),
			'show_author' => HotspotsHelper::getSettings('show_author', 1),
			'show_date' => HotspotsHelper::getSettings('show_date', 1),
			'show_detailpage' => HotspotsHelper::getSettings('hotspot_detailpage', 1)
		);

		$settings->setProperties($properties);

		return $settings;
	}


	private function prepareHotspot($hotspot)
	{
		if (HotspotsHelper::getSettings('marker_allow_plugin', 0) == 1)
		{
			$hotspot->description_small = JHTML::_('content.prepare', $hotspot->description_small, '');
			$hotspot->description = JHTML::_('content.prepare', $hotspot->description, '');
		}
		$hotspot->created = hotspotsUtils::getLocalDate($hotspot->created);
		if ($hotspot->picture_thumb)
		{
			$hotspot->picture_thumb = HOTSPOTS_THUMB_PATH . $hotspot->picture_thumb;
		}
		if ($hotspot->picture)
		{
			$hotspot->picture = HOTSPOTS_PICTURE_PATH . $hotspot->picture;
		}


		return $hotspot;
	}
}