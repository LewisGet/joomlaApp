<?php
/**
 * @author     Daniel Dimitrov
 * @date: 19.04.2013
 *
 * @copyright  Copyright (C) 2008 - 2012 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');
?>

<?php if (HotspotsHelper::getSettings('show_address', 1)) : ?>
	<?php if (HotspotsHelper::getSettings('user_interface', 0) == 0) : ?>
		<?php echo $this->hotspot->street ?>
		<?php echo $this->hotspot->plz ? ', ' . $this->hotspot->plz : ''; ?>
		<?php echo $this->hotspot->town ? ' ' . $this->hotspot->town : ''; ?>
	<?php else: ?>
		<?php echo $this->hotspot->street ?>
		<?php echo $this->hotspot->town ? ', ' . $this->hotspot->town : ''; ?>
		<?php echo $this->hotspot->plz ? ', ' . $this->hotspot->plz : ''; ?>
	<?php endif; ?>

	<?php if (HotspotsHelper::getSettings('show_address_country', 0)) : ?>
		<?php echo ', '.$this->hotspot->country; ?>
	<?php endif; ?>
<?php endif; ?>