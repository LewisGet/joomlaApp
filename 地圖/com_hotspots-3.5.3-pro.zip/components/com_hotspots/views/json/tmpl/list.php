<?php
/***************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

defined('_JEXEC') or die ('Restricted access');

/**
 * The following lines are getting pretty complex. Maybe we should move this to a
 * helper class?
 */
$html = array();
$html['count'] = $this->list['count'];
$html['catInfo'] = '';
if (!JRequest::getInt('start', 0, 'POST')) {
    if ($html['count']) {
        if (HotspotsHelper::getSettings('show_marker_count')) {
            $markerCount = ($html['count'] > 1) ? JText::_('COM_HOTSPOTS_THERE_ARE') : JText::_('COM_HOTSPOTS_THERE_IS');
            if (JRequest::getVar('task') == 'searchList') {
                $markerCount = JText::_('COM_HOTSPOTS_SEARCH_RETURNED');
            }
            $markerCount .= ' ' . $html['count'] . ' ';
            $markerCount .= ($html['count'] > 1) ? JText::_('COM_HOTSPOTS_HOTSPOTS') : JText::_('COM_HOTSPOTS_HOTSPOT');
            if (JRequest::getVar('cat')) {
                $markerCount .= ' ' . JText::_('COM_HOTSPOTS_IN_THIS_CATEGORY') . '.';
            } else {
                $markerCount .= ' ' . JText::_('COM_HOTSPOTS_IN_ALL_CATEGORIES') . '.';
            }
        }

        if (HotspotsHelper::getSettings('category_info')) {
            if (JRequest::getVar('cat')) {
                if (isset($this->list['hotspots'][0]->cat_name)) {
                    $html['catInfo'] = '<h3>' . $this->list['hotspots'][0]->cat_name . '</h3>';
                }
            }
            if (isset($this->list['hotspots'][0]->cat_description) || HotspotsHelper::getSettings('show_marker_count')) {
                $html['catInfo'] .= '<div class="info-content">';
                //				show the cat description only if we have a category
                if (JRequest::getVar('cat')) {
                    if (isset($this->list['hotspots'][0]->cat_description)) {
                        if ($this->list['hotspots'][0]->cat_description) {
                            $html['catInfo'] .= '<div>';
                            $html['catInfo'] .= $this->list['hotspots'][0]->cat_description;
                            $html['catInfo'] .= '</div>';
                        }
                    }
                }
                if (HotspotsHelper::getSettings('show_marker_count')) {
                    $html['catInfo'] .= $markerCount;
                }
            }
            $html['catInfo'] .= '</div>';
        }

        if (HotspotsHelper::getSettings('show_marker_count') && !HotspotsHelper::getSettings('category_info')) {
            $html['catInfo'] = '<div class="info-content">';
            $html['catInfo'] .= $markerCount;
            $html['catInfo'] .= '</div>';
        }
    }
}

foreach ($this->list['hotspots'] as $catid => $hotspots) {

    foreach ($hotspots as $value) {


        $this->hotspot = $value;
        ob_start();
        require('list_description.php');
        $description = ob_get_contents();
        ob_end_clean();

        $html['hotspots'][$catid][$value->hotspots_id] = array(
            'id' => $value->hotspots_id,
            'latitude' => $value->gmlat,
            'longitude' => $value->gmlng,
            'title' => $value->name,
            'description' => $description,
            'icon' => HOTSPOTS_PICTURE_CATEGORIES_PATH . $value->cat_icon,
            'shadow' => HOTSPOTS_PICTURE_CATEGORIES_PATH . $value->cat_shadowicon
        );
    }
}


echo (json_encode($html));
