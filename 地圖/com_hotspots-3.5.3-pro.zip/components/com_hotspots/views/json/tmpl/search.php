<?php
/**
 * @package    Hotspots
 * @author: DanielDimitrov - compojoom.com
 * @date: 04.06.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die ('Restricted access');
header('Content-type: application/json');

$html = array();

foreach ($this->list['hotspots'] as $key => $value)
{
	$this->hotspot = $value;

	$html['hotspots'][$value->catid][$key] = array(
		'id' => $value->hotspots_id,
		'latitude' => $value->gmlat,
		'longitude' => $value->gmlng,
		'title' => $value->name,
		'description' => preg_replace("@[\\r|\\n|\\t]+@", '', $this->hotspot->description_small),
		'street' => $this->hotspot->street,
		'city' => $this->hotspot->town,
		'zip' => $this->hotspot->plz,
		'country' => $this->hotspot->country,
		'date' => $this->hotspot->created,
		'readmore' => $this->hotspot->link
	);

	if (HotspotsHelper::getSettings('show_author', 1))
	{
		$html['hotspots'][$value->catid][$key]['created_by'] = $this->hotspot->created_by_alias ? $this->hotspot->created_by_alias : $this->hotspot->user_name;
	}

	if ($value->params->get('markerimage'))
	{
		$html['hotspots'][$value->catid][$key]['icon'] = HOTSPOTS_PICTURE_CATEGORIES_PATH . $value->params->get('markerimage');
	}
}

$html['worldCount'] = $this->list['worldCount'];
$html['viewCount'] = $this->list['count'];
$html['offset'] = JRequest::getInt('offset');
echo json_encode($html);

jexit();