<?php
/**
 * @author Daniel Dimitrov
 * @date: 23.03.12
 *
 * @copyright  Copyright (C) 2008 - 2012 compojoom.com . All rights reserved.
 * @license	GNU General Public License version 2 or later; see LICENSE
 */
defined('_JEXEC') or die('Restricted access');

$json = array();
foreach((array)$this->kmls as $key => $kml) {
    $json[$kml->catid][] = array(
        'file' => JURI::root() .'media/com_hotspots/kmls/'.$kml->mangled_filename
    );
}

echo json_encode($json);

//let us exit here and not let plugins screw our response
jexit();