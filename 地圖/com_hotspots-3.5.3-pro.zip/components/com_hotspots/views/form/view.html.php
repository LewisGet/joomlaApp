<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');
require_once( JPATH_COMPONENT_ADMINISTRATOR . '/libraries/recaptcha/hotspotsRecaptcha.php');
class HotspotsViewForm extends HotspotsView {

	public function display($tpl = null) {
		// Initialise variables.
		$user		= JFactory::getUser();
		$this->recaptcha = null;

		// Get model data.
		$this->state		= $this->get('State');
		$this->item			= $this->get('Item');
		$this->form			= $this->get('Form');

		$this->returnPage	= $this->get('ReturnPage');

		if (empty($this->item->id)) {
			$authorised = $user->authorise('core.create', 'com_hotspots');
		} else {
			$authorised = $user->authorise('core.edit.own', 'com_hotspots');
		}


		if ($authorised !== true) {
			JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));
			return false;
		}

//		if (!empty($this->item) && isset($this->item->id)) {
//			$this->item->images = json_decode($this->item->images);
//			$this->item->urls = json_decode($this->item->urls);
//
//			$this->form->bind($this->item);
//			$this->form->bind($this->item->urls);
//			$this->form->bind($this->item->images);
//
//		}

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseWarning(500, implode("\n", $errors));
			return false;
		}

		// Create a shortcut to the parameters.
		$params	= &$this->state->params;

		//Escape strings for HTML output
		$this->pageclass_sfx = htmlspecialchars($params->get('pageclass_sfx'));

		$this->params	= $params;
		$this->user		= $user;

		$userRecaptcha = hotspotsUtils::isUserInGroups(HotspotsHelper::getSettings('captcha_usergroup', array()));
		if (HotspotsHelper::getSettings('captcha', 1) && $userRecaptcha ) {
			$recaptcha = new hotspotsRecaptcha();

			$this->recaptcha = $recaptcha->getHtml();
		}

		$this->setLayout('form');
		parent::display($tpl);
	}
	
	private function prepareSettings() {
		$settings = new JObject();
		$properties = array (
			'show_address' => HotspotsHelper::getSettings('show_address', 1),
			'show_country' => HotspotsHelper::getSettings('show_address_country', 0),
			'show_author' => HotspotsHelper::getSettings('show_author', 1),
			'show_date' => HotspotsHelper::getSettings('show_date', 1),
			'show_detailpage' => HotspotsHelper::getSettings('hotspot_detailpage', 1)
		);
		
		$settings->setProperties($properties);
		
		return $settings;
	}

	
	private function prepareHotspot($hotspot) {

		$description = $hotspot->description;
		
		if (HotspotsHelper::getSettings('marker_allow_plugin', 0) == 1) {
			$description = JHTML::_('content.prepare', $description, '');
		}
		$hotspot->postdate = hotspotsUtils::getLocalDate($hotspot->postdate);
		if($hotspot->picture_thumb) {
			$hotspot->picture_thumb = HOTSPOTS_THUMB_PATH . $hotspot->picture_thumb;
		}
		if($hotspot->picture) {
			$hotspot->picture = HOTSPOTS_PICTURE_PATH . $hotspot->picture;
		}

		$hotspot->description = $description;
			
		return $hotspot;
	}
}