<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       02.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die ('Restricted access');

jimport('joomla.filesystem.file');
require_once JPATH_COMPONENT_ADMINISTRATOR . '/version.php';
JLoader::discover('hotspotsHelper', JPATH_COMPONENT . '/helpers');
require_once JPATH_COMPONENT . '/utils.php';
require_once JPATH_COMPONENT . '/includes/defines.php';
require_once JPATH_ADMINISTRATOR . '/components/com_hotspots/helpers/hotspots.php';
require_once JPATH_COMPONENT . '/views/view.php';
JTable::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_hotspots/tables');

// Thank you for this black magic Nickolas :)
// Magic: merge the default translation with the current translation
$jlang = JFactory::getLanguage();
$jlang->load('com_hotspots', JPATH_SITE, 'en-GB', true);
$jlang->load('com_hotspots', JPATH_SITE, $jlang->getDefault(), true);
$jlang->load('com_hotspots', JPATH_SITE, null, true);
$jlang->load('com_hotspots', JPATH_ADMINISTRATOR, 'en-GB', true);
$jlang->load('com_hotspots', JPATH_ADMINISTRATOR, $jlang->getDefault(), true);
$jlang->load('com_hotspots', JPATH_ADMINISTRATOR, null, true);

$controller = JControllerLegacy::getInstance('Hotspots');
$controller->execute(JFactory::getApplication()->input->getCmd('task'));
$controller->redirect();
