<?php
/**
* Hotspots - Adminstrator
* @package Joomla!
* @Copyright (C) 2009 Yves Hoppe - lunajoom.de
* @All rights reserved
* @Joomla! is Free Software
* @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @version $Revision: 0.9.3 beta $
**/

jimport('joomla.application.component.controller');

defined( '_JEXEC' ) or die ( 'Restricted access' );

class hotspotsController extends JControllerLegacy
{

}