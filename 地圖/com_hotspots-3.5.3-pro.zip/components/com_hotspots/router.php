<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */

defined('_JEXEC') or die('Restricted access');

/**
 * I hate this router functions and the joomla 1.5 way of handling sef urls in
 * general. 
 * TODO: improve this somehow as it is a f... nightmare
 */
function HotspotsBuildRoute(&$query) {
	$segments = array();

	// get a menu item based on Itemid or currently active
	$appl = JFactory::getApplication();
	$menu = $appl->getMenu();
	if (empty($query['Itemid'])) {
		$menuItem = $menu->getActive();
	} else {
		$menuItem = $menu->getItem($query['Itemid']);
	}
	$mView = (empty($menuItem->query['view'])) ? null : $menuItem->query['view'];
	$mCatid = (empty($menuItem->query['catid'])) ? null : $menuItem->query['catid'];
	$mId = (empty($menuItem->query['id'])) ? null : $menuItem->query['id'];

	if (isset($query['view'])) {
		$view = $query['view'];
		if (empty($query['Itemid'])) {
			$segments[] = $query['view'];
		}
		unset($query['view']);
	};

	if (($mView == 'hotspot') && (isset($query['id'])) && ($mId == intval($query['id']))) {
		unset($query['view']);
		unset($query['catid']);
		unset($query['id']);
	}

	if (isset($query['catid'])) {
		// if we are routing an article or category where the category id matches the menu catid, don't include the category segment
		if ((($view == 'hotspot') and ($mView != 'category'))) {
			$segments[] = $query['catid'];
		}
		unset($query['catid']);
	}

    if (isset($query['layout'])) {
        $segments[] = $query['layout'];
        unset($query['layout']);
    }

	if (isset($query['id'])) {
		if (empty($query['Itemid'])) {
			$segments[] = $query['id'];
		} else {
			if (isset($menuItem->query['id'])) {
				if ($query['id'] != $mId) {
					$segments[] = $query['id'];
				}
			} else {
				$segments[] = $query['id'];
			}
		}
		unset($query['id']);
	}

	return $segments;
}

function HotspotsParseRoute($segments) {
	$vars = array();

	// Get the active menu item.
	$appl = JFactory::getApplication();
	$menu = $appl->getMenu();
	$item = $menu->getActive();

	// Count segments
	$count = count($segments);

// go to single view
	if ($item->query['view'] == 'hotspots') {
		$vars['view'] = 'hotspot';
	}

    if (count($segments) == 1) {
        $vars['id'] = $segments[0];

        if (JFactory::getApplication()->input->getCmd('task') == 'form.edit') {
            $vars['view'] = 'form';
            $vars['task'] = 'edit';
        }
    }

    if ($segments[0] == 'edit') {
        $vars['view'] = 'form';
        $vars['task'] = 'edit';
    }

    if (isset($segments[1])) {
        if (count($segments) > 1) {
            $cat = explode(':', $segments[0]);
            $vars['catid'] = $cat[0];
            $id = explode(':', $segments[1]);
            $vars['id'] = $id[0];
        }
    }

	return $vars;
}
