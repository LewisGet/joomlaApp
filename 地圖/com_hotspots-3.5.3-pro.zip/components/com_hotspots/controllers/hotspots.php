<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       02.07.13
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

/**
 * Class HotspotsControllerHotspots
 *
 * @since  3
 */
class HotspotsControllerHotspots extends JControllerLegacy
{
	/**
	 * Creates the rss feed
	 *
	 * @return void
	 */
	public function rss()
	{
		hotspotsUtils::createFeed();
	}
}
