//credit to http://www.designvsdevelop.com/jquery-in-joomla-i-was-wrong/ for this idea
var jqLocator = {};
jqLocator = jQuery.noConflict();