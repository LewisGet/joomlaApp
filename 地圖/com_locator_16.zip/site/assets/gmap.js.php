<?php
/**
 * @package Locator Component
 * @copyright 2009 - Fatica Consulting L.L.C.
 * @license GPL - This is Open Source Software 
 * $Id: gmap.js.php 941 2011-10-14 09:37:23Z fatica $
 */

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
</script>
<script language="javascript" type="text/javascript">

</script>
<script type="text/javascript">
<?php


?>
