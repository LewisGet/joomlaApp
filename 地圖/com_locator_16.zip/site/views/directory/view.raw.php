<?php
/**
 * @package Locator Component
 * @copyright 2009 - Fatica Consulting L.L.C.
 * @license GPL - This is Open Source Software 
 * $Id: view.html.php 600 2011-01-10 16:59:49Z fatica $
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

require_once (JPATH_COMPONENT_SITE.DS.'view.php');

require_once(JPATH_COMPONENT_SITE . DS . 'views' . DS . 'directory' . DS . 'view.html.php');