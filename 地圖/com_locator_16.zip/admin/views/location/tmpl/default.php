<?php 
/**
 * @package Locator Component
 * @copyright 2009 - Fatica Consulting L.L.C.
 * @license GPL - This is Open Source Software 
 * $Id$
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
	

include(JPATH_BASE . DS . 'components' . DS. 'com_locator' .DS.'views' . DS. 'location'.DS. 'tmpl' . DS .'default.php');

?>