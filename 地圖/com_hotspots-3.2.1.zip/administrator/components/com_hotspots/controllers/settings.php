<?php
/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2009 Yves Hoppe - lunajoom.de
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.3 beta $
 **/

defined('_JEXEC') or die ('Restricted access');

class HotspotsControllersettings extends HotspotsController
{
    public function __construct()
    {
        parent::__construct();
        $this->registerTask('apply', 'save');
    }

    public function save()
    {
        $post = JRequest::get('post');
        $hotspotsSet = JRequest::getVar('hotspotsset', array(0), 'post', 'array');

        require_once(JPATH_COMPONENT . '/models/settings.php');
        $model = new HotspotsModelSettings;

        switch (JRequest::getCmd('task')) {
            case 'apply':

                if ($model->store($hotspotsSet)) {
                    $msg = JText::_('COM_HOTSPOTS_CHANGES_TO_HOTSPOTS_SETTINGS_SAVED');
                } else {
                    $msg = JText::_('COM_HOTSPOTS_ERROR_SAVING_HOTSPOTS_SETTINGS');
                }
                $this->setRedirect('index.php?option=com_hotspots&view=settings', $msg);
                break;

            case 'save':
            default:
                if ($model->store($hotspotsSet)) {
                    $msg = JText::_('COM_HOTSPOSTS_SETTINGS_SAVED');
                } else {
                    $msg = JText::_('COM_HOTSPOTS_ERROR_SAVING_HOTSPOTS_SETTINGS');
                }
                $this->setRedirect('index.php?option=com_hotspots', $msg);
                break;
        }

        $model->checkin();
    }

    public function cancel()
    {

        $this->setRedirect('index.php?option=com_hotspots');
    }

}

?>