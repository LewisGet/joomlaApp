<?php


/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
//jimport('joomla.application.component.controller');
jimport('joomla.application.component.controllerform');

class HotspotsControllerCategory extends JControllerForm {

	private $blacklist = array( ".php", 
								".phtml", 
								".php3", 
								".php4", 
								".php5", 
								".html", 
								".txt", 
								".dhtml", 
								".htm", 
								".doc", 
								".asp", 
								".net", 
								".js", 
								".rtf"
		);

    public function __construct() {
        parent::__construct();

        // Register Extra tasks
        $this->registerTask('add', 'edit');
        $this->registerTask('apply', 'save');
    }

    public function save() {
		$db =& JFactory::getDBO();
        $row = & JTable::getInstance('categorie', 'Table');
        $postcat = JRequest::get('post');

        $id = JRequest::GetVar('id', 0);
		
        $wsampleshadow = JRequest::GetVar('wsampleshadow', 0);
        $wsampleicon = JRequest::GetVar('wsampleicon', 0);
		
		$selectIcon = JRequest::getString('select-icon');
		$selectShadow = JRequest::getString('select-shadow');

        if (!$row->bind($postcat)) {
            echo "<script> alert('" . $row->getError() . "'); window.history.go (-1); </script>\n";
            exit();
        }

        if (!isset($row->cat_date)) {
			$row->cat_date = date('Y-m-d H:i:s');
		}
            
		switch($selectIcon) {
			case 'new':
				$name = $this->uploadFile('cat_icon');
				if($name !== false) {
					$row->cat_icon = $name;
				}
				break;
			case 'delete':
				$this->deleteImage('cat_icon', $id);
				break;
			case 'sample':
				$name = $this->copySampleImage($wsampleicon);
				if($name !== false) {
					$row->cat_icon = $name;
				}
				break;
		}
		
		switch($selectShadow) {
			case 'new':
				$name = $this->uploadFile('cat_shadowicon');
				if($name !== false) {
					$row->cat_shadowicon = $name;
				}
				break;
			case 'delete':
				$this->deleteImage('cat_shadowicon', $id);
				break;
			case 'sample':
				$name = $this->copySampleImage($wsampleshadow);
				if($name !== false) {
					$row->cat_shadowicon = $name;
				}
				break;
		}
		
		$catImage = $this->uploadFile('cat_image');
		if($catImage !== false) {
			$row->cat_image = $catImage;
		}

		if($row->id) {
			$query = 'SELECT COUNT(*) AS count FROM ' . $db->quoteName('#__hotspots_marker') . ' WHERE catid = ' .$row->id;
			$db->setQuery($query);
			$row->count = $db->loadObject()->count;
		}

        if (!$row->store()) {
            echo "<script> alert('" . $row->getError() . "'); window.history.go (-1); </script>\n";
            exit();
        }


        switch ($this->task) {
            case 'apply':
                $msg = JText::_('COM_HOTSPOTS_CATAPPLY');
                $link = 'index.php?option=com_hotspots&task=category.edit&id=' . $row->id;
                break;
            case 'save':
            default:
                $msg = JText::_('COM_HOTSPOTS_CATSAVE');
                $link = 'index.php?option=com_hotspots&view=categories';
                break;
        }

        $this->setRedirect($link, $msg);
    }
	
	private function copySampleImage($image) {
		$appl = JFactory::getApplication();
		$user = JFactory::getUser();
		$sampleImagePath = JPATH_ROOT .'/media/com_hotspots/images/categories/' .$image;
		$newImageName = time().'_'.JString::substr($user->name,0,1).'_'.preg_replace('#(sample|_shadow|\/)#','',$image);
		
		$moveTo = JPATH_ROOT .'/media/com_hotspots/images/categories/'.$newImageName;
		
		if(JFile::copy($sampleImagePath, $moveTo)) {
			$msg = JText::sprintf('COM_HOTSPOTS_SAMPLE_IMAGE_COPIED',$newImageName);
			$appl->enqueueMessage($msg);
			return $newImageName;
		} else {
			$msg = JText::sprintf('COM_HOTSPOTS_SAMPLE_IMAGED_COPY_FAILED', $image);
		}
		
		$appl->enqueueMessage($msg);
		return false;
	}
	
	private function deleteImage($column, $id) {
		$db = JFactory::getDBO();
		$query = "SELECT '.$column.' FROM #__hotspots_categorie WHERE id = " . $id;
		$db->setQuery($query);
		$image = $db->loadResult();
		$imagePath = JPATH_ROOT . '/media/com_hotspots/images/categories/' . $image;
		unlink($imagePath);

		$query = 'UPDATE #__hotspots_categorie SET '.$column.' = "" WHERE id = ' . $db->Quote($id);
		$db->setQuery($query);
		$db->query();
	}
	
	private function uploadFile($fileName) {
		$appl = JFactory::getApplication();
		$fileData = JRequest::getVar($fileName, 0, 'FILES');
		$msg = '';
		
		if ($fileData['name'] != '') {
			$user = JFactory::getUser();
			$name = time().'_'.  JString::substr($user->name, 0,1).'_'.$fileData['name'];
			$tmpName = $fileData['tmp_name'];
			
            $imageinfo = getimagesize($fileData['tmp_name']);
			$mime = $imageinfo['mime'];
			
            if ($mime != 'image/gif' && $mime != 'image/jpeg' && $mime != 'image/png') {
                $msg .= JText::_('COM_HOTSPOTS_IMAGE_MIME_NOT_SUPPORTED') ;
            } else {
                $blacklist = $this->blacklist;
                foreach ($blacklist as $item) {
                    if (preg_match("/$item\$/i", $name)) {
                        $msg .= JText::sprintf('COM_HOTSPOTS_DONT_ALLOW_THIS_TYPE', $item);
                    }
                }

                $uploadPath = JPATH_ROOT .'/media/com_hotspots/images/categories/';
                $uploadImage = $uploadPath . basename($name);

                if (JFile::move($fileData['tmp_name'], $uploadImage)) {
                    $msg .= JText::sprintf('COM_HOTSPOTS_ICON_SUCCESSFULLY_UPLOADED_TO', $uploadImage);
                } else {
                    $msg .= JText::sprintf('COM_HOTSPOTS_FAILED_TO_UPLOAD_ICON',$uploadPath);
                }
				$appl->enqueueMessage($msg);		
				return basename($name);
            }
        }
		$appl->enqueueMessage($msg);
		
		return false;
	}

    public function cancel() {
        $link = 'index.php?option=com_hotspots&view=categories';
        $this->setRedirect($link);
    }

}