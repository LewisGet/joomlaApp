<?php
/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2010 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 beta2
 * */
defined('_JEXEC') or die();
jimport('joomla.application.component.modeladmin');

class HotspotsModelHotspot extends JModelAdmin {

    /**
     * @var		string	The prefix to use with controller messages.
     * @since	1.6
     */
    protected $text_prefix = 'COM_HOTSPOTS';

    /**
     * Prepare and sanitise the table data prior to saving.
     *
     * @param	JTable	A JTable object.
     *
     * @return	void
     * @since	1.6
     */
    protected function prepareTable(&$table)
    {
        // Set the publish date to now
        if($table->published == 1 && intval($table->publish_up) == 0) {
            $table->publish_up = JFactory::getDate()->toSql();
        }

    }

    /**
     * Returns a reference to the a Table object, always creating it.
     *
     * @param	type	The table type to instantiate
     * @param	string	A prefix for the table class name. Optional.
     * @param	array	Configuration array for model. Optional.
     * @return	JTable	A database object
     * @since	1.6
     */
    public function getTable($type = 'Marker', $prefix = 'Table', $config = array())
    {
        return JTable::getInstance($type, $prefix, $config);
    }

    /**
     * Method to get the record form.
     *
     * @param	array	$data		An optional array of data for the form to interogate.
     * @param	boolean	$loadData	True if the form is to load its own data (default case), false if not.
     * @return	JForm	A JForm object on success, false on failure
     * @since	1.6
     */
    public function getForm($data = array(), $loadData = true)
    {

        // Initialise variables.
        $app	= JFactory::getApplication();

        // Get the form.
        $form = $this->loadForm('com_hotspots.marker', 'marker', array('control' => 'jform', 'load_data' => $loadData));

        if (empty($form)) {
            return false;
        }

        // Determine correct permissions to check.
        if ($this->getState('hotspot.id')) {
            // Existing record. Can only edit in selected categories.
            $form->setFieldAttribute('catid', 'action', 'core.edit');
        } else {
            // New record. Can only create in selected categories.
            $form->setFieldAttribute('catid', 'action', 'core.create');
        }

        // Modify the form based on access controls.
        if (!$this->canEditState((object) $data)) {
            // Disable fields for display.
            $form->setFieldAttribute('published', 'disabled', 'true');
            $form->setFieldAttribute('publish_up', 'disabled', 'true');
            $form->setFieldAttribute('publish_down', 'disabled', 'true');

            // Disable fields while saving.
            // The controller has already verified this is a record you can edit.
            $form->setFieldAttribute('published', 'filter', 'unset');
            $form->setFieldAttribute('publish_up', 'filter', 'unset');
            $form->setFieldAttribute('publish_down', 'filter', 'unset');
        }

        return $form;
    }

    /**
     * Method to get a single record.
     *
     * @param	integer	The id of the primary key.
     *
     * @return	mixed	Object on success, false on failure.
     */
    public function getItem($pk = null)
    {
        if ($item = parent::getItem($pk)) {

            $item->hotspotText = trim($item->description) != '' ? $item->description_small . "<hr id=\"system-readmore\" />" . $item->description : $item->description_small;
        }

        return $item;
    }

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return	mixed	The data for the form.
     * @since	1.6
     */
    protected function loadFormData()
    {
        // Check the session for previously entered form data.
        $data = JFactory::getApplication()->getUserState('com_hotspots.edit.hotspot.data', array());

        if (empty($data)) {
            $data = $this->getItem();
        }
        return $data;
    }

    public function save($data) {
        $file = JRequest::getVar('jform', '', 'files', 'array');
        $emptyFile = true;
        if(!empty($file)) {
            if(!empty($file['name']['picture'])) {
                foreach($file as $key => $value) {
                    $newFile[$key] = $value['picture'];
                }
                $emptyFile = false;
            }
        }

        if(!$emptyFile) {
            $picture = HotspotsUtils::uploadPicture($newFile);
            if($picture) {
                $data['picture'] = $picture;
                hotspotsUtils::createThumb($picture);
                $data['picture_thumb'] = "thumb_" . $picture ;
            }

        }

        return parent::save($data);
    }
}