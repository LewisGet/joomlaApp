<?php
/**
 * Hotspots - Adminstrator
 * @package Joomla!
 * @Copyright (C) 2010 Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 1.0 beta2 
 */

defined('_JEXEC') or die('Restricted access');
// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_hotspots')) {
    return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}
require_once( JPATH_COMPONENT_SITE . '/includes/defines.php');
require_once(JPATH_COMPONENT_SITE . '/views/view.php');
require_once( JPATH_COMPONENT_SITE . '/utils.php');
require_once( JPATH_COMPONENT . '/controller.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR . '/helpers/hotspots.php');
require_once JPATH_COMPONENT_ADMINISTRATOR.'/liveupdate/liveupdate.php';
// in J3.0 the toolbar is not loaded automatically, so let us load it ourselves.
require_once('toolbar.hotspots.php');

JTable::addIncludePath(JPATH_COMPONENT . '/tables');

// thank you for this black magic Nickolas :)
// Magic: merge the default translation with the current translation
$jlang =& JFactory::getLanguage();
$jlang->load('com_hotspots', JPATH_SITE, 'en-GB', true);
$jlang->load('com_hotspots', JPATH_SITE, $jlang->getDefault(), true);
$jlang->load('com_hotspots', JPATH_SITE, null, true);
$jlang->load('com_hotspots', JPATH_ADMINISTRATOR, 'en-GB', true);
$jlang->load('com_hotspots', JPATH_ADMINISTRATOR, $jlang->getDefault(), true);
$jlang->load('com_hotspots', JPATH_ADMINISTRATOR, null, true);

$input = JFactory::getApplication()->input;
if($input->getCmd('view','') == 'liveupdate') {
	JToolBarHelper::preferences( 'com_hotspots' );
    LiveUpdate::handleRequest();
    return;
}

$view = $input->getCmd('view','');
if(( $view == '' && $input->getCmd('task') == '') || $view == 'controlcenter') {
	require_once JPATH_COMPONENT_ADMINISTRATOR.'/controlcenter/controlcenter.php';
	JToolBarHelper::preferences( 'com_hotspots' );
	CompojoomControlCenter::handleRequest();
	return;
}


$controller = JControllerLegacy::getInstance('Hotspots');
$controller->execute($input->getCmd('task'));
$controller->redirect();
