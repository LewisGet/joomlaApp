<?php
/**
 * Tiles
 * @package Joomla!
 * @Copyright (C) 2012 - Daniel Dimitrov - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 3.0
 **/
defined('_JEXEC') or die('Restricted access');

/**
 * Script file of Matukio component
 */
class com_hotspotsInstallerScript extends CompojoomInstaller
{
	/*
	 * The release value to be displayed and checked against throughout this file.
	 */
	public $release = '3.0';
	public $minimum_joomla_release = '2.5';
	public $extension = 'com_hotspots';
    private $type = '';

	private $installationQueue = array(
		// modules => { (folder) => { (module) => { (position), (published) } }* }*
		'modules' => array(
			'admin' => array(
				'mod_hotspots' => array('ccc_hotspots_left', 1),
				'mod_ccc_hotspots_icons' => array('ccc_hotspots_left',1),
				'mod_hotspots_stats' => array('ccc_hotspots_slider',1),
				'mod_ccc_hotspots_newsfeed' => array('ccc_hotspots_slider',1),
				'mod_ccc_hotspots_overview' => array('ccc_hotspots_slider',1),
				'mod_ccc_hotspots_update' => array('ccc_hotspots_slider',1)
			)
		),
		'plugins' => array(
			'plg_hotspots_jomsocial' => 0,
			'plg_hotspots_email' => 0,
			'plg_hotspotslinks_content' => 1,
			'plg_hotspotslinks_k2' => 0,
			'plg_hotspotslinks_sobipro' => 0,
			'plg_search_hotspots' => 0,
            'plg_content_hotspots' => 0
		)
	);


	/**
	 * method to uninstall the component
	 *
	 * @param $parent
	 * @return void
	 */
	public function uninstall($parent)
	{
        $this->type = 'uninstall';
		$this->parent = $parent;

		$this->status->plugins = $this->uninstallPlugins($this->installationQueue['plugins']);
		$this->status->modules = $this->uninstallModules($this->installationQueue['modules']);

		$this->droppedTables = false;

		if (hotspotsInstallerDatabase::isCompleteUninstall()) {
			hotspotsInstallerDatabase::dropTables();
			$this->droppedTables = true;
		}

		echo $this->displayInfoUninstallation();


	}

	/**
	 * method to run after an install/update/discover method
	 *
	 * @param $type
	 * @param $parent
	 * @return void
	 */
	public function postflight($type, $parent)
	{
		$this->loadLanguage();
		$this->update = hotspotsInstallerDatabase::checkIfUpdating();

		switch ($this->update) {
			case '1b':
				hotspotsInstallerFiles::dropToolbars();
				updateFiles();
				hotspotsInstallerDatabase::updateSettings1b();
			case '1b2':
				hotspotsInstallerFiles::updateFilesBeta2();
			case '1stable':
				hotspotsInstallerFiles::updateFiles1stable();
				hotspotsInstallerDatabase::updateSettings1stable();
			case '2.0':
			case '2.0.1':
			case '2.0.2':
			case '2.0.3':
			case '2.0.4':
				hotspotsInstallerDatabase::updateSettings204();
			case '2.0.5':
				hotspotsInstallerDatabase::updateDatabaseStructure205();
			case '3.0':
				hotspotsInstallerFiles::updateFilesTo3_0();
				hotspotsInstallerDatabase::updateDatabaseStructureTo3_0();
				hotspotsInstallerDatabase::updateSettingsTo3_0();
				hotspotsInstallerDatabase::updateMenuTo3_0();
            case 'git_1253cfa':
            case '3.0.1':
                hotspotsInstallerDatabase::updateKMLStructureTo3_0_1();
            case '3.1':
                hotspotsInstallerDatabase::updateCategoriesTiles3_1();
            case '3.1.1':
                hotspotsInstallerDatabase::updateHotspots3_1_1();
            case '3.2':
                hotspotsInstallerDatabase::updateHotspots3_2();
				break;
			case 'new':
				// insert new stuff only if we don't have a previous dev release
				if (!strstr($this->update, 'git_')) {
					hotspotsInstallerDatabase::insertNewSettings();
				}
				break;
		}

        if($this->update != 'new' && $this->type != 'uninstall') {
            hotspotsInstallerDatabase::updateVersionNumber();
        }

		// let us install the modules
		$this->status->plugins = $this->installPlugins($this->installationQueue['plugins']);
		$this->status->modules = $this->installModules($this->installationQueue['modules']);

        // install the cb plugin if CB is installed
        if(JFile::exists(JPATH_ADMINISTRATOR . '/components/com_comprofiler/library/cb/cb.installer.php')) {
            global $_CB_framework;
            require_once(JPATH_ADMINISTRATOR . '/components/com_comprofiler/plugin.foundation.php');
            require_once(JPATH_ADMINISTRATOR . '/components/com_comprofiler/plugin.class.php');
            require_once(JPATH_ADMINISTRATOR . '/components/com_comprofiler/comprofiler.class.php');

            require_once(JPATH_ADMINISTRATOR . '/components/com_comprofiler/library/cb/cb.installer.php');

            $cbInstaller = new cbInstallerPlugin();
            if($cbInstaller->install($parent->getParent()->getPath('source').'/components/com_comprofiler/plugin/user/plug_hotspots/'))
            {
                $path = $parent->getParent()->getPath('source').'/components/com_comprofiler/plugin/user/plug_hotspots/administrator/language';
                $languages = JFolder::folders($path);

                foreach ($languages as $language) {
                    if(JFolder::exists(JPATH_ROOT.'/administrator/language/'.$language)) {
                        JFile::copy($path.'/'.$language.'/'.$language.'.plg_plug_hotspots.ini',
                            JPATH_ROOT.'/administrator/language/'.$language.'/'.$language.'.plg_plug_hotspots.ini'
                        );
                    }
                }

                $this->status->cb = true;
            }
        }

		echo $this->displayInfoInstallation();

	}

	private function displayInfoInstallation()
	{
		$html[] = '<div class="header">' . JText::_('COM_HOTSPOTS_INSTALLATION_SUCCESS') . '</div>';
		$html[] = '<img src="'. JURI::root() .'media/com_hotspots/images/utils/logo.jpg "/>';
		$html[] = '<p>' . JText::_('COM_HOTSPOTS_INSTALLATION_DOC_FORUMS_FIND');
		$html[] = '<a href="http://www.compojoom.com" target="_blank">http://compojoom.com</a>';
		$html[] = '<br/>';
		$html[] = '<br/>';
		$html[] = '<strong>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_QUICK_INSTRUCTIONS') . ' <br/>';

		$html[] = '</strong></p>';
		$html[] = '<div>';
		$html[] = '<ol>';
		$html[] = '<li>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_PERMISSIONS');
		$html[] = '</li>';
		$html[] = '<li>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_CREATE_A_CATEGORY');
		$html[] = '(<a href="' . JRoute::_('index.php?option=com_hotspots&task=category.edit') . '"
			    target="_blank">' . JText::_('COM_HOTSPOTS_INSTALLATION_CLICK_HERE') . ' </a>)';
		$html[] = '</li>';
		$html[] = '<li>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_CREATE_A_HOTSPOT') . '(<a
			href="' . JRoute::_('index.php?option=com_hotspots&task=hotspot.edit') . '"
			target="_blank">' . JText::_('COM_HOTSPOTS_INSTALLATION_CLICK_HERE') . '</a>)';
		$html[] = '</li>';
		$html[] = '<li>';
		$html[] = JText::_('COM_HOTSPOTS_INSTALLATION_CREATE_A_MENU_LINK') . '(<a
			href="' . JRoute::_('index.php?option=com_menus&task=view&menutype=mainmenu') . '"
			target="_blank">' . JText::_('COM_HOTSPOTS_INSTALLATION_CLICK_HERE') . '</a>)';
		$html[] = '</li>';
		$html[] = '</ol>';
		$html[] = '</div>';


		if ($this->status->plugins) {
			$html[] = $this->renderPluginInfoInstall($this->status->plugins);
		}

		if ($this->status->modules) {
			$html[] = $this->renderModuleInfoInstall($this->status->modules);
		}
        if($this->status->cb) {
            $html[] = '<br /><span style="color:green;">Community builder detected. CB plugin installed!</span>';
        }

		return implode('', $html);
	}

	public function displayInfoUninstallation()
	{
		$html[] = '<div class="header">Hotspots is now removed from your system</div>';
		if ($this->droppedTables) {
			$html[] = '<p>The option uninstall complete mode was set to true. Database tables were removed</p>';
		} else {
			$html[] = '<p>The option uninstall complete mode was set to false. The database tables were not removed.</p>';
		}

		$html[] = $this->renderPluginInfoUninstall($this->status->plugins);
		$html[] = $this->renderModuleInfoUninstall($this->status->modules);

		return implode('', $html);
	}

}

class CompojoomInstaller
{
	public function loadLanguage()
	{
		$extension = $this->extension;
		$jlang =& JFactory::getLanguage();
		$path = $this->parent->getParent()->getPath('source') . '/administrator';
		$jlang->load($extension, $path, 'en-GB', true);
		$jlang->load($extension, $path, $jlang->getDefault(), true);
		$jlang->load($extension, $path, null, true);
		$jlang->load($extension . '.sys', $path, 'en-GB', true);
		$jlang->load($extension . '.sys', $path, $jlang->getDefault(), true);
		$jlang->load($extension . '.sys', $path, null, true);
	}

	public function installModules($modulesToInstall)
	{
		$src = $this->parent->getParent()->getPath('source');
		$status = array();
		// Modules installation
		if (count($modulesToInstall)) {
			foreach ($modulesToInstall as $folder => $modules) {
				if (count($modules)) {
					foreach ($modules as $module => $modulePreferences) {
						// Install the module
						if (empty($folder)) {
							$folder = 'site';
						}
						$path = "$src/modules/$module";
						if ($folder == 'admin') {
							$path = "$src/administrator/modules/$module";
						}
						if (!is_dir($path)) {
							continue;
						}
						$db = JFactory::getDbo();
						// Was the module alrady installed?
						$sql = 'SELECT COUNT(*) FROM #__modules WHERE `module`=' . $db->Quote($module);
						$db->setQuery($sql);
						$count = $db->loadResult();
						$installer = new JInstaller;
						$result = $installer->install($path);
						$status[] = array('name' => $module, 'client' => $folder, 'result' => $result);
						// Modify where it's published and its published state
						if (!$count) {
							list($modulePosition, $modulePublished) = $modulePreferences;
							$sql = "UPDATE #__modules SET position=" . $db->Quote($modulePosition);
							if ($modulePublished) $sql .= ', published=1';
							$sql .= ', params = ' . $db->quote($installer->getParams());
							$sql .= ' WHERE `module`=' . $db->Quote($module);
							$db->setQuery($sql);
							$db->query();

//	                        get module id
							$db->setQuery('SELECT id FROM #__modules WHERE module = ' . $db->quote($module));
							$moduleId = $db->loadObject()->id;

							// insert the module on all pages, otherwise we can't use it
							$query = 'INSERT INTO #__modules_menu(moduleid, menuid) VALUES (' . $db->quote($moduleId) . ' ,0 );';
							$db->setQuery($query);

							$db->query();
						}
					}
				}
			}
		}
		return $status;
	}

	public function uninstallModules($modulesToUninstall)
	{
		$status = array();
		if (count($modulesToUninstall)) {
			$db = JFactory::getDbo();
			foreach ($modulesToUninstall as $folder => $modules) {
				if (count($modules)) {

					foreach ($modules as $module => $modulePreferences) {
						// Find the module ID
						$db->setQuery('SELECT `extension_id` FROM #__extensions WHERE `element` = '
							. $db->Quote($module) . ' AND `type` = "module"');

						$id = $db->loadResult();
						// Uninstall the module
						$installer = new JInstaller;
						$result = $installer->uninstall('module', $id, 1);
						$status[] = array('name' => $module, 'client' => $folder, 'result' => $result);
					}
				}
			}
		}
		return $status;
	}

	public function installPlugins($plugins)
	{
		$src = $this->parent->getParent()->getPath('source');

		$db = JFactory::getDbo();
		$status = array();

		foreach ($plugins as $plugin => $published) {
			$parts = explode('_', $plugin);
			$pluginType = $parts[1];
			$pluginName = $parts[2];

			$path = $src . "/plugins/$pluginType/$pluginName";

			$query = "SELECT COUNT(*) FROM  #__extensions WHERE element=" . $db->Quote($pluginName) . " AND folder=" . $db->Quote($pluginType);

			$db->setQuery($query);
			$count = $db->loadResult();

			$installer = new JInstaller;
			$result = $installer->install($path);
			$status[] = array('name' => $plugin, 'group' => $pluginType, 'result' => $result);

			if ($published && !$count) {
				$query = "UPDATE #__extensions SET enabled=1 WHERE element=" . $db->Quote($pluginName) . " AND folder=" . $db->Quote($pluginType);
				$db->setQuery($query);
				$db->query();
			}
		}

		return $status;
	}

	public function uninstallPlugins($plugins)
	{
		$db = JFactory::getDbo();
		$status = array();

		foreach ($plugins as $plugin => $published) {
			$parts = explode('_', $plugin);
			$pluginType = $parts[1];
			$pluginName = $parts[2];
			$db->setQuery('SELECT `extension_id` FROM #__extensions WHERE `type` = "plugin" AND `element` = ' . $db->Quote($pluginName) . ' AND `folder` = ' . $db->Quote($pluginType));

			$id = $db->loadResult();

			if ($id) {
				$installer = new JInstaller;
				$result = $installer->uninstall('plugin', $id, 1);
				$status[] = array('name' => $plugin, 'group' => $pluginType, 'result' => $result);
			}
		}

		return $status;
	}

	/*
		  * get a variable from the manifest file (actually, from the manifest cache).
		  */
	public function getParam($name)
	{
		$db = JFactory::getDbo();
		$db->setQuery('SELECT manifest_cache FROM #__extensions WHERE name = ' . $db->quote($name));
		$manifest = json_decode($db->loadResult(), true);
		return $manifest[$name];
	}

	public function renderModuleInfoInstall($modules) {
		$rows = 0;

		$html = array();
		if (count($modules)) {
			$html[] = '<table>';
			$html[] = '<tr>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) .'_MODULE') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) .'_CLIENT') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) .'_STATUS') . '</th>';
			$html[] = '</tr>';
			foreach ($modules as $module) {
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $module['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($module['client']) . '</td>';
				$html[] = '<td>';
				$html[] = '<span style="color:' . (($module['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($module['result']) ? JText::_(strtoupper($this->extension) .'_MODULE_INSTALLED') : JText::_(strtoupper($this->extension) .'_MODULE_NOT_INSTALLED');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = '</tr>';
			}
			$html[] = '</table>';
		}


		return implode('', $html);
	}

	public function renderModuleInfoUninstall($modules)
	{
		$rows = 0;
		$html = array();
		if (count($modules)) {
			$html[] = '<table>';
			$html[] = '<tr>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_MODULE') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_CLIENT') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_STATUS') . '</th>';
			$html[] = '</tr>';
			foreach ($modules as $module) {
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $module['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($module['client']) . '</td>';
				$html[] = '<td>';
				$html[] = '<span style="color:' . (($module['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($module['result']) ? JText::_(strtoupper($this->extension) . '_MODULE_UNINSTALLED') : JText::_(strtoupper($this->extension) . '_MODULE_COULD_NOT_UNINSTALL');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = '</tr>';
			}
			$html[] = '</table>';
		}

		return implode('', $html);
	}

	public function renderPluginInfoInstall($plugins)
	{
		$rows = 0;
		$html[] = '<table>';
		if (count($plugins)) {
			$html[] = '<tr>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_PLUGIN') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_GROUP') . '</th>';
			$html[] = '<th>' . JText::_(strtoupper($this->extension) . '_STATUS') . '</th>';
			$html[] = '</tr>';
			foreach ($plugins as $plugin) {
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $plugin['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($plugin['group']) . '</td>';
				$html[] = '<td>';
				$html[] = '<span style="color: ' . (($plugin['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($plugin['result']) ? JText::_(strtoupper($this->extension) . '_PLUGIN_INSTALLED') : JText::_(strtoupper($this->extension) . 'PLUGIN_NOT_INSTALLED');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = '</tr>';
			}
		}
		$html[] = '</table>';

		return implode('', $html);
	}

	public function renderPluginInfoUninstall($plugins)
	{
		$rows = 0;
		$html = array();
		if (count($plugins)) {
			$html[] = '<table>';
			$html[] = '<tbody>';
			$html[] = '<tr>';
			$html[] = '<th>Plugin</th>';
			$html[] = '<th>Group</th>';
			$html[] = '<th></th>';
			$html[] = '</tr>';
			foreach ($plugins as $plugin) {
				$html[] = '<tr class="row' . (++$rows % 2) . '">';
				$html[] = '<td class="key">' . $plugin['name'] . '</td>';
				$html[] = '<td class="key">' . ucfirst($plugin['group']) . '</td>';
				$html[] = '<td>';
				$html[] = '	<span style="color:' . (($plugin['result']) ? 'green' : 'red') . '; font-weight: bold;">';
				$html[] = ($plugin['result']) ? JText::_(strtoupper($this->extension) . '_PLUGIN_UNINSTALLED') : JText::_(strtoupper($this->extension) . '_PLUGIN_NOT_UNINSTALLED');
				$html[] = '</span>';
				$html[] = '</td>';
				$html[] = ' </tr> ';
			}
			$html[] = '</tbody > ';
			$html[] = '</table > ';
		}

		return implode('', $html);
	}

	/**
	 * method to run before an install/update/discover method
	 *
	 * @param $type
	 * @param $parent
	 * @return void
	 */
	public function preflight($type, $parent)
	{
		$jversion = new JVersion();

		// Extract the version number from the manifest file
		$this->release = $parent->get("manifest")->version;

		// Find mimimum required joomla version from the manifest file
		$this->minimum_joomla_release = $parent->get("manifest")->attributes()->version;

		if (version_compare($jversion->getShortVersion(), $this->minimum_joomla_release, 'lt')) {
			Jerror::raiseWarning(null, 'Cannot install ' . $this->extension . ' in a Joomla release prior to '
				. $this->minimum_joomla_release);
			return false;
		}

		// abort if the component being installed is not newer than the currently installed version
		if ($type == 'update') {
			$oldRelease = $this->getParam('version');
			$rel = $oldRelease . ' to ' . $this->release;
			if (!strstr($this->release, 'git_')) {
				if (version_compare($this->release, $oldRelease, 'lt')) {
					Jerror::raiseWarning(null, 'Incorrect version sequence. Cannot upgrade ' . $rel);
					return false;
				}
			}
		}

	}

	/**
	 * method to update the component
	 *
	 * @param $parent
	 * @return void
	 */
	public function update($parent)
	{
		$this->parent = $parent;
	}

	/**
	 * method to install the component
	 *
	 * @param $parent
	 * @return void
	 */
	public function install($parent)
	{
		$this->parent = $parent;

	}

}

class hotspotsInstallerDatabase
{

	public function updateDatabaseStructure205()
	{
		$db = JFactory::getDBO();
		$query = 'ALTER TABLE ' . $db->quoteName('#__hotspots_categorie') . ' ADD `cat_image` VARCHAR( 255 ) NOT NULL ';
		$db->setQuery($query);
		$db->query();
		$query = 'ALTER TABLE ' . $db->quoteName('#__hotspots_marker') .
			' CHANGE `description_small` `description_small` MEDIUMTEXT
				CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ';
		$db->setQuery($query);
		$db->query();
	}

	public function updateSettings204()
	{
		$db = JFactory::getDBO();
		$query = 'INSERT INTO ' . $db->quoteName('#__hotspots_settings') . " (`title`, `value`, `values`, `type`, `catdisp`) VALUES
	('hotspots_order', 'name ASC', '{name ASC=Hotspots name}{name DESC=Hotspots name (desc)}{postdate ASC=Date}{postdate DESC=Date (desc)}', 'select', 'layout');";
		$db->setQuery($query);
		$db->query();
	}

	public function updateVersionNumber()
	{
		$db = JFactory::getDBO();
		$query = 'UPDATE ' . $db->quoteName('#__hotspots_settings')
			. ' SET value = ' . $db->Quote('@@VERSION@@')
			. ' WHERE title = ' . $db->Quote('version');
		$db->setQuery($query);
		$db->query();
	}


	function updateSettings1b()
	{
		$db = JFactory::getDBO();

		$query = 'SELECT count(*) as count FROM ' . $db->quoteName('#__hotspots_settings');

		$db->setQuery($query);

		$count = $db->loadObject();

		/**
		 * In the first versions there were only 53 settings
		 */
		if ($count->count > 53) {
			$query = 'DELETE FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE id > 53';
			$db->setQuery($query);
			$db->Query();
		}

		$updateQuery = 'UPDATE ' . $db->quoteName('#__hotspots_settings')
			. ' SET '
			. $db->quoteName('value') . '=' . $db->Quote('default') . ','
			. $db->quoteName('values') . '=' . $db->Quote('{default=default}')
			. ' WHERE ' . $db->quoteName('title') . '=' . $db->Quote('template');
		$db->setQuery($updateQuery);
		$db->Query();

		$query = 'INSERT INTO ' . $db->quoteName('#__hotspots_settings') . " (`title`, `value`, `values`, `type`, `catdisp`) VALUES
	('footer', '1', '{0=No}{1=Yes}', 'select', 'layout'),
	('complete_uninstall', '0', '{0=No}{1=Yes}', 'select', 'advanced');";

		$db->setQuery($query);
		$db->Query();

		$updateCategory = 'ALTER TABLE ' . $db->quoteName('#__hotspots_categorie')
			. ' ADD count INT( 11 ) NOT NULL ';
		$db->setQuery($updateCategory);
		$db->Query();

		/**
		 * update count for markers
		 */
		countCategoryMarker();
	}

	public function countCategoryMarker()
	{
		$db = JFactory::getDBO();

		$query = 'SELECT id FROM ' . $db->quoteName('#__hotspots_categorie');
		$db->setQuery($query);

		$catIds = $db->loadColumn();

		$insertQuery = '';
		foreach ($catIds as $key => $value) {
			$query = ' SELECT COUNT(*) FROM ' . $db->quoteName('#__hotspots_marker')
				. ' WHERE catid = ' . $db->Quote($value)
				. ' AND published = ' . $db->Quote(1);
			$db->setQuery($query);
			$count = $db->loadRow();
			$insert = ' UPDATE ' . $db->quoteName('#__hotspots_categorie') . ' AS c '
				. ' SET c.count = ' . $db->Quote($count[0])
				. ' WHERE c.id = ' . $db->Quote($value)
				. ';';
			$insertQuery .= $insert;
		}
		$db->setQuery($insertQuery);
		$db->queryBatch();
	}

	public function insertNewSettings()
	{
		$db = JFactory::getDBO();
		$query = 'INSERT INTO ' . $db->quoteName('#__hotspots_settings')
			. " (`title`, `value`, `values`, `type`, `catdisp`) VALUES
			('show_welcome_text', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('welcome_text', 'Welcome,<br /><br />to Hotspots google map manager for Joomla 2.5 by Compojoom. The documentation, forums and more you can find at <a href=\"http://www.compojoom.com\" target=\"_blank\">www.compojoom.com</a><br /><br />\r\n\r\nYou can edit or switch off this text in the backend', '', 'textarea', 'basic'),
			('map_type', '0', '{0=All types}{1=Only Map}{2=Only satellite}{3=Only Hybrid}{4=Only Physical}', 'select', 'basic'),
			('map_height', '600', '', 'text', 'layout'),
			('map_startposition', 'Karlsruhe, Germany', '', 'text', 'basic'),
			('map_startzoom', '10', '', 'text', 'basic'),
			('show_address', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('show_address_country', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('show_date', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('date_format', 'Y-m-d H:i:s', '', 'text', 'basic'),
			('show_author', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('hotspot_detailpage', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('addhs_autopublish', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('rss_enable', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('print_map', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('category_info', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('mail_map', '1', '{0=No}{1=Yes}', 'select', 'basic'),
			('template', 'default', '{default=default}', 'select', 'layout'),
			('show_marker_count', '1', '{0=No}{1=Yes}', 'select', 'layout'),
			('number_of_cats_to_show', '4', '', 'text', 'layout'),
			('category_ordering', 'id ASC', '{id ASC=Id}{id DESC=Id (desc)}{cat_name ASC=Category name}{cat_name DESC=Category name (desc)}{cat_date ASC=Date}{cat_date DESC=Date (desc)}', 'select', 'layout'),
			('hotspots_order', 'name ASC', '{name ASC=Hotspots name}{name DESC=Hotspots name (desc)}{postdate ASC=Date}{postdate DESC=Date (desc)}', 'select', 'layout'),
			('gm_control', '1', '{0=none}{1=Big controls}{2=Small controls}{3=Small zoom}{4=Overviewmap}', 'select', 'layout'),
			('gm_control_pos', 'topLeft', '{topLeft=topLeft}{topRight=topRight}{bottomLeft=bottomLeft}{bottomRight=bottomRight}', 'select', 'layout'),
			('search_zoom', '14', '', 'text', 'advanced'),
			('addhs_picture', '1', '{0=No}{1=Yes}{2=Only registered}', 'select', 'advanced'),
			('addhs_adminmail', '1', '{0=No}{1=Yes}', 'select', 'advanced'),
			('addhs_adminusertypes', 'Super Administrator', '{Super Administrator=Super Administrator}{Administrator=Administrator}{Editor=Editor}{Manager=Manager}', 'select', 'advanced'),
			('rss_logopath', 'media/com_hotspots/images/utils/logo.jpg', '', 'text', 'advanced'),
			('rss_limit', '50', '', 'text', 'advanced'),
			('rss_type', '0', '{0=Rss 2.0}{1=RSS 1.0}{3=Atom}', 'select', 'advanced'),
			('picturethumb_width', '80', '', 'text', 'advanced'),
			('picturethumb_height', '80', '', 'text', 'advanced'),
			('map_static_width', '500', '', 'text', 'advanced'),
			('map_static_height', '300', '', 'text', 'advanced'),
			('josc_support', '0', '{0=No}{1=Yes}', 'select', 'advanced'),
			('marker_allow_plugin', '0', '{0=No}{1=Yes}', 'select', 'advanced'),
			('footer', '1', '{0=No}{1=Yes}', 'select', 'layout'),
			('resize_map', '1', '{0=No}{1=Yes}', 'select', 'layout'),
			('complete_uninstall', '0', '{0=No}{1=Yes}', 'select', 'advanced'),
			('captcha', '0', '{0=No}{1=Yes}', 'select', 'security'),
			('recaptcha_public_key', '', '', 'text', 'security'),
			('recaptcha_private_key', '', '', 'text', 'security'),
			('version','@@VERSION@@','','','version'),
			('user_interface', '0', '{0=European}{1=American}', 'select', 'layout');";
		$db->setQuery($query);
		$db->Query();
	}

	/**
	 * This function checks if we are updating and if true from which version
	 * @return string
	 */
	public function checkIfUpdating()
	{
		$update = 'new';
		$db = JFactory::getDBO();

        $query = 'SHOW TABLES LIKE ' . $db->q($db->replacePrefix('#__hotspots_settings'));
        $db->setQuery($query);

        if($db->loadObject()) {
            $query = 'SELECT * FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE title = ' . $db->Quote('api_key');

            $db->setQuery($query);
            $update1b = $db->loadObject();

            if ($update1b) {
                $update = '1b';
            }

            $query = 'SELECT * FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE title = ' . $db->Quote('complete_uninstall');

            $db->setQuery($query);
            $update1b2 = $db->loadObject();

            $folder = JPATH_ROOT . '/components/com_hotspots/views/all';
            if ($update1b2 && JFolder::exists($folder)) {
                $update = '1b2';
            }

            $query = 'SELECT count(*) as count FROM ' . $db->quoteName('#__hotspots_settings');

            $db->setQuery($query);
            $stable = $db->loadObject();

            $fileThatShouldNotExistInStable = JPATH_ROOT . '/media/com_hotspots/js/utils.js';
            // in 1.0 stable there were exactly 55 settings
            if ($stable->count == 55 && !JFile::exists($fileThatShouldNotExistInStable)) {
                $update = '1stable';
            }


            $query = 'SELECT * FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE title = ' . $db->Quote('version');

            $db->setQuery($query);
            $dbVersion = $db->loadObject();

            if ($dbVersion) {
                $update = $dbVersion->value;
            }
        }

		return $update;
	}

	public function isCompleteUninstall()
	{
		$db = JFactory::getDBO();
		$query = 'SELECT * FROM ' . $db->quoteName('#__hotspots_settings') . ' WHERE title = "complete_uninstall"';
		$db->setQuery($query);
		$completeUninstall = $db->loadObject();

		if (is_object($completeUninstall)) {
			return $completeUninstall->value;
		}

		return false;
	}

	public function updateDatabaseStructureTo3_0()
	{
		$db = JFactory::getDbo();
		$db->setQuery(
			"ALTER TABLE `#__hotspots_marker`
			ADD `asset_id` int(11) NOT NULL COMMENT 'FK to #__assets',
			ADD `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `modified_by` int(11) NOT NULL,
			ADD `params` text NOT NULL,
			ADD `language` char(7) NOT NULL,
			ADD `access` int(10) unsigned NOT NULL DEFAULT '0',
			ADD `import_table` varchar(255) NOT NULL COMMENT 'If we import data from 3rd party components we store the table_id here',
			ADD `import_id` int(11) NOT NULL COMMENT 'Original id of the stored object',
			CHANGE `autoruserid` `created_by` int(11) NOT NULL,
			CHANGE `autor` `created_by_alias` varchar(255) NOT NULL,
			CHANGE `autorip` `created_by_ip` int(11) unsigned NOT NULL,
			CHANGE `postdate` `created` datetime NOT NULL,
			ADD KEY `gmlat` (`gmlat`),
            ADD KEY `gmlng` (`gmlng`),
            ADD KEY `catid` (`catid`);");
		$db->query();

		$db->setQuery(
			"ALTER TABLE `#__hotspots_categorie`
				ADD `import_table` varchar(255) NOT NULL COMMENT 'If we import data from 3rd party components we store the table_id here',
				ADD `import_id` int(11) NOT NULL COMMENT 'Original id of the stored object';
			");
		$db->query();

		$db->setQuery(
			"CREATE TABLE IF NOT EXISTS `#__hotspots_kmls` (
			  `hotspots_kml_id` bigint(20) NOT NULL AUTO_INCREMENT,
			  `catid` int(11) NOT NULL COMMENT 'FK to #__hotspots_categorie',
			  `original_filename` varchar(1024) NOT NULL,
			  `mangled_filename` varchar(1024) NOT NULL,
			  `mime_type` varchar(255) NOT NULL DEFAULT 'application/octet-stream',
			  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			  `created_by` bigint(20) NOT NULL DEFAULT '0',
			  `status` tinyint(4) NOT NULL DEFAULT '1',
			  PRIMARY KEY (`hotspots_kml_id`)
			) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;");
		$db->query();

	}

    public function updateKMLStructureTo3_0_1(){
        $db = JFactory::getDbo();
        $db->setQuery(
            "ALTER TABLE `#__hotspots_kmls`
			ADD `title` varchar(255) NOT NULL ,
			ADD `description` text NOT NULL,
			CHANGE `created_on` `created` datetime NOT NULL,
			CHANGE `status` `state` tinyint(4) NOT NULL DEFAULT '1';");
        $db->query();
    }

    public function updateCategoriesTiles3_1() {
        $db = JFactory::getDbo();
        $db->setQuery(
            "ALTER TABLE `#__hotspots_categorie`
			ADD `params` TEXT NOT NULL;");
        $db->query();
    }

	public function updateSettingsTo3_0()
	{
		$db = JFactory::getDbo();
		$db->setQuery(
			"DELETE FROM `#__hotspots_settings`
			WHERE `title` = 'addhs_user'
			OR `title` = 'addhs_adminmail'
			OR `title` = 'addhs_adminusertypes'"
		);
		$db->query();

		$db->setQuery('UPDATE `#__hotspots_settings` SET value = "Y-m-d H:i:s"
			WHERE title = "date_format"');
		$db->query();
	}

    public function updateMenuTo3_0() {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*')->from('#__menu')
            ->where('link = "index.php?option=com_hotspots&view=hotspots" AND client_id = 0');

        $db->setQuery($query, 0,1);

        $menu = $db->loadObject();

        if($menu) {
            $params = json_decode($menu->params);

            if(isset($params->hs_startcat) && is_string($params->hs_startcat)) {
                $params->hs_startcat = array($params->hs_startcat);
                $query->update('#__menu')->set('params = '.$db->quote(json_encode($params)))->where('id = ' .$db->quote($menu->id));
                $db->setQuery($query);
                $db->query();
            }
        }
    }

    public function updateHotspots3_1_1() {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->update('#__hotspots_marker')->set($db->qn('access') . '=' . $db->q(1))
            ->where($db->qn('access') . '=' . $db->q(0));
        $db->setQuery($query);
        $db->query();
    }

    /**
     * need to fix a bug introduced with 3.2 - added the settings twice during update
     */
    public function updateHotspots3_2() {
        $db = JFactory::getDbo();

        $query = 'DELETE ' . $db->qn('t1') . ' FROM ' .$db->qn('#__hotspots_settings') .' AS '
            . $db->qn('t1') . ' JOIN ' . $db->qn('#__hotspots_settings') . ' AS ' . $db->qn('t2')
            . ' ON ' . $db->qn('t1.id'). '>'.$db->qn('t2.id')
            . ' AND ' . $db->qn('t1.title') . ' = ' . $db->qn('t2.title');
        $db->setQuery($query);
        $db->query();
    }

	public function dropTables()
	{
		$db =& JFactory::getDBO();
		$dropTables = 'DROP TABLE ' . $db->quoteName('#__hotspots_marker') . ';';
		$dropTables .= 'DROP TABLE ' . $db->quoteName('#__hotspots_categorie') . ';';
		$dropTables .= 'DROP TABLE ' . $db->quoteName('#__hotspots_settings') . ';';
		$dropTables .= 'DROP TABLE ' . $db->quoteName('#__hotspots_kmls') . ';';

		$db->setQuery($dropTables);
		$db->queryBatch();

		return true;
	}


}

class hotspotsInstallerFiles
{
	public function dropToolbars()
	{
		$toolbar_rem = (JPATH_BASE . '/components/com_hotspots/toolbar.hotspots.html.php');
		$toolbar2_rem = (JPATH_BASE . '/components/com_hotspots/toolbar.hotspots.php');
		if (file_exists($toolbar_rem)) {
			unlink($toolbar_rem);
		}
		if (file_exists($toolbar2_rem)) {
			unlink($toolbar2_rem);
		}
	}

	/**
	 * This function moves files to the media folder and deletes
	 * unnecessary folders
	 */
	public function updateFiles()
	{
		jimport('joomla.filesystem');
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$frontendPath = JPATH_ROOT . '/components/com_hotspots/';


		$filesToMove = array(
			'frontend' => array(
				'categories' => $frontendPath . 'images/categories',
				'hotspots' => $frontendPath . 'images/hotspots',
				'thumbs' => $frontendPath . 'images/thumbs',
				'utils' => $frontendPath . 'images/utils'
			)
		);

		$foldersToDelete = array(
			'backend' => array(
				$adminPath . 'images',
			),
			'frontend' => array(
				$frontendPath . 'js',
				$frontendPath . 'lang',
				$frontendPath . 'images'
			)
		);

		$filesToDelete = array(
			'backend' => array(
				$adminPath . 'admin.hotspots.html.php',
				$adminPath . 'install.mysql.sql',
				$adminPath . 'uninstall.mysql.sql',
				$adminPath . 'helpers/feed.php',
				$adminPath . 'sql/unistall.mysql.sql'
			),
			'frontend' => array(
				$frontendPath . 'hotspots.css',
				$frontendPath . 'hotspots.html.php',
				$frontendPath . 'views/all/tmpl/default.css',
				$frontendPath . 'views/all/tmpl/default_old.css',
				$frontendPath . 'views/all/tmpl/default_old.php',
				$frontendPath . 'views/all/tmpl/default_slider_old.php',
				$frontendPath . 'views/all/tmpl/slider.css',
				$frontendPath . 'views/all/tmpl/slider_old.css',
				$frontendPath . 'views/all/tmpl/default_slider.php',
				$frontendPath . 'views/all/tmpl/border_watcher.css'
			)
		);

		$captchaPath = $frontendPath . 'captcha';

		$exclude = array('.svn', 'CVS', 'captcha.PNG', 'XFILES.TTF', 'index.html');
		$captchaImages = JFolder::files($captchaPath, $filter = '.', false, false, $exclude);

		if (is_array($captchaImages) && !empty($captchaImages)) {
			foreach ($captchaImages as $captchaImage) {
				JFile::delete($captchaPath . '/' . $captchaImage);
			}
		}

		foreach ($filesToMove as $pathToFiles) {
			foreach ($pathToFiles as $key => $pathToFile) {
				if (JFolder::exists($pathToFile)) {
					$oldDestination = $frontendPath . 'images/' . $key . '/';
					$moveTo = JPATH_ROOT . '/media/com_hotspots/images/' . $key . '/';
					$files = JFolder::files($pathToFile);
					foreach ($files as $file) {
						if (!JFile::exists($moveTo . $file)) {
							JFile::move($oldDestination . $file, $moveTo . $file);
						}
					}
				}
			}
		}

		foreach ($foldersToDelete as $pathToFolders) {
			foreach ($pathToFolders as $pathToFolder) {
				if (JFolder::exists($pathToFolder)) {
					JFolder::delete($pathToFolder);
				}
			}
		}

		foreach ($filesToDelete as $paths) {
			foreach ($paths as $path) {
				if (JFile::exists($path)) {
					JFile::delete($path);
				}
			}
		}
	}

	public function updateFiles1stable()
	{
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$frontendPath = JPATH_ROOT . '/components/com_hotspots/';
		$mediaPath = JPATH_ROOT . '/media/com_hotspots/';

		$foldersToDelete = array(
			'frontend' => array(
				$frontendPath . 'captcha',
				$frontendPath . 'views/all',
				$frontendPath . 'views/getcords',
				$frontendPath . 'views/gethotspots',
				$frontendPath . 'views/popupmail',
				$frontendPath . 'views/showaddhotspot',
			),
			'media' => array(
				$mediaPath . 'captcha'
			)
		);

		$filesToDelete = array(
			'backend' => array(
				$adminPath . 'admin.hotspots.php'
			),
			'frontend' => array(
				$frontendPath . 'controller.php',
				$frontendPath . 'models/all.php',
				$frontendPath . 'models/getcords.php',
				$frontendPath . 'models/gethotspots.php',
				$frontendPath . 'models/popupmail.php',
				$frontendPath . 'models/showaddhotspot.php',
			),
			'media' => array(
				$mediaPath . 'css/border_watcher.css',
				$mediaPath . 'js/borderwatcher.js',
				$mediaPath . 'js/progressbarcontrol_packed.js',
				$mediaPath . 'js/hsslider.js',
				$mediaPath . 'images/utils/bg-foot.gif',
				$mediaPath . 'images/utils/gps.png',
				$mediaPath . 'images/utils/hr-space.png',
				$mediaPath . 'images/utils/map_overlay_black.png',
				$mediaPath . 'images/utils/map_overlay_blue.png',
				$mediaPath . 'images/utils/map_overlay_close.png',
				$mediaPath . 'images/utils/map_overlay_red.png',
				$mediaPath . 'images/utils/map_overlay_white.png',
				$mediaPath . 'images/utils/map_overlay_yellow.png',
				$mediaPath . 'images/utils/open.png',
				$mediaPath . 'images/utils/satellite.png',
				$mediaPath . 'images/utils/thumb_up_icon.gif',
				$mediaPath . 'images/utils/arrow-up.png',
				$mediaPath . 'images/utils/categories.png',
				$mediaPath . 'images/utils/city-48x48.png',
				$mediaPath . 'images/utils/city.png',
				$mediaPath . 'images/utils/dialog_close.png',
				$mediaPath . 'images/utils/hybrid.png',
				$mediaPath . 'images/utils/info_off.gif',
				$mediaPath . 'images/utils/left.gif',
				$mediaPath . 'images/utils/right.gif',
				$mediaPath . 'images/utils/terrain.png',
				$mediaPath . 'images/utils/map.png',
				$mediaPath . 'images/utils/menu.gif',
				$mediaPath . 'images/utils/menu_small.gif',
				$mediaPath . 'images/utils/mini-categories.png',
				$mediaPath . 'images/utils/Mountain-32x32.png',
				$mediaPath . 'images/utils/reset-map.png',
				$mediaPath . 'images/utils/thumb_down_icon.gif',
				$mediaPath . 'images/utils/117043-matte-blue-and-white-square-icon-business-printer.png'
			)
		);


		foreach ($foldersToDelete as $pathToFolders) {
			foreach ($pathToFolders as $pathToFolder) {
				if (JFolder::exists($pathToFolder)) {
					JFolder::delete($pathToFolder);
				}
			}
		}

		foreach ($filesToDelete as $paths) {
			foreach ($paths as $path) {
				if (JFile::exists($path)) {
					JFile::delete($path);
				}
			}
		}
	}

	/**
	 * removes unnecessary files and folders from beta2
	 */
	public function updateFilesBeta2()
	{
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$frontendPath = JPATH_ROOT . '/components/com_hotspots/';
		$mediaPath = JPATH_ROOT . '/media/com_hotspots/';

		$foldersToDelete = array(
			'frontend' => array(
				$frontendPath . 'views/mailsent',
				$frontendPath . 'views/getold',
			)
		);

		$filesToDelete = array(
			'frontend' => array(
				$frontendPath . 'models/mailsent.php',
				$frontendPath . 'models/getold.php',
			),
			'media' => array(
				$mediaPath . 'js/utils.js'
			)
		);

		foreach ($foldersToDelete as $pathToFolders) {
			foreach ($pathToFolders as $pathToFolder) {
				if (JFolder::exists($pathToFolder)) {
					JFolder::delete($pathToFolder);
				}
			}
		}

		foreach ($filesToDelete as $paths) {
			foreach ($paths as $path) {
				if (JFile::exists($path)) {
					JFile::delete($path);
				}
			}
		}
	}

	public function updateFilesTo3_0()
	{
		$adminPath = JPATH_ADMINISTRATOR . '/components/com_hotspots/';
		$mediaPath = JPATH_ROOT . '/media/com_hotspots/';

		$filesToDelete = array(
			'backend' => array(
				$adminPath . 'admin.utils.php',
				$adminPath . 'install.hotspots.php',
				$adminPath . 'uninstall.hotspots.php',
				$adminPath . 'mootools.php',
			),
			'media' => array(
				$mediaPath . 'js/Hotspots.Add.Backend.js',
				$mediaPath . 'js/Hotspots.Add.js',
				$mediaPath . 'js/Hotspots.Backend.js',
				$mediaPath . 'js/Hotspots.Categories.js',
				$mediaPath . 'js/Hotspots.Helper.js',
				$mediaPath . 'js/Hotspots.Hotspot.js',
				$mediaPath . 'js/Hotspots.js',
				$mediaPath . 'js/Hotspots.Layout.js',
				$mediaPath . 'js/Hotspots.Layout.Hotspot.js',
				$mediaPath . 'js/Hotspots.Layout.Hotspots.js',
				$mediaPath . 'js/Hotspots.Slide.js',
				$mediaPath . 'js/Hotspots.Tab.js',
			)
		);

		foreach ($filesToDelete as $paths) {
			foreach ($paths as $path) {
				if (JFile::exists($path)) {
					JFile::delete($path);
				}
			}
		}

	}
}