<?php
/**
 * @version	$Id: chnagelog.php
 * @package	hotspots
 * @copyright	Copyright (C) 2008 - 2010 Compojoom.com. All rights reserved.
 * @license	GNU/GPL
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
Changelog
------------
This is a non-exhaustive (but still near complete) changelog for
Hotspots, including beta and release candidate versions.
Our thanks to all those people who've contributed bug reports and
code fixes.
The bug tracker can be found at http://dev.compojoom.com/projects/hotspots/issues

Legend:

* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note

-------------------- 2.0.5 stable [29-July-2011]----------------
Bug #692: search text behind category icons
Bug #693: wrong text on top of search results
Bug #709: unpublished hotspots showing in search results
Bug #710: Tool-tips in backends are cut off
Bug #712: Geocoding of addresses missing
Bug #714: Wrong link to hotspot in jomsocial latest activity
Bug #723: Can't hide page title on Joomla 1.7
Feature #694: Include category name in search results
Feature #707: Organize category list
Feature #715: fireEvent when searching
Language #713: Add swedish translation to 2.0.5

-------------------- 2.0.4 stable [18-July-2011]----------------
Bug #662: Missing shadow brakes map
Bug #663: Saving link to content or sobi2 not working
Bug #664: Search results tab problems
Bug #665: results are not in alphabetical order
Bug #666: submit button is hidden
Bug #667: Improve address output
Bug #675: Thumbnails not having the proper size
Bug #676: Show menu set to 0 doesn't hide the categories selection
Bug #678: close streetView when searching for a direction
Bug #679: Missing translations
Bug #688: Live update config is missing
Feature #668: Add a clear route button
Feature #677: Quick search near categories
Language #680: Add french translation

-------------------- 2.0.3 stable [12-July-2011]----------------
# Updated live update, fixing an annoying bug - a big thank you to Nick from AkeebaBackup!

-------------------- 2.0.2 stable [10-July-2011]----------------
#659: street view not taking in account the size of the page
#660: Saving of a hotspot was deleting all the html in description

-------------------- 2.0.1 stable [6-July-2011]-----------------
# When searching for a hotspot the link to the single view was wrong 

-------------------- 2.0 stable [4-July-2011]-------------------
#239: Change the float type of lng and lat database fields
#255: editing a category deletes the marker count
#281: Wrong date in RSS
#603: Small fixes
#611: Wrong infowindow shown
+ 116: Manual Lng/Lat
+ 122: Quicker Add hotspot navigation
+ 123: Hot Spots for mobile?
+ 134: Show all markers from all categories
+ 158: google maps v3
+ 160: Add directions to single view of a hotspots
+ 188: Wrong marker icons on e-mail and print action
+ 194: user interface (USA English)
+ 251: Display a marker when we use the search option
+ 256: Message "Hotspot added"
+ 546: New map view interface
+ 547: New add hotspot view
+ 549: Remove border watcher
+ 550: Remove progressbar
+ 551: Add recaptcha support and remove the default captcha
+ 552: New interface for sending mails
+ 553: New interface for searching directions/locations/hotspots
+ 554: Fullscreen size map
+ 570: Menu - single hotspots - show list with hotspots
+ 580: Show welcome message
+ 581: Joomla 1.6 support
+ 582: Update install script
+ 591: Improve the existing router.php
+ 594: Update the backend add hotspot view
+ 595: Add option to sort the hotspots by date in backend
+ 598: Edit hotspots in frontend
+ 601: Single map view interface
+ Full german translation
+ Full Portuguese brazil translation
+ Norwegian translation
+ mootools 1.2 check on joomla 1.5 systems


-------------------- 1.0 stable [25-November-2010] -------------
^ Bug #177: Translation of 'Close' button in marker detail page not working
# Bug #178: No map displayed when route planning (routenplaner) is disabled in backend
# Bug #179: Hotspots Logo missing in Backend Informations
# Bug #180: Locations (marker) always active at backend
# Bug #182: Footer Menu to be disabled
^ Bug #187: translation string not found
^ Bug #189: Fixed english backend language.ini
# Bug #190: 'Reset Map Position'-Link does not lead to map startposition
# Bug #192: mail Send current map view (Mail)
# Bug #196: Misspellings found on various pages of Hotspots
# Bug #214: Highlight current marker brakes map
^ Bug #215: Frontend english translation reviewed and fixed some misspellings
# Bug #216: Width of table columns at backend import from sobi2
# Bug #217: Footer menu address search
^ Bug #228: correction
# Bug #229: Fatal error: call to a member function...
# Bug #230: a is null
# Bug #231: sobi2 import bug on options page
+ Feature #115: placing a marker offroad does not work
+ Feature #135: JomSocial integration
+ Feature #175: Mouse wheel zoom
+ Feature #186: Menu items need to be translated
+ Feature #207: Upload spanish translation to the download directory
+ Feature #232: Hotspot translations available in Joomfish Backend

-------------------- 1.0 beta2 [27-October-2010] ---------------
# fixed bug 103 - div overlay floating menu is not runing off
# fixed bug 104 - author of the map incorrectly handled
# markers were not loading in single view, due to js error on single view page
# borderwatcher.js and css were not loaded in single view
# fixed bug 138 sobi2 import fix
^ removed uninstall.mysql.sql file - the login is now in the uninstall file
# fixed bug 108 - location lost when editing marker
# fixed bug 109 - incorrect menu placing
# fixed bug 111 - hotspots not showing on CB Tab version 0.9.4
# fixed bug 132 - Search in description - search plugin updated
# fixed bug 136 - Route planner bug
# fixed bug 138 - Sobi2 import not working
# fixed bug 139 - userId not saved when marker added from frontend
# fixed bug 140 - only selected group can post from frontend, instead of selected group + all above it
# fixed bug 141 - new locations link doesn't work properly
# fixed bug 142 - category marker counter changes
# fixed bug 144 - The single view icon for category is now taken from the category icon
+ feature 151 - Option to disable copyright notice in the backend
- removed the slider template - only available template is default
$ fixed bug 153 - translations missing
# fixed bug 154 - Route planner mootools 1.2 / hotspots supports mootools 1.2
# fixed bug 169 - IE7 and IE8 nto loading map
# fixed bug 172 - border watcher doesn't function properly
+ complete uninstall option


-------------------- 1.0 beta1 [31-August-2010] ------------------
^ Config object is created once - saves around 50sql queries
# Bug #114 (Resolved): Map not loading caused by interlinear spacing
# Bug #113 (Resolved): Map not Loading
# Bug #101 (Resolved): Loading category hotspots with 'enter' in text
# Hotspots doesn't generate any notices anymore
# Map is not Loading in IE with Cyrillic characters
# Bug #110: Locations name does not properly encoded
# Bug #105 (Resolved): Zipcode
# Bug #106 (Resolved): Joomla User ID not captured
^ Stylesheets, images, css, captcha and moved to the media directory
- Removed the old template
$ added russian language file
! A lot of additional tweaks and changes