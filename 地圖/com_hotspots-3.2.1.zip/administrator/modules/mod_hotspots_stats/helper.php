<?php
/**
 * Compojoom Control Center
 * @package Joomla!
 * @Copyright (C) 2012 - Yves Hoppe - compojoom.com
 * @All rights reserved
 * @Joomla! is Free Software
 * @Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @version $Revision: 0.9.0 beta $
 **/

// No direct access.
defined('_JEXEC') or die;

class modHotspotsStatsHelper
{
    /**
     * @static
     * @return array
     */
    public static function getStats() {
		$all = self::countHotspots();
		$published = self::countHotspots('published = 1');
		$stats = array(
			'all' => $all,
			'published' => $published,
			'unpublished' => $all - $published
		);

		return $stats;
	}

    /**
     * @static
     * @param null $where
     * @return mixed
     */
    private static function countHotspots($where = null) {
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('COUNT(*) AS count')
			->from('#__hotspots_marker');

		if($where) {
			$query->where($where);
		}

		$db->setQuery($query);

		return $db->loadObject()->count;
	}

    /**
     *
     * @static
     * @return array - file count & total size
     */
    public static function tilesStats() {
        $path = JPATH_ROOT . '/media/com_hotspots/tiles';
        $totalSize = 0;
        $count = 0;
        foreach( new DirectoryIterator($path) as $file) {
            if($file->isFile()) {
                $totalSize += $file->getSize();
                $count += 1;
            }
        }

        return array(
            'files' => $count,
            'size' => $totalSize
        );

    }

    /**
     * @static
     * @param $size
     * @param int $precision
     * @return int|string
     */
    public static function formatBytes($size, $precision = 2)
    {
        if($size == 0) {
            return 0;
        }
        $base = log($size) / log(1024);
        $suffixes = array('', 'k', 'M', 'G', 'T');

        return round(pow(1024, $base - floor($base)), $precision) . $suffixes[floor($base)];
    }

}