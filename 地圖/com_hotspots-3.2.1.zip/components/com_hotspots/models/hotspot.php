<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.modeladmin');


class hotspotsModelHotspot extends JModelAdmin
{

	private $_hotspot = null;
	private $_id = null;
	private $_hotspots = null;
	private $_hotspotsInCategory = null;

	public function __construct($config = array())
	{
		$config['event_before_save'] = 'onBeforeHotspotSave';
		$config['event_after_save'] = 'onAfterHotspotSave';

		parent::__construct($config);

        $input = JFactory::getApplication()->input;
		$id = $input->getInt('id', 0);
		$this->_catid = $input->getInt('cat', 1);

		if ($id != 0) {
			$this->_id = $id;
		}
	}

	public function getHotspot()
	{
		$db = $this->_db;
		if (!$this->_hotspot) {
			$query = 'SELECT m.id as hotspots_id, m.* FROM ' . $db->qn('#__hotspots_marker') . ' AS m'
				. ' WHERE m.id = ' . $db->Quote($this->_id);
			$db->setQuery($query, 0, 1);
			$this->_hotspot = $db->loadObject();
			if (!$this->_hotspot->published) {
				JError::raiseError(404, "Invalid ID provided");
			}

			if ($this->_hotspot) {
				$query = 'SELECT * FROM ' . $db->qn('#__hotspots_categorie')
					. ' WHERE id = ' . $db->Quote($this->_hotspot->catid);
				$db->setQuery($query, 0, 1);
				$this->_hotspot->category = $db->loadObject();
			}
		}
		return $this->_hotspot;
	}

	public function getAllHotspots($offset = null, $limit = null)
	{
		if (!$this->_hotspotsInCategory) {
			$db = JFactory::getDBO();
			$query = 'SELECT SQL_CALC_FOUND_ROWS m.id AS hotspots_id, m.*, c.cat_icon, c.cat_shadowicon FROM ' . $db->qn('#__hotspots_marker') . ' AS m'
				. ' LEFT JOIN ' . $db->qn('#__hotspots_categorie') . 'AS c'
				. ' ON m.catid = c.id '
				. " WHERE m.published = '1'"
				. ' ORDER BY m.' . HotspotsHelper::getSettings('hotspots_order', 'name ASC');
			if ($offset >= 0 && $limit > 0) {
				$db->setQuery($query, $offset, $limit);
			} else {
				$db->setQuery($query);
			}
			$data['hotspots'] = $db->loadObjectList();

			$db->setQuery('SELECT FOUND_ROWS()');
			$data['count'] = $db->loadResult();

			$this->_hotspotsInCategory = $data;
		}
		return $this->_hotspotsInCategory;
	}

	public function getUserHotspots($userId)
	{
		$db = JFActory::getDBO();
		$query = 'SELECT m.*, c.cat_name FROM ' . $db->qn('#__hotspots_marker') . ' AS m'
			. ' LEFT JOIN ' . $db->qn('#__hotspots_categorie') . ' AS c'
			. ' ON m.catid = c.id'
			. ' WHERE m.created_by = ' . $db->Quote($userId)
			. ' ORDER BY m.' . HotspotsHelper::getSettings('hotspots_order', 'name ASC');
		$db->setQuery($query);
		return $db->loadObjectList();
	}

	public function getList()
	{
		if (!$this->_hotspots) {
			$query = "SELECT * FROM #__hotspots_marker WHERE published = '1'";
			$this->_hotspots = $this->_getList($query, 0, 0);
		}
		return $this->_hotspots;
	}

	public function search($sentence, $offset = null, $limit = null)
	{
		$db = JFactory::getDBO();
        $query = $db->getQuery(true);
		$data = array();

        $query->select('SQL_CALC_FOUND_ROWS m.id AS hotspots_id, m.*,c.*, m.params as params, c.params as cat_params')
            ->from($db->quoteName('#__hotspots_marker') . 'AS m')
            ->leftJoin($db->quoteName('#__hotspots_categorie') . 'AS c ON  m.catid = c.id')
            ->order('m.name ASC');
//      restrict by coordinates
        $this->buildWhereCoordQuery($query);
//      restrict by search term
        $this->buildWhereSearchQuery($sentence, $query);
//      restrict by general stuff such as publish, publish_up...
        $this->buildWhereGeneralQuery($query);

		$db->setQuery($query, $offset, $limit);
		$data['hotspots'] = $db->loadObjectList();

		$db->setQuery('SELECT FOUND_ROWS()');
		$data['count'] = $db->loadResult();

        // now count how many we have in the whole world
        $query->clear('select');
        $query->select('COUNT(*) AS count');
        $query->clear('where');
        $this->buildWhereSearchQuery($sentence, $query);
        $this->buildWhereGeneralQuery($query);

        $db->setQuery($query);

        $data['worldCount'] = $db->loadObject()->count;
		return $data;
	}

    public function buildWhereGeneralQuery(&$query) {
        $query->where( ' m.published = 1');
        $query->where( ' c.published = 1');

        $nullDate = $query->nullDate();
        $nowDate = $query->Quote(JFactory::getDate()->toSQL());

        $query->where('(m.publish_up = ' . $nullDate . ' OR m.publish_up <= ' . $nowDate . ')');
        $query->where('(m.publish_down = ' . $nullDate . ' OR m.publish_down >= ' . $nowDate . ')');
    }

    public function buildWhereSearchQuery($sentence, &$q) {
        $name = $q->quoteName('m.name');
        $description = $q->quoteName('m.description');
        $descriptionSmall = $q->quoteName('m.description_small');
        $plz = $q->quoteName('m.plz');
        $catName = $q->quoteName('c.cat_name');
        $street = $q->quoteName('m.name');
        $country = $q->quoteName('m.name');
        $town = $q->quoteName('m.name');
        $and = array();

        if (preg_match('/"([^"]+)"/', $sentence, $m)) {
            /*
             * example:
             * 1. "test something" else
             * will match -> "something else" AND else
             * 2. test something else
             * will match -> test OR something OR else
             */
            $searchWord = $q->Quote('%' . $q->escape(trim($m[1]), true) . '%', false);


            $search[] = $name . ' LIKE ' . $searchWord;
            $search[] = $description . ' LIKE ' . $searchWord;
            $search[] = $descriptionSmall . ' LIKE ' . $searchWord;
            $search[] = $plz . ' LIKE ' . $searchWord;
            $search[] = $catName .' LIKE ' . $searchWord;
            $search[] = $street . ' LIKE ' . $searchWord;
            $search[] = $country . ' LIKE ' . $searchWord;
            $search[] = $town . ' LIKE ' . $searchWord;

            $word = trim(str_replace('"'.$m[1].'"', '', $sentence));

            if($word) {
                $searchWord = $q->Quote('%' . $q->escape(trim($word), true) . '%', false);
                $and[] = $name. ' LIKE ' . $searchWord;
                $and[] = $description . ' LIKE ' . $searchWord;
                $and[] = $descriptionSmall . ' LIKE ' . $searchWord;
                $and[] = $plz . ' LIKE ' . $searchWord;
                $and[] = $catName . ' LIKE ' . $searchWord;
                $and[] = $street . ' LIKE ' . $searchWord;
                $and[] = $country . ' LIKE ' . $searchWord;
                $and[] = $town . ' LIKE ' . $searchWord;
            }
        } else {
            $words = explode(' ', $sentence);
            foreach ($words as $word) {
                $searchWord		= $q->Quote('%'.$q->escape($word, true).'%', false);
                $search[] = $name . ' LIKE ' . $searchWord;
                $search[] = $description . ' LIKE ' . $searchWord;
                $search[] = $descriptionSmall . ' LIKE ' . $searchWord;
                $search[] = $plz . ' LIKE ' . $searchWord;
                $search[] = $catName . ' LIKE ' . $searchWord;
                $search[] = $street . ' LIKE ' . $searchWord;
                $search[] = $country . ' LIKE ' . $searchWord;
                $search[] = $town . ' LIKE ' . $searchWord;
            }
        }

        $q->where('('.implode(' OR ', $search).')');

        if(count($and)) {
            $q->where('('.implode(' OR ', $and).')');
        }
    }

    public function buildWhereCoordQuery(&$query) {
        $input = JFactory::getApplication()->input;
        $level = $input->get('z', 0);

        $levels = array(0, 1);
        /**
         * at small zoomelevels we can end up having 2 datelines
         * because of this our queries will fail. To go around that
         * problem we will get all hohtspots in the categories
         * a nasty trick, but it should work in most situations...
         */
        if (!in_array($level, $levels)) {
            $ne = $input->getString('ne', '');
            $sw = $input->getString('sw', '');
            list($nelat, $nelng) = explode(',', $ne);
            list($swlat, $swlng) = explode(',', $sw);

            /**
             * We need to take in account the meridian in the Mercator
             * projection of the map. In the Mercator projection the meridian of the earth
             * is at the left and right edges. When you slide to the left the
             * or right, the map will wrap as you move past the meridian
             * at +/- 180 degrees. In that case, the bounds are partially split
             * across the left and right edges of the map and the northeast
             * corner is actually positioned at a poin that is greater than 180 degree.
             * The gmaps API automatiacally adjusts the longitude values to fit
             * between -180 and +180 degrees so we ned to request 2 portions of the map
             * from our database convering the left and right sides.
             */
            if ($nelng > $swlng) {
                $query->where(' (m.gmlng > ' . $swlng . ' AND m.gmlng < ' . $nelng . ')');
                $query->where(' (m.gmlat <= ' . $nelat . ' AND m.gmlat >= ' . $swlat . ')');
            } else {
                $query->where(' (m.gmlng >= ' . $swlng . ' OR m.gmlng <= ' . $nelng . ')');
                $query->where(' (m.gmlat <= ' . $nelat . ' AND m.gmlat >= ' . $swlat . ')');
            }
        }

        return $query;
    }

	public function getTable($type = 'Marker', $prefix = 'Table', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param    array    $data        An optional array of data for the form to interogate.
	 * @param    boolean    $loadData    True if the form is to load its own data (default case), false if not.
	 * @return    JForm    A JForm object on success, false on failure
	 * @since    1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{

		// Initialise variables.
		$app = JFactory::getApplication();

		// Get the form.
		$form = $this->loadForm('com_hotspots.marker', 'marker', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form)) {
			return false;
		}

		// Determine correct permissions to check.
		if ($this->getState('hotspot.id')) {
			// Existing record. Can only edit in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.edit');
		} else {
			// New record. Can only create in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.create');
		}

		// Modify the form based on access controls.
//		if (!$this->canEditState((object) $data)) {
//			// Disable fields for display.
//			$form->setFieldAttribute('published', 'disabled', 'true');
//			$form->setFieldAttribute('publish_up', 'disabled', 'true');
//			$form->setFieldAttribute('publish_down', 'disabled', 'true');
//
//			// Disable fields while saving.
//			// The controller has already verified this is a record you can edit.
//			$form->setFieldAttribute('published', 'filter', 'unset');
//			$form->setFieldAttribute('publish_up', 'filter', 'unset');
//			$form->setFieldAttribute('publish_down', 'filter', 'unset');
//		}

		return $form;
	}

	public function validate($form, $data)
	{
		$user = JFactory::getUser();
		$jform = JFactory::getApplication()->input->get('jform', array(), 'ARRAY');

		// do those checks only if we don't have userId
		if (!$user->id) {
			$data['created_by_alias'] = $jform['created_by_alias'];
			$data['email'] = $jform['email'];
		} else {
			$data['created_by_alias'] = $user->name;
			$data['created_by'] = $user->id;
		}

		//Test if it is a shared client
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		//Is it a proxy address
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		//The value of $ip at this point would look something like: "192.0.34.166"
		$data['created_by_ip']  = ip2long($ip);;

		return parent::validate($form, $data);
	}


	/**
	 * Method to save the form data. Basically the only difference with the parent
	 * method is the use of the hotspots plugins instead of content
	 *
	 * @param   array  $data  The form data.
	 *
	 * @return  boolean  True on success, False on error.
	 *
	 * @since   11.1
	 */
	public function save($data)
	{
		// Initialise variables;
		$dispatcher = JDispatcher::getInstance();
		$table = $this->getTable();
		$key = $table->getKeyName();
		$pk = (!empty($data[$key])) ? $data[$key] : (int) $this->getState($this->getName() . '.id');
		$isNew = true;

		// Include the content plugins for the on save events.
		JPluginHelper::importPlugin('hotspots');

        $file = JRequest::getVar('jform', '', 'files', 'array');
        $emptyFile = true;
        if(!empty($file)) {
            if(!empty($file['name']['picture'])) {
                foreach($file as $key => $value) {
                    $newFile[$key] = $value['picture'];
                }
                $emptyFile = false;
            }
        }

        if(!$emptyFile) {
            $picture = HotspotsUtils::uploadPicture($newFile);
            if($picture) {
                $data['picture'] = $picture;
                hotspotsUtils::createThumb($picture);
                $data['picture_thumb'] = "thumb_" . $picture ;
            }

        }

		// Allow an exception to be thrown.
		try
		{
			// Load the row if saving an existing record.
			if ($pk > 0)
			{
				$table->load($pk);
				$isNew = false;
			}

			// Bind the data.
			if (!$table->bind($data))
			{
				$this->setError($table->getError());
				return false;
			}

			// Prepare the row for saving
			$this->prepareTable($table);

			// Check the data.
			if (!$table->check())
			{
				$this->setError($table->getError());
				return false;
			}

			// Trigger the onContentBeforeSave event.
			$result = $dispatcher->trigger($this->event_before_save, array($this->option . '.' . $this->name, &$table, $isNew));
			if (in_array(false, $result, true))
			{
				$this->setError($table->getError());
				return false;
			}

			// Store the data.
			if (!$table->store())
			{
				$this->setError($table->getError());
				return false;
			}

			// Clean the cache.
			$this->cleanCache();

			// Trigger the onContentAfterSave event.
			$dispatcher->trigger($this->event_after_save, array($this->option . '.' . $this->name, &$table, $isNew));
		}
		catch (Exception $e)
		{
			$this->setError($e->getMessage());

			return false;
		}

		$pkName = $table->getKeyName();

		if (isset($table->$pkName))
		{
			$this->setState($this->getName() . '.id', $table->$pkName);
		}
		$this->setState($this->getName() . '.new', $isNew);

		return true;
	}
}