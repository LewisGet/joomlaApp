<?php
/***************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

defined('_JEXEC') or die ('Restricted access');
require_once(JPATH_COMPONENT_SITE . '/views/json.php');
class hotspotsViewJson extends HotspotsJson
{
    public function display($tpl = null)
    {
        $cat = JRequest::getVar('cat', false);
        $level = JRequest::getVar('level', false);
        $position = JRequest::getVar('position', false);

        $model = &$this->getModel();
        $categoryModel = JModelLegacy::getInstance('Category', 'HotspotsModel');

        $list = ($model->getHotspots());

        //		prepare the hotspot - create proper links etc...
        if(!isset($list['hotspots'])) {
            $list['hotspots'] = array();
        }
        foreach ($list['hotspots'] as $catid => $hotspot) {
            foreach ($hotspot as $key => $value) {
                if($key != 'viewCount' && $key != 'categoryCount') {
                    $list['hotspots'][$catid][$key] = hotspotsUtils::prepareHotspot($value);
                }

            }
        }

        $category = hotspotsUtils::prepareCategory($categoryModel->getCategory());

        $settings = $this->prepareSettings();
        $this->list = $list;
        $this->category = $categoryModel->getCategory();
        $this->settings = $settings;
        $this->categoryid = $cat;
        $this->hsposition = $position;
        $this->hslevel = $level;
        parent::display($tpl);
    }

    private function prepareSettings()
    {
        $settings = new JObject();
        $properties = array(
            'show_address' => HotspotsHelper::getSettings('show_address', 1),
            'show_country' => HotspotsHelper::getSettings('show_address_country', 0),
            'show_author' => HotspotsHelper::getSettings('show_author', 1),
            'show_date' => HotspotsHelper::getSettings('show_date', 1),
            'show_detailpage' => HotspotsHelper::getSettings('hotspot_detailpage', 1)
        );

        $settings->setProperties($properties);

        return $settings;
    }

    private function prepareHotspots($hotspots)
    {

        foreach ($hotspots['hotspots'] as $key => $hotspot) {
            $hotspots[$key] = hotspotsUtils::prepareHotspot($hotspot);
        }
        return $hotspots;
    }

    public function search(array $list)
    {

        $cat = JRequest::getVar('cat', false);
        $level = JRequest::getVar('level', false);
        $position = JRequest::getVar('position', false);

        $settings = $this->prepareSettings();
	    foreach($list['hotspots'] as $key => $hotspot) {
		    $list['hotspots'][$key] = hotspotsUtils::prepareHotspot($hotspot);
	    }

        $this->list = $list;
        $this->settings = $settings;
        $this->categoryid = $cat;
        $this->hsposition = $position;
        $this->hslevel = $level;

        parent::display(null);
    }

    public function hotspotsList(array $list)
    {
        $cat = JRequest::getVar('cat', false);
        $level = JRequest::getVar('level', false);
        $position = JRequest::getVar('position', false);
        //		prepare the hotspot - create proper links etc...
        foreach ($list['hotspots'] as $catid => $hotspot) {
            foreach ($hotspot as $key => $value) {
                if($key != 'count') {
                    $list['hotspots'][$catid][$key] = hotspotsUtils::prepareHotspot($value);
                }            }

        }

        $settings = $this->prepareSettings();
        $this->list = $list;
        $this->settings = $settings;
        $this->categoryid = $cat;
        $this->hsposition = $position;
        $this->hslevel = $level;


        parent::display(null);
    }

}