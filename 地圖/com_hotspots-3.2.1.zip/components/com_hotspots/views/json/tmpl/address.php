<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php if (HotspotsHelper::getSettings('show_address', 1)) : ?>
	<?php if (HotspotsHelper::getSettings('user_interface', 0) == 0) : ?>
		<?php echo $this->hotspot->street ?>
		<?php echo $this->hotspot->plz ? ', ' . $this->hotspot->plz : ''; ?>
		<?php echo $this->hotspot->town ? ', ' . $this->hotspot->town : ''; ?>

		<?php if ($this->settings->get('show_country')) : ?>
			<?php echo $this->hotspot->country; ?>
		<?php endif; ?>

	<?php else: ?>
		<?php echo $this->hotspot->street ?>
		<?php echo $this->hotspot->town ? ', ' . $this->hotspot->town : ''; ?>
		<?php echo $this->hotspot->plz ? ', ' . $this->hotspot->plz : ''; ?>
		
		<?php if ($this->settings->get('show_country')) : ?>
			<?php echo $this->hotspot->country; ?>
		<?php endif; ?>

	<?php endif; ?>
<?php endif; ?>