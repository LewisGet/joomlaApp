<?php
/***************************************************************
*  Copyright notice
*
*  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
*  All rights reserved
*
*  This script is part of the Hotspots project. The Hotspots project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license
*  from the author is found in LICENSE.txt distributed with these scripts.
*
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

defined( '_JEXEC' ) or die ( 'Restricted access' );
//header ('Content-type: text/json; charset=utf-8');
header('Content-type: application/json');

$html = array();
foreach($this->list['hotspots'] as $key => $value) {
	
	$this->hotspot=$value;
	ob_start();
	require('default_description.php');
	$description = ob_get_contents();
	ob_end_clean();
	
	$html['hotspots'][$value->catid][$key] = array (
		'id' => $value->hotspots_id,
		'latitude' => $value->gmlat,
		'longitude' => $value->gmlng,
		'title' => $value->name,
		'description' => $description,
        'street' => $this->hotspot->street,
        'city' => $this->hotspot->town,
        'zip' => $this->hotspot->plz,
        'country' => $this->hotspot->country,
        'created_by' => $this->hotspot->created_by_alias,
        'date' => $this->hotspot->created
	);
    if($value->params->get('markerimage')) {
        $html['hotspots'][$value->catid][$key]['icon'] =  HOTSPOTS_PICTURE_CATEGORIES_PATH . $value->params->get('markerimage');
    }

}

$html['worldCount'] = $this->list['worldCount'];
$html['viewCount']  = $this->list['count'];
$html['offset'] = JRequest::getInt('offset');
echo json_encode($html);

jexit();