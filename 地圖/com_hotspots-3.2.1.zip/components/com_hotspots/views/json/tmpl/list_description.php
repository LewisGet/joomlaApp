<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class='marker-description'>
	<?php echo $this->hotspot->description_small; ?>
	<?php if ($this->hotspot->picture) : ?>
		<a href='<?php echo $this->hotspot->link; ?>' title='<?php echo $this->hotspot->name; ?>' class="right">
			<img src='<?php echo $this->hotspot->picture_thumb; ?>' alt='<?php echo $this->hotspot->name ?>' />
		</a>
	<?php endif; ?>
	<div class="clear-both"></div>
</div>

<div class="small">
<?php require(JPATH_COMPONENT . '/views/hotspot/tmpl/default_one_line_address.php'); ?>
</div>
<div class="clear-both"></div>
<div class="hotspot-creation-info small">
	<?php if ($this->settings->get('show_author') && $this->hotspot->autor != "sobi2" && $this->hotspot->autor != "article") : ?>
			<?php echo JTEXT::_('COM_HOTSPOTS_POSTED_BY'); ?>
			<strong>
				<?php echo $this->hotspot->autor; ?>
			</strong>
		<?php endif; ?>

		<?php if ($this->settings->get('show_date')) : ?>
			<?php echo JText::_('COM_HOTSPOTS_ON'); ?>

			<?php echo $this->hotspot->postdate; ?>
		<?php endif; ?>
</div>
<div class="clear-both"></div>