<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');
require_once( JPATH_COMPONENT_ADMINISTRATOR . '/libraries/recaptcha/hotspotsRecaptcha.php');
class HotspotsViewHotspot extends HotspotsView {

	public function display($tpl = null) {

		$mainframe = JFactory::getApplication();
		$model = &$this->getModel();
		$this->hotspot = hotspotsUtils::prepareHotspot($model->getHotspot());

		$categoryModel =JModelLegacy::getInstance('category', 'HotspotsModel');
		$this->category = hotspotsUtils::prepareCategory($categoryModel->getCategory($this->hotspot->catid));

		$this->settings = $this->prepareSettings();
		$pathway = $mainframe->getPathWay();
		$pathway->additem($this->hotspot->name, '');

		$itemId = '&Itemid=' . hotspotsUtils::getItemid('com_hotspots', 'hotspots');

		$this->backlink = JRoute::_('index.php?option=com_hotspots' . $itemId);

		$doc = JFactory::getDocument();
		$doc->addScript('http://maps.google.com/maps/api/js?sensor=true');
		
		$this->setLayout('single');
		parent::display('raw');
	}
	
	
	
	private function prepareSettings() {
		$settings = new JObject();
		$properties = array (
			'show_address' => HotspotsHelper::getSettings('show_address', 1),
			'show_country' => HotspotsHelper::getSettings('show_address_country', 0),
			'show_author' => HotspotsHelper::getSettings('show_author', 1),
			'show_date' => HotspotsHelper::getSettings('show_date', 1),
			'show_detailpage' => HotspotsHelper::getSettings('hotspot_detailpage', 1)
		);
		
		$settings->setProperties($properties);
		
		return $settings;
	}

}