<?php defined('_JEXEC') or die('Restricted access');  ?>
<strong><?php echo $this->hotspot->name ?></strong><br /><br />

<?php require_once(JPATH_COMPONENT . '/views/json/tmpl/address.php'); ?>
