<?php
defined('_JEXEC') or die('Restricted access');
?>

<div id="hotspots" class="error">
	<?php echo $this->getError(); ?>
</div>