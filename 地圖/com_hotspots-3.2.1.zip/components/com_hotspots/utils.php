<?php

/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2011 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The Hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */

defined('_JEXEC') or die('Restricted access');


class hotspotsUtils {

	private static $frontCategories;

	public static function isUserInGroups($groups = array()) {
		$user = JFactory::getUser();

		$userGroups = $user->getAuthorisedGroups();
		if(array_intersect($groups, $userGroups)) {
			return true;
		}

		return false;
	}

	/**
	 * Returns a formated date that also takes in account the user timezone
	 * @static
	 * @param $date
	 * @return mixed
	 */
	public static function getLocalDate($date) {
		$format = HotspotsHelper::getSettings('date_format', 'Y-m-d H:i:s');
		$formattedDate = JHtml::_('date', $date, $format, true, true);
		return $formattedDate;
	}

	/**
	 * This function is based on the singleton pattern
	 * @return array $categories
	 */
	public function get_front_categories() {
		if (!isset(self::$frontCategories)) {
			$db = & JFactory::getDBO();
			$query = "SELECT id, id AS value, cat_name AS text, cat_description, count, cat_icon FROM #__hotspots_categorie WHERE published='1' ORDER BY " . HotspotsHelper::getSettings('category_ordering', 'id ASC');
			$db->setQuery($query);
			$rows = $db->loadAssocList('id');

			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			self::$frontCategories = $rows;
		}
		return self::$frontCategories;
	}

	public function getJSVariables() {
		$settings = array();
		$app = JFactory::getApplication();
		$settings['baseUrl'] = JURI::root();
		$settings['mapStartPosition'] = HotspotsHelper::getSettings('map_startposition', 'Karlsruhe, Germany');
		$settings['mapStartZoom'] = HotspotsHelper::getSettings('map_startzoom', '4');
		$settings['searchZoom'] = HotspotsHelper::getSettings('search_zoom', '14');
		if($app->isSite() && $app->input->getCmd('view') == 'hotspots') {
			$settings['startCat'] = implode(';',HotspotsHelper::getSettings('hs_startcat', 1));
		}
		$settings['staticMapWidth'] = HotspotsHelper::getSettings('map_static_width', 500);
		$settings['staticMapHeight'] = HotspotsHelper::getSettings('map_static_height', 300);
		$settings['getDirections'] = HotspotsHelper::getSettings('routenplaner', 1);
		$settings['gmControl'] = HotspotsHelper::getSettings('gm_control', '1');
		$settings['gmControlPos'] = HotspotsHelper::getSettings('gm_control_pos', 'topLeft');
		$settings['mapType'] = HotspotsHelper::getSettings('map_type', 0);
		$settings['centerType'] = HotspotsHelper::getSettings('map_centertyp', 1) ? 0 : 1;
		$settings['userInterface'] = HotspotsHelper::getSettings('user_interface', 1);
		$settings['readMore'] = HotspotsHelper::getSettings('hotspot_detailpage', 1);
		$settings['print'] = HotspotsHelper::getSettings('print_map', 1);
		$settings['resizeMap'] = HotspotsHelper::getSettings('resize_map', 1);
		$settings['mailMap'] = HotspotsHelper::getSettings('mail_map', 1);
		$settings['listLength'] = HotspotsHelper::getSettings('marker_list_length', 20);
//		there is no dedicated setting to the directions right now, but if the
//		menu is not there we should hide them
		$settings['showDirections'] = HotspotsHelper::getSettings('hs_show_controllmenu', 1);
        $settings['showAddress'] = HotspotsHelper::getSettings('show_address', 1);
        $settings['showCountry'] = HotspotsHelper::getSettings('show_address_country', 0);
        $settings['showAuthor'] = HotspotsHelper::getSettings('show_author', 1);
        $settings['showDate'] = HotspotsHelper::getSettings('show_date', 1);
		$settings['showMenu'] = HotspotsHelper::getSettings('hs_show_controllmenu', 1);
		$settings['numOfCatsToShow'] = HotspotsHelper::getSettings('number_of_cats_to_show', 4);
		$settings['categoryInfo'] = HotspotsHelper::getSettings('category_info', 4);
		$settings['showMarkerCount'] = HotspotsHelper::getSettings('show_marker_count', 4);

        $settings['categories'] = self::getCategoriesInfo();
		return 'hotspots.DefaultOptions = ' . json_encode($settings) . ';';
	}

    public function getCategoriesInfo() {
        // pass the path as we use this one in the backend as well
//        JModel::addIncludePath(JPATH_COMPONENT_SITE . '/models');

        $catModel = JModelLegacy::getInstance('Category', 'hotspotsModel');
        $boundaries = self::boundaries();
        $categories = $catModel->getCategories();
        foreach($categories as $key => $category) {
            $categories[$key] = self::prepareCategory($category);
            if(isset($boundaries[$key])) {
                $categories[$key]->boundaries = $boundaries[$key];
            }

        }

        return $categories;
    }

    /**
     * I'm not sure that this function belongs here. Maybe we should
     * add it to a model???
     *
     * The function returns the map boundaries of all categories
     * @return mixed
     */
    public static function boundaries() {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query->select('catid, MIN( gmlat ) AS south, MAX( gmlat ) AS north, MAX( gmlng ) AS east, MIN( gmlng ) AS west')
                ->from('#__hotspots_marker')
                ->group('catid')
                ->where('published = 1');
        $db->setQuery($query);

        return $db->loadObjectList('catid');
    }

	public function getJsLocalization() {
		$strings = array(
			'COM_HOTSPOTS_JS_DIRECTIONS',
			'COM_HOTSPOTS_GET_DIRECTIONS',
			'COM_HOTSPOTS_ZOOM',
			'COM_HOTSPOTS_TO',
			'COM_HOTSPOTS_FROM',
			'COM_HOTSPOTS_SUBMIT',
			'COM_HOTSPOTS_LOADING_DATA',
			'COM_HOTSPOTS_NO_HOTSPOTS_IN_CATEGORY',
			'COM_HOTSPOTS_MORE_HOTSPOTS',
			'COM_HOTSPOTS_READ_MORE',
			'COM_HOTSPOTS_CANCEL',
			'COM_HOTSPOTS_COULDNT_FIND_LOCATION',
			'COM_HOTSPOTS_ZERO_RESULTS_LOCATION',
			'COM_HOTSPOTS_PRINT',
			'COM_HOTSPOTS_SOMETHING_IS_WRONG',
			'COM_HOTSPOTS_ENTER_FULL_DESCRIPTION',
			'COM_HOTSPOTS_ENTER_SOBI2_ID',
			'COM_HOTSPOTS_ENTER_ARTICLE_ID',
			'COM_HOTSPOTS_GEOLOCATION_NO_SUPPORT',
			'COM_HOTSPOTS_DRAG_ME',
			'COM_HOTSPOTS_THERE_ARE',
			'COM_HOTSPOTS_THERE_IS',
			'COM_HOTSPOTS_EMAIL_THIS_MAP',
			'COM_HOTSPOTS_CLEAR_ROUTE',
			'COM_HOTSPOTS_SEND',
			'COM_HOTSPOTS_CLOSE',
            'COM_HOTSPOTS_SEARCH_RETURNED_NO_RESULTS',
            'COM_HOTSPOTS_POSTED_BY',
            'COM_HOTSPOTS_ON',
            'COM_HOTSPOTS_IN_YOUR_CURRENT_VIEW_THERE_ARE',
            'COM_HOTSPOTS_HOTSPOTS',
            'COM_HOTSPOTS_SEARCH_RESULTS_AROUND_THE_WORLD',
            'COM_HOTSPOTS_SEARCH_RETURNED_NO_RESULTS_IN_THIS_VIEW',
            'COM_HOTSPOTS_SEARCH_IN_YOUR_CURRENT_VIEW_RETURNED'
		);

		foreach($strings as $string) {
			JText::script($string);
		}
	}

	public function prepareCategory($category) {
		$iconWebPath = (JURI::root() . "media/com_hotspots/images/categories/");

		if ($category->cat_icon) {
			$category->cat_icon = $iconWebPath . $category->cat_icon;
		}
		if ($category->cat_shadowicon) {
			$category->cat_shadowicon = $iconWebPath . $category->cat_shadowicon;
		}

		return $category;
	}

    public function prepareHotspot($hotspot) {
        $descriptionSmall = $hotspot->description_small;

        if (HotspotsHelper::getSettings('marker_allow_plugin', 0) == 1) {
            $descriptionSmall = JHTML::_('content.prepare', $descriptionSmall, '');
        }
        $hotspot->postdate = hotspotsUtils::getLocalDate($hotspot->created);
        if($hotspot->picture_thumb) {
            $hotspot->picture_thumb = HOTSPOTS_THUMB_PATH . $hotspot->picture_thumb;
        }
        if($hotspot->picture) {
            $hotspot->picture = HOTSPOTS_PICTURE_PATH . $hotspot->picture;
        }

//      we should actually have always just one plugin that executes for that
//      particular component
	    $parameters = new JRegistry;
	    $parameters->loadString($hotspot->params);
	    $hotspot->params = $parameters;

        $hotspot->link = self::createLink($hotspot);

        $hotspot->description_small = $descriptionSmall;

        return $hotspot;
    }

	public static function createLink($hotspot) {
		if(!is_object($hotspot->params)){
			$parameters = new JRegistry;
			$parameters->loadString($hotspot->params);
			$hotspot->params = $parameters;
		}
		if($hotspot->params->get('link_to')) {
			$plugin = JPluginHelper::getPlugin('hotspotslinks', $hotspot->params->get('link_to'));
			if(is_object($plugin)) {
				JPluginHelper::importPlugin('hotspotslinks', $hotspot->params->get('link_to'));
				$dispatcher = JDispatcher::getInstance();
				$links = $dispatcher->trigger('onCreateLink', $hotspot->params->get('link_to_id'));
				$hotspotsLink = $links[0];
			} else {
				// if we don't have an object, then let us link to the single view
				$hotspotsLink = self::linkToHotspot($hotspot);
			}
		} else {
			$hotspotsLink = self::linkToHotspot($hotspot);
		}

		return $hotspotsLink;
	}

    /**
     * Create a link to single view of a marker.
     *
     * @param $hotspot - the whole marker object
     * @return The
     */
    public function linkToHotspot($hotspot) {

        $cats = hotspotsUtils::get_front_categories();
        if(isset($cats[$hotspot->catid])) {
            $urlcat = $hotspot->catid . ':' . JFilterOutput::stringURLSafe($cats[$hotspot->catid]['text']);
        }
        $urlid =  $hotspot->hotspots_id.':'.JFilterOutput::stringURLSafe($hotspot->name);
        $hotspotsLink = JRoute::_(HotspotsHelperRoute::getHotspotRoute($urlid, $urlcat), false);

        return $hotspotsLink;
    }

	public function createFeed() {
		require_once(JPATH_COMPONENT_ADMINISTRATOR . "/libraries/rss/feedcreator.php");
		$rss = new UniversalFeedCreator();
		$folderPath = JPATH_SITE . '/media/com_hotspots/rss';
		$folderExists = JFolder::exists($folderPath);
		if (!$folderExists) {
			JFolder::create($folderPath);
		}
		$rss->useCached("RSS2.0", $folderPath . '/hotspotsfeed.xml');

		$rss->title = JURI::Base() . " - " . JTEXT::_('Newest Hotspots');
		$rss->description = JTEXT::_('New Hotspots at') . ' ' . JURI::Base();
		$rss->link = JURI::Base();
		$image = new FeedImage();
		$image->title = JURI::Base() . " " . "Hotspots";
		$image->url = HotspotsHelper::getSettings('rss_logopath', JURI::Base() . "media/com_hotspots/images/utils/logo.jpg");
		$image->link = JURI::Base();
		$image->description = JTEXT::_('Feed provided by') . " " . JURI::Base() . ". " . JTEXT::_('Click to visit');
		$rss->image = $image;
		$hs_show_address = HotspotsHelper::getSettings('show_address', 1);
		$hs_show_address_country = HotspotsHelper::getSettings('show_address_country', 0);
		$hs_show_author = HotspotsHelper::getSettings('show_author', 1);
		$hs_show_detailpage = HotspotsHelper::getSettings('hotspot_detailpage', 1);
		$db = & JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__hotspots_marker WHERE published = 1 ORDER BY created DESC", 0, HotspotsHelper::getSettings('rss_limit', "100"));
		$rows = $db->loadObjectList();
		if ($rows != null) {
			foreach ($rows as $row) {
				$name = htmlspecialchars("$row->name");
				$street = htmlspecialchars("$row->street");
				$plz = htmlspecialchars("$row->plz");
				$town = htmlspecialchars("$row->town");
				$country = htmlspecialchars("$row->country");
				if ($hs_show_address == "1") {
					if ($hs_show_address_country == "1")
						$adress = "$street, $plz $town<br />$country<br /><br />";
					else
						$adress = "$street, $plz $town<br /><br />";
				}
				if ($hs_show_detailpage == "1") {
					$mlink = self::createLink($row);
				}
				if ($hs_show_author == "1") {
					$autor = JURI::Base();
					if($row->created_by_alias) {
						$autor = $row->created_by_alias;
					}
				}
				if (substr(ltrim($mlink), 0, 7) != 'http://') {
					$uri = & JURI::getInstance();
					$base = $uri->toString(array('scheme', 'host', 'port'));
					$mlink = $base . $mlink;
				}
				$rss_item = new FeedItem();
				$rss_item->title = $name;
				$rss_item->link = $mlink;
				$rss_item->description = $adress . $row->description_small;
				$rss_item->date = JFactory::getDate($row->created)->toRFC822();
				$rss_item->source = JURI::Base();
				$rss_item->author = $autor;
				$rss->addItem($rss_item);
			}
		}
		$rss->cssStyleSheet = "http://www.w3.org/2000/08/w3c-synd/style.css"; // 0 = RSS 2.0, 1 = RSS 1.0, 2= ATOM
		if (HotspotsHelper::getSettings('rss_type', 0) == 0) {
			$rss->saveFeed("RSS2.0", $folderPath . '/hotspotsfeed.xml');
		} elseif (HotspotsHelper::getSettings('rss_type', 0) == 1) {
			$rss->saveFeed("RSS1.0", $folderPath . '/hotspotsfeed.xml');
		} else {
			$rss->saveFeed("ATOM", $folderPath . '/hotspotsfeed.xml');
		}
	}

	/**
	 *
	 * @staticvar <int> $ids
	 * @param string $component
	 * @param string $view
	 * @internal param $ <string> $component
	 * @return mixed <int>
	 */
	public function getItemid($component='', $view = '') {
		$menu = JSite::getMenu();
		$items = $menu->getItems('component', $component);

		if ($view) {
			foreach ($items as $value) {
				if (strstr($value->link, 'view=' . $view)) {
					$itemId = $value->id;
					break;
				}
			}
		} else {
			$itemId = $items[0]->id;
		}
		return $itemId;
	}

	/**
	 * TODO: write this function
	 * @return type 
	 */
	public function isModerator() {
		return false;
	}

    /**
     * TODO: fix this function - change the german language and output proper error messages
     * @param $picture
     * @return string
     */
    public static function createThumb($picture) {
        jimport('joomla.filesystem.folder');
		// Based on thumbnail script by forsterm @ tutorials.de
		$upload_path = (JPATH_ROOT . '/media/com_hotspots/images/hotspots/');
		$img_src = $upload_path . $picture;

		$thumb_dir = (JPATH_ROOT . '/media/com_hotspots/images/thumbs');
		$cache = true;
		if (!isset($img_src)) {
			return "Es wurde kein Bildpfad �bergeben aus dem ein Thumbnail ezeugt werden k�nnte"; // Gibt eine Fehlermeldung aus
		}

		if (!$image_infos = @getimagesize($img_src)) {
			return JText::_('COM_HOTSPOTS_PIC_NOT_FOUND');
			exit;
		}

		$width = $image_infos[0];
		$height = $image_infos[1];
		$type = $image_infos[2];
		$mime = $image_infos['mime'];

		$w = HotspotsHelper::getSettings('picturethumb_width', "80");
		$h = HotspotsHelper::getSettings('picturethumb_height', "80");
		$p = true;

		// should we make the thumb proportional?
		if (strstr($w, 'p')) {
			$p = (int) str_replace('p', '', $w);
			$w = null;
			$h = null;
		}

		if (isset($p) && !isset($w) && !isset($h)) { // �berpr�fen ob die Bildgr��e proportional berechnet werden soll
			if ($width < $height) { // �berpr�fen ob das Bild Hoch- oder Querformat ist
				$new_width = ceil(($p / $height) * $width);
				$new_height = intval($p); // Zuweisen der neuen H�he
			} else {
				$new_height = ceil(($p / $width) * $height);
				$new_width = intval($p); // Zuweisen der neuen Breite
			}
		} else if (isset($w) && !isset($h) && !isset($p)) { // �berpr�fen ob die Breite oder die H�he berechnent werden soll
			$new_width = intval($w); // Zuweisen der neuen Breite
			$new_height = ceil($height * $new_width / $width); // Berechnen der neuen H�he
		} else if (isset($h) && !isset($w) && !isset($p)) { // �berpr�fen ob die Breite oder die H�he berechnent werden soll
			$new_height = intval($h); // Zuweisen der neuen H�he
			$new_width = ceil($width * $new_height / $height); // Berechnen der neuen Breite
		} else if (isset($h) && isset($w) && isset($p)) {
			$new_height = intval($h); // Zuweisen der neuen H�he
			$new_width = intval($w); // Zuweisen der neuen Breite
		} else {
			return 'Es muss entweder die neu H�he oder die neu Breite angegeben werden.'; // Fehlermeldung ausgeben
		}

		if ($cache === true && !JFolder::exists($thumb_dir)) {
			JFolder::create($thumb_dir); // Legt das Cache Verzeichnis an. Sollte dies nicht m�glich sein, so wird ein Fehler ausgegeben
		}

		switch ($type) {
			case 1:
				if (imagetypes() & IMG_GIF) { // �berpr�fen ob das Bildformat untest�tzt wird
					if (!JFile::exists($thumb_dir . '/thumb_' . $picture)) { // Wenn das Thumbnail nicht existiert wird es erstellt
						$orginal = imagecreatefromgif($img_src); // Bild aus dem Orginalbild erstellen
						$thumb = imagecreatetruecolor($new_width, $new_height); // Das Thumbnailbild erstellen
						imagecopyresampled($thumb, $orginal, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
						if ($cache === true) { // Pr�ft ob das Bild gespeichert werden soll
							imagegif($thumb, $thumb_dir . '/thumb_' . $picture); // Bild speichern
						}
					} else {
						JFile::read($thumb_dir . '/thumb_' . $picture); // Bild ausgeben
					}
				} else {
					return JText::_('COM_HOTSPOTS_GIF_NOT_SUPPORTED');
					; // Fehlermeldung ausgeben, wenn das Bildformat nicht unterst�tzt wird
				}
				break;
			case 2:
				if (imagetypes() & IMG_JPG) { // �berpr�fen ob das Bildformat untest�tzt wird
					if (!JFile::exists($thumb_dir . '/thumb_' . $picture)) { // Wenn das Thumbnail nicht existiert wird es erstellt
						$orginal = imagecreatefromjpeg($img_src); // Bild aus dem Orginabild erstellen
						$thumb = imagecreatetruecolor($new_width, $new_height); // Das Thumbnailbild erstellen
						imagecopyresampled($thumb, $orginal, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
						if ($cache === true) { // Pr�ft ob das Bild gespeichert werden soll
							imagejpeg($thumb, $thumb_dir . '/thumb_' . $picture); // Bild speichern
						}
					} else {
						JFile::read($thumb_dir . '/thumb_' . $picture); // Bild ausgeben
					}
				} else {
					return JText::_('COM_HOTSPOTS_JPG_NOT_SUPPORTED'); // Fehlermeldung ausgeben, wenn das Bildformat nicht unterst�tzt wird
				}
				break;
			case 3:
				if (imagetypes() & IMG_PNG) { // �berpr�fen ob das Bildformat untest�tzt wird
					if (!JFile::exists($thumb_dir . '/thumb_' . $picture)) { // Wenn das Thumbnail nicht existiert wird es erstellt
						$orginal = imageCreateFromPNG($img_src); // Bild aus dem Orginalbild erstellen
						$thumb = imagecreatetruecolor($new_width, $new_height); // Das Thumbnailbild erstellen
						imagecopyresampled($thumb, $orginal, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
						if ($cache === true) { // Pr�ft ob das Bild gespeichert werden soll
							imagepng($thumb, $thumb_dir . '/thumb_' . $picture); // Bild speichern
						}
					} else {
						JFile::read($thumb_dir . '/thumb_' . $picture); // Bild ausgeben
					}
				} else {
					return JText::_('COM_HOTSPOTS_PNG_NOT_SUPPORTED'); // Fehlermeldung ausgeben, wenn das Bildformat nicht unterst�tzt wird
				}
				break;
			default:
				return JText::_('COM_HOTSPOTS_PIC_NOT_SUPPORTED'); // Fehlermeldung ausgeben, wenn das Bildformat nicht unterst�tzt wird
		}
	}

    /**
     * TODO: fix this function - return proper error messages
     * @static
     * @param $picture
     * @return bool|string
     */
    public static function uploadPicture($picture) {
        if(is_array($picture) && isset($picture['tmp_name'])) {
            $errormsg = '';
            $imageinfo = getimagesize($picture['tmp_name']);
            if ($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg' && $imageinfo['mime'] != 'image/png') {
                $errormsg .= "Sorry this is no supported image - gif, jpg, png";
                return false;
            } else {
                $blacklist = array(".php", ".phtml", ".php3", ".php4", ".php5", ".html", ".txt", ".dhtml", ".htm", ".doc", ".asp", ".net", ".js", ".rtf");
                foreach ($blacklist as $item) {
                    if (preg_match("/$item\$/i", $picture['name'])) {
                        $errormsg .= "We do not allow uploading PHP files\n";
                        return false;
                    }
                }
                $upload_path = (JPATH_ROOT . '/media/com_hotspots/images/hotspots/');
                $upload_image = $upload_path . basename($picture['name']);
                if (JFile::upload($picture['tmp_name'], $upload_image)) {
                    echo "<script> alert('File " . basename($picture['name']) . "sucessfully uploaded'); window.histroy.go(-1); </script>\n";
                    $errormsg .= "sucessfull upload at $upload_path";
                } else {
                    echo "<script> alert('Error uploading " . basename($picture['name']) . "!!!'); window.histroy.go(-1); </script>\n";
                    $errormsg .= "failed to upload at $upload_path";
                }
                return basename($picture['name']);
            }
        }
        return false;
    }

}