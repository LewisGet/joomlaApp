<?php
/* * *************************************************************
 *  Copyright notice
 *
 *  Copyright 2012 Daniel Dimitrov. (http://compojoom.com)
 *  All rights reserved
 *
 *  This script is part of the Hotspots project. The hotspots project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  A copy is found in the textfile GPL.txt and important notices to the license
 *  from the author is found in LICENSE.txt distributed with these scripts.
 *
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 * ************************************************************* */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.plugin.plugin');

class plgContentHotspots extends JPlugin
{
    public function __construct(&$subject, $params)
    {
        $jlang =& JFactory::getLanguage();
        $jlang->load('com_hotspots', JPATH_SITE, 'en-GB', true);
        $jlang->load('com_hotspots', JPATH_SITE, $jlang->getDefault(), true);
        $jlang->load('com_hotspots', JPATH_SITE, null, true);

        parent::__construct($subject, $params);
    }

    public function onContentPrepare($context, &$article, &$params, $page = 0)
    {
        // Don't run this plugin when the content is being indexed
        if ($context == 'com_finder.indexer') {
            return true;
        }


        // simple performance check to determine whether bot should process further
        if (strpos($article->text, 'hotspots') === false) {
            return true;
        }

        // expression to search for (positions)
        $regex = '/{hotspots\s+(.*?)}/i';

        // Find all instances of plugin and put in $matches for hotspots
        // $matches[0] is full pattern match, $matches[1] contains the settings
        preg_match_all($regex, $article->text, $matches, PREG_SET_ORDER);
        // No matches, skip this
        if (isset($matches[0][1])) {
            $options = explode(' ', $matches[0][1]);
            foreach ($options as $option) {
                if (strpos($option, '=') === false) {
                    continue;
                }
                $option = explode('=', $option);
                $settings[$option[0]] = $option[1];
            }
        }

        if (count($settings)) {
            if (isset($settings['hotspot'])) {
                $this->getHotspot($settings['hotspot']);
                $output = $this->mapHotspot();
                $replace = $matches[0][0];
                $article->text = preg_replace("|$replace|", addcslashes($output, '\\$'), $article->text, 1);
            }
        }
    }

    private function getHotspot($id)
    {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('m.id as hotspots_id, m.*, c.*')
            ->from('#__hotspots_marker  AS m')
            ->leftJoin('#__hotspots_categorie as c ON m.catid = c.id')
            ->where('m.id = ' . $db->quote($id));

        $db->setQuery($query);
        $this->hotspot = $db->loadObject();

        return $this->hotspot;
    }

    public function mapHotspot()
    {

        $frontend = JPATH_BASE . '/components/com_hotspots';
        require_once  $frontend . '/includes/defines.php';
        require_once  $frontend . '/helpers/route.php';
        JModel::addIncludePath($frontend . '/models');
        require_once JPATH_BASE . '/administrator/components/com_hotspots/helpers/hotspots.php';
        require_once  $frontend . '/utils.php';

        JHTML::_('behavior.mootools', true);
        JHTML::_('behavior.tooltip');
        JHTML::_('stylesheet', 'hotspots.css', 'media/com_hotspots/css/');

        $doc = & JFactory::getDocument();
        $gmapsapi = 'http://maps.google.com/maps/api/js?sensor=true';
        $doc->addScript($gmapsapi);

        hotspotsUtils::getJsLocalization();
        $domready = "window.addEvent('domready', function(){ \n";
        $this->hotspot = hotspotsUtils::prepareHotspot($this->hotspot);
        $hotspot = array(
            'id' => $this->hotspot->id,
            'latitude' => $this->hotspot->gmlat,
            'longitude' => $this->hotspot->gmlng,
            'title' => $this->hotspot->name,
            'icon' => (JURI::root() . "media/com_hotspots/images/categories/") . $this->hotspot->cat_icon,
            'shadow' => (JURI::root() . "media/com_hotspots/images/categories/") . $this->hotspot->cat_shadowicon
        );

        $hotspot['description'] = '<h2>' . $this->hotspot->name . '</h2>'
            . '<div>' . $this->hotspot->description_small . '</div>'
            . '<div>' . $this->hotspot->street
            . ' ' . $this->hotspot->town
            . ' ' . $this->hotspot->plz
            . ' ' . $this->hotspot->country
            . '</div>';

        $domready .= 'hotspots = new compojoom.hotspots.core();';
        $domready .= hotspotsUtils::getJSVariables();
        $domready .= 'var hotspot = ' . json_encode($hotspot) . ';' . "\n";
        $domready .= "
hotspots.addSandbox('map_canvas', hotspots.DefaultOptions);

hotspots.addModule('hotspot', hotspot, hotspots.DefaultOptions);
hotspots.addModule('menu',hotspots.DefaultOptions);
hotspots.startAll();";
        $domready .= "});";

        $doc->addScriptDeclaration($domready);

        $domready .= "});";
        JHTML::_('script', 'fixes.js', 'media/com_hotspots/js/');
        JHTML::_('script', 'spin.js', 'media/com_hotspots/js/spin/');
        JHTML::_('script', 'Class.SubObjectMapping.js', 'media/com_hotspots/js/moo/');
        JHTML::_('script', 'Map.js', 'media/com_hotspots/js/moo/');
        JHTML::_('script', 'Map.Extras.js', 'media/com_hotspots/js/moo/');
        JHTML::_('script', 'Map.Marker.js', 'media/com_hotspots/js/moo/');
        JHTML::_('script', 'Map.InfoWindow.js', 'media/com_hotspots/js/moo/');
        JHTML::_('script', 'Map.Geocoder.js', 'media/com_hotspots/js/moo/');
        JHTML::_('script', 'helper.js', 'media/com_hotspots/js/helpers/');

        JHTML::_('script', 'core.js', 'media/com_hotspots/js/');
        JHTML::_('script', 'sandbox.js', 'media/com_hotspots/js/');

        JHTML::_('script', 'hotspot.js', 'media/com_hotspots/js/modules/hotspot/');
        JHTML::_('script', 'menu.js', 'media/com_hotspots/js/modules/');

        JHTML::_('script', 'slide.js', 'media/com_hotspots/js/helpers/');
        JHTML::_('script', 'tab.js', 'media/com_hotspots/js/helpers/');

        $map = '<div id="hotspots" class="plg_content_hotspots hotspots">
                    <div id="map_cont" style="height: ' . $this->params->get('map_height', 400) . 'px;">';
        ob_start();
        require_once $frontend . '/views/hotspot/tmpl/default_menu.php';
        $map .= ob_get_contents();
        ob_end_clean();

        $map .= '<div id="map_canvas" class="map_canvas"
                             style="height: ' . $this->params->get('map_height', 400) . 'px;"></div>

                    </div>
                </div>';

        return $map;
    }


}