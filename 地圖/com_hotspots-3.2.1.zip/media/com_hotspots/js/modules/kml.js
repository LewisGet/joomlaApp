new Class('compojoom.hotspots.modules.kml',{
    Implements:[Options, Events, compojoom.hotspots.helper],

    isMenuOpen:false,
    fullScreen:false,
    options:{

        mailMap:1

    },
    xhr:{},
    executed: [],

    eventsMap: [{
        host: window,
        events: {
            loadedKmls: null,
            hotspotsLoadCategory: 'getKmls'
        }
    }],


    initialize:function (options, sb) {
        this.sb = sb;
        this.setOptions(options);

        this.exportAllEvents();
    },

    /**
     * we use a small trick here - since we load all the kmls for a particular category at once
     * we don't need to ask the server each time to serve us the KML - just one request is enough!
     * @param params
     */
    getKmls:function (params) {

        if(typeof params == 'undefined') {
            params = {};
        }

        var bounds = this.sb.getMap().getBounds();
        var offset = 0;
        var categories = this.gup('catid');

        if(!this.executed[categories.replace(';','_')]) {
            if (typeof params.categories != 'undefined') {
                categories = params.categories;
            }
            if(typeof params.offset != 'undefined') {
                offset = params.offset;
            }
            var query = [
                'option=com_hotspots',
                'view=kmls',
                'cat=' + categories,
                'level=' + this.sb.getMap().getZoom(),
                'ne=' + bounds.getNorthEast().toUrlValue(),
                'sw=' + bounds.getSouthWest().toUrlValue(),
                'format=json'
            ];

            this.xhr = new Request.JSON({
                url: this.options.baseUrl + "index.php?" + query.join('&'),
                link: 'cancel',
                onRequest: function () {
                    window.fireEvent('hotspotsLoaderStart');
                }.bind(this),
                onSuccess: function (data) {
                    window.fireEvent('loadedKmls', data);
                }.bind(this),
                onComplete: function () {
                    window.fireEvent('hotspotsLoaderStop');
                }.bind(this)
            });

            this.xhr.send();
//          let us mark the call
            this.executed[categories.replace(';','_')] = true;
        }
    },

    onLoadedKmls: function(kmls) {
        var self = this;
        Object.each(kmls , function(kml) {
            kml.each(function(value) {
                var kmlLayer = new google.maps.KmlLayer(value.file, {preserveViewport: true});
                kmlLayer.setMap(self.sb.getMap());
            })

        });

    }
});