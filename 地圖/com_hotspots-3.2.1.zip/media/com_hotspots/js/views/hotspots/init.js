window.addEvent('domready', function() {
	
//	if(window.location.hash == '') {
//		window.location.hash = '!/catid='+hotspots.DefaultOptions.startCat;
//	}
//
//    hotspots.addModule('welcome',hotspots.DefaultOptions);
//    hotspots.addModule('loader','map_cont',hotspots.DefaultOptions);
//    hotspots.addModule('menu',hotspots.DefaultOptions);
//    hotspots.addModule('categories','#hotspots-category-items', 'span',hotspots.DefaultOptions);
//    hotspots.addModule('menubar',hotspots.DefaultOptions);
//    hotspots.addModule('send',hotspots.DefaultOptions);
//    hotspots.addModule('print',hotspots.DefaultOptions);
//    hotspots.addModule('search',hotspots.DefaultOptions);
//
//    hotspots.addModule('hotspot',hotspots.DefaultOptions);
//    hotspots.addModule('kml',hotspots.DefaultOptions);
//    hotspots.addModule('map',hotspots.DefaultOptions);
//    hotspots.addModule('navigator',hotspots.DefaultOptions);
//
//    hotspots.startAll();
	
});
