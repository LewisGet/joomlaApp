<?php
/**
 * @package        JFBConnect
 * @copyright (C) 2009-2013 by Source Coast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.pane');
JHTML::_('behavior.tooltip');

$model = $this->model;
$pane = JPane::getInstance('tabs');
?>
<script type="text/javascript">
    function toggleHide(rowId, styleType)
    {
        document.getElementById(rowId).style.display = styleType;
    }
</script>
<style type="text/css">
    div.config_setting {
        width: 150px;
    }
    div.config_option {
        width: 300px;
    }
    div.config_setting_option {
        width: 350px;
    }
</style>


<form method="post" id="adminForm" name="adminForm">
<div>
<?php echo JText::_('COM_JFBCONNECT_CANVAS_TAB_CONFIGURATION');?>
<br/>
<?php
//print_r($this->canvasProperties);
echo $pane->startPane('content-pane');
echo $pane->startPanel(JText::_('COM_JFBCONNECT_CANVAS_MENU_PAGE_TAB'), 'tab_application_settings');

$tabReady = true;
$tabName = $this->canvasProperties->get('page_tab_default_name', "");
if (!$tabName)
{
    $tabName = '<span style="color:#FF4444"><b>'.JText::_('COM_JFBCONNECT_CANVAS_WARNING_NOT_SET').'</b></span>';
    $tabReady = false;
}
$tabUrl = $this->canvasProperties->get('page_tab_url', "");
if (!$tabUrl)
{
    $tabUrl = '<span style="color:#FF4444"><b>'.JText::_('COM_JFBCONNECT_CANVAS_WARNING_NOT_SET').'</b></span>';
    $tabReady = false;
}
$secureTabUrl = $this->canvasProperties->get('secure_page_tab_url', "");
if (!$secureTabUrl)
{
    $secureTabUrl = '<span style="color:#FF4444"><b>'.JText::_('COM_JFBCONNECT_CANVAS_WARNING_NOT_SET').'</b></span>';
    $tabReady = false;
}

$websiteUrl = $this->canvasProperties->get('website_url', '');

?>
<div>
    <div class="config_setting header config_row" style="width:250px"><?php echo JText::_('COM_JFBCONNECT_CANVAS_PAGE_TAB_CONFIG_STATUS');?></div>
    <div style="clear:both"></div>
    <div class="config_row">
    <?php if ($tabReady)
    { ?>
    <?php echo JText::_('COM_JFBCONNECT_CANVAS_PAGE_TAB_CONFIG_DESC');?>
    <a href="https://www.facebook.com/dialog/pagetab?app_id=<?php echo $this->jfbcLibrary->facebookAppId;?>&display=popup&next=<?php echo $websiteUrl;?>" target="_BLANK"><?php echo JText::_('COM_JFBCONNECT_CANVAS_PAGE_TAB_CONFIG_DESC1');?></a>
    <?php } else
    { ?>
    <?php echo JText::_('COM_JFBCONNECT_CANVAS_PAGE_TAB_CONFIG_DESC2');?>
    <?php } ?>
    </div>
    <br/>
</div>
<div>
    <div class="config_row">
        <div class="config_setting header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_JOOMLA_DISPLAY_SETTING');?></div>
        <div class="config_option header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_OPTIONS_LABEL');?></div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_DISPLAY_TEMPLATE_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_DISPLAY_TEMPLATE_LABEL');?>:</div>
        <div class="config_option">
            <?php echo JHTML::_('select.genericlist', $this->templates, 'canvas_tab_template', null, 'directory', 'name', $this->canvasTabTemplate, 'canvas_tab_template'); ?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_REVEAL_PAGE_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_REVEAL_PAGE_LABEL');?>:</div>
        <div class="config_option">
            <input type="text" name="canvas_tab_reveal_article_id"
                   value="<?php echo $model->getSetting('canvas_tab_reveal_article_id') ?>" size="20">
        </div>
        <div class="config_description">
            <?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_REVEAL_PAGE_DESC2');?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_AUTOMATIC_RESIZING_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_AUTOMATIC_RESIZING_LABEL');?>:</div>
        <div class="config_option">
            <fieldset id="canvas_tab_resize_enabled" class="radio">
                <input type="radio" id="canvas_tab_resize_enabled1" name="canvas_tab_resize_enabled" value="1" <?php echo $model->getSetting('canvas_tab_resize_enabled') == '1' ? 'checked="checked"' : ""; ?> />
                <label for="canvas_tab_resize_enabled1"><?php echo JText::_('COM_JFBCONNECT_ENABLED_LABEL');?></label>
                <input type="radio" id="canvas_tab_resize_enabled0" name="canvas_tab_resize_enabled" value="0" <?php echo $model->getSetting('canvas_tab_resize_enabled') == '0' ? 'checked="checked"' : ""; ?> />
                <label for="canvas_tab_resize_enabled0"><?php echo JText::_('COM_JFBCONNECT_DISABLED_LABEL');?></label>
            </fieldset>
        </div>
        <div style="clear:both"></div>
    </div>
    <br/>
</div>
<div>
    <div class="config_row">
        <div class="config_setting header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_APPLICATION_SETTING');?></div>
        <div class="config_option header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_CURRENT_SETTING');?></div>
        <div style="clear:both"></div>
        <div>
            <b>
                <?php echo JText::sprintf('COM_JFBCONNECT_CANVAS_APPLICATION_SETTING_DESC', $this->jfbcLibrary->get('facebookAppId'));?>
            </b>
        </div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_TAB_NAME_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_TAB_NAME_LABEL');?>:</div>
        <div class="config_option"><?php echo $tabName; ?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_TAB_PAGE_URL_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_TAB_PAGE_URL_LABEL');?>:</div>
        <div class="config_option"><?php echo $tabUrl; ?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_SECURE_TAB_PAGE_URL_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_SECURE_TAB_PAGE_URL_LABEL');?>:</div>
        <div class="config_option"><?php echo $secureTabUrl; ?>
        </div>
        <div class="config_description">
            <?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_SECURE_TAB_PAGE_URL_DESC2');?>
        </div>
        <div style="clear:both"></div>
    </div>
</div>
<?php
echo $pane->endPanel();
echo $pane->startPanel(JText::_('COM_JFBCONNECT_CANVAS_MENU_CANVAS_APP'), "canvas_app_settings");

$autoResizingEnabled = $model->getSetting('canvas_canvas_resize_enabled');
$canvasFluidHeight = $this->canvasProperties->get('canvas_fluid_height', false);
if ($canvasFluidHeight)
    $canvasFluidHeight = $autoResizingEnabled ? JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_HEIGHT_FLUID') : JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_HEIGHT_FLUID').'<br/><span style="color:#FF4444">' .JText::sprintf('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_HEIGHT_FLUID_NEED_AUTORESIZING', JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_AUTOMATIC_RESIZING_LABEL')).'</span>';
else
    $canvasFluidHeight = JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_HEIGHT_MANUAL').'<span style="color:#FF4444">'.JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_HEIGHT_MANUAL_WARNING').'</span>';

$canvasFluidWidth = $this->canvasProperties->get('canvas_fluid_width', false);
$canvasFluidWidth = $canvasFluidWidth ? JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_WIDTH_FLUID') : JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_WIDTH_FIXED');

$canvasReady = true;
$canvasName = $this->canvasProperties->get('namespace', "");
if (!$canvasName)
{
    $canvasReady = false;
    $canvasName = '<span style="color:#FF4444"><b>'.JText::_('COM_JFBCONNECT_CANVAS_WARNING_NOT_SET').'</b></span>';
}

$canvasUrl = $this->canvasProperties->get('canvas_url', '');
if ($canvasUrl == "")
{
    $canvasUrl = '<span style="color:#FF4444"><b>'.JText::_('COM_JFBCONNECT_CANVAS_WARNING_NOT_SET').'</b></span>';
    $canvasReady = false;
}
$secureCanvasUrl = $this->canvasProperties->get('secure_canvas_url', '');
if ($secureCanvasUrl == "")
{
    $secureCanvasUrl = '<span style="color:#FF4444"><b>'.JText::_('COM_JFBCONNECT_CANVAS_WARNING_NOT_SET').'</b></span>';
    $canvasReady = false;
}

if ($canvasReady)
    $canvasLink = '<a target="_blank" href="http://apps.facebook.com/' . $canvasName . '">https://apps.facebook.com/' . $canvasName . '</a>';
else
    $canvasLink = '';



?>
<div>
    <div class="config_setting header config_row" style="width:250px"><?php echo JText::_('COM_JFBCONNECT_CANVAS_CANVAS_STATUS');?></div>
    <div style="clear:both"></div>
    <div class="config_row">
    <?php if ($canvasLink)
{ ?>
    <?php echo JText::_('COM_JFBCONNECT_CANVAS_CANVAS_STATUS_DESC');?>
    <b><?php echo $canvasLink; ?></b>
    <?php } else
{ ?>
    <?php echo JText::_('COM_JFBCONNECT_CANVAS_CANVAS_STATUS_DESC2');?>
    <?php } ?>
    </div>
    <br/>
</div>
<div>
        <div class="config_row">
        <div class="config_setting header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_JOOMLA_DISPLAY_SETTING');?></div>
        <div class="config_option header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_OPTIONS_LABEL');?></div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_DISPLAY_TEMPLATE_DESC2');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_DISPLAY_TEMPLATE_LABEL');?>:</div>
        <div class="config_option">
            <?php echo JHTML::_('select.genericlist', $this->templates, 'canvas_canvas_template', null, 'directory', 'name', $this->canvasCanvasTemplate, 'canvas_canvas_template'); ?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_AUTOMATIC_RESIZING_DESC2');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_PAGE_AUTOMATIC_RESIZING_LABEL');?>:</div>
        <div class="config_option">
            <fieldset id="canvas_canvas_resize_enabled" class="radio">
                <input type="radio" id="canvas_canvas_resize_enabled1" name="canvas_canvas_resize_enabled" value="1" <?php echo $model->getSetting('canvas_canvas_resize_enabled') == '1' ? 'checked="checked"' : ""; ?> />
                <label for="canvas_canvas_resize_enabled1"><?php echo JText::_('COM_JFBCONNECT_ENABLED_LABEL');?></label>
                <input type="radio" id="canvas_canvas_resize_enabled0" name="canvas_canvas_resize_enabled" value="0" <?php echo $model->getSetting('canvas_canvas_resize_enabled') == '0' ? 'checked="checked"' : ""; ?> />
                <label for="canvas_canvas_resize_enabled0"><?php echo JText::_('COM_JFBCONNECT_DISABLED_LABEL');?></label>
            </fieldset>
        </div>
        <div style="clear:both"></div>
    </div>
    <br/>
</div>
<div>
    <div class="config_row">
        <div class="config_setting header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_APPLICATION_SETTING');?></div>
        <div class="config_option header"><?php echo JText::_('COM_JFBCONNECT_CANVAS_CURRENT_SETTING');?></div>
        <div style="clear:both"></div>
        <div><?php echo JText::_('COM_JFBCONNECT_CANVAS_APPLICATION_SETTING_DESC');?>
            <b><a target="_BLANK"
                href="https://developers.facebook.com/apps/<?php echo $this->jfbcLibrary->get('facebookAppId');?>/fb-apps">
                <?php echo JText::_('COM_JFBCONNECT_CANVAS_APPLICATION_SETTING_DESC2');?>
            </a></b>
        </div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_NAME_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_NAME_LABEL');?>:</div>
        <div class="config_option"><?php echo $canvasName ?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_URL_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_URL_LABEL');?>:</div>
        <div class="config_option"><?php echo $canvasUrl; ?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_SECURE_CANVAS_URL_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_SECURE_CANVAS_URL_LABEL');?>:</div>
        <div class="config_option"><?php echo $secureCanvasUrl; ?>
        </div>
        <div class="config_description">
            <?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_SECURE_CANVAS_URL_DESC2');?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_HEIGHT_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_HEIGHT_LABEL');?>:</div>
        <div class="config_option"><?php echo $canvasFluidHeight; ?>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="config_row">
        <div class="config_setting hasTip"
             title="<?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_WIDTH_DESC');?>"><?php echo JText::_('COM_JFBCONNECT_CANVAS_FIELD_CANVAS_WIDTH_LABEL');?>:</div>
        <div class="config_option"><?php echo $canvasFluidWidth; ?>
        </div>
        <div style="clear:both"></div>
    </div>
</div>
<?php
echo $pane->endPanel();
echo $pane->endPane();
?>
<input type="hidden" name="option" value="com_jfbconnect"/>
<input type="hidden" name="controller" value="canvas"/>
<input type="hidden" name="cid[]" value="0"/>
<input type="hidden" name="task" value=""/>
<?php echo JHTML::_('form.token'); ?>
</div>
</form>
