<?php

/**
 * @package        JFBConnect
 * @copyright (C) 2009-2013 by Source Coast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class JFBConnectViewCanvas extends JView
{
    function display($tpl = null)
    {
        require_once(JPATH_COMPONENT_SITE . DS . 'libraries' . DS . 'facebook.php');
        $model = $this->getModel('config');
        $jfbcLibrary = JFBConnectFacebookLibrary::getInstance();
            
         // SC15
        
            require_once JPATH_ADMINISTRATOR.DS.'components'.DS.'com_templates'.DS.'helpers'.DS.'templates.php';
            JModel::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_templates'.DS.'models');
            $templatesModel = JModel::getInstance('Styles', 'TemplatesModel');
            $allTemplates = $templatesModel->getItems();
            $templates = array();
            foreach ($allTemplates as $template)
            {
                if ($template->client_id == 0)
                {
                    // Make it the same as J15 so we can use the same selectlist
                    $template->directory = $template->id;
                    $template->name = $template->title;
                    $templates[] = $template;
                }
            }
         // SC16

        // Add the "Don't Override" option to set no special template
        $defaultTemplate = new stdClass();
        $defaultTemplate->directory = -1;
        $defaultTemplate->name = JText::_('COM_JFBCONNECT_CANVAS_DISPLAY_TEMPLATE_DEFAULT');
        array_unshift($templates, $defaultTemplate);

        require_once(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jfbconnect' . DS . 'controllers' . DS . 'canvas.php');
        $canvasProperties = JFBConnectControllerCanvas::setupCanvasProperties();

        $canvasTabTemplate = $model->getSetting('canvas_tab_template', -1);
        $canvasCanvasTemplate = $model->getSetting('canvas_canvas_template', -1);

        $this->assignRef('canvasProperties', $canvasProperties);
        $this->assignRef('canvasTabTemplate', $canvasTabTemplate);
        $this->assignRef('canvasCanvasTemplate', $canvasCanvasTemplate);
        $this->assignRef('templates', $templates);
        $this->assignRef('model', $model);
        $this->assignRef('jfbcLibrary', $jfbcLibrary);
        parent::display($tpl);
    }

}
