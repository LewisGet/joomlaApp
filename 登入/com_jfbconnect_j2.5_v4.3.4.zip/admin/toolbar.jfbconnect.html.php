<?php
/**
 * @package        JFBConnect
 * @copyright (C) 2009-2013 by Source Coast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * @package Joomla
 * @subpackage Config
 */
class TOOLBAR_JFBConnect
{
    static function _DEFAULT()
    {
        $viewName = JRequest::getVar('view');

        // TODO: Move the title control into each view.html.php file.
        if ($viewName != 'OpenGraph')
            JToolBarHelper::title('JFBConnect', 'jfbconnect.png');

        if ($viewName == "Config" || $viewName == "Social" || $viewName == "Profiles" || $viewName == "Canvas")
        {
            JToolBarHelper::apply('apply', JText::_('COM_JFBCONNECT_BUTTON_APPLY_CHANGES'));
        }

        // Check if AutoTune is up-to-date
        if ($viewName != 'AutoTune')
        {
            JToolBarHelper::divider();
            $autotuneModel = JModel::getInstance('AutoTune', 'JFBConnectModel');
            $upToDate = $autotuneModel->isUpToDate();
            if ($upToDate)
                JToolBarHelper::custom('autotune', 'config', 'config', JText::_('COM_JFBCONNECT_BUTTON_AUTOTUNE'), false);
            else
                JToolBarHelper::custom('autotune', 'config', 'config', JText::_('COM_JFBCONNECT_BUTTON_AUTOTUNE_RECOMMENDED'), false);
        }
        else
            JToolBarHelper::title(JText::_('COM_JFBCONNECT_TITLE_AUTOTUNE'), 'jfbconnect.png');

    }

}