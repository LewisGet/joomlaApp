<?php
/**
 * @package        JFBConnect
 * @copyright (C) 2009-2013 by Source Coast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
// No direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
jimport('sourcecoast.utilities');

class JFBConnectViewLoginRegister extends JView
{
    var $_configModel;
    var $_loginRegisterModel;
    var $_postData;

    function display($tpl = null)
    {
        $jfbcLibrary = JFBConnectFacebookLibrary::getInstance();
        $fbUserId = $jfbcLibrary->getFbUserId();
        $fbUserProfile = $jfbcLibrary->_getUserName($fbUserId);
        $this->_configModel = $jfbcLibrary->getConfigModel();
        $this->_loginRegisterModel = $this->getModel('loginregister');

        if ($fbUserId == null)
        {
            $app = JFactory::getApplication();
            $app->redirect('index.php');
        }

        $app = JFactory::getApplication();
        JPluginHelper::importPlugin('jfbcprofiles');
        $profileFields = $app->triggerEvent('jfbcProfilesOnShowRegisterForm');

        // Get previously filled in values
        $this->_postData = $this->_getLoginRegisterPostData();

        $fbEmail1 = '';
        $fbEmail2 = '';

        SCUserUtilities::getDisplayEmail($this->_postData, $fbUserProfile['email'], $fbEmail1, $fbEmail2);
        $fbUsername = SCUserUtilities::getDisplayUsername($this->_postData, $fbUserProfile['first_name'], $fbUserProfile['last_name'], $fbEmail1, $fbUserId, $this->_configModel, $this->_loginRegisterModel);
        $fbPassword = SCUserUtilities::getDisplayPassword($this->_configModel, $this->_loginRegisterModel);
        $fbMemberName = SCUserUtilities::getDisplayNameByFullName($this->_postData, $fbUserProfile['name']);

         //SC15

        
        $language = JFactory::getLanguage();
        $language->load('com_users');
        JModel::addIncludePath(JPATH_SITE . DS . 'components' . DS . 'com_users' . DS . 'models');
        $userModel = JModel::getInstance('Registration', 'UsersModel');
        $this->data = $userModel->getData();
        JForm::addFormPath(JPATH_SITE . DS . 'components' . DS . 'com_users' . DS . 'models' . DS . 'forms');
        JForm::addFieldPath(JPATH_SITE . DS . 'components' . DS . 'com_users' . DS . 'models' . DS . 'fields');
        $this->form = $userModel->getForm();

        // Setup the fields we can pre-populate
        // To do: Give option to show/hide the name on the form
        $this->form->setValue('name', null, $fbMemberName);

        $this->form->setValue('username', null, $fbUsername);
        if (!$this->_configModel->getSetting('registration_show_username') && $fbUsername != '')
        {
            $this->form->setFieldAttribute('username', 'type', 'hidden');
        }

        $this->form->setValue('email1', null, $fbEmail1);
        $this->form->setValue('email2', null, $fbEmail2);
        if (!$this->_configModel->getSetting('registration_show_email') && $fbEmail1 != '' && $fbEmail2 != '')
        {
            $this->form->setFieldAttribute('email1', 'type', 'hidden');
            $this->form->setFieldAttribute('email2', 'type', 'hidden');
        }

        $this->form->setValue('password1', null, $fbPassword);
        $this->form->setValue('password2', null, $fbPassword);
        if (!$this->_configModel->getSetting('registration_show_password') && $fbPassword != '')
        {
            $this->form->setFieldAttribute('password1', 'type', 'hidden');
            $this->form->setFieldAttribute('password2', 'type', 'hidden');
        }

        // Set an inputbox style on all the input elements so that inherited template styles look better
        $this->form->setFieldAttribute('name', 'class', 'inputbox');
        $this->form->setFieldAttribute('username', 'class', 'validate-username inputbox');
        $this->form->setFieldAttribute('email1', 'class', 'inputbox');
        $this->form->setFieldAttribute('email2', 'class', 'inputbox');
        $this->form->setFieldAttribute('password1', 'class', 'validate-password inputbox');
        $this->form->setFieldAttribute('password2', 'class', 'validate-password inputbox');
         //SC16

        //Check for form validation from each of the plugins
        $areProfilesValidating = $app->triggerEvent('jfbcProfilesAddFormValidation');
        $defaultValidationNeeded = true;
        foreach ($areProfilesValidating as $hasDoneValidation)
        {
            if ($hasDoneValidation == true)
            {
                $defaultValidationNeeded = false;
                break;
            }
        }

        //Check to see if JLinked is installed
        $jLinkedLoginButton = "";
        if (SCSocialUtilities::isJLinkedInstalled())
        {
            require_once(JPATH_ROOT . DS . 'components' . DS . 'com_jlinked' . DS . 'libraries' . DS . 'linkedin.php');
            $jLinkedLibrary =& JLinkedApiLibrary::getInstance();

            SCStringUtilities::loadLanguage('com_jlinked');
            $loginText = JText::_('COM_JLINKED_LOGIN_USING_LINKEDIN');

            $jLinkedLoginButton = '<link rel="stylesheet" href="components/com_jlinked/assets/jlinked.css" type="text/css" />';
            $jLinkedLoginButton .= '<div class="jLinkedLogin"><a href="' . $jLinkedLibrary->getLoginURL() . '"><span class="jlinkedButton"></span><span class="jlinkedLoginButton">' . $loginText . '</span></a></div>';
        }

        // Setup the view appearance
        // TODO: Make the addStyleSheet into a Utilities function to be used elsewhere.
        $displayType = $this->_configModel->getSetting('registration_display_mode');;
        $css = JPath::find($this->_path['template'], 'loginregister.css');
        $css = str_replace(JPATH_ROOT.DS, JURI::base(), $css);
        $doc = JFactory::getDocument();
        $doc->addStyleSheet($css);

        // Set the session bit to check for a new login on next page load
        SCSocialUtilities::setJFBCNewMappingEnabled();

        $this->assignRef('fbUserId', $fbUserId);
        $this->assignRef('fbUserProfile', $fbUserProfile);
        $this->assignRef('configModel', $this->_configModel);
        $this->assignRef('profileFields', $profileFields);
        $this->assignRef('jLinkedLoginButton', $jLinkedLoginButton);
        $this->assignRef('defaultValidationNeeded', $defaultValidationNeeded);
        $this->assignRef('displayType', $displayType);

        parent::display($tpl);
    }

    function _getLoginRegisterPostData()
    {
        $session = JFactory::getSession();
        $postData = $session->get('postDataLoginRegister', array());

        $this->assignRef('postData', $postData);

        return $postData;
    }
}
