<?php
defined('_JEXEC') or die;

// For backwards compatibility
require_once __DIR__ . '/agents.php';
class JElementNN_Browsers extends JElementNN_Agents
{
}
