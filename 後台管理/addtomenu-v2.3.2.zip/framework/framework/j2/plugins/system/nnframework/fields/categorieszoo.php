<?php
defined('_JEXEC') or die;

// For backwards compatibility
require_once __DIR__ . '/zoo.php';
class JFormFieldNN_CategoriesZOO extends JFormFieldNN_ZOO
{
}
