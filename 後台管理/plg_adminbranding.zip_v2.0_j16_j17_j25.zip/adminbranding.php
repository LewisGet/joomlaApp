<?php
/*------------------------------------------------------------------------
# plg_adminbranding - System - Admin Branding
# ------------------------------------------------------------------------
# author    Sabuj Kundu
# copyright Copyright (C) 2010-2012 codeboxr.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://codeboxr.com
# Technical Support:  Forum - http://codeboxr.com/product/joomla-admin-branding
-------------------------------------------------------------------------*/

//error_reporting(E_ALL);
//ini_set("display_errors", 1);

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
 
/**
 * Adminbranding system plugin
 */
class plgSystemAdminbranding extends JPlugin
{
	/**
	 * Constructor.
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	public function __construct( &$subject, $config )
	{
            parent::__construct( $subject, $config );
            //global $mainframe;

            // Do some extra initialisation in this constructor if required
            // load plugin parameters
            //$this->_plugin = JPluginHelper::getPlugin( 'system', 'adminbranding' );
            //$this->params = new JParameter( $this->_plugin->params );
            // return if params are empty
            if(!$this->params) return;
            //change admin header portion
            //$this->_headercolor     = $this->params->get('headercolor','h_green');
            $this->_headercolor     = 'h_blue';
            $this->_headerpadding   = $this->params->get('headerpadding',10);
            //$this->_headerheight    = $this->params->get('headerheight',70);
            $this->_bcolor          = $this->params->get('bcolor','#d9d9d9');

            $this->_gcolor1         = $this->params->get('gcolor1','#d7d7d7');
            $this->_gcolor2         = $this->params->get('gcolor2','#e4e4e4');
            $this->_showlogo        = $this->params->get('showlogo',1);
            $this->_showslogo       = $this->params->get('showslogo',1);
            $this->_customlogo      = $this->params->get('customlogo','powered_by.png');
            //$this->_showversion     = $this->params->get('showversion', 1);
            $this->_showtitle       = $this->params->get('showtitle', 1);
            $this->_titlepadding    = $this->params->get('titlepadding', 0);
            $this->_titleheight     = $this->params->get('titleheight', 0);
            $this->_colort          = $this->params->get('colort','#FFFFFF'); //getault background color #000000
            //$this->_colorv          = $this->params->get('colorv','#000000'); //getault background color #000000
            $this->_showfooter      = $this->params->get('showfooter', 1); //getault show
            $this->_showheadercolor = $this->params->get('showheadercolor', 1); //getault show
            $this->_showhgradient   = $this->params->get('showhgradient', 1); //getault show
            $this->_showround       = $this->params->get('showround', 1); //getalt show
            $this->_headerheight    = intval($this->params->get('headerheight',70));

            // admin login page
            
            
            $app = &JFactory::getApplication(); //global $mainframe;  in j1.5
            // Dont run in admin if preview is not enabled
            if (!$app->isAdmin()) return;

            $user =& JFactory::getUser();
            if($user->guest) $this->_loginpage = true;
            else $this->_loginpage = false;
            
            $this->_showlogintitle   = $this->params->get('showlogintitle',1); //default show login title
            //login image
            $this->_showcllogo       = $this->params->get('showcllogo',0);
            $this->_customlogologin  = $this->params->get('customlogologin','');
            $this->_customlogologinh = $this->params->get('customlogologinh','75');

            //lock
            $this->_showlock         = $this->params->get('showlock',1);
            $this->_showclock        = $this->params->get('showclock',0);
            $this->_customlogol      = $this->params->get('customlogol','');

            //admin favicon
            //$this->_adminfavicon     = $this->params->get('adminfavicon',1);
            //$this->_adminfaviconurl  = $this->params->get('adminfaviconurl','');
            
            //var_dump($this->_loginpage);
	}
 
	/**
	 * Do something onAfterInitialise 
	 */
	function onAfterInitialise()
	{
	         
	
	}
 
	/**
	 * Do something onAfterRoute 
	 */
	function onAfterRoute()
	{
	
	}
 
	/**
	 * Do something onAfterDispatch 
	 */
	function onAfterDispatch()
	{
            $version = new JVersion();
            //var_dump($version);
            //var_dump($version->RELEASE);
            $app = &JFactory::getApplication(); //global $mainframe;  in j1.5
            // Dont run in admin if preview is not enabled
            if (!$app->isAdmin()) return;
            $doc = &JFactory::getDocument();            
            $extracss = '';
            $paddingtitle = '';
            $hidelogo = '';
            if(intval($this->_showlogo)){
                //if($this->_customlogo != ''){
                //    $hidelogo = 'background: url("'.JURI::root().'images/'.$this->_customlogo .'") 10px  5px no-repeat;';
                //}
            }
            else {
                $hidelogo = 'background:none; display:none;';
                //$paddingtitle = 'padding-left:0;';
            }
            $extracss .= 'body #border-top .logo{'.$hidelogo.'}';

            
            /*
            $hideversion ='';

            //var_dump($this->_showversion);
            if(intval($this->_showversion) == 0){
                $hideversion = 'display:none; text-indent:-99999px;';
            }
            */
            $hidetitle = '';
            //var_dump($this->_showtitle);
            if(intval($this->_showtitle) == 0){
                $hidetitle = 'display:none; text-indent:-99999px;';
            }
            else{$paddingtitle = 'padding-left:0px;';}
            //var_dump($this->_colorv);


            //$extracss .= ' #border-top span.version{ color:'.$this->_colorv.';'.$hideversion.'}';
            $extracss .= ' body #border-top .title, body #border-top .title a{ color:'.$this->_colort.'; '.$hidetitle.'}';
            $titleheight = '';
            if(intval($this->_showslogo && $this->_customlogo != '')){
                if($this->_showtitle){
                    $paddingtitle = 'padding-left:'.$this->_titlepadding.'px;';
                }
                if($this->_titleheight != '0'){
                    $titleheight = 'height:'.$this->_titleheight.'px;';
                }
                $extracss .= ' body #border-top .title, body #border-top .title a{ display:block;'.$paddingtitle.'}';
                $extracss .= ' body #border-top .title{background: url("'.JURI::root().'images/'.$this->_customlogo .'") 10px  5px no-repeat;'.$titleheight.'}';
                
            }

            if(intval($this->_showfooter) == 0){

                $extracss .= ' body #footer p.copyright{display:none; text-indent:-99999px;}';
            }

            if(intval($this->_loginpage)){
                if(intval($this->_showlock)){
                    if($this->_showclock && $this->_customlogol != '' ){
                        $extracss .= ' .login #lock{height:137px; width:150px; background: url("'.JURI::root().'images/'.$this->_customlogol.'") no-repeat;}';
                    }
                }
                else{
                    $extracss .= ' .login #lock{height:137px; width:150px; display:block; background:none;}';
                }
                if($this->_showlogintitle){
                    if(intval($this->_showcllogo && $this->_customlogologin != '')){
                        $extracss .= ' .login h1{text-indent:-99999px; background: url("'.JURI::root().'images/'.$this->_customlogologin.'") no-repeat; height:'.$this->_customlogologinh.'px;}';
                    }
                }
                else{
                    $extracss .= ' .login h1{display:none; text-indent:-99999px;}';
                }
                

            }

            $gradient = '';
            if(intval($this->_showheadercolor) && intval($this->_showhgradient)){
                $gradient ='background: '.$this->_bcolor.' none;
                            background:-moz-linear-gradient(bottom,  '.$this->_gcolor1.',  '.$this->_gcolor2.');
                            background:-webkit-gradient(linear, left bottom, left top, from('.$this->_gcolor1.'), to('.$this->_gcolor2.'));}
                            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=\''.$this->_gcolor1.'\', endColorstr=\''.$this->_gcolor2.'\');
                            -ms-filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=\''.$this->_gcolor1.'\', endColorstr=\''.$this->_gcolor2.'\');';
                //var_dump("yes");
            }
            else if(intval($this->_showheadercolor)){
                $gradient = 'background: '.$this->_bcolor.' none;';
            }
            else $gradient = 'background:none no-repeat scroll 0 0 transparent;';
            $round = '';
            //var_dump($this->_showround);
            if(intval($this->_showround)){
                $round = '-webkit-border-radius: 10px 10px 0 0; -moz-border-radius: 10px 10px 0 0; border-radius:10px 10px 0 0; -khtml-border-radius:10px 10px 0 0;';
            }
                        
            
            
            $headerpadding      = intval($this->_headerpadding);
            $headerheight       = intval($this->_headerheight);
            if($headerheight == 0){$headerheightcss    = 'height:auto;';}
            else{$headerheightcss    = 'height:'.$headerheight.'px;';}
            
            $release =  floatval($version->RELEASE);
            switch ($release){
                case $release > 1.6:
                    $extracss .= ' body #border-top.'.$this->_headercolor.'{padding:'.$headerpadding.'px '.$headerpadding.'px 0 '.$headerpadding.'px;'.$headerheightcss.'}';
                    //$extracss .= ' body #border-top.'.$this->_headercolor.' div{ background:transparent;}';
                    $extracss .= 'body #border-top.'.$this->_headercolor.'{border:1px #c6c6c6 solid;'.$round.$gradient.'}';
                    break;
                default:
                    $extracss .= ' body #border-top.'.$this->_headercolor.' div div{background:transparent; padding:'.$headerpadding.'px '.$headerpadding.'px 0 '.$headerpadding.'px;'.$headerheightcss.'}';
                    $extracss .= ' body #border-top.'.$this->_headercolor.' div{ background:transparent;}';
                    $extracss .= ' body #border-top.'.$this->_headercolor.'{border:1px #c6c6c6 solid;'.$round.$gradient.'}';
            }
            
            
            
            
            

            $doc->addStyleDeclaration($extracss);            
	}
 
	/**
	 * Do something onAfterRender 
	 */
	function onAfterRender(){
            $app = &JFactory::getApplication(); //global $mainframe;  in j1.5
            // Dont run in admin if preview is not enabled
            if (!$app->isAdmin()) return;
            $doc = &JFactory::getDocument();
            //var_dump($doc);
            //$extracss = 'body { background:red;}';
            //$doc->addStyleDeclaration($extracss);
            /*
            if($this->_adminfavicon){
                //var_dump('+++++');
                //$app = &JFactory::getApplication(); 
                $doc->addFavicon( JURI::root().'images/'.$this->_adminfaviconurl);
                
            }
            */
	}
}
