<?php
// No direct access
defined('_JEXEC') or die;

// Please update you NoNumber extensions and uninstall the NoNumber Elements plugin!
return;