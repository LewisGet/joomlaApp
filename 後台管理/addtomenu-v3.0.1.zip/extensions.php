<?php
/**
 * Install File
 * Does the stuff for the specific extensions
 *
 * @package         Add to Menu
 * @version         3.0.1
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2013 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

function install(&$states, &$ext)
{
	$name = 'Add to Menu';
	$alias = 'addtomenu';
	$ext = $name . ' (administrator module)';

	// ADMIN MODULE
	$states[] = installExtension($states, $alias, 'NoNumber ' . $name, 'module', array('access' => '3'), 1);
}

