<?php
/**
* FastBroadcast Calendar Statistik Module for Joomla (1.5, 2.5)
*
* @package		FastBroadcast Calendar
* @author    	Horst Noreick
* @copyright 	Copyright (C) 2012 Noreick Software
* @license		GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');


if ( !defined('NOS_LIBRARY') )
	require_once NOSPATH_CALENDAR.'/Nos/Nos.php';

if ( !defined('NOSPATH_CALENDAR') )
	define('NOSPATH_CALENDAR', JPATH_ROOT.'/components/com_noscalendar' );


require_once NOSPATH_CALENDAR.'/helpers/NosCalendarCityCloud.php';
$cloud = new NosCalendarCityCloud();

$itemid = NosCalendar::GetInstance()->Itemid();

$sef = JFactory::getConfig()->get('sef', 1);

$query = array();
if ( $sef )
{
	$query['option'] = 'com_noscalendar'; //  
	$query['target_option'] = JRequest::getCmd('option'); //
	$query['target_view'] 	= JRequest::getCmd('view'); //	
	if ( $itemid )
		$query['Itemid'] = $itemid;
}
else
{
	$query['option'] = JRequest::getCmd('option'); //
	$query['view'] 	= JRequest::getCmd('view'); //
	if ( $itemid )
		$query['Itemid'] = $itemid;
}

$cloud->SetQuery( $query );
$cloud->SetPath( 'index.php' );
$cloud->fontsize_min 	= $params->get('fontsize_min', 12 );
$cloud->max_items 		= $params->get('max_items', 10 );
$cloud->max_tags		= $params->get('max_tags', 6 );

echo $cloud->Render();	
