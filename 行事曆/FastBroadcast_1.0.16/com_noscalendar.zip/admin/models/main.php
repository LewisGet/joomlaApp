<?php
defined('_JEXEC') or die;

if ( !class_exists('JModelLegacy'))
	require_once COM_NOSCALENDAR_ADMIN_COMPONENT_DIR.'/helpers/Nos.JModelLegacy.php';

class NosCalendarModelMain extends JModelLegacy
{
	public function getData()
	{
		return null;
	}
}
