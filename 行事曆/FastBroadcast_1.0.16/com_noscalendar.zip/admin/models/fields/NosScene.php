<?php
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

defined('JPATH_BASE') or die;

class JFormFieldNosScene extends JFormFieldList
{
	protected $type = 'NosScene';

	protected function getOptions()
	{

		require_once ( JPATH_ROOT.DS.'components/com_noscalendar/helpers'.DS.'NosCalendar.php');

		$params = &JComponentHelper::getParams( 'com_noscalendar' );
		$pool = $params->get('pool'); 
		
		$options = array();		
		if ( NosCalendar::GetInstance()->GetScenes( $pool, $scenes ) == NOS_SUCCESS )
		{
			$options[] = JHtml::_('select.option', '', '' );
			foreach ( $scenes as $scene )
				$options[] = JHtml::_('select.option', $scene, $scene );
		}
		
		return $options;		
	}
	
}
