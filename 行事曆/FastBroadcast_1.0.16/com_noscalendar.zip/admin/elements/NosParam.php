<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

 defined('_JEXEC') or die('Restricted access');

class JElementNosSeparator extends JElement
{
	var $name = 'NosSeparator';
	
	function fetchElement( $name, $value, &$node, $control_name)
	{
		return '<div style="font-weight:bold;">' . $value . 'xxx</div>';
	}
}



?>