<?php 
	defined('_JEXEC') or die;
?> 

	<table width="100%" cellspacing="0" cellpadding="">
		<tr>
			<td valign="top" style="padding-right: 20px; line-height: 1.3em;  padding: 20px;">
				<div style="background-color: #ffffff; padding-left: 40px; padding-right: 40px; padding-top: 60px; padding-bottom: 40px;">
				<p style="font-size: 120%; color: #146295; font-weight: bold; margin-bottom: 30px;">Vielen Dank, dass Sie FastBroadcast einsetzen!</p> 
				
			
				<p>Die <strong>Grundeinstellung</strong> der FastBroadcast-Extension erfolgt über den Optionen-Dialog, 
				der sich rechts oben auf dieser Seite befindet.
				</p>
				
				<p>Um den Kalender sichtbar zu machen, muss ein neuer Menüeintrag angelegt werden.
				Einstellungen zur Anzeige des Kalenders werden bei der Bearbeitung des Menüeintrags sichtbar. 
				<strong>Hilfe zu den Einstellungsmöglichkeiten</strong> erhalten Sie, wenn Sie die Maus über 
				den Namen einer Einstelloption bewegen, wie in der Abbildung rechts.</p>

				
				<P>FastBroadcast ist ein Community-Kalender, das bedeutet, dass die Kalendereinträge 
				auch für andere öffentlich sichtbar sind und auch auf anderen Portalen und Seiten angezeigt werden. 
				Es muss nicht jeder, der Termine in den Kalender einträgt eine eigene (Joomla-)Wesite haben, 
				deshalb sind die Programme zum Anzeigen von Terminen (diese Komponente) getrennt zu sehen, 
				von den Programmen zum Einstellen von Terminen.</p>   
				<p>
				Zum <strong>Eintragen von Veranstaltungen</strong> in Ihren Kalender benötigen Sie die Kalendersoftware 
				von <a style="font-weight: bold;" href="http://www.FastBroadcast.de">www.FastBroadcast.de</a>, 
				die dort kostenlos heruntergeladen werden kann. Diese Software erfordert nach der Installation beim ersten
				Aufruf eine Registrierung, die von den Administratoren bestätigt werden muss. Die Registrierung ist notwendig, 
				jeder Einträge in den öffentlich sichtbaren Kalender machen kann und die Admins müssen dafür sorgen, dass der 
				Kalender für alle angenehm bleibt.
				</p>
				<p>
				Für Vorschläge zur Verbesserung der Software sind wir stets offen und wir freuen uns darauf, mit Ihnen zusammen das 
				System beständig nützlicher für Ihre Einsatz zu machen. Für Fragen, Anregungen und Kritik 
				nutzen Sie bitte das Forum auf <a style="font-weight: bold;" href="http://www.FastBroadcast.de">www.FastBroadcast.de</a>. Bei Fragen zu 
				individuellen Anpassungen oder Programmieraufgaben nutzen Sie bitte die E-mail: horst.noreick@fastbroadcast.de 
				oder das Kontaktformular auf FastBroadcast.de
				</P>
				<p>
				INCREASE THE SPIRIT
				</p>
				<p>
				Horst Noreick
				</p>
				
				
				<div>
				<a href="http://www.fastbroadcast.de" style="display: block; padding-top: 6px; text-align: center;" title="FastBroadcast.de - Increase the Spirit">
					<img src="<?php echo JURI::base( true ). '/components/com_noscalendar/images/fastbroadcast-logo.png'; ?>" width="200" height="45" alt="&copy; 2012 FastBroadcast.de - Increase the Spirit" title="FastBroadcast.de - Increase the Spirit"/>
				</a>
				</div>
				
				<div style="padding: 10px; margin-top: 60px; ">
				<strong>ANGEBOT:</strong> Wenn Sie mit einem Grafikprogramm ein schickes Layout für den 
				Kalender erstellen, dass Sie auch kostenfrei mit anderen Benutzern teilen wollen, 
				realisieren wir das kostenfrei. (Disclaimer: ... sofern wir Ihren Entwurf für andere Mitglieder als nützlich 
				einschätzen.). Einfach mal anfragen... 				
				</div>
				     

				</div>				
			</td>
			<td valign="top" style="padding: 20px;">
				<div style=" width: 392px; padding: 10px; float: right;  background-color: #ffffff; font-size: 85%; " >
					<img style="margin-bottom: 10px;" src="<?php echo JURI::base( true ).'/components/com_noscalendar/images/help01_de.gif';?>" />
					Sie erhalten Hilfe zu den einzelnen Einstellungsmöglichkeiten, wenn Sie mit der Maus über den Namen
					einer Einstellung fahren, so wie in der Abbildung.  
				</div>   
			</td>
		</tr>
	
	</table>

