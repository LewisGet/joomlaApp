<?php
/**
 * @package     
 * @subpackage  
 *
 * @copyright   
 * @license     
 */

defined('_JEXEC') or die;
?>


<div style="font-size: 130%; ">

<?php 


switch ( strtolower(JFactory::getDocument()->language) )
{
case 'de-de':
	require_once 'default_de.php';
	break;
default:
	require_once 'default_en.php';
}
?>
	
	
</div>

