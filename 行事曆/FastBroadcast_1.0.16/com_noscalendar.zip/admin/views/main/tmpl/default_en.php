<?php 
	defined('_JEXEC') or die;
?> 

	<table width="100%" cellspacing="0" cellpadding="">
		<tr>
			<td valign="top" style="padding-right: 20px; line-height: 1.3em;  padding: 20px;">
				<div style="background-color: #ffffff; padding-left: 40px; padding-right: 40px; padding-top: 60px; padding-bottom: 40px;">
				<p style="font-size: 120%; color: #146295; font-weight: bold; margin-bottom: 30px;">
				Thanks for using FastBroadcast!</p> 
				
			
				<p><strong>Basic Setup</strong> of the FastBroadcast-Extension will be done with the options-dialog. 
				You 'll find the options-dialog (in Joomla 1.5 and 2.5) top right of this page. 
				</p>
				
				<p>
				To Add a calendar to your application you have to create a new menuitem. 
				You 'll get the configuration options for a specific calendar on the right side 
				of the 'Menu Manager: Edit Menu Item'. If you stay with the mousepointer above a label 
				you will get some help for that option. 
				</p>

				
				<P>
				FastBroadcast is designed as a community-calendar, this means all events are public and 
				available on other sites, portales and facebook-fanpages. 
				It is not required that each organizer has an own website, this is the reason
				that frontent and backend are different applications in this release.
				The creation and editing of events will be done by a desktop application you can download at 
				<a style="font-weight: bold;" href="http://www.FastBroadcast.de">www.FastBroadcast.de</a> 
				for free. The desktop application requires a user-registration because we have to ensure 
				that people who insert and edit events in this public calendar are real an do legal things.
				</p>
				<p>
				Please help us to increase the power of this tool. For ideas, questions and critic you can 
				use the forum on <a style="font-weight: bold;" href="http://www.FastBroadcast.de">www.FastBroadcast.de</a>.
				Request for individual programing task you can also use the contact form on FastBroadcast.de 
				or send a mail to horst.noreick@fastbroadcast.de.	
				</P>
				<p>
				INCREASE THE SPIRIT
				</p>
				<p>
				Horst Noreick
				</p>
				
				
				<div>
				<a href="http://www.fastbroadcast.de" style="display: block; padding-top: 6px; text-align: center;" title="FastBroadcast.de - Increase the Spirit">
					<img src="<?php echo JURI::base( true ). '/components/com_noscalendar/images/fastbroadcast-logo.png'; ?>" width="200" height="45" alt="&copy; 2012 FastBroadcast.de - Increase the Spirit" title="FastBroadcast.de - Increase the Spirit"/>
				</a>
				</div>
				     

				</div>				
			</td>
			<td valign="top" style="padding: 20px;">
				<div style=" width: 392px; padding: 10px; float: right;  background-color: #ffffff; font-size: 85%; " >
					<img style="margin-bottom: 10px;" src="<?php echo JURI::base( true ).'/components/com_noscalendar/images/help01_de.gif';?>" />
					You 'll get more information for a specific option if you stay with the mousepointer above a label.  
				</div>   
			</td>
		</tr>
	
	</table>

