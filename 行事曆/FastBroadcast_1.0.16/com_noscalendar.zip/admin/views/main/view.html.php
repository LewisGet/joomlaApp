<?php
defined('_JEXEC') or die;

if ( !class_exists('JViewLegacy'))
	require_once COM_NOSCALENDAR_ADMIN_COMPONENT_DIR.'/helpers/Nos.JViewLegacy.php';

class NosCalendarViewMain extends JViewLegacy
{
	public function display($tpl = null)
	{
		JToolbarHelper::preferences('com_noscalendar');
	
		parent::display($tpl);
	}
	
}
