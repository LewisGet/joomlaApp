<?php
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

define('NOSPATH_CALENDAR', JPATH_COMPONENT );
define('NOSPATH_CALENDAR_HELPERS', JPATH_COMPONENT.'/helpers' );
define('NOSPATH_CALENDAR_ASSETS', JPATH_COMPONENT.'/assets' );

// Require the base controller
require_once JPATH_COMPONENT.'/controller.php';

if ( !defined('NOS_LIBRARY') )
	require_once JPATH_BASE.'/components/com_noscalendar/Nos/Nos.php';


require_once NOSPATH_CALENDAR_HELPERS.'/NosCalendar.php';

// TODO
//JPluginHelper::importPlugin('noscalendar');

$controller = new NosCalendarController();

// Perform the Request task
$controller->execute( JRequest::getVar('task') );

// Redirect if set by the controller
$controller->redirect();

?>
