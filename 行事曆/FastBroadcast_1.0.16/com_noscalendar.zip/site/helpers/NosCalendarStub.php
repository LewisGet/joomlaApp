<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// This Line is required to pass the JEDChecker in Joomla
defined('_JEXEC') or die('Restricted access');
 
 
defined( 'NOS_LIBRARY' ) or die( 'Restricted access' );

class NosCalendarStub
{
	var $date 				= 0;
	var $showColHeader 		= true;
	var $showLineHeader 	= true;
	var $class				= '';
	var $orientation		= ''; // horizontal oder vertical
	var $showHeaderweekdays	= 0; // 0 = ausgeschrieb, >0 = Anzahl der Zeichen 
	var $offset				= 0; //
	var $time				= 0; //
	
	
	function IsCurrentDay( $day )
	{
		$a = getdate($day);
		$b = getdate(time());
		return ($a['mon'] == $b['mon'] && $a['mday'] == $b['mday'] && $a['year'] == $b['year']);	
	}
	
	
}



?>