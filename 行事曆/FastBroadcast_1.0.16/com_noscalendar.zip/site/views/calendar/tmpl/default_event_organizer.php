<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$calendar = NosCalendar::GetInstance();

$e = $this->event_class;
$i = 0;

?>



<div class="eventbox eventbox-organizer">
  <div class="title">
    <?php echo Nos::GetString('TID_VERANSTALTER')?>
  </div>

  <?php
	while ( ($organizer = $e->Organizer($i++)) != null )	
	{
		$url = $organizer->URL();
	?>

  <div class="organizer-wrapper">
    <?php 
		
			if ( $organizer->IsLogo() )
			{
				if ( $url )
					echo '<a href="'. $url. '">';
					
				echo '<img class="logo" src="' . $organizer->LogoURL( 1, $calendar->GetParam('event_logo_width') ) . '" alt="" /><br />';
				if ( $url )
					echo "</a>";
			}					
		
			if ( $url )
				echo "<a href=\"$url\">";
			echo $organizer->FullName();
			if ( $url )
				echo "</a>";
		?>
		<br />
		</div>

	<?php 
	}
	?>
</div>




