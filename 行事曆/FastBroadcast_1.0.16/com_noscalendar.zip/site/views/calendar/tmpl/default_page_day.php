<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$eventlist 	= $this->eventlist;
$e = $this->event_class;
$calendar = NosCalendar::GetInstance();


$this->day = $calendar->GetTime();

?>

<div class="view_calendar eventlist week <?php echo $this->eventlist_class; ?>" >

<?php
    $event = ( is_array($eventlist) && count($eventlist))? $eventlist[0] : null;
	$e->SetEvent( $event );
	
	if ( $e->IsValid() )
	{	
		$class = ($e->IsToday())? ' current' : '';
			echo '<div class="day'. $class .'" >';	// BEGIN: day
				
		if ( $this->show_dayheader )		
			echo $this->loadTemplate( 'eventlist_dayheader' );
		
		if ( $this->show_daymarker )
			echo $this->loadTemplate( 'eventlist_daymarker' );
		
		echo '<div class="event_wrapper">';	// BEGIN: event_wrapper
					
		while ( $e->IsValid() )
		{
			echo $this->loadTemplate( $this->eventlist_eventtemplate );			
			
			$e->SetEvent( next($eventlist) );
			if ( $e->IsValid() )
				echo '<span class="event_separator" >&nbsp;</span>';
		}
	
		echo '</div>';						// END: event_wrapper
		echo '</div>';						// END: day		
	}			
?>		

</div>