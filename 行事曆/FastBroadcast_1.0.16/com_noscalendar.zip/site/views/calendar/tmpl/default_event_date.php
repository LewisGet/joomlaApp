<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$e          = $this->event_class;
$schema_org	= $this->schema_org;

$day = '';

$multilpe_day_event = false;
if ( $e->Start('md') != $e->End('md') && $e->End() - $e->Start() > 60 * 60 * 10 )
{
	$multilpe_day_event = true;
	$start 	= $e->sprintf('{start_d}. {start_F} {start_H}:{start_i} ') . Nos::GetString('TID_UHR');
	$end 	= $e->sprintf('{end_d}. {end_F} {end_H}:{end_i} ') . Nos::GetString('TID_UHR');
}
else 
{
	$day = Nos::GetString($e->Start( 'l' )) . ', ' . $e->Start( 'j' ) . '. ' . Nos::GetString($e->Start( 'F' )) . ' ' . $e->Start( 'Y' );
	$start 	= $e->Start( 'H:i' ) . ' ' . Nos::GetString('TID_UHR');			
	$end 	= $e->End( 'H:i' ) . ' ' . Nos::GetString('TID_UHR');
}



?>
<div class="eventbox date">
  <?php	
    echo $schema_org->meta_startdate();
		echo $schema_org->meta_enddate();
  ?>
	<div class="title"><?php echo Nos::GetString('TID_ZEIT')?></div>
	<?php if (!$multilpe_day_event) echo '<span class="day">'. $day. '</span><br />';?>
	<table cellspacing="0" cellpadding="0">
	<tr><th><?php echo Nos::GetString('TID_BEGINN') . ':'; ?></th><td><?php echo $start;?></td></tr>
	<tr><th><?php echo Nos::GetString('TID_ENDE') . ':'; ?></th><td><?php echo $end;?></td></tr>	
	</table>
</div>




