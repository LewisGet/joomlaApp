<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$e = $this->event_class;
$i = 0;
?>



<div class="eventbox djlist">
	<div class="title"><?php echo Nos::GetString('DJ')?></div>
	<?php while ( ($dj = $e->Dj($i++)) != null ) :	?>
		<div class="dj">
			<?php if ( $dj->IsURL()) : ?>
				<a href="<?php echo $dj->URL(); ?>">
			<?php endif; ?>
			<?php echo $dj->FullName(); ?>
			<?php if ( $dj->IsURL()) : ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endwhile;	?>
</div>





