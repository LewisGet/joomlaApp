<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$calendar = NosCalendar::GetInstance();

if ( !defined('NOS_APPTYPE') )
{
	$version = new JVersion();
	if ( $version->isCompatible('3.0.0') )
		JHtml::_('behavior.framework');
	else
		JHTML::_('behavior.mootools');
}

$skin = $calendar->GetParam( 'skin');
if ( !empty( $skin ))
	$skin = ' skin_'.$skin;
?>


<div id="com_noscalendar" <?php echo $this->schema_org->init_event();?> class="com_noscalendar<?php echo $this->pageclass_sfx;?> ncal_page_<?php echo $this->page; ?> <?php echo $skin;?>">
	<?php
		if ( $calendar->GetParam('show_page_heading') != 0 )
		{
			$page_heading = $this->escape( $calendar->GetParam('page_heading'));
			if ( $page_heading )
				echo "<h1>$page_heading</h1>";
		}
		
/*
 wenn ein text angezeigt werden soll
$textid = 23;
$stmt = 'SELECT * FROM #__content WHERE id = $textid';
$db = JFactory::getDBO();
$db->setQuery(
              'SELECT *' .
              ' FROM #__content' .
              ' WHERE id = '.(int)$textid
         );

if ( ($content = $db->loadObject()))
{
	echo '<div class="contentheading">' . $content->title . '</div>';
	echo '<div class="contentpaneopen">' . $content->introtext . $content->fulltext . '</div>';
}
*/	
		
		
		
		if ( $calendar->GetParam('show_navigationbar') != 0 )
			echo $calendar->NavigationBar($this->periodScrollButtonParams, $this->headline, $this->periodButtonParams );
			
		echo $this->loadTemplate( 'page_'.$this->page );
	?>
	
	<div id="fastbroadcast" style="text-align: center;">
		<span class="day_separator">&nbsp;</span>
		<a href="http://www.fastbroadcast.de" style="display: block; padding-top: 6px;" title="Get an own calendar for your site and connect to the community">
			<img src="<?php echo JURI::base( true ). '/components/com_noscalendar/assets/images/fastbroadcast-logo.png'; ?>" width="200" height="45" alt="&copy; 2012 FastBroadcast.de - Increase the Spirit" title="Get an own calendar for your site and connect to the community"/>
		</a>
	</div>
</div>


