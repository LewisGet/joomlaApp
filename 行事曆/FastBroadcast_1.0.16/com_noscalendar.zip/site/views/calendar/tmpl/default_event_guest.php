<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$calendar = NosCalendar::GetInstance();

$e = $this->event_class;
$i = 0;

?>



<div class="eventbox guestlist">
  <div class="title">
    <?php echo Nos::GetString('TID_GAST')?>
  </div>

  <?php
	while ( ($guest = $e->Guest($i++)) != null )	
	{
		$url = $guest->URL();
	?>

  <div class="guest">
    <?php 
		
			if ( $guest->IsLogo() )
			{
				if ( $url )
					echo '<a href="'. $url. '">';
					
				echo '<img class="logo" src="' . $guest->LogoURL( 1, $calendar->GetParam('event_logo_width') ) . '" alt="" /><br />';
				if ( $url )
					echo "</a>";
			}					
		
			if ( $url )
				echo "<a href=\"$url\">";
			echo $guest->FullName();
			if ( $url )
				echo "</a>";
		?>
		<br />
		</div>

	<?php 
	}
	?>
</div>




