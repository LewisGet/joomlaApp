<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

// Dayheader darf nicht event beutzen, weil nicht zwingend für jeden
// Tag ein Event vorhanden ist!!

$day = getdate( $this->day );


/*
$class		= 'daymarker';
$calendar 	= NosCalendar::GetInstance();	


$date = Nos::GetString(date( "l", $day )).' '. date( "j", $day ) .'.'. date( "n", $day );

$month_abbr = substr( Nos::GetString( $d['month'] ), 0, 3 );
$day_nr		= GetString( $d['month'] ), 0, 3 );

$navigation_show_day = $calendar->GetParam( 'navigation_show_day','int', true, '0');

// if the dayview is not part of the navigation, the day_view cannot be a link target
if ( $navigation_show_day )
{
	$d		= getdate($day);
	$url 	= JRoute::_('index.php?option=com_noscalendar&view=calendar&page=day' . $calendar->GetDateURLParams('day', $d['year'], $d['mon'], $d['mday'] ) . $calendar->GetSysParams(true) );		
}
*/
?>

<div class="daymarker">
	<div class="dm_month_abbr" >
		<?php echo mb_substr( Nos::GetString( $day['month'] ), 0, 3 ); ?>
	</div>
	<div class="dm_mday" >
		<?php echo $day['mday'] ?>
	</div>	
	<div class="dm_weekday" >
		<?php echo Nos::GetString( $day['weekday']); ?>
	</div>	
</div>
