<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$event 	= $this->event;
$url 	= JURI::getInstance()->toString();
$config = JFactory::getApplication()->getParams('com_noscalendar');
?>


<div class="eventbox share">
	<?php if ($config->get( 'event_show_plusone', 1 )) :?>
	<a class="function share plusone " href="https://plus.google.com/share?hl=de&amp;url=<?php echo urlencode($url);?>" rel="nofollow">
		<span class="uiButtonTip" title="<?php echo Nos::GetString('TID_SHARE_ON_PLUSONE');?>"><span class="ico">&nbsp;</span>Google+</span>
	</a>
	<?php endif; ?>
	<?php if ($config->get( 'event_show_xing', 1 )) :?>	
	<a class="function share xing uiButtonTip" href="https://xing.com/social_plugins/share?url=<?php echo urlencode($url);?>" title="XING" rel="nofollow">
		<span class="uiButtonTip" title="<?php echo Nos::GetString('TID_SHARE_ON_XING');?>"><span class="ico">&nbsp;</span>XING</span>
	</a>
	<?php endif; ?>
	<?php if ($config->get( 'event_show_linkedin', 0 )) :?>		
	<a class="function share linkedin" href="https://linkedin.com/cws/share?url=<?php echo urlencode($url);?>" rel="nofollow">
		<span class="uiButtonTip" title="<?php echo Nos::GetString('TID_SHARE_ON_LINKEDIN');?>"><span class="ico">&nbsp;</span>Linked in</span>
	</a>
	<?php endif; ?>
	<?php if ($config->get( 'event_show_twitter', 1 )) :?>		
	<a class="function share twitter" href="https://twitter.com/home/?status=<?php echo urlencode($url);?>" rel="nofollow">
		<span class="uiButtonTip" title="<?php echo Nos::GetString('TID_SHARE_ON_TWITTER');?>"><span class="ico">&nbsp;</span>Twitter</span>
	</a>
	<?php endif; ?>
	<?php if ($config->get( 'event_show_facebook', 1 )) :?>		
	<a class="function share facebook" href="https://facebook.com/share.php?u=<?php echo urlencode($url);?>" rel="nofollow">
		<span class="uiButtonTip" title="<?php echo Nos::GetString('TID_SHARE_ON_FACEBOOK');?>"><span class="ico">&nbsp;</span>Facebook</span>
	</a>
	<?php endif; ?>	
</div>	 