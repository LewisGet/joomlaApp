<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

//$event = $this->event;
$e = $this->event_class;
$download_list = $e->Download();

$calendar = NosCalendar::GetInstance();
?>

<div class="eventbox download">
	<div class="title"><?php echo Nos::GetString('TID_DOWNLOAD')?></div>
	<?php 
	$i = 0;
	foreach ( $download_list as $download )
	{
		$url = $e->DownloadURL( $i );
		$extension = isset($download['EXTENSION'])? $download['EXTENSION'] : ''; 
		$text = isset($download['TEXT'])? Nos::GetString($download['TEXT']) : Nos::GetString('Download') . ' #'. $i;
		echo '<div class="evt_download"><a href="'.$url.'"><span class="ico '. $extension . '">&nbsp;</span>' . $text .'</a></div>';
		
		$i++;
	}
	
	echo '<div class="evt_download"><a href="'.$e->ICalURL().'"><span class="ico ical">&nbsp;</span>'.Nos::GetString('TID_TERMIN_IN_KALENDER_EINTRAGEN').'</a></div>';	
	
	?>	
</div>



