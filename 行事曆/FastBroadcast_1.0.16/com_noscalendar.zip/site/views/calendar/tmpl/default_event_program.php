<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$e = $this->event_class;
$program = $e->Program();

?>
<div class="eventbox program">
	<div class="title"><?php echo Nos::GetString('TID_PROGRAMM')?></div>
	<table cellspacing="0" cellpadding="0">
		<?php foreach ( $program as $row ) :?>
		<tr><th><?php echo $row['COL_1'];?></th><td><?php echo $row['COL_2'];?></td></tr>
		<?php endforeach; ?>
	</table>
</div>