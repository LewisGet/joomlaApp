<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

require_once NOSPATH_CALENDAR_HELPERS.DS.'NosCalendarMonth.php';

$calendar = NosCalendar::GetInstance();

$month = new NosCalendarMonth;
$month->time 			= $calendar->GetTime();		
//$month->showLineHeader 	= $calendar->GetParam( 'month_showlineheader', 'cmd', true, '0' );
//$month->showColHeader 	= $calendar->GetParam( 'month_showcolheader', 'cmd', true, '1' );

// These Values are now fixed. It seems to confuse the user
// and it does not make any sense to hide the names of the weekdays.
// lineheaders might be usefull to display the no of the week..
$month->showLineHeader 	= false;
$month->showColHeader 	= true;


$month->event 			= $this->eventlist;	
$month->event_class		= $this->event_class;
echo $month->Export();

?>