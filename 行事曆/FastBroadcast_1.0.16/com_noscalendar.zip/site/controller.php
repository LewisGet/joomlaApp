<?php
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

if ( !class_exists('JControllerLegacy'))
	require_once NOSPATH_CALENDAR_HELPERS.'/Nos.JControllerLegacy.php';

class NosCalendarController extends JControllerLegacy
{
	function display($cachable = false, $urlparams = false)
	{
		parent::display($cachable, $urlparams );			
		return $this;
	}
}

