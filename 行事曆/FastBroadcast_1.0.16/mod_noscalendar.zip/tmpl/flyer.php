<?php 
/**
 * @package		NosCalendar
 * @version		1.0.0
 * @copyright	Copyright (C) 2012 Horst Noreick, Inc. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */ 

// no direct access
defined('_JEXEC') or die('Restricted access'); 

$itemid 		= $params->get('itemid');
$link_to 		= $params->get('link_to', 'event');
$image_style 	= $params->get('image_style');
$image_width 	= (int)$params->get('image_width');
$image_height 	= ($image_style == 'squared')? $image_width : 0;					
$line_1			= $params->get('line_1');
$line_2 		= $params->get('line_2');
$module_width	= $params->get('module_width');

$style			= '';

$module_id = 'mod_noscalendar_' . $params->get('page');

// prepare
if (empty($helper->eventlist))
	return;

// alle events mit flyer in flyerliste kopieren
$flyerlist = array();
foreach ($helper->eventlist as $event ) 
{ 
	$e->SetEvent( $event );
	$index = 0;
	if ( $e->IsFlyer($index) )
		$flyerlist[] = $event;
}

if (empty($flyerlist))
	return;

switch ( count($flyerlist) )
{
case 1: 
	$e->SetEvent( $flyerlist[0] );
	break;
default:
	$e->SetEvent( $flyerlist[ mt_rand( 0, count($flyerlist)-1) ] ); 
}


$index = 0;
$e->IsFlyer($index);
$imageurl = $e->ImageURL( $index, $image_width, $image_height  );

echo '<a href="'.$calendar->EventURL( $e, $itemid, $link_to ).'" >'
	.'<img width="' . $image_width . '" src="' . $imageurl . '" alt="" />'
	.'</a>';

