<?php
/**
* @package   FaceBook Slider
* @copyright Copyright (C) 2009 - 2010 Open Source Matters. All rights reserved.
* @license   http://www.gnu.org/licenses/lgpl.html GNU/LGPL, see LICENSE.php
* Contact to : info@autson.com, autson.com
**/
defined('_JEXEC') or die('Restricted access');
class modFaceBookSliderHelper
{
    
}
?>