News-Show-Pro-GK5
=================

Advanced Joomla! content module.