<?php
/**
 * @package		EasyBlog
 * @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 *
 * EasyBlog is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

$helper	= JPATH_ROOT . DS . 'components' . DS . 'com_easyblog' . DS . 'helpers' . DS . 'helper.php';

jimport( 'joomla.filesystem.file' );

if( !JFile::exists( $helper ) )
{
	return;
}
require_once( $helper );
require_once( dirname(__FILE__) . DS . 'helper.php' );
require_once( dirname(__FILE__) . DS . 'location.php' );

$my 				= JFactory::getUser();
$config				= EasyBlogHelper::getConfig();
$easyblogInstalled 	= true;

$loadedHeaders		= EasyBlogHelper::loadHeaders();

$posts				= modEasyBlogPostMapHelper::getPosts($params);
$category			= '';
$team				= '';
$bloggers			= '';
$tag				= '';

$locations			= '';

foreach( $posts as $post )
{
	// only extract necessary data
	$locations[] = new modEasyBlogMapLocation($post);
}

$language			= JFactory::getLanguage();
$language->load( 'com_easyblog' , JPATH_ROOT );

$document			= JFactory::getDocument();
$document->addStyleSheet( rtrim(JURI::root(), '/') . '/components/com_easyblog/assets/css/module.css' );

require( JModuleHelper::getLayoutPath( 'mod_easyblogpostmap' ) );
