<?php
/**
 * @package		EasyBlog
 * @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 *
 * EasyBlog is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

defined('_JEXEC') or die('Restricted access');

class modEasyBlogMapLocation
{
	public $latitude;
	public $longitude;
	public $address;
	public $title;
	public $content;

	public function __construct($item)
	{
		$this->id = $item->id;
		$this->latitude = $item->latitude;
		$this->longitude = $item->longitude;
		$this->address 	= $item->address;
		$this->title 	= $item->title;
		$this->content 	= $item->title;
		if( isset( $item->html ) )
		{
			$this->content = $item->html;
		}

	}
}
