<?php
/**
 * @package		EasyBlog
 * @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 *
 * EasyBlog is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

defined('_JEXEC') or die('Restricted access');

require_once(JPATH_ROOT.DS.'components'.DS.'com_easyblog'.DS.'helpers'.DS.'helper.php');
require_once(JPATH_ROOT.DS.'components'.DS.'com_easyblog'.DS.'helpers'.DS.'modules.php');
require_once(JPATH_ROOT.DS.'components'.DS.'com_easyblog'.DS.'classes'.DS.'easysimpleimage.php');
jimport('joomla.system.file');
jimport('joomla.system.folder');

class modEasyBlogPostMapHelper
{
	function getPosts(&$params)
	{
		$db 			= JFactory::getDBO();
		$config			= EasyBlogHelper::getConfig();
		$type			= $params->get( 'type' );
		$posts			= '';

		$query  = 'SELECT * FROM ' . $db->nameQuote( '#__easyblog_post' );

		// select valid latitude/longitude or address

		$query .= ' WHERE ((TRIM(' . $db->nameQuote( 'latitude' ) . ') <> ' . $db->quote( '' ) . ' AND TRIM(' . $db->nameQuote( 'longitude' ) . ') <> ' . $db->quote( '' ) . ')';
		$query .= ' OR TRIM(' . $db->nameQuote( 'address' ) . ') <> ' . $db->quote( '' ) . ')';

		/*$query .= ' WHERE ((TRIM(' . $db->nameQuote( 'latitude' ) . ') IS NOT NULL AND TRIM(' . $db->nameQuote( 'longitude' ) . ') IS NOT NULL)';
		$query .= ' OR TRIM(' . $db->nameQuote( 'address' ) . ') IS NOT NULL)';*/

		// select published post
		$query .= ' AND ' . $db->nameQuote( 'published' ) . ' = ' . $db->quote( '1' );

		switch( $type )
		{
			case '1' :
				// by blogger
				$bloggers = self::join( $params->get( 'bloggerids' ) );

				if( !empty( $bloggers ) )
				{
					$query .= ' AND ' . $db->nameQuote( 'created_by' ) . ' IN (' . $bloggers . ')';
				}
				break;
			case '2' :
				// by category
				$categories = self::join( $params->get( 'categoryids' ) );

				if( !empty( $categories ) )
				{
					$query .= ' AND ' . $db->nameQuote( 'category_id' ) . ' IN (' . $categories . ')';
				}
				break;

			case '3' :
				// by tag
				$tags = self::join( $params->get( 'tagids' ) );
				$post_ids = self::join( self::getTagPost( $tags ) );

				if( !empty( $post_ids ) )
				{
					$query .= ' AND ' . $db->nameQuote( 'id' ) . ' IN (' . $post_ids . ')';
				}

				break;

			case '4' :
				// by team
				$teams = self::join( $params->get( 'teamids' ) );
				$post_ids = self::join( self::getTeamPost( $teams ) );

				if( !empty( $post_ids ) )
				{
					$query .= ' AND ' . $db->nameQuote( 'id' ) . ' IN (' . $post_ids . ')';
				}

				break;

			case '0' :
			default:
				// by latest
				$featured = $params->get( 'usefeatured' );

				if( $featured )
				{
					$post_ids = self::join( self::getFeaturedPost() );

					if( !empty( $post_ids ) )
					{
						$query .= ' AND ' . $db->nameQuote( 'id' ) . ' IN (' . $post_ids . ')';
					}
				}
				break;
		}

		// always sort by latest
		$query .= ' ORDER BY ' . $db->nameQuote( 'created' ) . ' DESC';

		// set limit
		$query .= ' LIMIT ' . (int) $params->get( 'count' , 5 );

		$db->setQuery( $query );
		$posts = $db->loadObjectList();

		$posts = self::processItems( $posts, $params );
		return $posts;
	}

	private function processItems( $posts, &$params )
	{
		$config = EasyBlogHelper::getConfig();
		$total = count($posts);

		$results = array();

		for($i = 0; $i < count($posts); $i++ )
		{

			$data 	=& $posts[$i];
			$row 	= EasyBlogHelper::getTable( 'Blog', 'Table' );
			$row->bind( $data );


			$row->commentCount 	= EasyBlogHelper::getCommentCount($row->id);

			JTable::addIncludePath( EBLOG_TABLES );
			$author 			= EasyBlogHelper::getTable( 'Profile', 'Table' );
			$row->author		= $author->load( $row->created_by );
			$row->date			= EasyBlogDateHelper::toFormat( JFactory::getDate( $row->created ) , '%d %B %Y' );

			$row->featuredImage = '';
			if($params->get( 'showfeatureimage' , 1 ))
			{
				$row->featuredImage = self::getFeaturedImage( $row , $params );
			}

			self::prepareTooltipContent( $row, $params );
			$results[] = $row;
		}

		return $results;
	}

	private function prepareTooltipContent( &$post, &$params )
	{
		$image		= '<td class="ebpostmap_featuredImage"';
		if( $params->get( 'showavatar' ) )
		{
			$image .= ' colspan = "2"';
		}
		$image		.= '>'.$post->featuredImage.'</td>';

		$avatar		= '<td class="ebpostmap_avatar" valign="top"><a href="'.$post->author->getProfileLink().'" class="mod-avatar"><img class="avatar" src="'.$post->author->getAvatar().'" /></a></td>';

		$menuItemId = self::_getMenuItemId($post, $params);
		$link		= EasyBlogRouter::_( 'index.php?option=com_easyblog&view=entry&id=' . $post->id . $menuItemId );
		$title		= '<div class="ebpostmap_title"><a href="'.$link.'"><b>'.$post->title.'</b></a></div>';
		$blogger	= '<div class="ebpostmap_blogger">'.JText::sprintf( 'MOD_EASYBLOGPOSTMAP_POST_BY', $post->author->getName() ).'</div>';
		$address	= '<div class="ebpostmap_address">'.JText::sprintf( 'MOD_EASYBLOGPOSTMAP_ADDRESS_AT', $post->address ).'</div>';
		$ratings	= '<div class="ebpostmap_ratings">'.EasyBlogHelper::getHelper( 'ratings' )->getHTML( $post->id, 'entry', '',  'ebpostmap_'.$post->id.'-ratings', true ).'</div>';
		$hits		= '<div class="ebpostmap_hits">'.JText::sprintf( 'MOD_EASYBLOGPOSTMAP_HITS', $post->hits ).'</div>';
		$comment	= '<div class="ebpostmap_comments">'.JText::sprintf( 'MOD_EASYBLOGPOSTMAP_TOTAL_COMMENTS', $post->commentCount ).'</div>';

		$post->html = '<div class="ebpostmap_infoWindow"><table>';

		if( $params->get( 'showfeatureimage' ) && $post->featuredImage )
		{
			$post->html .= '<tr>' . $image . '</tr>';
		}

		$post->html .= '<tr>';

		if( $params->get( 'showavatar' ) )
		{
			$post->html .= $avatar;
		}

		$post->html .= '<td class="ebpostmap_detail">';

		$post->html .= $title;

		if( $params->get( 'showauthor' ) )
		{
			$post->html .= $blogger;
		}

		if( $params->get( 'showaddress' ) )
		{
			$post->html .= $address;
		}

		if( $params->get( 'showcommentcount' ) )
		{
			$post->html .= $comment;
		}

		if( $params->get( 'showhits' ) )
		{
			$post->html .= $hits;
		}

		if( $params->get( 'showratings' ) )
		{
			$post->html .= $ratings;
		}

		$post->html .= '</td></tr></div>';
	}

	private function getFeaturedImage( &$row , &$params )
	{
		$image      = '';
		$isImage    = $row->getImage();
		if( ! empty( $isImage ) )
		{
			$imagesrc   = $row->getImage()->getSource('small');
			$image    = '<img title="'.$row->title.'" src="' . $imagesrc . '" />';
		}
		else
		{
			$image = EasyBlogModulesHelper::getMedia( $row , $params );
		}

		return $image;
	}



	private function getFeaturedImageOld( &$row , &$params )
	{
		$pattern	= '#<img class="featured"[^>]*>#i';
		$content	= $row->intro . $row->content;

		preg_match( $pattern , $content , $matches );

		if( isset( $matches[0] ) )
		{
			// return self::getResizedImage($matches[0] , $params );
			return self::getThumbnailImage( $matches[0] );
		}

		// If featured image is not supplied, try to use the first image as the featured post.
		$pattern				= '#<img[^>]*>#i';

		preg_match( $pattern , $content , $matches );

		if( isset( $matches[0] ) )
		{
			// After extracting the image, remove that image from the post.
			$row->intro		= str_ireplace( $matches[0] , '' , $row->intro );
			$row->content	= str_ireplace( $matches[0] , '' , $row->intro );

			return self::getThumbnailImage( $matches[0] );
		}

		// If all else fail, try to use the default image
		return false;
	}

	private function getThumbnailImage($img)
	{
		$srcpattern = '/src=".*?"/';

		preg_match( $srcpattern , $img , $src );

		if(isset($src[0]))
		{
			$imagepath	= trim(str_ireplace('src=', '', $src[0]) , '"');
			$segment 	= explode('/', $imagepath);
			$file 		= end($segment);
			$thumbnailpath = str_ireplace($file, 'thumb_'.$file, implode('/', $segment));

			if(!JFile::exists($thumbnailpath))
			{
				$image = new EasySimpleImage();
				$image->load($imagepath);
				$image->resize(64, 64);
				$image->save($thumbnailpath);
			}

			if( stristr($thumbnailpath, rtrim( JURI::root(), '/' ) ) === false )
			{
				$thumbnailpath = JURI::root() . ltrim( $thumbnailpath, '/' );
			}

			$newSrc = 'src="'.$thumbnailpath.'"';
		}
		else
		{
			return false;
		}

		$oldAttributes = array('src'=>$srcpattern, 'width'=>'/width=".*?"/', 'height'=>'/height=".*?"/');
		$newAttributes = array('src'=>$newSrc, 'width'=>'', 'height'=>'');

		return preg_replace($oldAttributes, $newAttributes, $img);
	}


	private function getFeaturedPost()
	{
		$db = JFactory::getDBO();

		$query  = 'SELECT ' . $db->nameQuote( 'content_id' ) . ' FROM ' . $db->nameQuote( '#__easyblog_featured' );
		$query .= ' WHERE ' . $db->nameQuote( 'type' ) . ' = ' . $db->quote( 'post' );

		$db->setQuery( $query );

		$post_ids = $db->loadResultArray();
		return $post_ids;
	}

	private function getTagPost($tagid)
	{
		$db = JFactory::getDBO();

		$query  = 'SELECT ' . $db->nameQuote( 'post_id' ) . ' FROM ' . $db->nameQuote( '#__easyblog_post_tag' );
		$query .= ' WHERE ' . $db->nameQuote( 'tag_id' ) . ' IN (' . $db->quote( $tagid ) . ')';

		$db->setQuery( $query );

		$post_ids = $db->loadResultArray();
		return $post_ids;
	}

	private function getTeamPost($teamid)
	{
		$db = JFactory::getDBO();

		$query  = 'SELECT ' . $db->nameQuote( 'post_id' ) . ' FROM ' . $db->nameQuote( '#__easyblog_team_post' );
		$query .= ' WHERE ' . $db->nameQuote( 'team_id' ) . ' IN (' . $db->quote( $teamid ) . ')';

		$db->setQuery( $query );

		$post_ids = $db->loadResultArray();
		return $post_ids;
	}

	private	function _getMenuItemId( $post, &$params)
	{
		$itemId                 = '';
		$routeTypeCategory		= false;
		$routeTypeBlogger		= false;
		$routeTypeTag			= false;

		$routingType            = $params->get( 'routingtype', 'default' );

		if( $routingType != 'default' )
		{
			switch ($routingType)
			{
				case 'menuitem':
					$itemId					= $params->get( 'menuitemid' ) ? '&Itemid=' . $params->get( 'menuitemid' ) : '';
					break;
				case 'category':
					$routeTypeCategory  = true;
					break;
				case 'blogger':
					$routeTypeBlogger  = true;
					break;
				case 'tag':
					$routeTypeTag  = true;
					break;
				default:
					break;
			}
		}

		if( $routeTypeCategory )
		{
			$xid    = EasyBlogRouter::getItemIdByCategories( $post->category_id );
		}
		else if($routeTypeBlogger)
		{
			$xid    = EasyBlogRouter::getItemIdByBlogger( $post->created_by );
		}
		else if($routeTypeTag)
		{
			$tags	= self::_getPostTagIds( $post->id );
			if( $tags !== false )
			{
				foreach( $tags as $tag )
				{
					$xid    = EasyBlogRouter::getItemIdByTag( $tag );
					if( $xid !== false )
						break;
				}
			}
		}

		if( !empty( $xid ) )
		{
			// lets do it, do it, do it, lets override the item id!
			$itemId = '&Itemid=' . $xid;
		}

		return $itemId;
	}

	private function join($items)
	{
		$db = JFactory::getDBO();

		if( !is_array($items) )
		{
			$items = str_replace(' ', '', $items);
			$items = explode(',', $items);
		}

		$temp = '';

		foreach( $items as $item )
		{
			$temp[] = $db->quote( $item );
		}

		$result = implode(',', $temp);

		return $result;
	}

	/*function getPostByBlogger(&$params)
	{
		$db 			= JFactory::getDBO();
		$config			= EasyBlogHelper::getConfig();

		$bloggers		= modLatestBlogsHelper::_getBloggers($params);

		if(! empty($bloggers))
		{
			for($i = 0; $i < count($bloggers); $i++)
			{
				$row    	=& $bloggers[$i];

				$bloggerId  = $row->id;

				$profile		= EasyBlogHelper::getTable( 'Profile', 'Table' );
				$row->details   =& $profile->load($row->id);

				if($row->postcount > 0)
				{
					$row->posts = modLatestBlogsHelper::getLatestPost($params, $bloggerId, 'blogger');
				}
				else
				{
					$row->posts = array();
				}

			}//end foreach
		}

		return $bloggers;
	}



	function getLatestPost(&$params, $id = null, $type = 'latest')
	{
		$db 			= JFactory::getDBO();
		$config			= EasyBlogHelper::getConfig();
		$count			= (int) $params->get( 'count' , 0 );

		if( !class_exists( 'EasyBlogModelBlog' ) )
		{
			jimport( 'joomla.application.component.model' );
			JLoader::import( 'blog' , EBLOG_ROOT . DS . 'models' );
		}
		$model = JModel::getInstance( 'Blog' , 'EasyBlogModel' );

		$posts  = '';
		switch( $type )
		{
			case 'blogger':
				$posts = $model->getBlogsBy('blogger', $id, 'latest' , $count , EBLOG_FILTER_PUBLISHED, null, false);
				break;
			case 'category':
				$posts = $model->getBlogsBy('category', $id, 'latest' , $count , EBLOG_FILTER_PUBLISHED, null, false);
				break;
			case 'tag':
				$posts	= $model->getTaggedBlogs( $id, $count );
				break;
			case 'team':
				$posts	= $model->getBlogsBy( 'teamblog' , $id , 'latest' , $count , EBLOG_FILTER_PUBLISHED , null , false );
				break;
			case 'latest':
			default:
				if( $params->get( 'usefeatured' ) )
				{
					$posts = $model->getFeaturedBlog( array() , $count );
				}
				else
				{
					$categories	= $params->get( 'catid' );
					$categories = trim( $categories );
					$type = !empty( $categories ) ? 'category' : '';

					$catIds     = array();

					if( !empty( $categories ) )
					{
						$categories = explode( ',' , $categories );

						foreach($categories as $item)
						{
							$category   = new stdClass();
							$category->id   = trim( $item );

							$catIds[]   = $category->id;

							if( $params->get( 'includesubcategory', 0 ) )
							{
								$category->childs = null;
								EasyBlogHelper::buildNestedCategories($category->id, $category , false , true );
								EasyBlogHelper::accessNestedCategoriesId($category, $catIds);
							}
						}

						$catIds     = array_unique( $catIds );
					}

					$cid		= $catIds;
					$posts		= $model->getBlogsBy( $type , $cid , 'latest' , $count , EBLOG_FILTER_PUBLISHED, null, false);
				}
				break;
		}

		if(count($posts) > 0)
		{
			$posts  = modLatestBlogsHelper::_processItems( $posts, $params );
		}

		return $posts;
	}

	function _getMenuItemId( $post, &$params)
	{
		$itemId                 = '';
		$routeTypeCategory		= false;
		$routeTypeBlogger		= false;
		$routeTypeTag			= false;

		$routingType            = $params->get( 'routingtype', 'default' );

		if( $routingType != 'default' )
		{
			switch ($routingType)
			{
				case 'menuitem':
					$itemId					= $params->get( 'menuitemid' ) ? '&Itemid=' . $params->get( 'menuitemid' ) : '';
					break;
				case 'category':
					$routeTypeCategory  = true;
					break;
				case 'blogger':
					$routeTypeBlogger  = true;
					break;
				case 'tag':
					$routeTypeTag  = true;
					break;
				default:
					break;
			}
		}

		if( $routeTypeCategory )
		{
			$xid    = EasyBlogRouter::getItemIdByCategories( $post->category_id );
		}
		else if($routeTypeBlogger)
		{
			$xid    = EasyBlogRouter::getItemIdByBlogger( $post->created_by );
		}
		else if($routeTypeTag)
		{
			$tags	= modLatestBlogsHelper::_getPostTagIds( $post->id );
			if( $tags !== false )
			{
				foreach( $tags as $tag )
				{
					$xid    = EasyBlogRouter::getItemIdByTag( $tag );
					if( $xid !== false )
						break;
				}
			}
		}

		if( !empty( $xid ) )
		{
			// lets do it, do it, do it, lets override the item id!
			$itemId = '&Itemid=' . $xid;
		}

		return $itemId;
	}

	function _getPostTagIds( $postId )
	{
		static $tags	= null;

		if( ! isset($tags[$postId]) )
		{
			$db = JFactory::getDBO();

			$query  = 'select `tag_id` from `#__easyblog_post_tag` where `post_id` = ' . $db->Quote($postId);
			$db->setQuery($query);

			$result = $db->loadResultArray();

			if( count($result) <= 0 )
				$tags[$postId] = false;
			else
				$tags[$postId] = $result;

		}

		return $tags[$postId];
	}

	function _getBloggers(&$params)
	{
		$mainframe	= JFactory::getApplication();
		$db         = JFactory::getDBO();

		$my 		= JFactory::getUser();

		$bloggerList    = $params->get('bloggerlist','');

		$bloggers       = explode(',', $bloggerList);
		$arrBloggers    = '';

		for($i = 0; $i < count($bloggers); $i++)
		{
			$blogger    = $bloggers[$i];
			$blogger 	= trim($blogger);

			if(is_numeric($blogger))
			{
				$arrBloggers[]  = $blogger;
			}
		}

		$exQuery    = '';
		if(count($arrBloggers) <= 1)
		{
			$exQuery	= ' where a.id = ' . $db->Quote($arrBloggers[0]);
		}
		else
		{
			$exQuery	= ' where a.id IN (' . implode(',', $arrBloggers) . ')';
		}


		$query	= 'select a.`id`, count(c.`id`) as `postcount`';
		$query	.= ' from `#__easyblog_users` as a';
		$query	.= '   inner join `#__users` as b';
		$query	.= '     on a.`id` = b.`id`';
		$query	.= '   left join `#__easyblog_post` as c';
		$query	.= '     on c.`created_by` = a.`id`';
		$query	.= '     and c.`published` = ' . $db->Quote('1');
		$query	.= '     and c.`issitewide` = ' . $db->Quote('1');
		if(empty($my->id))
			$query	.= '     and c.`private` = ' . $db->Quote('0');
		$query	.= $exQuery;
		$query	.= ' group by a.`id`';

		$db->setQuery($query);
		$result = $db->loadObjectList();

		return $result;
	}

	function getCategoryTotalPost( $categoryId )
	{
		if( !class_exists( 'EasyBlogModelCategory' ) )
		{
			jimport( 'joomla.application.component.model' );
			JLoader::import( 'category' , EBLOG_ROOT . DS . 'models' );
		}

		$model = JModel::getInstance( 'Category' , 'EasyBlogModel' );
		$total = $model->getTotalPostCount( $categoryId );

		return $total;
	}

	function getThumbnailImage($img)
	{
		$srcpattern = '/src=".*?"/';

		preg_match( $srcpattern , $img , $src );

		if(isset($src[0]))
		{
			$imagepath	= trim(str_ireplace('src=', '', $src[0]) , '"');
			$segment 	= explode('/', $imagepath);
			$file 		= end($segment);
			$thumbnailpath = str_ireplace($file, 'thumb_'.$file, implode('/', $segment));

			if(!JFile::exists($thumbnailpath))
			{
				$image = new SimpleImage();
				$image->load($imagepath);
				$image->resize(64, 64);
				$image->save($thumbnailpath);
			}

			$newSrc = 'src="'.$thumbnailpath.'"';
		}
		else
		{
			return false;
		}

		$oldAttributes = array('src'=>$srcpattern, 'width'=>'/width=".*?"/', 'height'=>'/height=".*?"/');
		$newAttributes = array('src'=>$newSrc,'width'=>'', 'height'=>'');

		return preg_replace($oldAttributes, $newAttributes, $img);
	}*/
}
