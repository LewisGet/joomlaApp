<?php
/**
 * @package		EasyBlog
 * @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 *  
 * EasyBlog is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.filesystem.file' );

if( !JFile::exists( JPATH_ROOT.DS.'components'.DS.'com_easyblog'.DS.'easyblog.php') )
{
	return;
}

require_once( JPATH_ROOT . DS . 'components' . DS . 'com_easyblog' . DS . 'constants.php' );
require_once( EBLOG_HELPERS . DS . 'helper.php' );
require_once( EBLOG_HELPERS . DS . 'modules.php' );
require_once( EBLOG_HELPERS . DS . 'router.php' );
require_once (dirname(__FILE__).DS.'helper.php');

JTable::addIncludePath( EBLOG_TABLES );
EasyBlogHelper::loadModuleCss();
EasyBlogHelper::loadHeaders();

$document	= JFactory::getDocument();
$document->addStyleSheet( rtrim(JURI::root(), '/') . '/components/com_easyblog/assets/css/module.css' );

$language			= JFactory::getLanguage();
$language->load( 'com_easyblog' , JPATH_ROOT );
 
$config         	= EasyBlogHelper::getConfig();
$result				= modTopBlogsHelper::getPosts( $params );

require(JModuleHelper::getLayoutPath('mod_topblogs'));