<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');
?>
<table class="noshow">
	<tr>
		<td width="50%" valign="top">
			<fieldset class="adminform">
			<legend><?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_TITLE' ); ?></legend>
			<table class="admintable" cellspacing="1">
				<tbody>
				<tr>
					<td width="300" class="key">
					<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_THEME' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_THEME_DESC'); ?>">
						<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_THEME' ); ?>
					</span>
					</td>
					<td valign="top">
						<?php echo $this->getDashboardThemes( $this->config->get('layout_dashboard_theme' ) ); ?> 
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
					<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_SELECT_DEFAULT_EDITOR' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_SELECT_DEFAULT_EDITOR_DESC'); ?>">
						<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_SELECT_DEFAULT_EDITOR' ); ?>
					</span>
					</td>
					<td valign="top">
						<?php echo $this->getEditorList( $this->config->get('layout_editor') ); ?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_HEADERS' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_HEADERS_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_HEADERS' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboard_show_headers' , $this->config->get( 'layout_dashboard_show_headers' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_SEO' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_SEO_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_SEO' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardseo' , $this->config->get( 'layout_dashboardseo' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_TRACKBACK' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_TRACKBACK_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_TRACKBACK' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardtrackback' , $this->config->get( 'layout_dashboardtrackback' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_ANCHORS' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_ANCHORS_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_ANCHORS' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardanchor' , $this->config->get( 'layout_dashboardanchor' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_QUICKPOST' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_QUICKPOST_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_QUICKPOST' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardquickpost' , $this->config->get( 'layout_dashboardquickpost' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_LAYOUT_DASHBOARD_CATEGORY_SELECTION' ); ?>::<?php echo JText::_('COM_EASYBLOG_LAYOUT_DASHBOARD_CATEGORY_SELECTION_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_LAYOUT_DASHBOARD_CATEGORY_SELECTION' ); ?>
						</span>
					</td>
					<td valign="top">
						<select name="layout_dashboardcategoryselect" class="inputbox">
							<option value="select"<?php echo $this->config->get( 'layout_dashboardcategoryselect' ) == 'select' ? ' selected="selected"' : '';?>><?php echo JText::_( 'COM_EASYBLOG_LAYOUT_DASHBOARD_CATEGORY_SELECTION_SELECT_LIST' );?></option>
							<option value="dialog"<?php echo $this->config->get( 'layout_dashboardcategoryselect' ) == 'dialog' ? ' selected="selected"' : '';?>><?php echo JText::_( 'COM_EASYBLOG_LAYOUT_DASHBOARD_CATEGORY_SELECTION_DIALOG' );?></option>
						</select>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_LAYOUT_DASHBOARD_STATS_OVERVIEW' ); ?>::<?php echo JText::_('COM_EASYBLOG_LAYOUT_DASHBOARD_STATS_OVERVIEW_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_LAYOUT_DASHBOARD_STATS_OVERVIEW' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardstats' , $this->config->get( 'layout_dashboardstats' ) );?>
					</td>
				</tr>
				</tbody>
			</table>
			</fieldset>
			<fieldset class="adminform">
			<legend><?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_BLOGGER_THEME_TITLE' ); ?></legend>
			<table class="admintable" cellspacing="1">
				<tbody>
				<tr>
					<td width="300" class="key">
					<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_ENABLE_BLOGGER_THEME' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_ENABLE_BLOGGER_THEME_DESC'); ?>">
						<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_ENABLE_BLOGGER_THEME' ); ?>
					</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_enablebloggertheme' , $this->config->get( 'layout_enablebloggertheme' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
					<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_BLOGGER_THEME_SELECTION' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_BLOGGER_THEME_SELECTION_DESC'); ?>">
						<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_BLOGGER_THEME_SELECTION' ); ?>
					</span>
					</td>
					<td valign="top">
						<?php echo $this->getBloggerThemes() ?>
					</td>
				</tr>
				</tbody>
			</table>
			</fieldset>
		</td>
		<td valign="top">
			<fieldset class="adminform">
			<legend><?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_TOOLBAR_TITLE' ); ?></legend>
			<table class="admintable" cellspacing="1">
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_DISABLE' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_DISABLE_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_DISABLE' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_enabledashboardtoolbar' , $this->config->get( 'layout_enabledashboardtoolbar' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_HOME' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_HOME_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_HOME' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardhome' , $this->config->get( 'layout_dashboardhome' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_BLOGS' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_BLOGS_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_BLOGS' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardblogs' , $this->config->get( 'layout_dashboardblogs' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_MAIN' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_MAIN_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_MAIN' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardmain' , $this->config->get( 'layout_dashboardmain' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_COMMENT' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_COMMENT_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_COMMENT' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardcomments' , $this->config->get( 'layout_dashboardcomments' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_CATEGORIES' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_CATEGORIES_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_CATEGORIES' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardcategories' , $this->config->get( 'layout_dashboardcategories' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_DRAFTS' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_DRAFTS_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_DRAFTS' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboarddrafts' , $this->config->get( 'layout_dashboarddrafts' ) );?>
					</td>
				</tr>				
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_TAGS' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_TAGS_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_TAGS' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardtags' , $this->config->get( 'layout_dashboardtags' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_NEW_POST' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_NEW_POST_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_NEW_POST' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardnewpost' , $this->config->get( 'layout_dashboardnewpost' ) );?>
					</td>
				</tr>
				<tr>
					<td width="300" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_SETTINGS' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_SETTINGS_DESC'); ?>">
							<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_LAYOUT_DASHBOARD_ENABLE_SETTINGS' ); ?>
						</span>
					</td>
					<td valign="top">
						<?php echo $this->renderCheckbox( 'layout_dashboardsettings' , $this->config->get( 'layout_dashboardsettings' ) );?>
					</td>
				</tr>
			</table>
			</fieldset>
		</td>
	</tr>
</table>