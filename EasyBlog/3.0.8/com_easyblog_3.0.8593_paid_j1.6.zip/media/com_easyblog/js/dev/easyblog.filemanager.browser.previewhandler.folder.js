(function($){

$.Controller(
	'EasyBlog.FileManager.Browser.PreviewHandler.Folder',
	{
		defaults: {
			'{itemPreview}'	    : '.item-preview',
			'{itemProperties}'  : '.item-properties',

			'{folderGallery}'	: '.folder-gallery',
			"{addGallery}" 		: '.gallery-insert-button',
			"{deleteFolder}"	: '.delete-button',
			"{notificationMsg}"	: '.message-notification',
			'@Editor'			: 'EasyBlog.FileManager.Browser.PreviewHandler.Folder.Editor',
            '@Gallery'          : 'EasyBlog.FileManager.Browser.PreviewHandler.Folder.Gallery'
		}
	},
	function(self) { return {

		init: function()
		{
			self.fileManager = self.options.fileManager;

			self.render( function( html ){
				self.element.append( html );
			});
		},

		render: function( callback )
		{
			$.View(
				self.template('Editor'),
				self.options.properties,
				function(html)
				{
					return callback && callback.apply(self, [html]);
				}
			);
		},

		setLayout: function()
		{
			self.itemPreview().css('height', self.element.height() - self.itemProperties().outerHeight() - (self.itemPreview().outerHeight() - self.itemPreview().height()));
		},

		'{addGallery} click': function()
		{
			var folder	= self.options.properties;
			var obj		= $.toJSON( { 'path' : folder.path , 'name' : folder.name } );

			// Replace the quotes with single quotes.
			obj			= obj.replace( /"/g , "'" );
			
			$.View(
				self.template( 'Gallery' ),
				{
					name: folder.name,
					obj: obj
				},
				function( html )
				{
					self.fileManager.operations.insertIntoEditor( html );
				}
			);
		},

		'{deleteFolder} click' : function()
		{
			self.itemHandler.deleteFolder();
		}
	}}
);
})(Foundry);