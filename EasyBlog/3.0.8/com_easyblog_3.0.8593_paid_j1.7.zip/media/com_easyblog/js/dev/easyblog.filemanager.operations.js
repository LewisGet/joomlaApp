(function($){

$.Controller(
	'EasyBlog.FileManager.Operations',
	{
		defaults: {
		}
	},
	function(self) { return {

		init: function()
		{
			self.fileManager = self.options.fileManager;
		},

		createFolder: function(folderName, callback)
		{
			if ($.trim(folderName)=='') return;

			var path = self.fileManager.options.path;

			ejax.call('images', 'createFolder', [path, folderName], callback);
		},

		insertIntoEditor: function(html)
		{
			window.parent.jInsertEditorText(html, self.fileManager.options.editorName);

			window.parent.eblog.fileManager.collapse(0);

			self.fileManager.browser.setContentPaneMessage($.lang('COM_EASYBLOG_ITEM_INSERTED'), 'topAndFade');			
		},

		removeItem: function(itemProp, callback)
		{
			ejax.call('images', 'deleteItem', [itemProp.name , itemProp.type, itemProp.path_relative], callback);
		}
	}}
);
})(Foundry);