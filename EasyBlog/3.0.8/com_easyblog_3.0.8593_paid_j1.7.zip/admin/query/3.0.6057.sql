ALTER TABLE `#__easyblog_post` ADD `copyrights` TEXT NULL;
ALTER TABLE `#__easyblog_drafts` ADD `copyrights` TEXT NULL;