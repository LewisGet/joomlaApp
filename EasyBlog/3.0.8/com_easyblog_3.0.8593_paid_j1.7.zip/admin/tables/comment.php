<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');

require_once( JPATH_ROOT . DS . 'components' . DS . 'com_easyblog' . DS . 'constants.php' );
require_once( EBLOG_HELPERS . DS . 'string.php' );

class TableComment extends JTable
{
	var $id 			= null;
	var $post_id		= null;
	var $comment		= null;
	var $name			= null;
	var $title			= null;
	var $email			= null;
	var $url			= null;
	var $ip				= null;
	var $created_by		= null;


	/*
	 * Created datetime of the comment
	 * @var datetime
	 */
	var $created				= null;

	/*
	 * modified datetime of the comment
	 * optional
	 * @var datetime
	 */
	var $modified				= null;

	/*
	 * Tag publishing status
	 * @var int
	 */
	var $published		= null;

	/*
	 * comment publish datetime
	 * optional
	 * @var datetime
	 */
	var $publish_up		= null;

	/*
	 * Comment un-publish datetime
	 * optional
	 * @var datetime
	 */
	var $publish_down		= null;


	/*
	 * Comment ordering
	 * @var int
	 */
	var $ordering			= null;

	/*
	 * Comment vote
	 * @var int
	 */
	var $vote			= null;

	/*
	 * Comment hits
	 * @var int
	 */
	var $hits			= null;

	/*
	 * Comment notification sent
	 * @var int
	 */
	var $sent			= null;

	/*
	 * Comment lft - used in threaded comment
	 * @var int
	 */
	var $lft			= null;

	/*
	 * Comment rgt - used in threaded comment
	 * @var int
	 */
	var $rgt			= null;


	/**
	 * Constructor for this class.
	 *
	 * @return
	 * @param object $db
	 */
	function __construct(& $db )
	{
		parent::__construct( '#__easyblog_comment' , 'id' , $db );
	}


	public function delete($pk = null)
	{
		// @rule: Remove comment's stream
		$this->removeStream();
		parent::delete($pk);
	}

	/**
	 * When executed, remove any 3rd party integration records.
	 */
	public function removeStream()
	{
		jimport( 'joomla.filesystem.file' );

		$config 	= EasyBlogHelper::getConfig();

		// @rule: Detect if jomsocial exists.
		$file 		= JPATH_ROOT . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_community' . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'core.php';

		if( JFile::exists( $file ) && $config->get( 'integrations_jomsocial_comment_new_activity' ) )
		{
			// @rule: Test if record exists first.
			$db 	= JFactory::getDBO();
			$query	= 'SELECT COUNT(1) FROM ' . $db->nameQuote( '#__community_activities' ) . ' '
					. 'WHERE ' . $db->nameQuote( 'app' ) . '=' . $db->Quote( 'com_easyblog' ) . ' '
					. 'AND ' . $db->nameQuote( 'cid' ) . '=' . $db->Quote( $this->id ) . ' '
					. 'AND ' . $db->nameQuote( 'comment_type') . '=' . $db->Quote( 'com_easyblog.comments' );
			$db->setQuery( $query );

			$exists	= $db->loadResult();

			if( $exists )
			{
				$query	= 'DELETE FROM ' . $db->nameQuote( '#__community_activities' ) . ' '
						. 'WHERE ' . $db->nameQuote( 'app' ) . '=' . $db->Quote( 'com_easyblog' ) . ' '
						. 'AND ' . $db->nameQuote( 'cid' ) . '=' . $db->Quote( $this->id ) . ' '
						. 'AND ' . $db->nameQuote( 'comment_type') . '=' . $db->Quote( 'com_easyblog.comments' );

				$db->setQuery( $query );
				$db->Query();
			}
		}
	}

	 /*
	 *
	 */
	function bindPost($post)
	{
		$config 		= EasyBlogHelper::getConfig();

		if(! empty($post['commentId']))
			$this->id	= $post['commentId'];

		$this->post_id	= $post['id'];

		//replace a url to link
		$comment        = $post['comment'];

		$filter 		= JFilterInput::getInstance();
		$comment		= $filter->clean($comment);

		$this->comment	= $comment;

		if( isset( $post['name'] ) )
		{
			$this->name		= $filter->clean($post['name']);
		}

		if( isset( $post['title'] ) )
		{
			$this->title	= $filter->clean($post['title']);
		}

		if( isset( $post['email'] ) )
		{
			$this->email	= $filter->clean($post['email']);
		}

		if( isset( $post['url'] ) )
		{
			$this->url		= $filter->clean($post['url']);
		}
	}

	function updateSent()
	{
		$db = JFactory::getDBO();

		if(! empty($this->id))
		{
			$query  = 'UPDATE `#__easyblog_comment` SET `sent` = 1 WHERE `id` = ' . $db->Quote($this->id);

			$db->setQuery($query);
			$db->query();
		}

		return true;
	}

	function isCreator( $id = '' )
	{
		if( empty( $id ) )
		{
			$id	= JFactory::getUser()->id;
		}

		return $this->created_by == $id;
	}

	function validate( $type )
	{
		$config		= EasyBlogHelper::getConfig();


		if( $config->get( 'comment_requiretitle' ) && $type == 'title' )
		{
			return JString::strlen( $this->title ) != 0 ;
		}

		if( $type == 'name' )
		{
			return JString::strlen( $this->name ) != 0;
		}

		if( $type == 'email' )
		{
			return JString::strlen( $this->email ) != 0;
		}

		if( $type == 'comment' )
		{
			return JString::strlen( $this->comment ) != 0;
		}

		return true;
	}
}
