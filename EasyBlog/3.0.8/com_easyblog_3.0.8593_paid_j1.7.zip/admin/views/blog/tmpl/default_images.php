<?php
/**
 * @package		EasyBlog
 * @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 *
 * EasyBlog is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
(function($)
{
	eblog.fileManager = {

		isResizing: false,

		isReady: false,

		stayOnTop: false,

		settings: {
			url: '<?php echo JURI::base() . 'index.php?option=com_easyblog&view=images&tmpl=component&blogger_id=' . $this->blogger_id; ?>',
			height: 550,
			appHeight: 514, /* TODO: Recalculate */
			collapsedHeight: 88
		},

		init: function()
		{
			var fileManager = eblog.fileManager;

			fileManager.element = $('#eblog-filemanager');
			fileManager.app = $('.filemanager-app');
			fileManager.header = $('.filemanager-header');
			fileManager.stayOnTopCheckbox = $('#filemanager-stayontop');

			fileManager.element.css('overflow', 'hidden');

			fileManager.setLayout();

			$(window)
				.unbind('resize.fileManager')
				.bind('resize.fileManager', function()
				{
					fileManager.setLayout(true);
				})
				.bind('keyup.fileManager', function(event)
				{
					if (event.keyCode==27)
					{
						return (event.shiftKey) ? fileManager.show() : fileManager.hide();
					}	
				});
			
			fileManager.stayOnTopCheckbox
				.change((function()
				{
					fileManager.stayOnTop = fileManager.stayOnTopCheckbox.is(':checked');
					return arguments.callee;
				})());

			if (!fileManager.isReady) fileManager.load();

			fileManager.show();
		},

		setLayout: function(fast)
		{
			var fileManager = eblog.fileManager;
			var dashboard = $('#eblog-wrapper');

			var active = fileManager.element.hasClass('active');

			if (fast)
			{
				fileManager.element
					.css(
					{
						top    : (active) ? 0 : fileManager.settings.height * -1,
						left   : dashboard.offset().left
					});
			} else {

				fileManager.element
					.toggleClass('eb-loading', fileManager.isReady)
					.css(
					{
						width  : dashboard.width() - 2 /* 2px border */,
						height : fileManager.settings.height,
						top    : (active) ? 0 : fileManager.settings.height * -1,
						left   : dashboard.offset().left
					});
			}
		},

		load: function()
		{
			var fileManager = eblog.fileManager;

			// Double check
			if (fileManager.element.find('.filemanager-app').length > 0) return;

			fileManager.element
				.addClass('eb-loading');

			fileManager.app = $('<iframe class="filemanager-app" frameborder="0">');

			fileManager.app
				.css(
				{
					width: '100%',
					height: fileManager.settings.appHeight,
					opacity: 0
				})
				.appendTo(fileManager.element)
				.one('load', function()
				{
					fileManager.ready();
				})
				.attr('src', fileManager.settings.url);
		},

		ready: function()
		{
			var fileManager = eblog.fileManager;

			fileManager.element
				.removeClass('eb-loading');
			
			fileManager.app
				.stop()
				.animate({opacity: 1});
			
			fileManager.element
				.bind('mouseover.fileManager', fileManager.expand)
				.bind('mouseout.fileManager', fileManager.collapse);

		},

		show: function()
		{
			var fileManager = eblog.fileManager;

			try { IeCursorFix(); } catch(e) {};

			fileManager.isResizing = true;

			fileManager.element
				.stop()
				.animate(
				{
					top: 0
				},
				function()
				{
					fileManager.element.addClass('active');

					fileManager.isResizing = false;
				});
		},

		hide: function()
		{
			eblog.fileManager.isResizing = true;

			var fileManager = eblog.fileManager;

			fileManager.element
				.stop()
				.animate(
				{
					top: '-' + (fileManager.element.outerHeight(true) + 50) + 'px'
				},
				function()
				{
					fileManager.element.removeClass('active');

					fileManager.isResizing = false;
				});			
		},

		expandMonitor: null,
		collapseMonitor: null,

		expand: function()
		{
			var fileManager = eblog.fileManager;

			if (fileManager.isResizing || fileManager.stayOnTop) return;

			clearTimeout(fileManager.collapseMonitor);

			clearTimeout(fileManager.expandMonitor);

			fileManager.expandMonitor = setTimeout(function()
			{
				if (fileManager.isResizing) return;
				
				fileManager.element
					.stop()
					.animate({
						height: fileManager.settings.height
					}, 'fast');				
			}, 500);
		},

		collapse: function(delay)
		{
			if (delay===undefined || typeof delay=='object')
				delay = 800;
			
			var fileManager = eblog.fileManager;

			if (fileManager.isResizing || fileManager.stayOnTop) return;

			clearTimeout(fileManager.collapseMonitor);

			clearTimeout(fileManager.expandMonitor);

			fileManager.collapseMonitor = setTimeout(function()
			{
				if (fileManager.isResizing) return;

				fileManager.element
					.stop()
					.animate({
						height: fileManager.settings.collapsedHeight
					}, 'fast');					
			}, delay);
		}

	};

})(sQuery);

</script>

<div id="eblog-filemanager">
    <div class="filemanager-header"><h3><?php echo JText::_('COM_EASYBLOG_IMAGE_MANAGER_DIALOG_TITLE'); ?></h3><span class="stay-on-top"><input id="filemanager-stayontop" type="checkbox" name="filemanager-stayontop"/><label for="filemanager-stayontop"><?php echo JText::_('COM_EASYBLOG_STAY_ON_TOP'); ?></label></span><a href="javascript:void(0);" onclick="eblog.fileManager.hide();" class="closeme">Close</a></div>
</div>

<a href="javascript:void(0);" onclick="eblog.fileManager.init();" class="ir float-l ico-dimage mrs prel" title="<?php echo JText::_( 'COM_EASYBLOG_DASHBOARD_WRITE_INSERT_MEDIA' );?>">
	<b class="ir"><?php echo JText::_( 'COM_EASYBLOG_DASHBOARD_WRITE_INSERT_MEDIA' );?></b>
	<span class="ui-toolnote">
		<i></i>
		<b><?php echo JText::_( 'COM_EASYBLOG_DASHBOARD_WRITE_INSERT_MEDIA' );?></b>
		<span><?php echo JText::_('COM_EASYBLOG_DASHBOARD_WRITE_INSERT_MEDIA_TIPS'); ?></span>
	</span>
</a>