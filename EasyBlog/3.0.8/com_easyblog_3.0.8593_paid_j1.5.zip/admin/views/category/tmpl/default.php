<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
<?php if(EasyBlogHelper::getJoomlaVersion() >= 1.6) : ?>
	Joomla.submitbutton = function( action ) {

		if( action == 'saveNew' )
		{
			sQuery( '#savenew' ).val( '1' );
			action	= 'save';
		}
	
		Joomla.submitform( action );
    }
<?php else : ?>
function submitbutton( action )
{
	if( action == 'saveNew' )
	{
		sQuery( '#savenew' ).val( '1' );
		action	= 'save';
	}
	submitform( action );
}
<?php endif; ?>

sQuery(function()
{
	sQuery( '#private' ).bind( 'change' , function(){
		if( sQuery(this).val() == '2' )
		{
			sQuery( '#categoryaccess' ).show();
		}
		else
		{
			sQuery( '#categoryaccess').hide();
		}
	});
});

function insertUser( id , username )
{
	sQuery( '#author-name' ).html( username );
	sQuery('#created_by').val( id );

	<?php
	if( EasyBlogHelper::getJoomlaVersion() >= '1.6')
	{
	?>
		window.parent.SqueezeBox.close();
	<?php
	}
	else
	{
	?>
		window.parent.document.getElementById('sbox-window').close();
	<?php
	}
	?>
}
</script>
<form action="index.php" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
	<table width="100%">
	    <tr>
	        <td width="50%" valign="top">
				<fieldset class="adminform">
					<legend><?php echo JText::_('COM_EASYBLOG_CATEGORIES_EDIT_FORM_TITLE'); ?></legend>
					<table class="admintable">
						<tr>
							<td class="key">
								<label for="catname"><?php echo JText::_( 'COM_EASYBLOG_CATEGORIES_EDIT_CATEGORY_NAME' ); ?></label>
							</td>
							<td>
								<input class="inputbox" id="catname" name="title" size="55" maxlength="255" value="<?php echo $this->cat->title;?>" />
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="alias"><?php echo JText::_( 'COM_EASYBLOG_CATEGORIES_EDIT_CATEGORY_ALIAS' ); ?></label>
							</td>
							<td>
								<input class="inputbox" id="alias" name="alias" size="55" maxlength="255" value="<?php echo $this->cat->alias;?>" />
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="catname"><?php echo JText::_( 'COM_EASYBLOG_CATEGORIES_EDIT_CATEGORY_DESCRIPTION' ); ?></label>
							</td>
							<td>
								<?php echo $this->editor->display('description', $this->cat->get( 'description') , '99%', '200', '10', '10', array('image', 'readmore', 'pagebreak'), array(), 'com_easyblog'); ?>
							</td>
						</tr>
						<tr>
						    <td class="key"><label for="parent_id"><?php echo JText::_('COM_EASYBLOG_PARENT'); ?></label></td>
							<td><?php echo $this->parentList; ?></td>
						</tr>
						<tr>
							<td class="key"><label for="parent_id"><?php echo JText::_('COM_EASYBLOG_AUTHOR'); ?></label></td>
							<td>
								<input type="hidden" name="created_by" id="created_by" value="<?php echo $this->cat->get( 'created_by' );?>" /> 
								<?php if( !empty($this->cat->created_by)){ ?>
								<span id="author-name">
									<?php
									if(!empty( $this->cat->created_by ) )
									{
										echo JFactory::getUser( $this->cat->get( 'created_by') )->name;
									}
									?>
								</span>
								<?php }?>
								<span>
									[ <a class="modal" rel="{handler:'iframe',size:{x:650,y:375}}" href="index.php?option=com_easyblog&view=users&tmpl=component&browse=1&browsefunction=insertUser"><?php echo JText::_('COM_EASYBLOG_BROWSE_USERS');?></a> ]
								</span>
							</td>
						</tr>
						<tr>
				        	<td class="key"><label for="private"><?php echo JText::_('COM_EASYBLOG_CATEGORIES_PRIVACY'); ?></label></td>
							<td><?php echo JHTML::_( 'select.genericlist' , EasyBlogHelper::getHelper( 'Privacy' )->getOptions( 'category' ) , 'private' , 'size="1" class="inputbox"' , 'value' , 'text', $this->cat->private );?></td>
						</tr>
						<?php if($this->config->get('layout_categoryavatar', true)) : ?>
						<tr>
				        	<td class="key"><label for="Filedata"><?php echo JText::_('COM_EASYBLOG_CATEGORIES_EDIT_AVATAR'); ?></label></td>
							<td>
							    <?php if(! empty($this->cat->avatar)) { ?>
									<img style="border-style:solid; float:none;" src="<?php echo $this->cat->getAvatar(); ?>" width="60" height="60"/><br />
							    <?php }?>
								<?php if ($this->acl->rules->upload_cavatar) : ?>
									<input id="file-upload" type="file" name="Filedata" class="inputbox" size="33"/>
								<?php endif; ?>
							</td>
						</tr>
						<?php endif; ?>
						<tr>
							<td class="key"><label for="published"><?php echo JText::_( 'COM_EASYBLOG_CATEGORIES_EDIT_CATEGORY_PUBLISHED' ); ?></label></td>
							<td>
								<?php echo $this->renderCheckbox( 'published' , $this->cat->published ); ?>
							</td>
						</tr>
						<tr style="display: none;">
							<td class="key"><label for="created"><?php echo JText::_( 'COM_EASYBLOG_CATEGORIES_EDIT_CATEGORY_CREATED' ); ?></label></td>
							<td><?php echo JHTML::_('calendar', $this->cat->created , "created", "created"); ?></td>
						</tr>
					</table>
				</fieldset>
			</td>
			<td width="50%" valign="top">
				<fieldset class="adminform" id="categoryaccess" style="<?php echo $this->cat->private != 2 ? 'display: none;' : '';?>">
					<legend><?php echo JText::_('COM_EASYBLOG_CATEGORIES_ACCESS'); ?></legend>
					<table class="admintable">
					<?php foreach($this->categoryRules as $catRules) :
						$catRuleSet 	= $this->assignedACL[$catRules->id];
						$titleString	= 'COM_EASYBLOG_CATEGORIES_ACL_'.$catRules->action.'_TITLE';
						$descString		= 'COM_EASYBLOG_CATEGORIES_ACL_'.$catRules->action.'_DESC';
					?>
					    <tr>
					        <td class="key"><?php echo JText::_( $titleString ); ?></td>
					        <td>
					            <select multiple="multiple" name="category_acl_<?php echo $catRules->action; ?>[]">
								<?php foreach($catRuleSet as $ruleItem) : ?>
								    <option value="<?php echo $ruleItem->groupid; ?>" <?php echo ($ruleItem->status) ? 'selected="selected"' : ''; ?> ><?php echo $ruleItem->groupname; ?></option>
								<?php endforeach; ?>
								</select>
								(<?php echo JText::_( $descString ); ?>)
							</td>
					    </tr>
					<?php endforeach; ?>
					</table>

				</fieldset>
			</td>
		</tr>
	</table>
	
<?php echo JHTML::_( 'form.token' ); ?>
<input type="hidden" name="savenew" value="0" id="savenew" />
<input type="hidden" name="option" value="com_easyblog" />
<input type="hidden" name="c" value="category" />
<input type="hidden" name="task" value="save" />
<input type="hidden" name="catid" value="<?php echo $this->cat->id;?>" />
</form>