<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');

jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldModal_MultiCategories extends JFormField
{
	protected $type = 'Modal_MultiCategories';

	protected function getInput()
	{
		$mainframe	= JFactory::getApplication();
		$db			= JFactory::getDBO();
		$doc 		= JFactory::getDocument();

		require_once( JPATH_ROOT . DS . 'administrator' . DS . 'components' . DS . 'com_easyblog' . DS . 'models' . DS . 'categories.php' );
		$model		= new EasyBlogModelCategories();
		$categories	= $model->getAllCategories();

// 		if( !is_array( $this->value ) )
// 		{
// 			$this->value	= array( $this->value );
// 		}
// var_dump( $this->value );exit;
		ob_start();
		?>
		<select name="<?php echo $this->name;?>[]" multiple="multiple" style="width:250px;height:200px;" class="<?php echo $this->element['class'];?>">
		<?php		
		foreach($categories as $category)
		{
			$selected	= in_array( $category->id , $this->value ) ? ' selected="selected"' : '';
		?>
			<option value="<?php echo $category->id;?>"<?php echo $selected;?>><?php echo $category->title;?></option>
		<?php
		}
		?>
		</select>
		<?php
		$html	= ob_get_contents();
		ob_end_clean();
		
		return $html;
	}

}
