(function($){

$.Controller(
	'EasyBlog.FileManager.Toolbar',
	{
		defaults: {
			"{upload}": '.fileManager-toolbar-upload',
			"{search}": '.fileManager-toolbar-search',
			"{pathway}": '.fileManager-toolbar-pathway',
			"{message}": '.fileManager-toolbar-message'
		}
	},
	function(self) { return {

		init: function()
		{
			self.fileManager = self.options.fileManager;

			// Search
			self.search()
				.implement(
					'EasyBlog.FileManager.Toolbar.Search',
					{
						fileManager: self.fileManager
					},
					function()
					{
						self.search = this;
					}
				);

			// Pathway
			self.pathway()
				.implement(
					'EasyBlog.FileManager.Toolbar.Pathway',
					{
						fileManager: self.fileManager
					},
					function()
					{
						self.pathway = this;
					}
				);
			
			// Upload
			self.upload()
				.implement(
					'EasyBlog.FileManager.Toolbar.Upload',
					{
						fileManager: self.fileManager
					},
					function()
					{
						self.upload = this;
					}
				);
		},

		setLayout: function()
		{
			self.search.setLayout();
			self.pathway.setLayout();
			self.upload.setLayout();
		},

		hideToolbarMessage: null,

		setToolbarMessage: function(html, position)
		{
			clearTimeout(self.hideToolbarMessage);

			if (!position) position = 'top';

			self.message()
				.html(html)
				.show()
				.position(
				{
					my: 'center top',
					at: 'center top',
					of: self.element
				});				

			if (position=='topAndFade')
			{
				self.hideToolbarMessage = setTimeout(function()
				{
					self.message()
						.fadeOut();
				}, 3000);
			}
		},

		clearToolbarMessage: function()
		{
			self.message().hide();
		}
	}}
);
})(Foundry);