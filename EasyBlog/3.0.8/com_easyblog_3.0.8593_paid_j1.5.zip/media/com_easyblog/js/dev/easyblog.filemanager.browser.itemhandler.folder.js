(function($){

$.Controller(
	'EasyBlog.FileManager.Browser.ItemHandler.Folder',
	{
		defaults: {
			'{folderViewButton}': '.folder-view-button',
			'{folderDeleteButton}': '.folder-delete-button',

			'@Item': 'EasyBlog.FileManager.Browser.ItemHandler.Folder.Item'
		}
	},
	function(self) { return {

		init: function(el, options)
		{
			self.fileManager = this.options.fileManager;

			self.render(function(html)
			{
				self.element.html(html);
			});
		},

		render: function(callback)
		{
			$.View(
				self.template('Item'),
				self.options.properties,
				function(html)
				{
					return callback && callback.apply(self, [html]);
				}
			);
		},

		viewFolder: function()
		{
			var url = self.find( 'input[name=location]' ).val();
			window.location.href = url;
		},

		deleteFolder: function()
		{

			if (confirm($.lang('COM_EASYBLOG_DELETE_FOLDER_CONFIRMATION')))
			{
				self.fileManager.browser.setContentPaneMessage($.lang('COM_EASYBLOG_DELETING') + ' "' + self.options.properties.name + '"...');

				self.fileManager.operations.removeItem(self.options.properties, {
					success: function()
					{
						self.fileManager.browser.setContentPaneMessage($.lang('COM_EASYBLOG_DELETED') + ' "' + self.options.properties.name + '"!', 'topAndFade');

						self.fileManager.browser.removeItem(self);
					},
					error: function( message )
					{
						self.fileManager.browser.setContentPaneMessage($.lang('COM_EASYBLOG_ERROR_DELETING') + ' "' + self.options.properties.name + '"!', 'topAndFade');
					}
				});
			}	
		},

		"{folderViewButton} click": function()
		{
			self.viewFolder();
		},

		"{folderDeleteButton} click": function()
		{
			self.deleteFolder();
		},

		"dblclick": function()
		{
			self.viewFolder();
		}
	}}
);
})(Foundry);