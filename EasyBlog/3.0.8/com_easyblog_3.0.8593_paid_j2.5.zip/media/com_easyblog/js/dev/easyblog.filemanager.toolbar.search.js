(function($){

$.Controller(
	'EasyBlog.FileManager.Toolbar.Search',
	{
		defaults: {
			"{searchLocation}": '.item-search-location',
			"{toggle}" : '.item-search-toggle',
			"{keyword}": '.item-search-keyword'
		}
	},
	function(self) { return {

		init: function()
		{
			self.fileManager = self.options.fileManager;
		},

		setLayout: function()
		{

		},

		activate: function()
		{
			self.element.addClass('active');

			self.searchLocation()
				.html(self.fileManager.currentPath());

			self.keyword().focus();

			self.fileManager.toolbar.pathway.element.hide();			
		},

		deactivate: function()
		{
			self.element.removeClass('active');

			// Reset filter
			self.keyword().val('');
			self.filter('');
			self.fileManager.browser.clearContentPaneMessage();

			self.fileManager.toolbar.pathway.element.show();
		},

		filter: function(keyword)
		{
			var items = self.fileManager.browser.items;

			var filteredItems = {};

			$.each(items, function(uid, item)
			{
				var match = (item.options.properties.name.toUpperCase().indexOf(keyword.toUpperCase()) >= 0);

				item.element.toggle(match);

				if (match) filteredItems[uid] = item;
			});

			if ($.isEmptyObject(filteredItems))
			{
				self.fileManager.browser.setContentPaneMessage($.lang('COM_EASYBLOG_IMAGE_UPLOADER_SEARCH_NO_RESULTS'), 'middle');
			} else {
				self.fileManager.browser.clearContentPaneMessage();
			}

			return filteredItems;
		},

		"{toggle} click": function()
		{
			self.element.toggleClass('active');

			return (self.element.hasClass('active')) ? self.activate() : self.deactivate();
		},

		"{keyword} keyup": function(el)
		{
			var keyword = $.trim(el.val());
			self.filter(keyword);
		},
		
		"{keyword} keypress": function( el , event )
		{
			if( event.keyCode == 13 )
			{
				return false;
			}
		}
	}}
);
})(Foundry);