<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');

require_once( EBLOG_HELPERS . DS . 'helper.php' );

class EasyBlogViewEasyblog extends JView
{
	function getVersion()
	{
		$version	= EasyBlogHelper::getVersion();
		$local		= EasyBlogHelper::getLocalVersion();
		
		// Test build only since build will always be incremented regardless of version
		$localVersion	= explode( '.' , $local );
		$localBuild		= $localVersion[2];
		
		if( !$version )
			return JText::_('Unable to contact update servers');

		$remoteVersion	= explode( '.' , $version );
		$build			= $remoteVersion[ 2 ];
		
		$html			= '<span class="version_outdated">' . JText::sprintf( 'COM_EASYBLOG_VERSION_OUTDATED' , $local , JRoute::_( 'index.php?option=com_easyblog&view=updater') ) . '</span>';
		
		if( $localBuild >= $build )
		{
			$html		= '<span class="version_latest">' . JText::sprintf('COM_EASYBLOG_VERSION_LATEST' , $local ) . '</span>';
		}

		$ajax			= new Ejax();
		$ajax->script( 'sQuery(\'#submenu-box #submenu\').append(\'<li style="float: right; margin:5px 10px 0 0;">' . $html . '</li>\');');
		$ajax->send();
	}
	
	public function getNews()
	{
		$news		= EasyBlogHelper::getRecentNews();
		$content	= '';
		
		ob_start();
		if( $news )
		{
			foreach( $news as $item )
			{
		?>
		<li>
			<b><span><?php echo $item->title . ' - ' . $item->date; ?></span></b>
			<div><?php echo $item->desc;?></div>
		</li>
		<?php
			}
		}
		else
		{
		?>
		<li><?php echo JText::_('Unable to contact news server');?></li>
		<?php
		}

		$content	= ob_get_contents();
		@ob_end_clean();
		
		$ajax			= new Ejax();
		$ajax->assign( 'news-items' , $content );
// 		$ajax->script( "sQuery('#news-items").html(\'' . addslashes( $content ) . '\');');
		$ajax->send();
	}
}