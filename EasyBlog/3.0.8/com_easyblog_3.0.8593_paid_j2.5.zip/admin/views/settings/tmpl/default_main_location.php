<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');
?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td valign="top" width="50%">
			<table class="noshow">
				<tr>
					<td width="50%" valign="top">
						<fieldset class="adminform">
						<legend><?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_TITLE' ); ?></legend>
						<table class="admintable" cellspacing="1">
							<tbody>
							<tr>
								<td width="300" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_ENABLE_LOCATION' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_ENABLE_LOCATION_DESC'); ?>">
										<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_ENABLE_LOCATION' ); ?>
									</span>
								</td>
								<td class="value">
									<?php echo $this->renderCheckbox( 'main_locations' , $this->config->get( 'main_locations' ) );?>
									<a href="http://stackideas.com/docs/easyblog/how-tos/setting-up-location-services.html" target="_blank" style="margin-left:10px;line-height:3em;"><?php echo JText::_('COM_EASYBLOG_WHAT_IS_THIS'); ?></a>
								</td>
							</tr>
							<tr>
								<td width="300" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_USE_STATIC_MAPS' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_USE_STATIC_MAPS_DESC'); ?>">
										<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_USE_STATIC_MAPS' ); ?>
									</span>
								</td>
								<td class="value">
									<?php echo $this->renderCheckbox( 'main_locations_static_maps' , $this->config->get( 'main_locations_static_maps' ) );?>
								</td>
							</tr>
							<tr>
								<td width="300" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_BLOG_MAP_SIZE_WIDTH' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_BLOG_MAP_SIZE_WIDTH_DESC'); ?>">
										<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_BLOG_MAP_SIZE_WIDTH' ); ?>
									</span>
								</td>
								<td class="value">
									<input type="text" name="main_locations_blog_map_width" class="inputbox" style="width: 50px;text-align:center;" value="<?php echo $this->config->get('main_locations_blog_map_width');?>" />
									<?php echo JText::_( 'COM_EASYBLOG_PIXELS' );?>
								</td>
							</tr>
							<tr>
								<td width="300" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_BLOG_MAP_SIZE_HEIGHT' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_BLOG_MAP_SIZE_HEIGHT_DESC'); ?>">
										<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_BLOG_MAP_SIZE_HEIGHT' ); ?>
									</span>
								</td>
								<td class="value">
									<input type="text" name="main_locations_blog_map_height" class="inputbox" style="width: 50px;text-align:center;" value="<?php echo $this->config->get('main_locations_blog_map_height');?>" />
									<?php echo JText::_( 'COM_EASYBLOG_PIXELS' );?>
								</td>
							</tr>
							<tr>
								<td width="300" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_SHOW_BLOG_FRONTPAGE' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_SHOW_BLOG_FRONTPAGE_DESC'); ?>">
										<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_SHOW_BLOG_FRONTPAGE' ); ?>
									</span>
								</td>
								<td class="value">
									<?php echo $this->renderCheckbox( 'main_locations_blog_frontpage' , $this->config->get( 'main_locations_blog_frontpage' ) );?>
								</td>
							</tr>
							<tr>
								<td width="300" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_SHOW_BLOG_ENTRY' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_SHOW_BLOG_ENTRY_DESC'); ?>">
										<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_SHOW_BLOG_ENTRY' ); ?>
									</span>
								</td>
								<td class="value">
									<?php echo $this->renderCheckbox( 'main_locations_blog_entry' , $this->config->get( 'main_locations_blog_entry' ) );?>
								</td>
							</tr>
							<tr>
								<td width="300" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_LANGUAGE_CODE' ); ?>::<?php echo JText::_('COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_LANGUAGE_CODE_DESC'); ?>">
										<?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LOCATIONS_LANGUAGE_CODE' ); ?>
									</span>
								</td>
								<td class="value">
									<input type="text" name="main_locations_blog_language" class="inputbox" style="width: 50px;" value="<?php echo $this->config->get('main_locations_blog_language' );?>" />
									<a class="mlm" href="https://spreadsheets.google.com/a/stackideas.com/pub?key=p9pdwsai2hDMsLkXsoM05KQ&gid=1" target="_blank"><?php echo JText::_( 'COM_EASYBLOG_SETTINGS_WORKFLOW_LANGUAGE_CODE_REFERENCE');?></a>
								</td>
							</tr>
							</tbody>
						</table>
						</fieldset>
					</td>
				</tr>
			</table>
		</td>
		<td valign="top">&nbsp;</td>
	</tr>
</table>