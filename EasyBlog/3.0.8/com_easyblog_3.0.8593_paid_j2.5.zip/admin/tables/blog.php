<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');

class TableBlog extends JTable
{

	var $id 				= null;
	var $created_by			= null;
	var $modified			= null;
	var $created			= null;
	var $publish_up			= null;
	var $publish_down		= null;
	var $title				= null;
	var $permalink			= null;
	var $content			= null;
	var $intro				= null;
	var $category_id		= null;
	var $published			= null;
	var $ordering			= null;
	var $vote				= null;
	var $hits				= null;
	var $private			= null;
	var $allowcomment		= null;
	var $subscription		= null;
	var $frontpage			= null;
	var $isnew				= null;
	var $ispending			= null;
	var $issitewide			= null;
	var $blogpassword		= null;
	var $latitude			= null;
	var $longitude			= null;
	var $address			= null;
	var $source				= null;
	var $robots				= null;
	var $copyrights			= null;

	/**
	 * Constructor for this class.
	 *
	 * @return
	 * @param object $db
	 */
	function __construct(& $db )
	{
		parent::__construct( '#__easyblog_post' , 'id' , $db );
	}

	function load( $key = null , $permalink = false )
	{
		if( !$permalink )
		{
			return parent::load( $key );
		}

		$db		= $this->getDBO();

		$query	= 'SELECT id FROM ' . $this->_tbl . ' '
				. 'WHERE permalink=' . $db->Quote( $key );
		$db->setQuery( $query );

		$id		= $db->loadResult();

		// Try replacing ':' to '-' since Joomla replaces it
		if( !$id )
		{
			$query	= 'SELECT id FROM ' . $this->_tbl . ' '
					. 'WHERE permalink=' . $db->Quote( JString::str_ireplace( ':' , '-' , $key ) );
			$db->setQuery( $query );

			$id		= $db->loadResult();
		}
		return parent::load( $id );
	}

	function getSubscribers( $excludeEmails = array() )
	{
		$db = $this->_db;

		$excludeEmailsList  = '';

		if( !empty( $excludeEmails ) )
		{
			for( $i = 0; $i < count($excludeEmails); $i++ )
			{
				$excludeEmailsList  = ( empty( $excludeEmailsList ) ) ? $db->Quote( $excludeEmails[$i] ) : ', ' . $db->Quote( $excludeEmails[$i] );
			}
		}

		$query  = 'SELECT * FROM `#__easyblog_post_subscription` WHERE `post_id` = ' . $db->Quote($this->id);

		if( !empty( $excludeEmailsList ) )
		{
			$query  .= ' and `email` NOT IN (' . $excludeEmailsList . ')';
		}

		$db->setQuery($query);

		$result = $db->loadObjectList();
		return $result;
	}

	function getCategoryName()
	{
		if($this->category_id == 0)
		{
			return JText::_('UNCATEGORIZED');
		}

		static $loaded	= array();

		if( !isset( $loaded[ $this->category_id ] ) )
		{
			$db		= JFactory::getDBO();

			$query  = 'SELECT `title` FROM `#__easyblog_category` WHERE `id` = ' . $db->Quote($this->category_id);
			$db->setQuery($query);

			$loaded[ $this->category_id ]	= JText::_( $db->loadResult() );
		}
		return $loaded[ $this->category_id ];
	}

	/**
	 * Override functionality of JTable's hit method as we want to limit the hits based on the session.
	 *
	 **/
	public function hit($pk = null)
	{
		$ip			= JRequest::getVar( 'REMOTE_ADDR' , '' , 'SERVER' );

		if( !empty( $ip ) && !empty($this->id) )
		{
			$token		= md5( $ip . $this->id );

			$session	= JFactory::getSession();
			$exists		= $session->get( $token , false );

			if( $exists )
			{
				return true;
			}

			$my = JFactory::getUser();

			if($my->id > 0 && EasyBlogHelper::isAUPEnabled() )
			{
				$aupid = AlphaUserPointsHelper::getAnyUserReferreID( $my->id );
				AlphaUserPointsHelper::newpoints( 'plgaup_easyblog_read_blog', $aupid, '', JText::sprintf('COM_EASYBLOG_AUP_READ_BLOG', $this->title) );
			}
			$session->set( $token , 1 );
		}



		return parent::hit($pk);
	}

	/**
	 * Must only be bind when using POST data
	 **/
	function bind( $data , $post = false )
	{
		parent::bind( $data );

		if( $post )
		{
			$acl		= EasyBlogACLHelper::getRuleSet();
			$my			= JFactory::getUser();

			// Some properties needs to be overriden.
			$content	= JRequest::getVar('write_content_hidden', '', 'post', 'string', JREQUEST_ALLOWRAW );

			if($this->id == 0)
			{
				// this is to check if superadmin assign blog author during blog creation.
				if(empty($this->created_by))
				{
					$this->created_by	= $my->id;
				}
			}

			//remove unclean editor code.
			$pattern    = array('/<p><br _mce_bogus="1"><\/p>/i',
								'/<p><br mce_bogus="1"><\/p>/i',
								'/<br _mce_bogus="1">/i',
								'/<br mce_bogus="1">/i',
								'/<p><br><\/p>/i');
			$replace    = array('','','','','');
			$content    = preg_replace($pattern, $replace, $content);

			// Search for readmore tags using Joomla's mechanism
			$pattern = '#<hr\s+id=("|\')system-readmore("|\')\s*\/*>#i';
			$pos	= preg_match( $pattern, $content );

			if( $pos == 0 )
			{
				$this->intro	= $content;

				// @rule: Since someone might update this post, we need to clear out the content
				// if it doesn't contain anything.
				$this->content	= '';
			}
			else
			{
				list( $intro , $main ) = preg_split( $pattern , $content, 2 );

				$this->intro	= $intro;
				$this->content	= $main;
			}

			$publish_up		= '';
			$publish_down 	= '';
			$created_date   = '';

			$tzoffset       = EasyBlogDateHelper::getOffSet();
			if(!empty( $this->created ))
			{
				$date = JFactory::getDate( $this->created,  $tzoffset);
				$created_date   = $date->toMySQL();
			}

			if($this->publish_down == '0000-00-00 00:00:00')
			{
				$publish_down   = $this->publish_down;
			}
			else if(!empty( $this->publish_down ))
			{
				$date = JFactory::getDate( $this->publish_down, $tzoffset );
				$publish_down   = $date->toMySQL();
			}


			if(!empty( $this->publish_up ))
			{
				$date = JFactory::getDate($this->publish_up, $tzoffset);
				$publish_up   = $date->toMySQL();
			}

			//default joomla date obj
			$date		= JFactory::getDate();

			$this->created 		= !empty( $created_date ) ? $created_date : $date->toMySQL();
			$this->modified		= $date->toMySQL();
			$this->publish_up 	= (!empty( $publish_up)) ? $publish_up : $date->toMySQL();
			$this->publish_down	= (empty( $publish_down ) ) ? '0000-00-00 00:00:00' : $publish_down;
			$this->ispending 	= (empty($acl->rules->publish_entry)) ? 1 : 0;
			$this->title		= trim($this->title);
			$this->permalink	= trim($this->permalink);

		}

		return true;
	}

	/**
	 * Override delete routine from the parent as we need to run
	 * some custom routines in our deletion
	 */
	public function delete($pk = null)
	{
		// @rule: Delete relationships from jomsocial stream
		$this->removeStream();

		$status		= parent::delete($pk);

		JPluginHelper::importPlugin( 'easyblog' );
		$dispatcher = JDispatcher::getInstance();

		// Run some cleanup for our own plugins
		$dispatcher->trigger('onAfterEasyBlogDelete', array(&$this ));

		// Delete all relations
		$this->deleteBlogTags();
		$this->deleteMetas();
		$this->deleteComments();
		$this->deleteTeamContribution();



		// Delete group relations
		EasyBlogHelper::getHelper( 'Groups' )->deleteContribution( $this->id );

		return $status;
	}

	/**
	 * When executed, remove any 3rd party integration records.
	 */
	public function removeStream()
	{
		jimport( 'joomla.filesystem.file' );

		$config 	= EasyBlogHelper::getConfig();

		// @rule: Detect if jomsocial exists.
		$file 		= JPATH_ROOT . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_community' . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'core.php';

		if( JFile::exists( $file ) && $config->get( 'integrations_jomsocial_blog_new_activity' ) )
		{
			// @rule: Test if record exists first.
			$db 	= JFactory::getDBO();
			$query	= 'SELECT COUNT(1) FROM ' . $db->nameQuote( '#__community_activities' ) . ' '
					. 'WHERE ' . $db->nameQuote( 'app' ) . '=' . $db->Quote( 'com_easyblog' ) . ' '
					. 'AND ' . $db->nameQuote( 'cid' ) . '=' . $db->Quote( $this->id );
			
			$db->setQuery( $query );
			$exists	= $db->loadResult();

			if( $exists )
			{
				$query	= 'DELETE FROM ' . $db->nameQuote( '#__community_activities' ) . ' '
						. 'WHERE ' . $db->nameQuote( 'app' ) . '=' . $db->Quote( 'com_easyblog' ) . ' '
						. 'AND ' . $db->nameQuote( 'cid' ) . '=' . $db->Quote( $this->id );
				
				$db->setQuery( $query );
				$db->Query();
			}
		}
	}

	public function deleteTeamContribution()
	{
		$db 	= JFactory::getDBO();

		$query	= 'DELETE FROM ' . $db->nameQuote( '#__easyblog_team_post' ) . ' '
				. 'WHERE ' . $db->nameQuote( 'post_id' ) . '=' . $db->Quote( $this->id );

		$db->setQuery( $query );
		$db->Query();
		return true;
	}

	function deleteBlogTags()
	{
		$db = $this->_db;

		if($this->id == 0)
			return false;

		$query  = 'DELETE FROM `#__easyblog_post_tag` WHERE `post_id` = ' . $db->Quote($this->id);
		$db->setQuery($query);
		$db->query();

		return true;
	}

	function deleteMetas()
	{
		$db = $this->_db;

		if($this->id == 0)
			return false;

		$query  = 'DELETE FROM `#__easyblog_meta` WHERE `content_id` = ' . $db->Quote($this->id);
		$query  .= ' AND `type` = ' . $db->Quote('post');

		$db->setQuery($query);
		$db->query();

		return true;
	}

	function deleteComments()
	{
		$db = $this->_db;

		if($this->id == 0)
			return false;

		$query  = 'DELETE FROM `#__easyblog_comment` WHERE `post_id` = ' . $db->Quote($this->id);

		$db->setQuery($query);
		$db->query();

		return true;
	}

	public function getBlogContribution()
	{
		$db		= JFactory::getDBO();

		$query	= 'SELECT * FROM ' . $db->nameQuote( '#__easyblog_external_groups' ) . ' '
				. 'WHERE ' . $db->nameQuote( 'post_id' ) . '=' . $db->Quote( $this->id );
		$db->setQuery( $query );

		$result	= $db->loadObject();

		if( !$result )
		{
			return false;
		}

		$table	= EasyBlogHelper::getTable( 'ExternalGroup' );
		$table->bind( $result );

		return $table;
	}

	/**
	 * Updates a blog contribution
	 */
	function updateBlogContribution( $blogContribution , $contributionSource = 'easyblog' )
	{
		// If there's no data passed in here, we shouldn't process anything
		if( empty( $blogContribution ) )
		{
			if($contributionSource == 'easyblog')
			{
				// Delete any existing contribution
				$this->deleteTeamContribution();
			}
			return false;
		}

		if( $contributionSource == 'easyblog' )
		{
			// Delete any existing contribution
			$this->deleteTeamContribution();

			if( !is_array( $blogContribution ) )
			{
				$blogContribution	= array( $blogContribution );
			}

			foreach($blogContribution as $bc)
			{
				$post   = array();
				$post['team_id'] = $bc;
				$post['post_id'] = $this->id;

				$teamBlogPost		= EasyBlogHelper::getTable( 'TeamBlogPost', 'Table' );
				$teamBlogPost->bind($post);

				// we supress the error here. its okay, it safe to suppress it here.
				@$teamBlogPost->store();
			}
		}
		else
		{
			// Other than team, there's other 3rd party integrations. We leave it to the helper to process this.
			EasyBlogHelper::getHelper( 'Groups' )->updateContribution( $this->id , $blogContribution , $contributionSource );
		}
		return true;
	}

	function getTeamContributed()
	{
		$db = $this->_db;

		$query  = 'SELECT a.`team_id` FROM `#__easyblog_team_post` AS a';
		$query  .= ' INNER JOIN `#__easyblog_team` AS b';
		$query  .= '   ON a.team_id = b.id';
		$query  .= ' WHERE a.`post_id` = ' . $db->Quote($this->id);

		$db->setQuery($query);
		$result = $db->loadResult();

		return $result;
	}

	/**
	 * Determines whether the current blog is accessible to
	 * the current browser.
	 *
	 * @param	JUser	$my		Optional user object.
	 * @return	boolean		True if accessible and false otherwise.
	 **/
	public function isAccessible()
	{
		$isAllowed = EasyBlogHelper::getHelper( 'Privacy' )->checkPrivacy( $this );

		if( $isAllowed )
		{
			//now we check the category id
			$catId  	= $this->category_id;
			$category   = EasyBlogHelper::getTable('ECategory', 'Table' );
			$category->load( $catId );

			if( $category->private != '0')
			{
				$isAllowed = $category->checkPrivacy();
			}
		}

		return $isAllowed;
	}

	/**
	 * Determines whether the current blog is featured or not.
	 *
	 * @return	boolean		True if featured false otherwise
	 **/
	public function isFeatured()
	{
		if( $this->id == 0 )
		{
			return false;
		}

		static $loaded	= array();

		if( !isset( $loaded[ $this->id ] ) )
		{
			$loaded[ $this->id ]	= EasyBlogHelper::isFeatured( 'post' , $this->id );
		}
		return $loaded[ $this->id ];
	}

	public function getMetaId()
	{
		$db = $this->_db;

		$query  = 'SELECT a.`id` FROM `#__easyblog_meta` AS a';
		$query  .= ' WHERE a.`content_id` = ' . $db->Quote($this->id);
		$query  .= ' AND a.`type` = ' . $db->Quote( 'post' );

		$db->setQuery($query);
		$result = $db->loadResult();

		return $result;
	}

	/*
	 * Process neccessary replacements here.
	 *
	 */
	public function store($updateNulls = false)
	{
		// Filter / strip contents that are not allowed
		$filterTags 		= EasyBlogHelper::getHelper( 'Acl' )->getFilterTags();
		$filterAttributes	= EasyBlogHelper::getHelper( 'Acl' )->getFilterAttributes();

		// @rule: Apply filtering on contents
		jimport('joomla.filter.filterinput');
		$inputFilter 	= JFilterInput::getInstance( $filterTags , $filterAttributes , 1 , 1 , 0 );
		$inputFilter->tagBlacklist		= $filterTags;
		$inputFilter->attrBlacklist		= $filterAttributes;

		$this->intro 		= $inputFilter->clean( $this->intro );
		$this->content 		= $inputFilter->clean( $this->content );

		// @rule: Test for the empty-ness
		if( empty( $this->intro ) && empty( $this->content ) )
		{
			JFactory::getLanguage()->load( 'com_easyblog' , JPATH_ROOT );
			$this->setError( JText::_( 'COM_EASYBLOG_DASHBOARD_SAVE_CONTENT_ERROR' ) );
		}

		// alway set this to false no matter what! TODO: remove this column.
		$this->ispending    = '0';

		return parent::store($updateNulls);
	}
}
