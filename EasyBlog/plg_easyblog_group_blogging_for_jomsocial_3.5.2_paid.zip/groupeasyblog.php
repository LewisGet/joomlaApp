<?php
/**
 * @package		plg_easyblog
 * @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 *
 * EasyBlog is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

class plgSystemGroupEasyBlog extends JPlugin
{
	function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);
	}

	public function onAfterRoute()
	{
		// If Easyblog does not exists, just skip this
		if( !$this->exists() )
		{
			return;
		}

		// Process ajax calls
		$this->ajax();

		// Process blog views for external plugins
		$this->view();

		// Process write views
		$this->write();

		// Configurable group component?
		$this->jomsocial();
	}

	public function onAfterDispatch()
	{
		// Process RSS calls
		$this->rss();
	}

	public function rss()
	{
		$option		= JRequest::getInt( 'com_easyblog' );
		$view 		= JRequest::getCmd( 'view' );
		$doc 		= JFactory::getDocument();
		$id			= JRequest::getInt( 'group' );

		if( $option == 'com_easyblog' && $view == 'latest' && $doc->getType() == 'feed' && $id )
		{
			JFactory::getLanguage()->load( 'plg_groupeasyblog' , JPATH_ROOT . DS . 'administrator' );

			// @task: Reset the items
			$doc->items 	= array();

			$blogs			= $this->getBlogs( $id , 'jomsocial' );

			JTable::addIncludePath( JPATH_ROOT . DS . 'components' . DS . 'com_community' . DS . 'tables' );
			$group		= JTable::getInstance( 'Group' , 'CTable' );
			$group->load( $id );

			// @task: Reset the document title
			$doc->setTitle( JText::sprintf( 'GROUP_EASYBLOG_RSS_TITLE' , $group->name ) );

			// @task: Reset the document description
			$doc->setDescription( JText::sprintf( 'GROUP_EASYBLOG_RSS_DESC' , $group->name ) );

			foreach( $blogs as $blog )
			{
				$user 		= JFactory::getUser( $blog->created_by );
				$profile	= EasyBlogHelper::getTable( 'Profile' );
				$profile->load( $user->id );

				$created 	= EasyBlogDateHelper::dateWithOffSet( $blog->created );
				$formatDate	= true;

				if(EasyBlogHelper::getJoomlaVersion() >= '1.6')
				{
				    $langCode   = EasyBlogStringHelper::getLangCode();
				    if($langCode != 'en-GB' || $langCode != 'en-US')
						$formatDate = false;
				}

				$blog->created		= $created->toMySQL();
			    $blog->text			= $blog->intro . $blog->content;

				$blog->text          = EasyBlogHelper::getHelper( 'Videos' )->strip( $blog->text );
				$blog->text			= EasyBlogGoogleAdsense::stripAdsenseCode( $blog->text );

				$category	= EasyBlogHelper::getTable( 'ECategory' );
				$category->load( $blog->category_id );

				// Assign to feed item
				$title	= EasyBlogHelper::getHelper( 'String' )->escape( $blog->title );
				$title	= html_entity_decode( $title );

				// load individual item creator class
				$item				= new JFeedItem();
				$item->title 		= $title;
				$item->link 		= EasyBlogRouter::_('index.php?option=com_easyblog&view=entry&id=' . $blog->id );
				$item->description 	= $blog->text;
				$item->date			= $blog->created;
				$item->category   	= $category->title;
				$item->author		= $profile->getName();
				$item->authorEmail	= $user->email;

				$doc->addItem( $item );
			}
		}
	}

	public function ajax()
	{
		$option		= JRequest::getInt( 'easyblog_external' , 0 );
		$limitstart	= JRequest::getInt( 'showmoreBlogs' , 0 );
		$id			= JRequest::getInt( 'id' );

		if($option == 1 && $limitstart > 0 )
		{
			require_once( EBLOG_HELPERS . DS . 'helper.php' );
			require_once( JPATH_ROOT . DS . 'components' . DS . 'com_community' . DS . 'libraries' . DS . 'core.php' );

			JFactory::getLanguage()->load( 'com_easyblog' , JPATH_ROOT );

			$blogs		= $this->getBlogs( $id , 'jomsocial' , $limitstart );


			$total		= $this->getBlogsCount( $id, 'jomsocial' );

			$theme		= new CodeThemes();
			$theme->set( 'id' , $id );
			$theme->set( 'ajax' , true );
			$theme->set( 'blogs' , $blogs );
			$theme->set( 'total' , $total );
			$theme->set( 'params', $this->params );
			$theme->set( 'limit' , $this->params->get( 'count') );
			$content	= $theme->fetch( 'group.jomsocial.php' );

			$obj			= new stdClass();
			$obj->html		= $content;
			$obj->limitstart= $limitstart + $this->params->get( 'count' );
			$obj->hasMore	= $obj->limitstart < $total;

			require_once( EBLOG_CLASSES . DS . 'json.php' );
			$json	= new Services_JSON();
			echo $json->encode( $obj );
			exit;
		}
	}

	/**
	 * Determines whether the current user is allowed to view the entry or not
	 *
	 */
	public function view()
	{
		$my		= JFactory::getUser();

		$option	= JRequest::getVar( 'option' );
		$view	= JRequest::getVar( 'view' );
		$id		= JRequest::getInt( 'id' );

		if( $option == 'com_easyblog' && $view == 'entry' && !empty( $id ) )
		{
			// TODO: Configurable component?
			$this->viewJomsocialBlog( $id );
		}
	}

	public function write()
	{
		$option	= JRequest::getVar( 'option' );
		$view	= JRequest::getVar( 'view' );
		$layout	= JRequest::getVar( 'layout' );
		$id		= JRequest::getInt( 'external' );

		if( $option == 'com_easyblog' && $view == 'dashboard' && !empty( $id ) && $layout == 'write' )
		{
			// TODO: Configurable component?
			$this->writeJomsocialBlog( $id );
		}
	}

	private function writeJomsocialBlog( $id )
	{
		// Checking for privacy here.
		// Include jomsocial's core?
		require_once( JPATH_ROOT . DS . 'components' . DS . 'com_community' . DS . 'libraries' . DS . 'core.php' );

		JTable::addIncludePath( JPATH_ROOT . DS . 'components' . DS . 'com_community' . DS . 'tables' );
		$group		= JTable::getInstance( 'Group' , 'CTable' );
		$group->load( $id );

		// The magic begins here.
		JRequest::setVar( 'groupid' , $group->id );
		JRequest::setVar( 'hideToolbar' , 1 );
		JRequest::setVar( 'showJomsocialToolbar' , 1 );
	}

	/**
	 * Perform necessary tests here to see if user is allowed
	 * to view the blog post.
	 */
	private function viewJomsocialBlog( $id )
	{
		require_once( EBLOG_HELPERS . DS . 'helper.php' );

		$db			= JFactory::getDBO();
		$query		= 'SELECT * FROM ' . $db->nameQuote( '#__easyblog_external_groups' ) . ' '
					. 'WHERE ' . $db->nameQuote( 'post_id' ) . ' = ' . $db->Quote( $id ) . ' '
					. 'AND ' . $db->nameQuote( 'source' ) . ' = ' . $db->Quote( 'jomsocial' );
		$db->setQuery( $query );

		$result		= $db->loadObject();

		// We don't want to process any further since this blog is not tied to any groups.
		if( !$result )
		{
			return;
		}

		// Checking for privacy here.
		// Include jomsocial's core?
		require_once( JPATH_ROOT . DS . 'components' . DS . 'com_community' . DS . 'libraries' . DS . 'core.php' );

		JTable::addIncludePath( JPATH_ROOT . DS . 'components' . DS . 'com_community' . DS . 'tables' );

		$group		= JTable::getInstance( 'Group' , 'CTable' );
		$group->load( $result->group_id );

		// The magic begins here.
		JRequest::setVar( 'groupid' , $group->id );
		JRequest::setVar( 'hideToolbar' , 1 );
		JRequest::setVar( 'showJomsocialToolbar' , 1 );

		$my			= JFactory::getUser();
		if( $group->isPrivate() && !$group->isMember( $my->id ) )
		{
			// Redirect here.
			$app	= JFactory::getApplication();
			$app->redirect( CRoute::_( 'index.php?option=com_community&view=groups&task=viewgroup&groupid=' . $result->group_id , false ) , JText::_( 'You will need to be a member of the group first' ) , 'error' );
			$app->close();
		}

		// Otherwise, we continue with our normal operations.
		return;
	}

	/**
	 * Detects whether or not easyblog is installed on the site.
	 *
	 * @access	public
	 * @return	boolean
	 */
	public function exists()
	{
		static $exists	= null;

		if( is_null( $exists ) )
		{
			jimport( 'joomla.filesystem.file' );
			$constants	= JPATH_ROOT . DS . 'components' . DS . 'com_easyblog' . DS . 'constants.php';
			$exists		= true;
			if( !JFile::exists( $constants ) )
			{
				$exists	= false;
			}
			else
			{
				require_once( $constants );
			}
		}

		return $exists;
	}

	/**
	 * This is the group output for jomsocial
	 *
	 * @access	public
	 * @return	null
	 */
	private function addStyleSheet(  )
	{
		$doc	= JFactory::getDocument();

		if( $doc->getType() == 'html' )
		{
			$path	= EasyBlogHelper::getJoomlaVersion() >= '1.6' ? '/groupeasyblog/groupeasyblog/' : '/groupeasyblog/';
			$path	= rtrim( JURI::root() , '/' ) . '/plugins/system' . $path . 'styles.css';
			$doc->addStyleSheet( $path );
		}
	}

	/**
	 * This is the group output for jomsocial
	 *
	 * @access	public
	 * @return	null
	 */
	public function jomsocial()
	{
		$option	= JRequest::getVar( 'option' );
		$view	= JRequest::getVar( 'view' );
		$task	= JRequest::getVar( 'task' );
		$id		= JRequest::getInt( 'groupid' );

		if( $option == 'com_community' && $view == 'groups' && $task == 'viewgroup' )
		{
			// Include jomsocial's core?
			require_once( JPATH_ROOT . DS . 'components' . DS . 'com_community' . DS . 'libraries' . DS . 'core.php' );

			// Now work on our magic
			require_once( EBLOG_HELPERS . DS . 'helper.php' );

			// Add the stylesheets
			$this->addStyleSheet();

			// Load foundry into the headers.
			EasyBlogHelper::loadHeaders();

			JFactory::getLanguage()->load( 'com_easyblog' , JPATH_ROOT );
			JFactory::getLanguage()->load( 'plg_groupeasyblog' , JPATH_ROOT . DS . 'administrator' );

			$my			= JFactory::getUser();
			$group		= JTable::getInstance( 'Group' , 'CTable' );
			$group->load( $id );

			// According to the specifications in jomsocial, private groups doesn't show anything
			if( !$group->isMember( $my->id ) && $group->isPrivate() )
			{
				return;
			}

			$theme		= new CodeThemes();
			$theme->set( 'id' , $id );
			$theme->set( 'ajax' , false );
			$theme->set( 'tabs'		, self::isTabs() );
			$theme->set( 'blogs' , $this->getBlogs( $id , 'jomsocial' ) );
			$theme->set( 'total' , $this->getBlogsCount( $id, 'jomsocial' ) );
			$theme->set( 'params', $this->params );
			$theme->set( 'showRss' , $this->params->get( 'rss' , 1 ) );
			$theme->set( 'limit' , $this->params->get( 'count') );
			$content	= $theme->fetch( 'group.jomsocial.php' );

			// Add new blog post link in the group options
			$menu		= '';
			if( $group->isMember( $my->id ) )
			{
				$link		= EasyBlogRouter::_( 'index.php?option=com_easyblog&view=dashboard&layout=write&external=' . $id . '&return=' . base64_encode( JRequest::getURI() ) );
				$menu		= $this->encodeTemplate( '<li><a href="' . $link . '" class="group-add-blog">' . JText::_( 'GROUP_EASYBLOG_NEW_BLOG_POST' ) . '</a></li>');
			}

			$content	= $this->encodeTemplate( $content );

			if( !self::isTabs() )
			{
				$script		= '
				joms.plugins.groupEasyBlog = {
					initialize: function()
					{
						jomsQuery("#community-group-news").after( decodeURIComponent("' . $content . '") );
						jomsQuery("#community-group-action ul.group-menus").prepend( decodeURIComponent("' . $menu . '") );

						window.appendBlogs = function( content )
						{
							jomsQuery("ul.blog-items").append( content );
						}
					}
				};
				';
			}
			else
			{
				$script		= '
				var eblog_lightbox_title	= "1";

				joms.plugins.groupEasyBlog = {
					initialize: function()
					{
						jomsQuery( ".cTabsBar ul" ).append( "<li><a href=\"javascript:void(0);\">' . JText::_( 'GROUP_EASYBLOG_TAB_HEADER' ) . '</a></li>" );
						jomsQuery( "div.cTabsContentWrap" ).append( "<div class=\"cTabsContent\">" + decodeURIComponent("' . $content . '") + "</div>");

						jomsQuery("#community-group-action ul.group-menus").prepend( decodeURIComponent("' . $menu . '") );

						window.appendBlogs = function( content )
						{
							jomsQuery("ul.blog-items").append( content );
						}

					}
				};

				';
			}

			$document	= JFactory::getDocument();
			$document->addScriptDeclaration( $script );
		}
	}

	/**
	 * Retrieves the version of Jomsocial on the site.
	 */
	private function getJomsocialVersion()
	{
		$xml	= JPATH_ROOT . DS . 'administrator' . DS . 'components' . DS . 'com_community' . DS . 'community.xml';

		if( !JFile::exists( $xml ) )
		{
			return false;
		}

		$parser	= JFactory::getXMLParser( 'Simple' );
		$parser->loadString( JFile::read( $xml ) );

		$element	= $parser->document->getElementByPath( 'version' );
		$version	= $element->data();

		return $version;
	}

	/**
	 * Determines whether the groups are using tabs or not.
	 */
	private function isTabs()
	{
		$version	= self::getJomsocialVersion();

		if( stristr( $version , '2.2' ) !== false || stristr( $version , '2.0' ) !== false )
		{
			return false;
		}

		return true;
	}

	/**
	 * Simple way to count the total number of blogs for specific groups.
	 *
	 * @access	private
	 * @param	string $key			The unique id of the specific item.
	 * @param	string $source		The source of the component. E.g: Jomsocial,groupjive etc.
	 * @return	int
	 */
	private function getBlogsCount( $key , $source )
	{
		$db 	= JFactory::getDBO();
		$query	= 'SELECT COUNT(1) FROM ' . $db->nameQuote( '#__easyblog_external_groups' ) . ' AS a '
				. 'INNER JOIN ' . $db->nameQuote( '#__easyblog_post' ) . ' AS b '
				. 'ON a.' . $db->nameQuote( 'post_id' ) . ' = b.' . $db->nameQuote( 'id' ) . ' '
				. 'WHERE a.' . $db->nameQuote( 'source' ) . ' = ' . $db->Quote( $source ) . ' '
				. 'AND a.' . $db->nameQuote( 'group_id' ) . ' = ' . $db->Quote( $key ) . ' '
				. 'AND b.' . $db->nameQuote( 'published' ) . ' = ' . $db->Quote( POST_ID_PUBLISHED );
		$db->setQuery( $query );
		$total	= $db->loadResult();

		return $total;
	}

	/**
	 * Simple way to fetch blog posts for specific groups.
	 *
	 * @access	private
	 * @param	string $key			The unique id of the specific item.
	 * @param	string $source		The source of the component. E.g: Jomsocial,groupjive etc.
	 * @param	int	$limitstart		The current page that is being viewed on (Optional)
	 * @return	Array
	 */
	private function getBlogs( $key , $source , $limitstart = 0 )
	{
		$db 	= JFactory::getDBO();

		// @TODO: Configurable limit
		$limit	= $this->params->get( 'count', 5);

		$query	= 'SELECT b.* FROM ' . $db->nameQuote( '#__easyblog_external_groups' ) . ' AS a '
				. 'INNER JOIN ' . $db->nameQuote( '#__easyblog_post' ) . ' AS b '
				. 'ON a.' . $db->nameQuote( 'post_id' ) . ' = b.' . $db->nameQuote( 'id' ) . ' '
				. 'WHERE a.' . $db->nameQuote( 'source' ) . ' = ' . $db->Quote( $source ) . ' '
				. 'AND a.' . $db->nameQuote( 'group_id' ) . ' = ' . $db->Quote( $key ) . ' '
				. 'AND b.' . $db->nameQuote( 'published' ) . ' = ' . $db->Quote( POST_ID_PUBLISHED ) . ' '
				. 'ORDER BY b.' . $db->nameQuote( 'created' ) . ' DESC '
				. 'LIMIT ' . $limitstart . ',' . $limit;

		$db->setQuery( $query );
		$blogs	= $db->loadObjectList();

		// Format the blogs with the proper category items.
		if( count( $blogs ) > 0 )
		{
			foreach( $blogs as $blog )
			{
				$category		= EasyBlogHelper::getTable( 'ECategory' );
				$category->load( $blog->category_id );

				// Custom properties
				$blog->category			= $category;

				$author					= EasyBlogHelper::getTable( 'Profile' );
				$author->load( $blog->created_by );
				$blog->blogger			= $author;

				EasyBlogHelper::truncateContent( $blog , true , true );
				
				$date					= EasyBlogDateHelper::dateWithOffSet( $blog->created );
	 			$blog->formattedDate	= ltrim( EasyBlogDateHelper::toFormat( $date , '%d' ) , 0 ) . ' ' . EasyBlogDateHelper::toFormat( $date , '%b' );
	 			$blog->systemDate		= EasyBlogDateHelper::toFormat( $date , $this->params->get( 'dateformat' , '%A, %d %B %Y' ) );
			}
		}

		return $blogs;
	}

	/**
	 * This is something similar like what encodeURIComponent does , just that
	 * it is a simple work around to embed html codes into the page without affecting anything else
	 *
	 * @access	private
	 * @param	string $contents The html content to be translated
	 * @return	string
	 */
	private function encodeTemplate( $contents )
	{
	    $revert = array('%21'=>'!', '%2A'=>'*', '%27'=>"'", '%28'=>'(', '%29'=>')');
	    return strtr(rawurlencode($contents), $revert);
	}
}
