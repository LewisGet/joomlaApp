<?php
/**
* @package		Eblog
* @copyright	Copyright (C) 2010 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Eblog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');

require_once( JPATH_ROOT . DS . 'components' . DS . 'com_easyblog' . DS . 'constants.php' );
require_once( JPATH_ROOT . DS . 'components' . DS . 'com_easyblog' . DS . 'helpers' . DS . 'helper.php' );

//JPlugin::loadLanguage( 'plg_search_easyblog' );


class plgSearchEasyblog extends JPlugin
{

	function plgSearchEasyblog( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	/** 1.6 **/
	function onContentSearchAreas()
	{
		JFactory::getLanguage()->load( 'com_easyblog' , JPATH_ROOT );

		$areas = array(
			'blogs' => JText::_( 'PLG_EASYBLOG_SEARCH_BLOGS' )
			);
			return $areas;
	}

	/** 1.5 **/
	function onSearchAreas()
	{
		JFactory::getLanguage()->load( 'com_easyblog' , JPATH_ROOT );

		$areas = array(
			'blogs' => JText::_( 'PLG_EASYBLOG_SEARCH_BLOGS' )
		);
		return $areas;
	}
	
	/** 1.6 **/
	function onContentSearch($text, $phrase='', $ordering='', $areas=null)
	{
		return $this->onSearch( $text, $phrase, $ordering, $areas );
	}
	
	/** 1.5 **/
	function onSearch( $text, $phrase='', $ordering='', $areas=null )
	{
	 	$plugin	= JPluginHelper::getPlugin('search', 'easyblog');
	 	$params	= new JParameter( $plugin->params );
	 	
		if( !plgSearchEasyblog::exists() )
		{
			return array();
		}
		
		if (is_array( $areas )) {
			if (!array_intersect( $areas, array_keys( plgSearchEasyblog::onContentSearchAreas() ) )) {
				return array();
			}
		}
		
		$text = trim( $text );
		if ($text == '') {
			return array();
		}

		$result	= plgSearchEasyblog::getResult( $text , $phrase );

		if( !$result )
			return array();

		require_once( EBLOG_HELPERS . DS . 'router.php' );
		
		foreach($result as $row)
		{
			$row->href		= 'index.php?option=com_easyblog';
			$row->section	= plgSearchEasyblog::getCategory( $row->category_id );
			$row->section	= JText::sprintf( 'PLG_EASYBLOG_SEARCH_BLOGS_SECTION', $row->section);
			$row->href		= EasyBlogRouter::getEntryRoute( $row->id );
		}
		
		return $result;
	}
	
	function exists()
	{
		$path	= JPATH_ROOT . DS . 'administrator' . DS . 'components' . DS . 'com_easyblog' . DS . 'easyblog.xml';

		jimport( 'joomla.filesystem.file' );
		return JFile::exists( $path );
	}
	
	function getCategory( $categoryId )
	{
		$db		= JFactory::getDBO();
		$query	= 'SELECT `title` FROM #__easyblog_category WHERE id=' . $db->Quote( $categoryId );
		$db->setQuery( $query );
		
		return $db->loadResult();
	}
	
	function getResult( $text , $phrase)
	{
		$config	= EasyBlogHelper::getConfig();
		$my     = JFactory::getUser();
		
		$db		= JFactory::getDBO();
		$where	= array();
		$where2	= array();
		
		// used for privacy
		$queryWhere             = '';
		$queryExclude			= '';
		$queryExcludePending    = '';
		$excludeCats			= array();

		switch ($phrase)
		{
			case 'exact':
				$where[]	= 'a.`title` LIKE ' . $db->Quote( '%'.$db->getEscaped( $text, true ).'%', false );
				$where[]	= 'a.`content` LIKE ' . $db->Quote( '%'.$db->getEscaped( $text, true ).'%', false );
				$where[]	= 'a.`intro` LIKE ' . $db->Quote( '%'.$db->getEscaped( $text, true ).'%', false );
				
				$where2		= '( t.title LIKE ' . $db->Quote( '%'.$db->getEscaped( $text, true ).'%', false ) . ')';
				$where 		= '(' . implode( ') OR (', $where ) . ')';
				break;
			case 'all':
			case 'any':
			default:
				$words		= explode( ' ', $text );
				$wheres		= array();
				$where2		= array();
				$wheres2	= array();
				
				foreach ($words as $word)
				{
					$word		= $db->Quote( '%'.$db->getEscaped( $word, true ).'%', false );
					
					$where[]	= 'a.`title` LIKE ' . $word;
					$where[]	= 'a.`content` LIKE ' . $word;
					$where[]	= 'a.`intro` LIKE ' . $word;
					
					$where2[]	= 't.title LIKE ' . $word;
					
					$wheres[] 	= implode( ' OR ', $where );
					$wheres2[]	= implode( ' OR ' , $where2	);
				}
				$where = '(' . implode( ($phrase == 'all' ? ') AND (' : ') OR ('), $wheres ) . ')';
				$where2	= '(' . implode( ($phrase == 'all' ? ') AND (' : ') OR ('), $wheres2 ) . ')';
				break;
		}
		
		
	    //get teamblogs id.
	    $teamBlogIds    = '';
	    $query  		= '';
	    if( $config->get( 'main_includeteamblogpost' ) )
	    {
			$teamBlogIds	= EasyBlogHelper::getViewableTeamIds();
			if( count( $teamBlogIds ) > 0 )
            	$teamBlogIds    = implode( ',' , $teamBlogIds);
	    }
	    
		// get all private categories id
		$excludeCats	= EasyBlogHelper::getPrivateCategories();
		
		if(! empty($excludeCats))
		{
		    $queryWhere .= ' AND a.`category_id` NOT IN (' . implode(',', $excludeCats) . ')';
		}
		
	    if( $config->get( 'main_includeteamblogpost' ) && !empty($teamBlogIds))
	    {
			$queryWhere	.= ' AND (u.team_id IN ('.$teamBlogIds.') OR a.`issitewide` = ' . $db->Quote('1') . ')';
		}
		else
		{
		    $queryWhere	.= ' AND a.`issitewide` = ' . $db->Quote('1');
		}
	    
	    
		$query	= 'SELECT a.*, CONCAT(a.`content` , a.`intro`) AS text , "2" as browsernav';
		$query	.= ' FROM `#__easyblog_post` as a ';
		
		if( $config->get( 'main_includeteamblogpost' ) )
		{
		    $query  .= ' LEFT JOIN `#__easyblog_team_post` AS u ON a.id = u.post_id';
		}
		
		$query	.= ' WHERE (' . $where;
		
		$query  .= ' AND a.`published` = ' . $db->Quote('1');
		$query	.= ' OR a.`id` IN( ';
		$query	.= '		SELECT tp.`post_id` FROM `#__easyblog_tag` AS t ';
		$query	.= '		INNER JOIN `#__easyblog_post_tag` AS tp ON tp.`tag_id` = t.`id` ';
		$query	.= '		WHERE ' . $where2;
		$query	.= '))';

				
		$my = JFactory::getUser();
		if($my->id == 0)
		{
		    //guest should only see public post.
		    $query    .= ' AND a.`private` = ' . $db->Quote('0');
		}

		//do not show unpublished post
		$query    .= ' AND a.`published` = ' . $db->Quote('1');
		
		$query  .= $queryWhere;

		$db->setQuery( $query );
		return $db->loadObjectList();
	}
}