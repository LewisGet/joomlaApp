window.EasyBlog = abstractComponent();
