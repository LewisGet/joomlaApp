<?php
/**
 * @package		MooFAQ
 * @copyright	Copyright (C) 2006 - 2011 iDealExtensions.com, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * Editor Article buton
 *
 * @package Editors-xtd
 * @since 1.5
 */
class plgButtonMoofaq extends JPlugin
{
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$lang	= JFactory::getLanguage();
		$lang->load("com_moofaq",JPATH_ADMINISTRATOR);
		$lang->load('plg_editors-xtd_moofaq',JPATH_ROOT.DS.'plugins/editors-xtd/moofaq');
	}


	/**
	 * Display the button
	 *
	 * @return array A four element array of (article_id, article_title, category_id, object)
	 */
	function onDisplay($name)
	{
		if( 
			(is_array($this->params->get('avoid_components')) 
				AND in_array(JRequest::getVar('option'),$this->params->get('avoid_components',array())))
			OR (!is_array($this->params->get('avoid_components')) 
				AND JRequest::getVar('option') == 'com_contactenhanced')
		){
			return '';
		}
		/*
		 * Javascript to insert the link
		 * View element calls jSelectArticle when an article is clicked
		 * jSelectArticle creates the link tag, sends it to the editor,
		 * and closes the select frame.
		 */
		$js = "
		function jSelectMooFAQ(tag) {
			jInsertEditorText(tag, '".$name."');
			SqueezeBox.close();
		}";

		$doc = JFactory::getDocument();
		$doc->addScriptDeclaration($js);
		$doc->addStyleDeclaration(
			'.button2-left .moofaq{'
				.'background:transparent url('
					.JURI::root().'administrator/components/com_moofaq/assets/images/j_button2_blank.png) no-repeat scroll 100% 0 }'
			.'.button2-left .moofaq a{'
				.'background:transparent url('
					.JURI::root().'administrator/components/com_moofaq/assets/images/icon-16.png) no-repeat scroll 94% 50%}'
					
			);

		JHTML::_('behavior.modal');

		/*
		 * Use the built-in element view to select the article.
		 * Currently uses blank class.
		 */
		$link = 'index.php?option=com_moofaq&amp;view=config&amp;layout=modal&amp;tmpl=component';

		$button = new JObject();
		$button->set('modal', true);
		$button->set('link', $link);
		$button->set('text', JText::_('PLG_EDITORSXTD_MOOFAQ_BUTTON_ADD'));
		$button->set('name', 'moofaq');
		$button->set('options', "{handler: 'iframe', size: {x: 770, y: 400}}");

		return $button;
	}
}
