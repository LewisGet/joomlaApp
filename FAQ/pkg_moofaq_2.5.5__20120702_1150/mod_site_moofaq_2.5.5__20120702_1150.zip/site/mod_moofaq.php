<?php
/**
 * @package		ContactEnhanced
 * @author		Douglas Machado {@link http://ideal.fok.com.br}
 * @author		Created on 24-Feb-2011
 * @copyright	Copyright (C) 2006 - 2011 iDealExtensions.com, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

// Include the syndicate functions only once
require_once dirname(__FILE__).DS.'helper.php';

$lang = JFactory::getLanguage();
$lang->load('mod_moofaq',dirname(__FILE__));

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));
$faq = modMooFAQHelper::loadMooFAQ($params);

require JModuleHelper::getLayoutPath('mod_moofaq', $params->get('layout', 'default'));