<?php
/**
 * @package		ContactEnhanced
 * @author		Douglas Machado {@link http://ideal.fok.com.br}
 * @author		Created on 24-Feb-2011
 * @copyright	Copyright (C) 2006 - 2011 iDealExtensions.com, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

class modMooFAQHelper
{
	static function loadMooFAQ(&$params)
	{
		
		$config		=& JFactory::getConfig();
		$lang =& JFactory::getLanguage();
		$lang->load('com_moofaq');
		
		$view		= $params->get('view','search');
		$category	= $params->get('view-category-id');
		$categories	= $params->get('view-categories-id');
		if($category AND $view == 'category'){
			JRequest::setVar('moofaq_id', $category);
		}elseif($categories AND $view == 'categories'){
			JRequest::setVar('moofaq_id', $categories);
		}
		JRequest::setVar('moofaqModule', 1);
		//if($params->get('displayDesc') == 'override') $params->set('displayDesc', 1);
		JRequest::setVar('moofaq_displayTitle',	$params->get('displayDesc', 0) );
		JRequest::setVar('moofaq_displayDesc',	$params->get('displayDesc', 0) );
		JRequest::setVar('moofaq_title',		$params->get('displayDesc-override-title', null) );
		JRequest::setVar('moofaq_description',	$params->get('displayDesc-override-description', null) );
		JRequest::setVar('q',					$params->get('search', null) );
		JRequest::setVar('moofaq_searchphrase',	$params->get('searchphrase', null) );
		JRequest::setVar('moofaq_search_type',	$params->get('search_type', null) );

		$model = JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'models'.DS.$view.'.php';
		if(file_exists($model)){
			require_once($model);
			$modelClass	= 'MoofaqModel'.ucfirst($view);
			$model		= new $modelClass();
		}elseif($config->getValue('config.error_reporting') == 6143 OR $conf->getValue('config.debug')){
			return JText::_('Model does not exists');
		}
		
	//Get view
		$viewPath = JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'views'.DS.$view.DS.'view.html.php';
		if(file_exists($viewPath)){
			require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'view.php');
			require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'includes.php');
			require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'models'.DS.$view.'.php');
			require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'models'.DS.'articles.php');
			require_once($viewPath);
			$viewClass	= 'MoofaqView'.ucfirst($view);
			$view		= new $viewClass();
			
			return $view->display();
			
		}elseif($config->getValue('config.error_reporting') == 6143 OR $conf->getValue('config.debug')){
			return JText::sprintf('View %s does not exists', $view);
		}
	}
}
