<?php
/**
 * @package    ContactEnhanced
 * @author     Douglas Machado {@link http://ideal.fok.com.br}
 * @author     Created on 24-Feb-2011
 */

//-- No direct access
defined('_JEXEC') or die('Access Denied - Please do not try to fool me! ;-)');

echo $faq;