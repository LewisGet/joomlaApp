<?php
/**
 * @package    MooFAQ
 * @subpackage Install
 * @author     Douglas Machado {@link http://idealextensions.com}
 * @author     Created on 21-Jan-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

function com_install(){

	@ini_set('max_execution_time',0);
	$lang =& JFactory::getLanguage();
	$lang->load('com_moofaq',JPATH_SITE);
	$installClass = new com_moofaqInstallerScript();
	$installClass->install();
	
}

/**
 * Enter description here ...@todo class doccomment.
 *
 */
class com_moofaqInstallerScript
{
    public function install($parent)
    {
     
        
    }//function

    public function uninstall($parent)
    {
        echo '<p>'.JText::_('com_moofaq_CUSTOM_UNINSTALL_SCRIPT').'</p>';
    }//function

    public function update($parent)
    {
        echo '<p>'.JText::_('com_moofaq_CUSTOM_UPDATE_SCRIPT').'</p>';
    }//function

    public function preflight($type, $parent)
    {
        echo '<p>'.JText::sprintf('com_moofaq_CUSTOM_PREFLIGHT', $type).'</p>';
    }//function

    public function postflight($type, $parent)
    {
     	$db = JFactory::getDbo();
        $db->setQuery(
				'UPDATE #__extensions ' .
				' SET enabled = 1' .
				' WHERE element="moofaq"'
			);
    	if (!$db->query()) {
			throw new Exception($db->getErrorMsg());
		}
        /*
         * An example of setting a redirect to a new location after the install is completed
         * $parent->getParent()->set('redirect_url', 'http://www.example.com');
         */
    }//function
}//class

