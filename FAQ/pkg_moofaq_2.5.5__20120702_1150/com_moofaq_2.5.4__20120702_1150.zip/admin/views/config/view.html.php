<?php
/**
 * @package    MooFAQ
 * @subpackage Views
 * @author     Douglas Machado {@link http://idealextensions.com}
 * @author     Created on 21-Jan-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

//-- Import Joomla view library
jimport('joomla.application.component.view');
require_once (JPATH_COMPONENT.'/helpers/moofaq.php');
/**
 * MooFAQ List View.
 *
 * @package MooFAQ
 */
class MooFAQViewConfig extends JView
{
   

    /**
     * MooFAQ view display method.
     *
     * @param string $tpl The name of the template file to parse;
     *
     * @return void
     */
    public function display($tpl = null)
    {
		JHTML::_('behavior.mootools');
   		$component =& JComponentHelper::getComponent('com_moofaq');
   		//echo '<pre>'; print_r($component); exit;
		$menus	= &JApplication::getMenu('site', array());
		$items	= $menus->getItems('component_id', $component->id);
		if(count($items)){
			$lists		= array();
			$views		= array();
			//$views[] 	= JHTML::_('select.option', 'search',		JText::_('COM_MOOFAQ_SEARCH') );
			$views[] 	= JHTML::_('select.option', 'category',		JText::_('JCATEGORY') );
			$views[] 	= JHTML::_('select.option', 'categories',	JText::_('JCATEGORIES') );
			$lists['view']			= JHTML::_('select.genericlist',   $views, 'view', 'class="inputbox" size="1" ', 'value', 'text', 'search');
					
			$types	= array();
			$types[] 	= JHTML::_('select.option', 'any',		JText::_('COM_MOOFAQ_SEARCH_TYPE_OPT_ANY') );
			$types[] 	= JHTML::_('select.option', 'keywords',	JText::_('COM_MOOFAQ_SEARCH_TYPE_OPT_KEYWORDS') );
			$lists['search_type']	= JHTML::_('select.genericlist',   $types, 'search_type', 'class="inputbox" size="1" ', 'value', 'text', 'any');
			
			$types	= array();
			$types[] 	= JHTML::_('select.option', 'any',		JText::_('COM_MOOFAQ_SEARCH_PHRASE_OPT_ANY') );
			$types[] 	= JHTML::_('select.option', 'all',		JText::_('COM_MOOFAQ_SEARCH_PHRASE_OPT_ALL') );
			$lists['searchphrase']	= JHTML::_('select.genericlist',   $types, 'searchphrase', 'class="inputbox" size="1" ', 'value', 'text', 'all');
			
			
			$arr = array(
				JHTML::_('select.option',  '0', JText::_( 'JNO' ) ),
				JHTML::_('select.option',  '1', JText::_( 'JYES' ) )
			);
			$lists['showtitle']		= JHTML::_('select.genericlist',	$arr,	'showtitle', 'class="inputbox" size="1" ', 'value', 'text', 0);	
			
			$arr = array(
				JHTML::_('select.option',  '0', JText::_( 'JNO' ) ),
				JHTML::_('select.option',  '1', JText::_( 'JYES' ) )
			);
			$lists['showdesc']		= JHTML::_('select.genericlist',	$arr,	'showdesc', 'class="inputbox" size="1" ', 'value', 'text', 0);	
			
			$this->assignRef('lists',	$lists);
			
			parent::display($tpl);
		}else{
			echo JText::_('COM_MOOFAQ_ERROR_NO_MENUITEM_FOUND');
		}
    }//function

    
}//class
