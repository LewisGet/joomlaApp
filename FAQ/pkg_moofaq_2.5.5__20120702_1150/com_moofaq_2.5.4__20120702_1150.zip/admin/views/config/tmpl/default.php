<?php
/**
 * @package    MooFAQ
 * @subpackage Views
 * @author     Douglas Machado {@link http://idealextensions.com}
 * @author     Created on 21-Jan-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');
	$document =& JFactory::getDocument();
		$document->setTitle(JText::_('Add FAQ'));
		
		JRequest::setVar('tmpl', 'component');
		
		
$js = "
function addMooFAQ()
	{
		var tag = '';
		var faqView		= $('view').getProperty('value');
		var search		= $('search').getProperty('value');
		var showtitle	= $('showtitle' ).getProperty('value');
		var title		= $('title' ).getProperty('value');
		var showdesc	= $('showdesc' ).getProperty('value');
		var description	= $('description').getProperty('value');
		var category	= $('category').getProperty('value');
		var categories	= $('categories').getProperty('value');
		var search_type	= $('search_type').getProperty('value');
		var searchphrase= $('searchphrase').getProperty('value');
		if(faqView == 'category'){
			tag = ' view=|'+faqView+'| id=|'+category+'| ';
		}else if(faqView == 'categories'){
			tag = ' view=|'+faqView+'| id=|'+categories+'| ';
		}else{
			tag = ' view=|'+faqView+'| ';
		}
		if(search){ 
			tag += ' search=|'+search+'| ';
			if(search_type){ tag += ' search_type=|'+search_type+'| ';}
			if(searchphrase){ tag += ' searchphrase=|'+searchphrase+'| ';}
		}
		if(title && showtitle == 1){ tag += ' title=|'+title+'| ';}else{ tag += ' showtitle=|'+showtitle+'| ';}
		if(description && showdesc == 1){ tag += ' description=|'+description+'| ';}else{ tag += ' showdesc=|'+showdesc+'| ';}
		
		tag = '{moofaq '+tag+' }';
	
		window.parent.jSelectMooFAQ(tag);
		return false;
	}
	
window.addEvent('domready', function(){
	var catSlide	= $('category-container');
	var secSlide	= $('categories-container');
	
	//catSlide.setStyle('display','none');
	secSlide.setStyle('display','none');
	
	$('view').addEvent('change', function(e){
		e = new Event(e);
		catSlide.setStyle('display','none');
		secSlide.setStyle('display','none');
		if($('view').getProperty('value') == 'category'){
			catSlide.setStyle('display','');
		}else if($('view').getProperty('value') == 'categories'){
			secSlide.setStyle('display','');
		}	
		e.stop();
	});
	
	var titleSlide	= $('title-container');
	titleSlide.setStyle('display','none');
	$('showtitle').addEvent('change', function(e){
		e = new Event(e);
		titleSlide.setStyle('display','none');
		if($('showtitle').getProperty('value') == '0'){
			titleSlide.setStyle('display','none');
		}else if($('showtitle').getProperty('value') == '1'){
			titleSlide.setStyle('display','');
		}	
		e.stop();
	});
	
	var descSlide	= $('description-container');
	descSlide.setStyle('display','none');
	$('showdesc').addEvent('change', function(e){
		e = new Event(e);
		descSlide.setStyle('display','none');
		if($('showdesc').getProperty('value') == '0'){
			descSlide.setStyle('display','none');
		}else if($('showdesc').getProperty('value') == '1'){
			descSlide.setStyle('display','');
		}	
		e.stop();
	});

});";
$document->addScriptDeclaration($js);
$document->addStyleDeclaration('
div label {display:block;float:left;margin:0 0 5px;padding:3px 5px;text-align:right;width:130px;}
div {clear:left;display:block;margin:5px 0 0;padding:1px 3px;width:354px;}
div input.inputText, form div input.inputPassword{margin:0;padding:1px 3px;width:200px;}
fieldset {border-color:#000000;border-style:solid none none;border-width:1px 0 0;clear:both;font-size:100%;margin:0;padding:10px;}
fieldset legend {background:url("components/com_moofaq/assets/images/icon-48.png") left top no-repeat;color:#000000;font-size:250%;font-weight:normal;margin:0;padding:0 0 0 55px;height:48px}
fieldset div.notes{background-color:#FFFFE1;border:1px solid #666666;color:#666666;float:right;font-size:88%;height:auto;margin:0 0 10px 10px;padding:5px;width:158px;}
fieldset div.notes h4{background:url("components/com_moofaq/assets/images/info-16.png") left top no-repeat;border-color:#666666;border-style:solid;border-width:0 0 1px;color:#666666;font-size:110%;padding:3px 0 3px 27px;}
fieldset div.notes p.last {margin:0;}
fieldset div.notes p{color:#666666;margin:0 0 1.2em;}
fieldset div.notes ul{padding:0 0 0 15px;}
div.submit{padding:0 0 0 136px;width:214px;}
div.submit div{display:inline;float:left;margin:0;padding:0;text-align:left;width:auto;}
div.submit div input.inputSubmit, form div.submit div input.inputButton,form div.submit div button.inputButton {float:right;margin:15px 0 0 5px;}
div textarea{width:50%;height:80px}
');	
?>


		<?php

?>
	<fieldset>
	<legend><?php echo JText::_('COM_MOOFAQ_ADD_FAQ_LABEL');?></legend>
		<div class="notes">
	        <h4><?php echo JText::_('COM_MOOFAQ_ADD_FAQ_NOTES');?></h4>
	        <p class="last"><?php echo JText::_('COM_MOOFAQ_ADD_FAQ_DESC');?></p>
       </div>
		<div>
			<label for="view"><?php echo JText::_( 'COM_MOOFAQ_ADD_FAQ_VIEW' ); ?></label>
			<?php echo $this->lists['view']; ?>
		</div>
		<div id="category-container">
			<label for="category""><?php echo JText::_( 'JCATEGORY' ); ?></label>
			<select name="category"  id="category" class="inputbox" >
				<!-- option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option  -->
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_content'), 'value', 'text','');?>
			</select>
		</div>
		<div id="categories-container">
			<label for="categories""><?php echo JText::_( 'JCATEGORIES' ); ?></label>
			<select name="categories" id="categories" class="inputbox">
				<!-- option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option  -->
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_content'), 'value', 'text', '');?>
			</select>
		</div>
		
		<div style="display:none">
			<label for="search"><?php echo JText::_( 'COM_MOOFAQ_SEARCH_TERM_LABEL' ); ?></label>
			<input type="text" id="search" name="search" />
		</div>
		<div style="display:none">
			<label for="search_type"><?php echo JText::_( 'COM_MOOFAQ_SEARCH_TYPE_LABEL' ); ?></label>
			<?php echo $this->lists['search_type']; ?>
		</div>
		<div style="display:none">
			<label for="searchphrase"><?php echo JText::_( 'COM_MOOFAQ_SEARCH_PHRASE_LABEL' ); ?></label>
			<?php echo $this->lists['searchphrase']; ?>
		</div>
		
		<div>
			<label for="showtitle"><?php echo JText::_( 'COM_MOOFAQ_SHOW_TITLE_LABEL' ); ?></label>
			<?php echo $this->lists['showtitle']; ?>
		</div>
		
		<div id="title-container">
			<label for="title"><?php echo JText::_( 'COM_MOOFAQ_OVERRIDE_TITLE_LABEL' ); ?></label>
			<input type="text" id="title" name="title" />
		</div>
		
		<div>
			<label for="showdesc"><?php echo JText::_( 'COM_MOOFAQ_SHOW_DESC_LABEL' ); ?></label>
			<?php echo $this->lists['showdesc']; ?>
		</div>
		<div id="description-container">
			<label for="description"><?php echo JText::_( 'COM_MOOFAQ_OVERRIDE_DESCRIPTION_LABEL' ); ?></label>
			<textarea id="description" name="description"></textarea>
		</div>
			
		<div class="submit">
			<div>
				<button class="inputButton button" onclick="return 	addMooFAQ();"><?php 
					echo JText::_( 'COM_MOOFAQ_ADD_FAQ_BUTTON' ); ?></button>
			</div>
		</div>

	</fieldset>
	<div class="clr"> </div>
