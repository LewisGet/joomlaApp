<?php
/**
 * @package    MooFAQ
 * @subpackage Base
 * @author     Douglas Machado {@link http://idealextensions.com}
 * @author     Created on 21-Jan-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

//-- Import joomla controller library
jimport('joomla.application.component.controller');

//-- Get an instance of the controller prefixed by MooFAQ
$controller = JController::getInstance('MooFAQ');

//-- Perform the Request task
$controller->execute(JRequest::getCmd('task'));

//-- Redirect if set by the controller
$controller->redirect();
