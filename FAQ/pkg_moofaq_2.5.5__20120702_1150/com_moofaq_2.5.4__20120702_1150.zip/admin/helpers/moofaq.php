<?php
/**
 * @version SVN: $Id: header.php 18 2010-11-08 01:10:19Z elkuku $
 * @package    MooFAQ
 * @subpackage Helpers
 * @author     Douglas Machado {@link http://idealextensions.com}
 * @author     Created on 21-Jan-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

/**
 * MooFAQ component helper.
 */
class MooFAQHelper
{
    /**
     * Configure the Linkbar.
     */
    public static function addSubmenu($submenu)
    {
        $document = JFactory::getDocument();
        $document->addStyleDeclaration('.icon-48-com_moofaq '
        .'{background-image: url(../media/com_moofaq/images/com_moofaq-48x48.png);}');

    }//function
    /**
     * Check is a menu item exists
     * @param string $option
     */
    public function menuItems($option='com_moofaq') {
    	$db			= & JFactory::getDBO();
		$query = 	'SELECT * FROM #__menu WHERE link LIKE '.$db->Quote('%'.$option.'%');
		$db->setQuery($query);
		return $db->loadObjectList();
    }
}//class
