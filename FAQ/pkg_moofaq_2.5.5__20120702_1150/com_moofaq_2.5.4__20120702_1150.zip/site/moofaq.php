<?php
/**
 * @package		MooFAQ
 * @copyright	Copyright (C) 2006 - 2011 Ideal Custm software development. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

// Make it ignore other formats
if(JRequest::getVar('format') != 'html'){
	JRequest::setVar('format','html');
}

$lang	= JFactory::getLanguage();
$lang->load('com_content');

// Include dependancies
jimport('joomla.application.component.controller');
require_once JPATH_COMPONENT.'/includes.php';


$controller = JController::getInstance('Moofaq');
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();
