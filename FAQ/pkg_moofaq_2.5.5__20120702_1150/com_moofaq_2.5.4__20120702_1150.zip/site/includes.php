<?php
/**
 * @package		MooFAQ
 * @copyright	Copyright (C) 2006 - 2011 Ideal Custm software development. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require the com_moofaq helper libraries
require_once(JPATH_ROOT.'/components/com_moofaq/controller.php');
require_once(JPATH_ROOT.'/components/com_moofaq/helpers/query.php');
require_once(JPATH_ROOT.'/components/com_moofaq/helpers/route.php');
require_once(JPATH_ROOT.'/components/com_moofaq/helpers/faq.php');
require_once(JPATH_ROOT.'/components/com_moofaq/helpers/slider.php');
require_once(JPATH_ROOT.'/components/com_moofaq/helpers/icon.php');
