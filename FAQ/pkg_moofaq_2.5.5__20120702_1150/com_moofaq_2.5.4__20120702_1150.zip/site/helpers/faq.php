<?php
/**
 * @package		MooFAQ
 * @copyright	Copyright (C) 2006 - 2011 Ideal Custm software development. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 */


// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * MooFAQ Component HTML Helper
 */
class moofaqHTMLHelper extends JObject
{
	var $id		= 0;
	
	var $pane	= null;
	
	var $access	= null;
	
	/**
	 * Category Object
	 * @var     Object
	 */
	var $category = null;
	
	/**
	 * Categories Array of Objects
	 * @var     Object
	 */
	var $categories = null;
	
	/**
	 * Parent Object
	 * @var     Object
	 */
	var $parent = null;
	
	/**
	 * FAQ type
	 * @var		String  Posssible values: category, categories, search
	 */
	var $view	= null;
	
	/**
	 * Parameters Object
	 * @var     Object
	 */
	var $params = null;
	
	var $paneParams = null;
	
	
	
	/**
	 * Creates a new instance of MooFAQ
	 */
	function __construct(&$params, $view)
	{
		
		// Initialize some variables
		$this->params	= &$params;
		
		$this->user		=& JFactory::getUser();
		
		$this->view		= $view;
		$class			= 'JHtml'.$params->get('sliderType','DIVSliders');
		$this->sliderObj= new $class(); 
		$this->addStyleSheets();
		$this->getPane();
		
	}//function
	
	function addStyleSheets(){
		//Include the CSS

		$doc =& JFactory::getDocument();
		$doc->addStyleSheet(JURI::root().'components/com_moofaq/templates/'.$this->params->get('template','basic').'/css/panel.css');
		
 		$lang =& JFactory::getLanguage();
		 if($lang->isRTL()){
			$doc->addStyleSheet(JURI::root().'components/com_moofaq/templates/'.$this->params->get('template','basic').'/css/panel_rtl.css');
		} else {
			$doc->addStyleSheet(JURI::root().'components/com_moofaq/templates/'.$this->params->get('template','basic').'/css/panel.css');
		}
	}
	
	/**
	 * Creates a new instance of the pane if it does not exists
	 */
	function getpane()
	{
		if(!$this->paneParams){
			$paneParams	= array();
			$paneParams['startOffset']			= $this->params->get('startOffset',null);
			$paneParams['startTransition']		= $this->params->get('startTransition',null);
			$paneParams['useCookie']			= $this->params->get('useCookie',true);
			$paneParams['opacityTransition']	= $this->params->get('opacityTransition',null);
			
			$paneParams['allowAllClose']		= true;
			
			$paneParams['autoscroll']			= $this->params->get('sliderType-LISliders-autoscroll',true);
			$paneParams['autohide']				= $this->params->get('sliderType-LISliders-autohide',false);
			$paneParams['slider_controls']		= $this->params->get('sliderType-LISliders-controls',true);
			$paneParams['duration']				= $this->params->get('sliderType-LISliders-duration',300);
			$paneParams['autoopen']				= $this->params->get('sliderType-LISliders-autoopen',0);
			
			$this->paneParams	= &$paneParams;	
		//	$this->pane = &JPane::getInstance($this->params->get('slider_type','DIVSliders'),$paneParams  );	
		}
		/*
		 * @todo: remove var pane 
		 */
		$this->pane='';
		return $this->pane;
	}//function
	
	function getTitle()
	{
		$html	= '';
		//echo '<pre>'; print_r($this); exit;
		if (JRequest::getVar('moofaq_displayTitle',1) == 1
			AND ( (isset($this->parent->title) AND $this->parent->title != 'ROOT') OR isset($this->category->title))
			AND ( 
				($this->params->get('show_base_title',1) AND  $this->view == 'categories')
				OR ($this->params->get('show_category_title',1) AND  $this->view == 'category')
			) // @todo implement this in the view xml file
		){
			$html	.= '<h2 class="moofaq-faqtitle contentheading'.$this->params->get('pageclass_sfx').'">';
				if($this->view == 'categories'){
					$html	.= $this->parent->title;
				}else{
					$html	.= $this->category->title;	
				}
			$html	.= '</h2>';	
		}
		return $html;
	}//function
	
	function getPageHading()
	{
		$html	= '';
		if ($this->params->get('show_page_heading') ){
			// added the title class in order to try to be compatible with RocketTheme templates
			$html	.= '<h1 class="title componentheading'.$this->params->get('pageclass_sfx').'">';
			// Add Span in order to add compatibility with some JoomlArt Templates
			$html	.= '<span>';
				$html	.= $this->params->get('page_heading',$this->params->get('page_title'));
			$html	.= '</span>';
			$html	.= '</h1>';	
		}
		return $html;
	}//function
	
	function getDescription($data=null)
	{
		$html	= '';
		$info	= $data;
		
		if(!JRequest::getVar('moofaq_displayDesc',1)){
			// Only allow to use JRequest::getVar('description') once, this way we wont have problems with the Categories view
			JRequest::setVar('moofaq_description',null);
			return '';
		}
		if(!$data AND $this->view == 'categories'){
			$info	= new stdClass();
			$info->description	= $this->parent->description;
		}elseif(!$data AND $this->view == 'category'){
			$info	= &$this->category;
			/*$info	= new stdClass();
			$info	= $this->category->description;
			echo moofaqHTMLHelper::print_r($this->category); exit; */
		}elseif(!$data){
			$info	= new stdClass();
			$info->description	= JRequest::getVar('moofaq_description', null);	
		}
		
		if ($this->params->get('show_base_description') 
				|| $this->params->get('show_description')  
				|| ( JRequest::getVar('moofaq_description') )  ){
			$html	.= '<div  class="category-desc" id="moofaq-description">';
				
				if(	$this->params->get('show_base_description') 
					AND $this->params->get('categories_description') 
					AND !defined('MOOFAQ_MAIN_CATEGORY')
					AND $this->view == 'categories'
					)
				{
					define('MOOFAQ_MAIN_CATEGORY',1);
					$html	.= JHtml::_('content.prepare',$this->params->get('categories_description'));
				}elseif (($this->params->get('show_description') && $info->description)){
					$html	.= JRequest::getVar('moofaq_description',$info->description, null, 'string', JREQUEST_ALLOWRAW);
					$html	.= '<br style="clear:both" />';
					// Only allow to use JRequest::getVar('description') once, this way we wont have problems with the Categories view
					JRequest::setVar('moofaq_description',null);
				}
			$html	.= '</div>';
		}
		return $html;
	}//function
	
	function getFaqPDF()
	{
		//disabled
		return '';
		
		$html	= '';
		if ($this->params->get('show_faq_pdf', 999) <= $this->user->get('aid', 0)){
			$html	.= '<div class="moofaq-faqpdf">';
				$html	.= JHTMLMooFAQ::_('icon.faqpdf',  $this->view, $this->id, $this->params);
			$html	.= '</div>';
		}
		return $html;
	}//function
	
	function getFaqPrint()
	{
		$html	= '';
		if ($this->params->get('show_faq_print', 1) AND $this->view != 'search'){
			$routeMethod	= 'get'.ucfirst($this->view).'Route';
				$html	.= '
					<ul class="actions moofaq-faqprint"><li>';
					$url	= MoofaqHelperRoute::$routeMethod($this->id, JRequest::getVar('catid'));
					$html	.= JHTML::_('moofaq.print_popup',  null,  $this->params, '',$url);
				$html	.= '</li></ul>';
		}
		return $html;
	}//function
	
	function getAnchors()
	{
		$html	= 	'';
		
		if ($this->params->get('show_anchor', 0) AND isset($this->categories)){
			$html	.=  '<ul class="moofaq-anchors">';
			foreach($this->categories[$this->parent->id] as $id => $category){
				if ( isset($category->numitems) AND ($category->numitems) > 0 ){
						$html	.=  '<li><a href="'.JRequest::getURI().'#moofaqCat-'.$category->id.'" >'.$category->title.'</a></li>';
					}
				}
				$html	.=  '</ul>';
		}
		return $html;
	}//function
	
	function render()
	{
		$html	= 	'
		<div class="item-page moofaq'.trim($this->params->get('pageclass_sfx',''))
						.(JRequest::getVar('tmpl') == 'component' ? ' moofaq-modal' : '').'">';
		$html	.=	$this->getPageHading();
		$html	.=	$this->getTitle();
		
		$access	= $this->user->authorisedLevels();
		// Check access level
		if(array_key_exists($this->params->get('access_level',0),$access)
			AND !$access[$this->params->get('access_level',0)]
		){
			$html	.= JText::_('COM_MOOFAQ_ACCESS_DENIED');
			return $html;
		}
		
		$html	.=	$this->getFaqPDF();
		$html	.=	$this->getFaqPrint();
		$html	.=	$this->getDescription();
		$html	.=	$this->getAnchors();
		
		if(isset($this->items) AND count($this->items) == 0){
			$html	.= '<div class="moofaq-no-result">'.JText::_('MOOFAQ_NO_RESULT_FOUND').'</div>';	
		}
		
		if(!defined('MOOFAQ_CONTROLS_LOADED') 
			AND $this->params->get('sliderType','DIVSliders') == 'LISliders' 
			AND $this->params->get('sliderType-LISliders-controls',true) 
			AND !JRequest::getVar('moofaqModule', false)
			AND !JRequest::getVar('print')
		){
			$html	.= '<br />';
			$html	.= $this->sliderObj->getControls();
			define('MOOFAQ_CONTROLS_LOADED',1);
		}elseif(!defined('MOOFAQ_CONTROLS_LOADED') AND $this->params->get('show_faq_print', 1)){
			$html	.= '<br />';
		}
		if(count($this->categories)>0){
			$html	.=	$this->getFaqCategories();
		}else{
			$questionCount	= JRequest::getInt('start',0)+1;
			if($this->category){
				$id	= $this->category->id;
			}else{
				$id	= 0;
			}
			$html	.=	$this->getFaqCategory($id,$questionCount);
		}
		$html		.=	$this->getLinks();
		$html		.=	$this->getFooter();
		
		$html		.= '</div>';
		 
		if(JRequest::getVar('moofaqPlugin', 0)){
			JRequest::setVar('moofaqPlugin', 0);
		}
		
		return $html;
	}//function
	
	function getFaqCategories()
	{
		$html	= '';
		$j		= 0;
		$questionCount = JRequest::getInt('start',0)+1;
		
//echo $this->print_r($this->parent); exit;
		//for ($j = 0; $j < count($this->categories[$this->parent->id]); $j++ ){
		foreach($this->categories[$this->parent->id] as $id => $category){
						//$category = &$item;
//echo $this->print_r($category); exit;
			if ( ($category->numitems) > 0 ){
				$html	.= '<a name="moofaqCat-'.$category->id.'" ></a>';
				$html	.= '<h2 class="componentheading'.$this->params->get('pageclass_sfx').' moofaq-category-title">'.$category->title.'</h2>';
				$this->items	= $category->articles;
				
				$html	.=	$this->getDescription($category);
				$html	.= $this->getFaqCategory($category->id,$questionCount,$j++);
			}
		}
		return $html;
	}//function
	
	function getFaqCategory($id,&$questionCount)
	{
		
		$html	= 	'';
		$html	.= '<div class="blog'.$this->params->get('pageclass_sfx').'">';
		
			$html	.= $this->sliderObj->start( "moofaq-pane-".$id, $this->paneParams);
				$i = JRequest::getInt('start',0);
				foreach ( $this->items as $article){
						
					$this->item =&$this->getItem($article,$i++);
					$faqtitle	= $this->item->title;
					if($this->params->get('add_line_numbers',0)){
						$faqtitle = ($questionCount++). ' - '. $this->item->title;
					}
					
					// Build the link and text of the title
					/*
					if ($this->params->get('link_titles',1))
					{
						
						// checks if the item is a public or registered/special item
						if ($this->item->access <= $this->user->get('aid', 0))
						{
							$faqtitle= JRoute::_(MoofaqHelperRoute::getArticleRoute($this->item->slug, $this->item->catslug));
						}
						else
						{
							$faqtitle = JRoute::_('index.php?option=com_user&view=login');
						}
						$faqtitle	= JHTML::_('link',$faqtitle, $this->item->title);
					}
					/**/
					$linkArticle	= JRoute::_(MoofaqHelperRoute::getArticleRoute($this->item->slug, $this->item->catslug));
					$html	.= $this->sliderObj->panel($faqtitle, 'article-id-'.$this->item->id, $linkArticle);
					
					$html	.= $this->loadItem();
				}
			$html	.= $this->sliderObj->end();
		$html	.= '</div><br />';
		
		return $html;
	}//function
	
	function &getItem($item, $index = 0)
	{
		$mainframe = &JFactory::getApplication();
//echo '<pre>'; print_r($item); exit;
		// Initialize some variables
		$user		=& JFactory::getUser();
		$dispatcher	=& JDispatcher::getInstance();
		$SiteName	= $mainframe->getCfg('sitename');


		// Get the page/component configuration and article parameters
		$item->params->merge($this->params);
		//echo moofaqHTMLHelper::print_r($item->params ); exit;
		if(isset($item->attribs)){
			$registry = new JRegistry;
			$registry->loadString($item->attribs);
			$aparams = $registry;
			// Merge article parameters into the page configuration
			$item->params->merge($aparams);
		}
		
		
		if($item->params->get('show_readmore') == 2){
			$item->text = $item->introtext.' '.$item->fulltext;
		}else{
			$item->text = $item->introtext;
		}
		
		
		if($item->params->get('enable_plugins')){
			// Process the content preparation plugins
			JPluginHelper::importPlugin('content');
			$results = $dispatcher->trigger('onContentPrepare', array ('com_content.article', &$item, &$item->params,0 ));
		}
		// Build the link and text of the readmore button
		if ($item->params->get('show_readmore') && $item->readmore){
						
			if ($item->params->get('access-view')){
				
				$item->readmore_link = JRoute::_(MoofaqHelperRoute::getArticleRoute($item->slug, $item->catid));
			}else{
				$menu = JFactory::getApplication()->getMenu();
				$active = $menu->getActive();
				$itemId = $active->id;
				$link1 = JRoute::_('index.php?option=com_users&view=login&Itemid=' . $itemId);
				//$returnURL = JRoute::_(MoofaqHelperRoute::getArticleRoute($this->item->slug));
				$item->readmore_link = new JURI($link1);
				$item->readmore_link->setVar('return', base64_encode(JURI::current()));
			}
		}
		
		$item->event = new stdClass();
		
		if($item->params->get('enable_plugins')){
			$item->event = new stdClass();
			$results = $dispatcher->trigger('onContentAfterTitle', array('com_content.article', &$item, &$item->params, 0));
			$item->event->afterDisplayTitle = trim(implode("\n", $results));
	
			$results = $dispatcher->trigger('onContentBeforeDisplay', array('com_content.article', &$item, &$item->params, 0));
			$item->event->beforeDisplayContent = trim(implode("\n", $results));
	
			$results = $dispatcher->trigger('onContentAfterDisplay', array('com_content.article', &$item, &$item->params, 0));
			$item->event->afterDisplayContent = trim(implode("\n", $results));
		}
		
		return $item;
	}
	
	function loadItem(){
		
		$canEdit	= ($this->user->authorize('com_content', 'edit', 'content', 'all') || $this->user->authorize('com_content', 'edit', 'content', 'own'));
		$html	= '';
		
		if ($this->item->state == 0){
			$html	.= '<div class="system-unpublished">';
		}
		
		if ($canEdit || $this->item->params->get('show_title') 
					|| $this->item->params->get('show_pdf_icon') 
					|| $this->item->params->get('show_print_icon') 
					|| $this->item->params->get('show_email_icon')
					|| $this->item->params->get('show_permalink_icon')
		){
			$html	.= '
					<ul class="actions">';
					if ($this->params->get('show_permalink_icon')){
						$html	.= '<li class="link-icon">'.JHTML::_('MooFAQ.permalink',  $this->item, $this->params).'</li>';
					}
					if ($this->params->get('show_pdf_icon')){
						$html	.= '<li class="pdf-icon">'.JHTML::_('MooFAQ.pdf',  $this->item, $this->params, $this->access).'</li>';
					}
					if ($this->params->get('show_print_icon')){
						$html	.= '<li class="print-icon">'.JHTML::_('MooFAQ.print_popup',  $this->item, $this->params, $this->access).'</li>';
					}
					if ($this->params->get('show_email_icon')){
						$html	.= '<li class="email-icon">'.JHTML::_('MooFAQ.email',  $this->item, $this->params, $this->access).'</li>';
					}
					if ($this->params->get('frontend_canedit',1) AND $canEdit){
						$html	.= '<li class="edit-icon">'.JHTML::_('MooFAQ.edit',  $this->item, $this->params, $this->access).'</li>';
					}
				$html	.= '</ul>
				';
		}

			
		if (!$this->item->params->get('show_intro') AND $this->item->params->get('enable_plugins')){
			$html	.= $this->item->event->afterDisplayTitle;
		}
		if($this->item->params->get('enable_plugins')){
			$html	.= $this->item->event->beforeDisplayContent; 
		}
		
		$html	.= '
				<div class="paneopen'.$this->item->params->get( 'pageclass_sfx' ).'">';
		
		$articleInfo = '';
			if ( ($this->item->params->get('show_category') && $this->item->catid)){
						
						if ($this->item->params->get('show_category') && $this->item->catid){
							$articleInfo	.= '<dd class="category-name">';
							$category_title	= $this->item->category_title;
							//echo CEHelper::print_r($this->item); exit;
							if ($this->item->params->get('link_category')){
								$category_title	= '<a href="'.JRoute::_(MoofaqHelperRoute::getCategoryRoute($this->item->catid)).'">'
											.  $category_title
											. '</a>';
							}
							$articleInfo	.= JText::sprintf('COM_MOOFAQ_CATEGORY', $category_title);
							$articleInfo	.= '</dd>
							';
						}
					
			} //end if
			
			
			if (($this->params->get('show_author', 0)) && ($this->item->author != "")){
				$articleInfo	.= '<dd class="createdby">';
				$author =  $this->item->author;
				$author = ($this->item->created_by_alias ? $this->item->created_by_alias : $author);

				if (!empty($this->item->contactid ) &&  $this->params->get('link_author') == true):
				 	$articleInfo	.= JText::sprintf('COM_MOOFAQ_WRITTEN_BY' , 
						JHTML::_('link',JRoute::_('index.php?option=com_contact&view=contact&id='.$this->item->contactid),$author));
				else :
					$articleInfo	.= JText::sprintf('COM_MOOFAQ_WRITTEN_BY', $author);
				endif;
				$articleInfo	.= '</dd>';
			}
			
			if ($this->params->get('show_create_date', 0 )){
				$articleInfo	.= '<dd class="created_date"><span>'.JHTML::_('date', $this->item->created, JText::_('DATE_FORMAT_LC2')).'</span></dd>';
			}
		
		if($articleInfo){
			$html	.= '<dl class="article-info">';
				$html	.= $articleInfo;
			$html	.= '</dl>
			';
		}
		
		if (isset ($this->item->toc)){
			$html	.= $this->item->toc;
		}
		
		$html	.= $this->item->text;
		
		if ($this->item->params->get('show_readmore') && $this->item->readmore){
			$html	.= '<p class="readmore">';
				$html	.= '<a href="'.$this->item->readmore_link.'">';
					if (!$this->item->params->get('access-view')){
						$html	.= JText::_('COM_MOOFAQ_REGISTER_TO_READ_MORE');
					}elseif ($readmore = $this->item->alternative_readmore){
						$html	.= $readmore;
						$html	.= JHTML::_('string.truncate', ($this->item->title), $this->item->params->get('readmore_limit'));
					}elseif ($this->item->params->get('show_readmore_title', 0) == 0){
						$html	.= JText::sprintf('COM_MOOFAQ_READ_MORE_TITLE');	
					}else{
						$html	.= JText::_('COM_MOOFAQ_READ_MORE');
						$html	.= JHTML::_('string.truncate', ($this->item->title), $this->item->params->get('readmore_limit'));
					}
				$html	.= '</a>';
			$html	.= '</p>';
			
		}
		$html	.= '</div>
		';
		if ($this->item->state == 0){
			$html	.= '</div>';
		}
		if($this->item->params->get('enable_plugins')){
			$html	.= $this->item->event->afterDisplayContent; 
		}
		
		
		//$html	.= '</table>';
		return $html;
	}///function
	
	/**
	 * print_r()
	 * Does a var_export of the array and returns it between <pre> tags
	 *
	 * @param mixed $var any input you can think of
	 * @return string HTML
	 */
	function print_r($var)
	{
	    $input =var_export($var,true);
	    $input = preg_replace("! => \n\W+ array \(!Uims", " => Array ( ", $input);
	    $input = preg_replace("!array \(\W+\),!Uims", "Array ( ),", $input);
	    return("<pre>".str_replace('><?', '>', highlight_string('<'.'?'.$input, true))."</pre>");
	} 
	
	public function getLinks() {
		if($this->params->get('show_links',JRequest::getVar('show_links'))){
			$html	= '<div class="moofaq-links">';
			$html	.= '	<ul>';
			    foreach(range('a', 'e') as $char) :// letters 'a' to 'e'
				    $link	= JRequest::getVar('link'.$char	,		$this->params->get('link'.$char));
				    $label	= JRequest::getVar('link'.$char.'_name',$this->params->get('link'.$char.'_name'));
	
				    if( ! $link) :
				        continue;
				    endif;
	
				    // Add 'http://' if not present
				    $link = (0 === strpos($link, 'http')) ? $link : 'http://'.$link;
	
				    // If no label is present, take the link
				    $label = ($label) ? $label : $link;
					$html	.= '<li class="moofaq-link-'.$char.'"  >';
						$html	.= '<a href="'.$link.'" '
							.($this->params->get('show_links') == '_blank' ? 'target="_blank"' : '').' >';
					    $html	.= $label; 
					$html	.= '</a></li>';
			endforeach;
			$html	.= '</ul>';
			$html	.= '</div>';
			return $html;
		}
	}
	
	public function getFooter() {
		if (JPluginHelper::isEnabled('system', 'irecommendlink')){
			return '<div class="moofaq-irecommend-link">{irecommend}</div>';
		}
	}
	
}//class
