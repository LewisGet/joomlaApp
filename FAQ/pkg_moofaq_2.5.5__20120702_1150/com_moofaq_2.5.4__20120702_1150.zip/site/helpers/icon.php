<?php
/**
 * @package		MooFAQ
 * @copyright	Copyright (C) 2006 - 2011 Ideal Custm software development. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

/**
 * Content Component HTML Helper
 *
 * @static
 * @package	com_moofaq
 * @since 1.5
 */
class JHTMLMooFAQ extends JHTML
{
	static function permalink($article,$params)
	{
		if(!isset($article->slug)){
			$article->slug	= $article->alias ? ($article->id.':'.$article->alias) : $article->id;
		}
		if(!isset($article->catslug)){
			$article->catslug		= $article->category_alias ? ($article->catid.':'.$article->category_alias) : $article->catid;
		}
		$url	= (MoofaqHelperRoute::getArticleRoute($article->slug, $article->catslug));
		
		if($params->get('show_permalink_icon') == 'sef'){
			$url	= JRoute::_($url);
		}else{
			$url	= JURI::root(true).'/'.$url;
		}
		
		if ($params->get('show_icons',1)) {
			
			$text	= '<img src="'.JURI::base(true).'/components/com_moofaq/images/permalink.png"
							title="'.JText::_('COM_MOOFAQ_ICON_PERMALINK_DESC').'" />';
		} else {
			$text = JText::_('COM_MOOFAQ_ICON_PERMALINK_LABEL').'&#160;';
		}

		$button =  JHTML::_('link',$url, $text);
		//echo $button; exit;
		$output = '<span class="hasTip" title="'.JText::_('COM_MOOFAQ_ICON_PERMALINK_DESC').'">'.$button.'</span>';
		return $output;
	}
	
	static function create($article, $params)
	{
		$uri = JFactory::getURI();

		$url = 'index.php?option=com_contact&task=article.add&return='.base64_encode($uri).'&a_id=0';

		if ($params->get('show_icons')) {
			$text = JHTML::_('image','system/new.png', JText::_('JNEW'), NULL, true);
		} else {
			$text = JText::_('JNEW').'&#160;';
		}

		$button =  JHTML::_('link',JRoute::_($url), $text);

		$output = '<span class="hasTip" title="'.JText::_('COM_MOOFAQ_CREATE_ARTICLE').'">'.$button.'</span>';
		return $output;
	}

	static function email($article, $params, $attribs = array())
	{
		$uri	= JURI::getInstance();
		$base	= $uri->toString(array('scheme', 'host', 'port'));
		$template = JFactory::getApplication()->getTemplate();
	
		if(!isset($article->slug)){
			$article->slug	= $article->alias ? ($article->id.':'.$article->alias) : $article->id;
		}
		$link	= $base.JRoute::_(MoofaqHelperRoute::getArticleRoute($article->slug, $article->catid) , false);
		$url	= 'index.php?option=com_mailto&tmpl=component&template='.$template.'&link='.base64_encode($link);

		$status = 'width=400,height=350,menubar=yes,resizable=yes';

		if ($params->get('show_icons')) {
			$text = JHTML::_('image','system/emailButton.png', JText::_('JGLOBAL_EMAIL'), NULL, true);
		} else {
			$text = '&#160;'.JText::_('JGLOBAL_EMAIL');
		}

		$attribs['title']	= JText::_('JGLOBAL_EMAIL');
		$attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";

		$output = JHTML::_('link',JRoute::_($url), $text, $attribs);
		return $output;
	}

	/**
	 * Display an edit icon for the article.
	 *
	 * This icon will not display in a popup window, nor if the article is trashed.
	 * Edit access checks must be performed in the calling code.
	 *
	 * @param	object	$article	The article in question.
	 * @param	object	$params		The article parameters
	 * @param	array	$attribs	Not used??
	 *
	 * @return	string	The HTML for the article edit icon.
	 * @since	1.6
	 */
	static function edit($article, $params, $attribs = array())
	{
		// Initialise variables.
		$user	= JFactory::getUser();
		$userId	= $user->get('id');
		$uri	= JFactory::getURI();

		// Ignore if in a popup window.
		if ($params && $params->get('popup')) {
			return;
		}

		// Ignore if the state is negative (trashed).
		if ($article->state < 0) {
			return;
		}

		JHtml::_('behavior.tooltip');

		$url	= 'index.php?task=article.edit&a_id='.$article->id.'&return='.base64_encode($uri);
		$icon	= $article->state ? 'edit.png' : 'edit_unpublished.png';
		$text	= JHTML::_('image','system/'.$icon, JText::_('JGLOBAL_EDIT'), NULL, true);

		if ($article->state == 0) {
			$overlib = JText::_('JUNPUBLISHED');
		}
		else {
			$overlib = JText::_('JPUBLISHED');
		}

		$date = JHTML::_('date',$article->created);
		$author = $article->created_by_alias ? $article->created_by_alias : $article->author;

		$overlib .= '&lt;br /&gt;';
		$overlib .= $date;
		$overlib .= '&lt;br /&gt;';
		$overlib .= JText::sprintf('COM_MOOFAQ_WRITTEN_BY', htmlspecialchars($author, ENT_COMPAT, 'UTF-8'));

		$button = JHTML::_('link',JRoute::_($url), $text);

		$output = '<span class="hasTip" title="'.JText::_('COM_MOOFAQ_EDIT_ITEM').' :: '.$overlib.'">'.$button.'</span>';

		return $output;
	}


	static function print_popup($article, $params, $attribs = array(), $url=null)
	{
		if(JRequest::getVar('print')){
			return self::print_screen($article, $params, $attribs, $url);
		}
		
		if (!isset($url)){
			if(!isset($article->slug)){
				$article->slug	= $article->alias ? ($article->id.':'.$article->alias) : $article->id;
			}
			$url  = MoofaqHelperRoute::getArticleRoute($article->slug, $article->catid);
		}
		$url .= '&tmpl=component&print=1&layout=default&page='.@ $request->limitstart;

		$status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';

		// checks template image directory for image, if non found default are loaded
		if ($params->get('show_icons')) {
			$text = JHTML::_('image','system/printButton.png', JText::_('JGLOBAL_PRINT'), NULL, true);
		} else {
			$text = JText::_('JGLOBAL_ICON_SEP') .'&#160;'. JText::_('JGLOBAL_PRINT') .'&#160;'. JText::_('JGLOBAL_ICON_SEP');
		}

		$attribs['title']	= JText::_('JGLOBAL_PRINT');
		$attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
		$attribs['rel']		= 'nofollow';

		return JHTML::_('link',JRoute::_($url), $text, $attribs);
	}

	static function print_screen($article, $params, $attribs = array())
	{
		// checks template image directory for image, if non found default are loaded
		if ($params->get('show_icons')) {
			$text = JHTML::_('image','system/printButton.png', JText::_('JGLOBAL_PRINT'), NULL, true);
		} else {
			$text = JText::_('JGLOBAL_ICON_SEP') .'&#160;'. JText::_('JGLOBAL_PRINT') .'&#160;'. JText::_('JGLOBAL_ICON_SEP');
		}
		if(!defined('MOOFAQ_PRINT_POP_UP_JS')){
			define('MOOFAQ_PRINT_POP_UP_JS',1);
			$doc	= JFactory::getDocument();
			$doc->addScriptDeclaration("window.addEvent('domready',function(){window.print();return false;});");
		}
		return '<a href="#" onclick="window.print();return false;">'.$text.'</a>';
	}
	
	

}