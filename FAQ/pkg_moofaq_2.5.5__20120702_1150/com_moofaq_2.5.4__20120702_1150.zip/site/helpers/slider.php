<?php
/**
 * @package		MooFAQ
 * @copyright	Copyright (C) 2006 - 2011 Ideal Custm software development. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 */


// no direct access
defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.mootools');
require_once (JPATH_ROOT.'/libraries/joomla/html/html/sliders.php');

class JHtmlLISliders extends JHtmlSliders
{
	protected static $opened = array();
	
	/**
	 * Creates a panes and loads the javascript behavior for it.
	 *
	 * @param	string	The pane identifier.
	 * @param	array	An array of options.
	 * @return	string
	 * @since	1.6
	 */
	public static function start($group = 'lisliders', $params = array())
	{
		self::_loadBehavior($group,$params);
		array_push(self::$opened,false);

		return '<div class="pane-container">'."\n\t".'<div id="'.$group.'" class="pane-sliders">'."\n";
	}
	
	/**
	 * Close the current pane.
	 *
	 * @return	string
	 * @since	1.6
	 */
	public static function end()
	{
		if (array_pop(self::$opened))
		{
			$close = "\n\t\t\t</div></div>\n\t\t</div>\n";
		}
		else
		{
			$close = '';
		}

		return $close."\n\t</div>\n</div>\n";
	}
	
	

	/**
	 * Begins the display of a new panel.
	 *
	 * @param	string	Text to display.
	 * @param	string	Identifier of the panel.
	 * @return	string
	 * @since	1.6
	 */
	public static function panel($text, $id,$link='javascript:void(0);')
	{
		if (self::$opened[count(self::$opened)-1])
		{
			$close = "\n\t\t\t</div></div>\n\t\t</div>\n";
		}
		else
		{
			self::$opened[count(self::$opened)-1] = true;
			$close = '';
		}

		$class	= '';
		if(JRequest::getVar('moofaqPlugin', 0)){
			$class	= 'moofaq-plugin-panel';
		}else{
			$class	= 'moofaq-component-panel';
		}
		
		return $close."\n\t\t".'<div class="panel '.$class.'">'."\n\t"
							.'<h3 class="pane-toggler moofaq-title title" id="'.$id.'">'."\n\t\t"
								.'<a name="faq-'.$id.'" href="'.$link.'"><span>'.$text.'</span></a></h3>'."\n\t\t\t"
								.'<div class="pane-slider content collapse">'."\n\t\t\t\t"
								.'<div class="collapse-container">'."\n\t\t\t\t\t"
								;
	}
	
	

	/**
	 * Load the JavaScript behavior.
	 *
	 * @param	string	The pane identifier.
	 * @param	array	Array of options.
	 * @return	void
	 * @since	1.6
	 */
	protected static function _loadBehavior($group, $params = array())
	{
		
		if(JRequest::getVar('print') == 1){
			return '';
		}
		static $loaded=array();
		if (!array_key_exists($group,$loaded))
		{
			$loaded[$group] = true;
			// Include mootools framework.
			JHtml::_('behavior.framework', true);

			$document	= JFactory::getDocument();
			$openSliders= (JRequest::getVar('open',$params['autoopen']));
			$open		= '';
			if ($openSliders) {
				
				$openSliders		= explode(',',$openSliders);
				foreach ($openSliders as $item){
					$item	= intval($item);
					$item--;
					$open	.="\n\t collapsibles[{$item}].toggle();";
				}
			}
			
			
			$js	= "
		if(typeof(jQuery) != 'undefined' && $===jQuery){
			jQuery.noConflict();
		}
var Slider"." = {
			slide: function(){
			
				var list			= $$('div.panel div.collapse');
				var headings		= $$('div.panel h3.moofaq-title');
				var collapsibles	= new Array();
				var	urlFragment		= window.location.hash.substring( 1 );
				var openArticleId	= null;
				headings.each( function(heading, i) {
					if(heading.get('id') == urlFragment){
						openArticleId	= i;
					}
					var collapsible = new Fx.Slide(list[i], { 
						duration: ".$params['duration'].", 
						transition: Fx.Transitions.linear"
						.($params['autoscroll'] ? ",
							onComplete: function(request){ 
								var open = request.getStyle('margin-top').toInt();
								if(open >= 0) new Fx.Scroll(window).toElement(headings[i]);
							}" : '')
						
					."});
					
					collapsibles[i] = collapsible;
					
					heading.onclick = function(){
						console.log(urlFragment);
						if(heading.hasClass('pane-toggler')){
							heading.addClass('pane-toggler-down');
							heading.removeClass('pane-toggler');
						}else{
							heading.addClass('pane-toggler');
							heading.removeClass('pane-toggler-down');
						}

						
						collapsible.toggle();
						".($params['autohide'] ? 
							"for(var j = 0; j < collapsibles.length; j++){
                        		if(j!=i){
                        			collapsibles[j].slideOut();
                        			headings[j].addClass('pane-toggler');
									headings[j].removeClass('pane-toggler-down');
                        		}
                			}" :"")."
						return false;
					}
					
					collapsible.hide();
					
				});
				".( ($params['slider_controls'] AND !JRequest::getVar('moofaqModule',0)) ? "
				$('collapse-all').onclick = function(){
					headings.each( function(heading, i) {
						collapsibles[i].hide();
							heading.removeClass('moofaq-toggler-down');
							heading.addClass('moofaq-toggler');
					});
					return false;
				}
				
				$('expand-all').onclick = function(){
					headings.each( function(heading, i) {
						collapsibles[i].show();
						".'var span = document.getElement'."('span', heading);
						if(span){
							span.removeClass('moofaq-toggler');
							span.addClass('moofaq-toggler-down');
						}
					});
					return false;
				}
				" : "")
				.$open."
				if(typeOf(openArticleId) == 'number' && (openArticleId >= 0)){
					collapsibles[openArticleId].toggle();
				}
			}			
		};
		window.addEvent('domready', Slider.slide);";
		
		$js = "/* <![CDATA[ */ \n".$js ." \n /* ]]> */";
		$document->addScriptDeclaration( $js );

		}
	}
	
	
	function getControls(){
		return '<div class="moofaqControls">
				<a title="'.JText::_('COM_MOOFAQ_EXPAND_ALL_DESC').'" href="'.JURI::current().'#expand" id="expand-all">'.JText::_('COM_MOOFAQ_EXPAND_ALL_LABEL').'</a> |
				<a title="'.JText::_('COM_MOOFAQ_COLLAPSE_ALL_DESC').'" href="'.JURI::current().'#collapse" id="collapse-all">'.JText::_('COM_MOOFAQ_COLLAPSE_ALL_LABEL').'</a>
			</div><br />';
	}

	function getCurrentURL(){
		$cururl = JRequest::getURI();
		if(($pos = strpos($cururl, "index.php"))!== false){
			$cururl = substr($cururl,$pos);
		}
		$cururl =  JRoute::_($cururl, true, 0);
		return $cururl;
	}
	protected static function _loadInnerJS($group, $params = array()){
		
	}
}

class JHtmlDIVSliders extends JHtmlSliders{
	
	function getControls(){
		return '';
	}
	
	static function _loadBehavior($params = array()){
		if(JRequest::getVar('print') == 1){
			return '';
		}
		parent::_loadBehavior($params);
	}
}

?>