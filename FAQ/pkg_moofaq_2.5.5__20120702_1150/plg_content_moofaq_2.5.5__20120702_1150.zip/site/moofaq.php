<?php
/**
 * @package    MooFAQ
 * @subpackage Base
 * @author     Douglas Machado {@link http://idealextensions.com}
 * @author     Created on 28-Mar-2011
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');

jimport('joomla.plugin.plugin');

/**
 * Example Content Plugin.
 *
 * @package    MooFAQ
 * @subpackage	Plugin
 */
class plgContentMooFAQ extends JPlugin
{
	/**
	 * Plugin that loads module positions within content
	 *
	 * @param	string	The context of the content being passed to the plugin.
	 * @param	object	The article object.  Note $article->text is also available
	 * @param	object	The article params
	 * @param	int		The 'page' number
	 */
	public function onContentPrepare($context, &$article, &$params, $page = 0)
    {
    	// simple performance check to determine whether bot should process further
    	if ( strpos( $article->text, 'moofaq' ) === false ) {
    		return true;
    	}
    	
    	
    	// Get plugin info
    	$plugin =& JPluginHelper::getPlugin('content', 'moofaq');

    	// define the regular expression for the bot
    	$regex = "#{moofaq(.*?)}#s";
    	
    	$registry		= new JRegistry();
		$registry->loadString($plugin->params);
		$pluginParams	= $registry;

    	// check whether plugin has been unpublished
    	if ( !$pluginParams->get( 'enabled', 1 ) ) {
    		$article->text = preg_replace( $regex, '', $row->text );
    		return true;
    	}
    	
    	
    	// find all instances of plugin and put in $matches
    	preg_match_all( $regex, $article->text, $matches );

    	// Number of plugins
     	$count = count( $matches[0] );

     	// plugin only processes if there are any instances of the plugin in the text
     	if ( $count ) {
    		// Get plugin parameters
    	 	$style	= $pluginParams->def( 'style', -2 );

     		$this->plgContentProcessMoofaq( $article, $matches, $count, $regex, $pluginParams );
    	}

		return;
	}//function
	
	function plgContentProcessMoofaq( &$row, &$matches, $count, $regex, &$botParams ){
		$config		=& JFactory::getConfig();
		
		$lang =& JFactory::getLanguage();
		$lang->load('com_moofaq');
		$lang->load('plg_content_moofaq',dirname(__FILE__));
		
		
		JRequest::setVar('article_id', (isset($row->id) ? $row->id : ''));
		for ( $i=0; $i < $count; $i++ ){
    	    if (@$matches[1][$i]) {
        		$inline_params = $matches[1][$i];
        		
        		JRequest::setVar('moofaqPlugin', 1);
        		
        		// get view
        		$view_matches = array();
        		preg_match( "#view=\|(.*?)\|#s", $inline_params, $view_matches );
        		if (isset($view_matches[1])){
        			$view = trim( strtolower($view_matches[1]) );
        		}else{
        			$view = 'search';
        		}
        		
				// get id
				$id_matches = array();
				preg_match( "#id=\|(.*?)\|#s", $inline_params, $id_matches );
				if (isset($id_matches[1])) 				JRequest::setVar('moofaq_id', trim($id_matches[1]));

        		// get title
        		$title_matches = array();
        		preg_match( "#title=\|(.*?)\|#s", $inline_params, $title_matches );
        		if (isset($title_matches[1]))			JRequest::setVar('moofaq_title', trim($title_matches[1]));
        		
        		// get showtitle
        		$title_matches = array();
        		preg_match( "#showtitle=\|(.*?)\|#s", $inline_params, $showtitle_matches );
        		if (isset($showtitle_matches[1]))		JRequest::setVar('moofaq_displayTitle', trim($showtitle_matches[1]));
        		        		
        		// get search
        		$search_matches = array();
        		preg_match( "#search=\|(.*?)\|#s", $inline_params, $search_matches );
        		if (isset($search_matches[1]))			JRequest::setVar('moofaq_search', trim($search_matches[1]));
        		
        		// get searchphrase
        		$searchphrase_matches = array();
        		preg_match( "#searchphrase=\|(.*?)\|#s", $inline_params, $searchphrase_matches );
        		if (isset($searchphrase_matches[1]))	JRequest::setVar('moofaq_searchphrase', trim($searchphrase_matches[1]));
				
        		// get search_type
        		$searchtype_matches = array();
        		preg_match( "#search_type=\|(.*?)\|#s", $inline_params, $searchtype_matches );
        		if (isset($searchtype_matches[1]))		JRequest::setVar('moofaq_search_type', trim($searchtype_matches[1]));
        		
        		// get text
        		$description_matches = array();
        		preg_match( "#description=\|(.*?)\|#s", $inline_params, $description_matches );
        		if (isset($description_matches[1]))		JRequest::setVar('moofaq_description', trim($description_matches[1]));
				
        		// get showdesc
        		$showdesc_matches = array();
        		preg_match( "#showdesc=\|(.*?)\|#s", $inline_params, $showdesc_matches );
        		if (isset($showdesc_matches[1]))		JRequest::setVar('moofaq_displayTitle', trim($showdesc_matches[1]));
				
        		// Get links
        		foreach(range('a', 'e') as $char){// letters 'a' to 'e'
        			$link_matches = array();
	        		preg_match( "#link{$char}=\|(.*?)\|#s", $inline_params, $link_matches );
	        		if (isset($link_matches[1])){
	        			$link	= explode('::', $link_matches[1]);
	        			JRequest::setVar('link'.$char,			$link[0]);
	        			JRequest::setVar('link'.$char.'_name',	$link[1]);
	        			JRequest::setVar('show_links',			1);
	        			
	        		}
        			
        		}
	  
        		
    	    //Get model
	    	    $model = JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'models'.DS.$view.'.php';
	        	if(file_exists($model)){
	        		require_once($model);
	        		$modelClass	= 'MoofaqModel'.ucfirst($view);
	        		$model		= new $modelClass();
	        	}elseif($config->getValue('config.error_reporting') == 6143 OR $config->getValue('config.debug')){
	        		$row->text = str_replace( $matches[0][$i], JText::_('Model does not exists'), $row->text );
	        		return '';
	        	}
	        	
    	    //Get view
	    	    $viewPath = JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'views'.DS.$view.DS.'view.html.php';
	        	if(file_exists($viewPath)){
	        		require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'view.php');
	        		require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'includes.php');
	        		require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'models'.DS.$view.'.php');
	        		require_once(JPATH_BASE.DS.'components'.DS.'com_moofaq'.DS.'models'.DS.'articles.php');
	        		require_once($viewPath);
	        		$viewClass	= 'MoofaqView'.ucfirst($view);
	        		$view		= new $viewClass();
	        		
	        		$row->text = str_replace( $matches[0][$i], $view->display(), $row->text );
	        		
	        	}elseif($config->getValue('config.error_reporting') == 6143 OR $config->getValue('config.debug')){
	        		$row->text = str_replace( $matches[0][$i], JText::sprintf('View %s does not exists', $view), $row->text );
	        		return '';
	        	}

        	}
        	
        	JRequest::setVar('moofaqPlugin', 0);
        	
		}
	}//function

    /**
     * Example after display title method
     *
     * Method is called by the view and the results are imploded and displayed in a placeholder
     *
     * @param 	object		The article object.  Note $article->text is also available
     * @param 	object		The article params
     * @param 	int			The 'page' number
     * @return	string
     */
    function onAfterDisplayTitle($article, &$params, $limitstart)
    {
        return '';
    }//function

    

    /**
     * Example after display content method
     *
     * Method is called by the view and the results are imploded and displayed in a placeholder
     *
     * @param 	object		The article object.  Note $article->text is also available
     * @param 	object		The article params
     * @param 	int			The 'page' number
     * @return	string
     */
    function onAfterDisplayContent(&$article, &$params, $limitstart)
    {
        return '';
    }//function

    /**
     * Example before save content method
     *
     * Method is called right before content is saved into the database.
     * Article object is passed by reference, so any changes will be saved!
     * NOTE:  Returning false will abort the save with an error.
     * 	You can set the error by calling $article->setError($message)
     *
     * @param 	object		A JTableContent object
     * @param 	boolean		If the content is just about to be created
     * @return	boolean		If false, abort the save
     */
    function onBeforeContentSave(&$article, $isNew)
    {
        return true;
    }//function

    /**
     * Example after save content method
     * Article is passed by reference, but after the save, so no changes will be saved.
     * Method is called right after the content is saved
     *
     *
     * @param 	object		A JTableContent object
     * @param 	boolean		If the content is just about to be created
     * @return	void
     */
    function onAfterContentSave(&$article, $isNew)
    {
        return true;
    }//function
}//class
